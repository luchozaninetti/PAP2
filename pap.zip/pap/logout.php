<?php
@session_start();

//se variáveis de sessão não existir 
if (!isset($_SESSION['autenticado'])) {
	header('Location: login.php');
	exit;
} else {
	session_destroy();

	echo "<p>Sessão terminada!</p>";
	echo "<a href= 'index.php'>Continuar</a>";
}
