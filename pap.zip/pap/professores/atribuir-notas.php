<?php
session_start();

if (!isset($_SESSION['autenticado']) || ($_SESSION['tipoutilizador'] != 1 && $_SESSION['tipoutilizador'] != 2)) {
    session_destroy();
    header('Location: login.php');
    exit;
}

require_once('../inc/Medoo.php');

$mensagem = ""; // Mensagem de erro ou sucesso

// Inserir ou atualizar nota
if (isset($_POST['aluno_id'], $_POST['ididioma'], $_POST['nota'])) {
    $aluno_id = intval($_POST['aluno_id']);
    $ididioma = intval($_POST['ididioma']);
    $nota = floatval($_POST['nota']);

    // Verificar se o aluno está inscrito nessa disciplina
    $inscrito = $basedados->has("matriculas", [
        "aluno_id" => $aluno_id,
        "ididioma" => $ididioma
    ]);

    if ($inscrito) {
        // Verificar se já existe nota
        $basedados->delete("notas", [
        "aluno_id" => $aluno_id,
        "ididioma" => $ididioma
         ]);
        $basedados->insert("notas", [
        "aluno_id" => $aluno_id,
        "ididioma" => $ididioma,
        "nota" => $nota
        ]);

        if ($existe) {
            // Atualizar nota existente
            $basedados->update("notas", [
                "nota" => $nota
            ], [
                "aluno_id" => $aluno_id,
                "ididioma" => $ididioma
            ]);
            $mensagem = "Nota atualizada com sucesso.";
        } else {
            // Inserir nova nota
            $basedados->insert("notas", [
                "aluno_id" => $aluno_id,
                "ididioma" => $ididioma,
                "nota" => $nota
            ]);
            $mensagem = "Nota atribuída com sucesso.";
        }
    } else {
        $mensagem = "⚠ O aluno não está inscrito nesta disciplina.";
    }
}

// Buscar alunos
$alunos = $basedados->select("tbutilizadores", ["id", "nome"], [
    "tipo" => 3,
    "ORDER" => ["nome" => "ASC"]
]);

// Buscar disciplinas (idiomas)
$idiomas = $basedados->select("idioma", ["id", "nome"], [
    "ORDER" => ["nome" => "ASC"]
]);

?>



<!doctype html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>Atribuir Notas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/estilos.css" rel="stylesheet">
</head>
<body>
<?php require_once('../inc/nav.php'); ?>

<main class="container-fluid">
    <?php require_once('../inc/banner.php'); ?>

     <section class="row mt-2 mb-2">
            <article class="col-12 text-center">
                <h1>Atribuir notas</h1>
            </article>
        </section>
        <section class="row">
            <div class="col-sm-12 col-lg-8 mx-auto">
                <table class="table table-bordered">
                    <thead class="table-light">
    <!-- Mensagem de erro ou sucesso -->
    <?php if (!empty($mensagem)): ?>
        <div class="alert alert-info"><?= htmlspecialchars($mensagem) ?></div>
    <?php endif; ?>

    <!-- Formulário para atribuição de notas -->
    <form method="post" class="row g-3">
        <div class="col-md-4">
            <label class="form-label">Aluno</label>
            <select name="aluno_id" class="form-select" required>
                <option value="">Selecione o aluno</option>
                <?php foreach ($alunos as $aluno): ?>
                    <option value="<?= $aluno['id'] ?>"><?= htmlspecialchars($aluno['nome']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label">Disciplina</label>
            <select name="ididioma" class="form-select" required>
                <option value="">Selecione a disciplina</option>
                <?php foreach ($idiomas as $idioma): ?>
                    <option value="<?= $idioma['id'] ?>"><?= htmlspecialchars($idioma['nome']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label">Nota</label>
            <input type="number" name="nota" class="form-control" step="0.01" min="0" max="20" required>
        </div>
             </table>
        <div class="col-12">
            <button type="submit" class="btn btn-primary">Atribuir Nota</button>
            <a href="/pap/Index.php" class="btn btn-secondary">Voltar ao Início</a>
           
        </div>
         </div>
        </section>
    </form>
             <?php require_once('../inc/rodape.php'); ?>
</main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
