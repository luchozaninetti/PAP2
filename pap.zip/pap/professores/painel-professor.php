<?php
// painel-professor.php
session_start();

if (!isset($_SESSION['autenticado']) || ($_SESSION['tipoutilizador'] != 1 && $_SESSION['tipoutilizador'] != 2)) {
    header('Location: ../login.php');
    exit;
}
?>
<!doctype html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>Painel do Professor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/estilos.css" rel="stylesheet">
</head>
<body>
<?php require_once('../inc/nav.php'); ?>

<main class="container py-4">
    <h1 class="text-center mb-4">Painel do Professor</h1>
    <div class="row g-4">
        <div class="col-md-4">
            <div class="card text-white bg-primary h-100">
                <div class="card-body text-center">
                    <h5 class="card-title">Gerir Turmas</h5>
                    <p class="card-text">Criar ou remover turmas.</p>
                    <a href="../professores/funcional.php" class="btn btn-light">Acessar</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-danger h-100">
                <div class="card-body text-center">
                    <h5 class="card-title">Atribuir Aluno</h5>
                    <p class="card-text">Matricular aluno em uma turma.</p>
                    <a href="../professores/atribuir-aluno-turma.php" class="btn btn-light">Acessar</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-success h-100">
                <div class="card-body text-center">
                    <h5 class="card-title">Atribuir Notas</h5>
                    <p class="card-text">Registrar notas dos alunos.</p>
                    <a href="../professores/atribuir-notas.php" class="btn btn-light">Acessar</a>
                </div>
            </div>
        </div>
    </div>
</main>

<?php require_once('../inc/rodape.php'); ?>
</body>
</html>
