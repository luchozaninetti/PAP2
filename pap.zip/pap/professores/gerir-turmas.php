<?php


session_start();

if (!isset($_SESSION['autenticado']) || ($_SESSION['tipoutilizador'] != 1 && $_SESSION['tipoutilizador'] != 2)) {
    session_destroy();
    header('Location: login.php');
    exit;
}


require_once('../inc/Medoo.php');


// Adicionar nova turma
if (isset($_POST['nova_turma'])) {
    $nome_turma = trim($_POST['nome_turma']);
    $ididioma = intval($_POST['ididioma']);

    if (!empty($nome_turma) && $ididioma > 0) {
        $basedados->insert("turmas", [
            "nome" => $nome_turma,
            "ididioma" => $ididioma
        ]);  
    }
    }


// Excluir turma
if (isset($_GET['eliminar']) && is_numeric($_GET['eliminar'])) {
    $id_turma = intval($_GET['eliminar']);
    $basedados->delete("turmas", ["id" => $id_turma]);
}

// Buscar turmas com o nome do idioma
$turmas = $basedados->query("
    SELECT turmas.id, turmas.nome AS turma_nome, idioma.nome AS idioma_nome
    FROM turmas
    JOIN idioma ON turmas.ididioma = idioma.id
    ORDER BY turmas.id ASC
")->fetchAll();

// Buscar todos os idiomas para o select
$idiomas = $basedados->select("idioma", ["id", "nome"], ["ORDER" => ["nome" => "ASC"]]);


?>
<!doctype html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>Gerir Turmas</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/estilos.css" rel="stylesheet">
</head>
<body>
    <?php require_once('../inc/nav.php'); ?>
     <?php require_once('../inc/banner.php'); ?>
    <main class="container-fluid">
        <section class="row mt-2 mb-2">
            <article class="col-12 text-center">
        <h1>Gerir Turmas</h1>
        </article>
        </section>

        <section class="row">
            <div class="col-sm-12 col-lg-8 mx-auto">
                <table class="table table-bordered">
                    <thead class="table-light">

        <!-- Formulário para adicionar nova turma -->
        <form method="post" class="row g-3 mb-4">
            <div class="col-md-4">
                <label class="form-label">Nome da Turma</label>
                <input type="text" name="nome_turma" class="form-control" placeholder="Ex: Turma A" required>
            </div>
            <div class="col-md-4">
            <label class="form-label">Disciplina</label>
            <select name="ididioma" class="form-select" required>
                <option value="">Selecione a disciplina</option>
                <?php foreach ($idiomas as $idioma): ?>
                    <option value="<?= $idioma['id'] ?>"><?= htmlspecialchars($idioma['nome']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

            <div class="col-md-4 d-flex align-items-end">
                <button type="submit" name="nova_turma" class="btn btn-primary w-100">Criar turma</button>
            </div>
        </form>

        <!-- Lista de turmas existentes -->
        <table class="table table-bordered">
             
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Nome da Turma</th>
                    <th>Idioma</th>
                    <th>Ações</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php foreach ($turmas as $turma): ?>
                    <tr>
                        <td><?= $turma['id'] ?></td>
                        <td><?= htmlspecialchars($turma['turma_nome']) ?></td>
                        <td><?= htmlspecialchars($turma['idioma_nome']) ?></td>
                        <td>
                            <a href="?eliminar=<?= $turma['id'] ?>" class="btn btn-danger btn-sm"
                               onclick="return confirm('Tem a certeza que deseja eliminar esta turma?')">Eliminar</a>
                        
                         
                            <a href="detalhes-turma.php?id=<?= $turma['id'] ?>" class="btn btn-info btn-sm">Ver Detalhes</a>

                               
                        </td>
                        
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
           </table>
        <a href="/pap/professores/painel-professor.php" class="btn btn-secondary mt-3">Voltar </a>
         </div>
        </section>

        <?php require_once('../inc/rodape.php'); ?>
    </main>
</body>
</html>