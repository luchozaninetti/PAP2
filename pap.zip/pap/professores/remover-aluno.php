<?php
require_once('../inc/Medoo.php');
session_start();

if (!isset($_SESSION['autenticado']) || ($_SESSION['tipoutilizador'] != 1 && $_SESSION['tipoutilizador'] != 2)) {
    session_destroy();
    header('Location: login.php');
    exit;
}


$aluno_id = intval($_GET['aluno_id']);
$turma_id = intval($_GET['turma_id']);

// Remove inscrição
$basedados->delete("matriculas", [
    "idutilizador" => $aluno_id,
    "idturma" => $turma_id
]);

header("Location: detalhes-turma.php?id=$turma_id");
exit;
