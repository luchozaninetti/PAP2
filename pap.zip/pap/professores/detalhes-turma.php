<?php
session_start();

if (!isset($_SESSION['autenticado']) || ($_SESSION['tipoutilizador'] != 1 && $_SESSION['tipoutilizador'] != 2)) {
    session_destroy();
    header('Location: login.php');
    exit;
}


require_once('../inc/Medoo.php');

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "ID da turma inválido.";
    exit;
}

$turma_id = intval($_GET['id']);

// Buscar nome da turma
$turma = $basedados->get("turmas", "nome", ["id" => $turma_id]);

// Buscar alunos inscritos na turma, com notas e idiomas
$stmt = $basedados->pdo->prepare("
    SELECT u.id AS aluno_id, u.nome AS aluno_nome, i.nome AS idioma_nome, n.nota
    FROM matriculas m
    INNER JOIN tbutilizadores u ON m.idutilizador = u.id
    LEFT JOIN notas n ON u.id = n.aluno_id
    LEFT JOIN idioma i ON n.ididioma = i.id
    WHERE m.idturma = ?
");
$stmt->execute([$turma_id]);
$alunos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!doctype html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>Detalhes da Turma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/estilos.css" rel="stylesheet">
</head>
<body>
    <?php require_once('../inc/nav.php'); ?>

    <main class="container-fluid">
     <?php require_once('../inc/banner.php'); ?>
      <section class="row mt-2 mb-2">
            <article class="col-12 text-center">
        <h1>Detalhes da Turma: <?= htmlspecialchars($turma) ?></h1>
        </article>
        </section>

        <section class="row">
            <div class="col-sm-12 col-lg-8 mx-auto">
                <table class="table table-bordered">
                    <thead class="table-light">
        <?php if (count($alunos) === 0): ?>
            <p class="text-muted">Nenhum aluno está matriculado nesta turma.</p>
            <a href="atribuir-aluno-turma.php" class="btn btn-primary mt-3">Matricular alunos</a>
        <?php else: ?>
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Aluno</th>
                        <th>Disciplina</th>
                        <th>Nota</th>
                        <th>Remover aluno</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($alunos as $aluno): ?>
                        <tr>
                            <td><?= htmlspecialchars($aluno['aluno_nome']) ?></td>
                            <td><?= htmlspecialchars($aluno['idioma_nome'] ?? '—') ?></td>
                            <td><?= is_null($aluno['nota']) ? '—' : number_format($aluno['nota'], 2) ?></td>
                            <td>
                                <a href="remover-aluno.php?aluno_id=<?= $aluno['aluno_id'] ?>&turma_id=<?= $turma_id ?>" 
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Tem certeza que deseja remover este aluno da turma?')">Remover</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
            </table>
        <a href="gerir-turmas.php" class="btn btn-secondary mt-3">Voltar</a>
           </div>
        </section>
         <?php require_once('../inc/rodape.php'); ?>
    </main>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
