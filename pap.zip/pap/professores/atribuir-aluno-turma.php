<?php
session_start();

if (!isset($_SESSION['autenticado']) || ($_SESSION['tipoutilizador'] != 1 && $_SESSION['tipoutilizador'] != 2)) {
    session_destroy();
    header('Location: login.php');
    exit;
}


require_once('../inc/Medoo.php');

$mensagem = '';
$tipoMensagem = ''; // successo, aviso, perigo, ou outro qualquer.

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aluno_id'], $_POST['turma_id'])) {
    $aluno_id = intval($_POST['aluno_id']);
    $turma_id = intval($_POST['turma_id']);

    // Verifica se já está matriculado
    $existe = $basedados->has("matriculas", [
        "idutilizador" => $aluno_id,
        "idturma" => $turma_id
    ]);

    if (!$existe) {
        $basedados->insert("matriculas", [
            "idutilizador" => $aluno_id,
            "idturma" => $turma_id
        ]);
        // Redirecionar com sucesso
        header("Location: atribuir-aluno-turma.php?status=sucesso");
        exit;
    } else {
        header("Location: atribuir-aluno-turma.php?status=existe");
        exit;
    }
}

// Mensagens de feedback
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'sucesso') {
        $mensagem = 'Aluno atribuído à turma com sucesso!';
        $tipoMensagem = 'success';
    } elseif ($_GET['status'] == 'existe') {
        $mensagem = 'Este aluno já está atribuído a esta turma.';
        $tipoMensagem = 'warning';
    }
}

// Buscar turmas
$turmas = $basedados->select("turmas", ["id", "nome"], [
    "ORDER" => ["nome" => "ASC"]
]);

// Buscar alunos (tp 3)
$alunos = $basedados->select("tbutilizadores", ["id", "nome"], [
    "tipo" => 3,
    "ORDER" => ["nome" => "ASC"]
]);
?>

<!doctype html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>Fisk</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
   <link href="../css/estilos.css" rel="stylesheet"> 
  <script src="../js/validacao.js"></script>
    <script src="../js/confirmacao.js"></script>
    <script src="../js/alertas.js"></script>

</head>
<body>
    <?php require_once('../inc/nav.php'); ?>

    <main class="container-fluid">

    <?php require_once('../inc/banner.php'); ?>

        <section class="row mt-2 mb-2">
            <article class="col-12 text-center">
                <h1>Atribuir aluno a turma</h1>
            </article>
        </section>
         <section class="row">
            <div class="col-sm-12 col-lg-8 mx-auto">
                <table class="table table-bordered">
                    <thead class="table-light">
        <?php if ($mensagem): ?>
            <div class="alert alert-<?= $tipoMensagem ?>" role="alert">
                <?= htmlspecialchars($mensagem) ?>
            </div>
        <?php endif; ?>

        <form method="post" class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Aluno</label>
                <select name="aluno_id" class="form-select" required>
                    <option value="">Selecione o aluno</option>
                    <?php foreach ($alunos as $aluno): ?>
                        <option value="<?= $aluno['id'] ?>"><?= htmlspecialchars($aluno['nome']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-6">
                <label class="form-label">Turma</label>
                <select name="turma_id" class="form-select" required>
                    <option value="">Selecione a turma</option>
                    <?php foreach ($turmas as $turma): ?>
                        <option value="<?= $turma['id'] ?>"><?= htmlspecialchars($turma['nome']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            </table>
            <div class="col-12">
                <button type="submit" class="btn btn-primary">Atribuir</button>
                <a href="/pap/professores/painel-professor.php" class="btn btn-secondary">Voltar</a>
                </section>
                 </div>
            </div>
        </form>
         <?php require_once('../inc/rodape.php'); ?>
    </main>
</body>
</html>
