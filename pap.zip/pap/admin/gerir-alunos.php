<?php
session_start();
if (!isset($_SESSION['autenticado']) || $_SESSION['tipoutilizador'] != 1) {
    header('Location: ../login.php');
    exit;
}

require_once('../inc/Medoo.php');

$mensagem = "";

// Remover aluno
if (isset($_GET['remover']) && is_numeric($_GET['remover'])) {
    $id = intval($_GET['remover']);
    $basedados->delete("matriculas", ["idutilizador" => $id]);
    $basedados->delete("notas", ["aluno_id" => $id]);
    $basedados->delete("tbutilizadores", ["id" => $id]);
    header("Location: gerir-alunos.php");
    exit;
}

// Criar novo aluno
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nome'], $_POST['email'], $_POST['senha'])) {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $senha = trim($_POST['senha']);

    if ($nome && $email && $senha) {
        $existe = $basedados->has("tbutilizadores", ["email" => $email]);

        if ($existe) {
            $mensagem = "<div class='alert alert-warning'>Já existe um aluno com esse email.</div>";
        } else {
           $hash = md5($senha); // Gera hash MD5 da senha
            $basedados->insert("tbutilizadores", [
             "nome" => $nome,
            "email" => $email,
            "password" => $hash,
            "tipo" => 3
            ]);

         
            $mensagem = "<div class='alert alert-success'>Aluno criado com sucesso.</div>";
        }
    } else {
        $mensagem = "<div class='alert alert-danger'>Preencha todos os campos corretamente.</div>";
    }
}

// Buscar alunos e seus idiomas
$alunos = $basedados->select("tbutilizadores", [
    "[>]matriculas" => ["id" => "idutilizador"],
    "[>]turmas" => ["matriculas.idturma" => "id"],
    "[>]idioma" => ["turmas.ididioma" => "id"]
], [
    "tbutilizadores.id",
    "tbutilizadores.nome",
    "tbutilizadores.email",
    "disciplinas" => Medoo\Medoo::raw("GROUP_CONCAT(DISTINCT idioma.nome SEPARATOR ', ')")
], [
    "tbutilizadores.tipo" => 3,
    "GROUP" => "tbutilizadores.id"
]);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gerir Alunos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/estilos.css" rel="stylesheet">
    <script src="../js/confirmacao.js"></script>
    <script src="../js/busca-ajax.js"></script>
</head>
<body>

<?php require_once('../inc/nav.php'); ?>

<main class="container-fluid">
    <?php require_once('../inc/banner.php'); ?>

    <section class="row mt-2 mb-2">
        <article class="col-12 text-center">
            <h1>Gerir Alunos</h1>
        </article>
    </section>

    <div class="col-sm-12 col-lg-8 mx-auto">
        <?= $mensagem ?>

        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Disciplinas</th>
                    <th>Remover</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($alunos as $aluno): ?>
                    <tr>
                        <td><?= htmlspecialchars($aluno['nome']) ?></td>
                        <td><?= htmlspecialchars($aluno['email']) ?></td>
                        <td><?= $aluno['disciplinas'] ?? '—' ?></td>
                        <td>
                            <a href="?remover=<?= $aluno['id'] ?>" class="btn btn-danger btn-sm"
                               onclick="return confirm('Deseja mesmo remover este aluno?')">Remover</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <hr>

        <h2 class="mt-4">Criar Novo Aluno</h2>
        <form method="post" class="mt-3">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome:</label>
                <input type="text" name="nome" id="nome" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email:</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="senha" class="form-label">Senha:</label>
                <input type="password" name="senha" id="senha" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Criar Aluno</button>
        </form>

        <a href="/pap/admin/painel-admin.php" class="btn btn-secondary mt-4">Voltar</a>
    </div>

    <?php require_once('../inc/rodape.php'); ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
