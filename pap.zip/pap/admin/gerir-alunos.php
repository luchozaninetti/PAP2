<?php
session_start();
if (!isset($_SESSION['autenticado']) || $_SESSION['tipoutilizador'] != 1) {
    header('Location: ../login.php');
    exit;
}

require_once('../inc/Medoo.php');

// Remover aluno
if (isset($_GET['remover']) && is_numeric($_GET['remover'])) {
    $id = intval($_GET['remover']);
    $basedados->delete("matriculas", ["idutilizador" => $id]);
    $basedados->delete("tbutilizadores", ["id" => $id]);
    header("Location: gerir-alunos.php");
    exit;
}

// Buscar alunos e seus idiomas
// Buscar alunos e seus idiomas
$alunos = $basedados->select("tbutilizadores", [
    "[>]matriculas" => ["id" => "idutilizador"],
    "[>]turmas" => ["matriculas.idturma" => "id"],
    "[>]idioma" => ["turmas.ididioma" => "id"]
], [
    "tbutilizadores.id",
    "tbutilizadores.nome",
    "tbutilizadores.email",
    "disciplinas" => Medoo\Medoo::raw("GROUP_CONCAT(DISTINCT idioma.nome SEPARATOR ', ')")
], [
    "tbutilizadores.tipo" => 3,
    "GROUP" => "tbutilizadores.id"
]);

?>

<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fisk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/estilos.css" rel="stylesheet">
    
    <script src="../js/confirmacao.js"></script>
    <script src="../js/busca-ajax.js"></script>
</head>

<body>

    <!-- menu de navegação -->
    <?php require_once('../inc/nav.php'); ?>

    <main class="container-fluid">
        <!-- banner -->
        <?php require_once('../inc/banner.php'); ?>

        <!-- título da página -->
        <section class="row mt-2 mb-2">
            <article class="col-12 text-center">
                <h1>Gerir Alunos</h1>
            </article>
        </section>

        <section class="row">
            <div class="col-sm-12 col-lg-8 mx-auto">
                <table class="table table-bordered">
                    <thead class="table-light">
                        <tr>
                            <th>Nome</th>
                            <th>Email</th>
                            <th>Disciplinas</th>
                            <th>Remover</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($alunos as $aluno): ?>
                            <tr>
                                <td><?= htmlspecialchars($aluno['nome']) ?></td>
                                <td><?= htmlspecialchars($aluno['email']) ?></td>
                                <td><?= $aluno['disciplinas'] ?? '—' ?></td>
                                <td>
                                    <a href="?remover=<?= $aluno['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja mesmo remover este aluno?')">Remover</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <a href="index.php" class="btn btn-secondary">Voltar</a>
            </div>
        </section>

        <?php require_once('../inc/rodape.php'); ?>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
