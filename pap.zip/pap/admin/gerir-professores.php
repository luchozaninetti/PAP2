<?php
session_start();
if (!isset($_SESSION['autenticado']) || $_SESSION['tipoutilizador'] != 1) {
    header('Location: ../login.php');
    exit;
}

require_once('../inc/Medoo.php');

// Remover professor
if (isset($_GET['remover']) && is_numeric($_GET['remover'])) {
    $id = intval($_GET['remover']);
    $basedados->delete("tbutilizadores", ["id" => $id]);
    header("Location: admin_ver_professores.php");
    exit;
}

// Buscar professores
$professores = $basedados->select("tbutilizadores", ["id", "nome", "email"], [
    "tipo" => 2
]);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Ver Professores</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link href="../css/estilos.css" rel="stylesheet">
</head>
<body>
     <!-- menu de navegação -->
    <?php require_once('../inc/nav.php'); ?>

      <?php require_once('../inc/banner.php'); ?>


    <main class="container-fluid ">
          <section class="row mt-2 mb-2">
            <article class="col-12 text-center">
                
        <h1 class="mb-4">Lista de Professores</h1>
          </article>
        </section>

        <section class="row">
            <div class="col-sm-12 col-lg-8 mx-auto">
                <table class="table table-bordered">
                    <thead class="table-light">
                <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Remover</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($professores as $prof): ?>
                    <tr>
                        <td><?= htmlspecialchars($prof['nome']) ?></td>
                        <td><?= htmlspecialchars($prof['email']) ?></td>
                        <td><a href="?remover=<?= $prof['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja mesmo remover este professor?')">Remover</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
         </div>
        </section>
        <a href="../Index.php" class="btn btn-secondary">Voltar</a>
         <?php require_once('../inc/rodape.php'); ?>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
