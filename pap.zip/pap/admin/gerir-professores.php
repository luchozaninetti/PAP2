<?php
session_start();
if (!isset($_SESSION['autenticado']) || $_SESSION['tipoutilizador'] != 1) {
    header('Location: ../login.php');
    exit;
}

require_once('../inc/Medoo.php');

// Remover professor
if (isset($_GET['remover']) && is_numeric($_GET['remover'])) {
    $id = intval($_GET['remover']);
    $basedados->delete("tbutilizadores", ["id" => $id]);
    header("Location: admin_ver_professores.php");
    exit;
}

// Buscar professores
$professores = $basedados->select("tbutilizadores", ["id", "nome", "email"], [
    "tipo" => 2
]);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Ver Professores</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <main class="container mt-5">
        <h2 class="mb-4">Lista de Professores</h2>
        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Remover</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($professores as $prof): ?>
                    <tr>
                        <td><?= htmlspecialchars($prof['nome']) ?></td>
                        <td><?= htmlspecialchars($prof['email']) ?></td>
                        <td><a href="?remover=<?= $prof['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja mesmo remover este professor?')">Remover</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="../Index.php" class="btn btn-secondary">Voltar</a>
    </main>
</body>
</html>
