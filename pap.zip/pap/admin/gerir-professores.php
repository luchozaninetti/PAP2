<?php
session_start();
if (!isset($_SESSION['autenticado']) || $_SESSION['tipoutilizador'] != 1) {
    header('Location: ../login.php');
    exit;
}

require_once('../inc/Medoo.php');

// Remover professor
if (isset($_GET['remover']) && is_numeric($_GET['remover'])) {
    $id = intval($_GET['remover']);
    $basedados->delete("tbutilizadores", ["id" => $id]);
    header("Location: admin_ver_professores.php");
    exit;
}

// Criar novo professor
$mensagem = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nome'], $_POST['email'], $_POST['senha'])) {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $senha = trim($_POST['senha']);

    if ($nome && $email && $senha) {
        $jaExiste = $basedados->has("tbutilizadores", ["email" => $email]);

        if ($jaExiste) {
            $mensagem = "<div class='alert alert-warning'>Já existe um professor com esse e-mail.</div>";
        } else {
            $hash = password_hash($senha, PASSWORD_DEFAULT);
            $basedados->insert("tbutilizadores", [
                "nome" => $nome,
                "email" => $email,
                "password" => $hash,
                "tipo" => 2 // 2 = professor
            ]);
            $mensagem = "<div class='alert alert-success'>Professor criado com sucesso.</div>";
        }
    } else {
        $mensagem = "<div class='alert alert-danger'>Preencha todos os campos.</div>";
    }
}

// Buscar professores
$professores = $basedados->select("tbutilizadores", ["id", "nome", "email"], [
    "tipo" => 2
]);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Ver Professores</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link href="../css/estilos.css" rel="stylesheet">
</head>
<body>
<?php require_once('../inc/nav.php'); ?>
<?php require_once('../inc/banner.php'); ?>

<main class="container-fluid">
    <section class="row mt-2 mb-2">
        <article class="col-12 text-center">
            <h1 class="mb-4">Gerir Professores</h1>
        </article>
    </section>

    <section class="row">
        <div class="col-sm-12 col-lg-8 mx-auto">
            <?= $mensagem ?>
            <table class="table table-bordered">
                <thead class="table-light">
                <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Remover</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($professores as $prof): ?>
                    <tr>
                        <td><?= htmlspecialchars($prof['nome']) ?></td>
                        <td><?= htmlspecialchars($prof['email']) ?></td>
                        <td>
                            <a href="?remover=<?= $prof['id'] ?>" class="btn btn-danger btn-sm"
                               onclick="return confirm('Deseja mesmo remover este professor?')">Remover</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <hr>
            <h2 class="mt-4">Criar Novo Professor</h2>
            <form method="post" class="mt-3">
                <div class="mb-3">
                    <label for="nome" class="form-label">Nome:</label>
                    <input type="text" name="nome" id="nome" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" name="email" id="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="senha" class="form-label">Senha:</label>
                    <input type="password" name="senha" id="senha" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Criar Professor</button>
            </form>

        </div>
    </section>

    <div class="text-center mt-4">
        <a href="/pap/admin/painel-admin.php" class="btn btn-secondary">Voltar</a>
    </div>

    <?php require_once('../inc/rodape.php'); ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
