<?php
// painel-admin.php
session_start();

if (!isset($_SESSION['autenticado']) || $_SESSION['tipoutilizador'] != 1) {
    header('Location: ../login.php');
    exit;
}
?>
<!doctype html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>Painel do Administrador</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/estilos.css" rel="stylesheet">
</head>
<body>
<?php require_once('../inc/nav.php'); ?>

<main class="container py-4">
    <h1 class="text-center mb-4">Painel do Administrador</h1>
    <div class="row g-4">
        <div class="col-md-6">
            <div class="card text-white bg-dark h-100">
                <div class="card-body text-center">
                    <h5 class="card-title">Gerir Professores</h5>
                    <p class="card-text">Visualizar e remover professores.</p>
                    <a href="../admin/gerir-professores.php" class="btn btn-light">Acessar</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card text-white bg-secondary h-100">
                <div class="card-body text-center">
                    <h5 class="card-title">Gerir Alunos</h5>
                    <p class="card-text">Visualizar e excluir alunos.</p>
                    <a href="../admin/gerir-alunos.php" class="btn btn-light">Acessar</a>
                </div>
            </div>
        </div>
    </div>
</main>

<?php require_once('../inc/rodape.php'); ?>
</body>
</html>
