<?php
session_start();

require_once('inc/Medoo.php');
require_once('inc/nav.php');
require_once('inc/banner.php');

// Verificação de sessão
if (!isset($_SESSION['autenticado']) || !isset($_SESSION['idutilizador']) || $_SESSION['tipoutilizador'] != 3) {
    echo "<div class='alert alert-danger container mt-4'>Erro: sessão inválida. Faça login novamente.</div>";
    exit;
}

$idAluno = $_SESSION['idutilizador'];
?>

<!doctype html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>Perfil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/estilos.css" rel="stylesheet">

    <script src="../js/alertas.js"></script>

</head>

<body>
<main class="container-fluid">
    <section class="row mt-2 mb-2">
        <article class="col-12 text-center">
            <h1>Perfil</h1>
        </article>
    </section>

    <section class="container mt-5">
        <h2 class="text-center mb-4">Disciplinas Inscritas e Notas</h2>

        <?php
        // Buscar disciplinas e notas corretamente
        $resultados = $basedados->select("matriculas", [
            "[>]turmas" => ["idturma" => "id"],
            "[>]idioma" => ["turmas.ididioma" => "id"],
            "[>]notas" => [
                "idutilizador" => "aluno_id",
                
            ]
        ], [
            "turmas.nome(turma)",
            "idioma.nome(disciplina)",
            "notas.nota"
        ], [
            "matriculas.idutilizador" => $idAluno
        ]);

        if ($resultados && count($resultados) > 0) {
            echo "<table class='table table-bordered'>";
            echo "<thead class='table-primary'><tr><th>Turma</th><th>Disciplina</th><th>Nota</th></tr></thead><tbody>";

            foreach ($resultados as $linha) {
                echo "<tr>
                        <td>" . htmlspecialchars($linha['turma']) . "</td>
                        <td>" . htmlspecialchars($linha['disciplina']) . "</td>
                        <td>" . (is_null($linha['nota']) ? '—' : htmlspecialchars($linha['nota'])) . "</td>
                      </tr>";
            }

            echo "</tbody></table>";
        } else {
            echo "<p class='alert alert-warning'>Você ainda não está inscrito em nenhuma disciplina.</p>";
        }
        ?>
    </section>

    <?php require_once('inc/rodape.php'); ?>
</main>
</body>
</html>
