<?php
session_start();

//se variáveis de sessão não existir 
if (!isset($_SESSION['autenticado'])) {
    //header('Location: login.php');
    // exit;
}
?>
<!doctype html>
<html lang="pt">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fisk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="css/estilos.css" rel="stylesheet">
</head>

<body>

    <!-- menu de navegação -->
    <?php require_once('inc/nav.php'); ?>

    <main class="container-fluid ">
        <!-- banner -->
        <?php require_once('inc/banner.php'); ?>

        <!-- título da página -->
        <section class="row mt-2 mb-2">
            <article class="col-12 text-center">
                <h1>Autenticação</h1>
            </article>
        </section>

        <!-- não alterar nada acima desta linha -->
        <section class="row">
            <div class="col-lg-4 col-sm-12 mx-auto mb-4">
            <form action="login-processo.php" method="post">
                    <div class="mb-3">
                        <label for="email" class="form-label">e-Mail</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                     </div>
                     <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                     </div>
                    <button type="submit" class="btn btn-primary">Autenticar</button>
                </form>
            </div>
        </section>
        <!-- não alterar nada abaixo desta linha -->
        <?php require_once('inc/rodape.php'); ?>
    </main>
    <!-- biblioteca bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>