document.addEventListener("DOMContentLoaded", () => {
  const inputBusca = document.getElementById("buscaAluno");
  const resultado = document.getElementById("resultadoBusca");

  if (inputBusca) {
    inputBusca.addEventListener("keyup", function () {
      const termo = this.value;

      fetch(`buscar-alunos.php?termo=${encodeURIComponent(termo)}`)
        .then(response => response.text())
        .then(data => {
          resultado.innerHTML = data;
        });
    });
  }
});
