
function trocarVideo(novoSrc, botao) {
    const player = videojs('videoPlayer');
    player.src({ type: "video/mp4", src: novoSrc });
    player.play();

    // Remover a classe 'active' de todos os botões
    document.querySelectorAll('.list-group-item').forEach(btn => btn.classList.remove('active'));
    botao.classList.add('active');
}
