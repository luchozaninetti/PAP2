document.addEventListener("DOMContentLoaded", () => {
  const links = document.querySelectorAll(".confirmar-remocao");

  links.forEach(link => {
    link.addEventListener("click", function (e) {
      const confirmar = confirm("Tem certeza que deseja remover?");
      if (!confirmar) {
        e.preventDefault();
      }
    });
  });
});
