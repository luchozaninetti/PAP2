document.addEventListener("DOMContentLoaded", () => {
  const alertas = document.querySelectorAll(".alert");

  alertas.forEach(alerta => {
    setTimeout(() => {
      alerta.style.display = "none";
    }, 4000);
  });
});
