function trocarVideo(url) {
    const player = videojs('videoPlayer');
    player.src({ type: 'video/mp4', src: url });
    player.play();
}