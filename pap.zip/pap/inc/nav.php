<?php 
@session_start();
require_once('Medoo.php'); // Certifique-se de que a conexão está funcionando

// Recuperar os idiomas em que o aluno está inscrito
$idiomas = [];
if (isset($_SESSION['autenticado']) && $_SESSION['tipoutilizador'] == 3) {
    $idAluno = $_SESSION['idutilizador'];
    $idiomas = $basedados->select("matriculas", [
        "[>]turmas" => ["idturma" => "id"],
        "[>]idioma" => ["turmas.ididioma" => "id"]
    ], [
        "idioma.id(idioma_id)",
        "idioma.nome"
    ], [
        "matriculas.idutilizador" => $idAluno,
        "GROUP" => "idioma.id"
    ]);
}
?>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img alt="FISK" src="/pap/img/logo.jpg" style="max-width: 80px; height: auto;">
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="/pap/index.php">Início</a>
        </li>

      <?php if (isset($_SESSION['autenticado']) && in_array($_SESSION['tipoutilizador'], [1, 2, 3])) ?>
     <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
      Disciplinas 
      </a>
      <ul class="dropdown-menu">
      <?php if (!empty($idiomas)): ?>
        <?php foreach ($idiomas as $idioma): ?>
          <li>
            <a class="dropdown-item" href="./conteudos/idioma.php?id=<?= $idioma['idioma_id'] ?>">
              <?= htmlspecialchars($idioma['nome']) ?>
            </a>
          </li>
                <?php endforeach; ?>
              <?php else: ?>
                <li><span class="dropdown-item disabled">Nenhuma inscrição</span></li>
              <?php endif; ?>
            </ul>
          </li>
          <?php if (isset($_SESSION['autenticado']) && $_SESSION['tipoutilizador'] == 3): ?>
          <li class="nav-item">
            <a class="nav-link" href="/pap/perfil.php">Perfil do Aluno</a>
          </li>
        <?php elseif (isset($_SESSION['autenticado']) && in_array($_SESSION['tipoutilizador'], [1, 2])): ?>
          <li class="nav-item">
            <a class="nav-link" href="/pap/professores/painel-professor.php">Painel Professor</a>
        <?php endif; ?>

        <?php if (isset($_SESSION['autenticado']) && $_SESSION['tipoutilizador'] == 1): ?>
          <li class="nav-item">
            
              <li><a class="nav-link" href="/pap/admin/painel-admin.php">Painel admin</a></li>
              
          </li>
        <?php endif; ?>

        <?php if (isset($_SESSION['autenticado'])): ?>
          <li class="nav-item">
            <a class="nav-link" href="/pap/logout.php">Logout</a>
          </li>
        <?php else: ?>
          <li class="nav-item">
            <a class="nav-link" href="/pap/login.php">Login</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
