<?php 
@session_start();
require_once('Medoo.php'); // Certifique-se de que a conexão está funcionando

$idiomas = [];

if (isset($_SESSION['autenticado']) && in_array($_SESSION['tipoutilizador'], [1, 2, 3])) {
    $tipo = $_SESSION['tipoutilizador'];
    
    if (in_array($tipo, [1, 2])) {
        // Admin ou professor: vê todos os idiomas
        $idiomas = $basedados->select("idioma", "*");
    } elseif ($tipo == 3) {
        // Aluno: vê apenas os idiomas das turmas em que está matriculado
        $idAluno = $_SESSION['idutilizador'];
        $idiomas = $basedados->select("idioma", [
            "[>]turmas" => ["id" => "ididioma"],
            "[>]matriculas" => ["turmas.id" => "idturma"]
        ], "idioma.*", [
            "matriculas.idutilizador" => $idAluno,
            "GROUP" => "idioma.id"
        ]);
    }
}
?>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img alt="FISK" src="/pap/img/logo.jpg" style="max-width: 80px; height: auto;">
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="/pap/index.php">Início</a>
        </li>

        <?php if (isset($_SESSION['autenticado']) && in_array($_SESSION['tipoutilizador'], [1, 2, 3])): ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Disciplinas 
            </a>
            <ul class="dropdown-menu">
              <?php if (!empty($idiomas)): ?>
                <?php foreach ($idiomas as $idioma): ?>
                  <?php
                    // Gera o nome do ficheiro com base no nome do idioma
                    $nomeArquivo = strtolower($idioma['nome']);
                    $nomeArquivo = preg_replace('/[^a-z0-9]/', '', iconv('UTF-8', 'ASCII//TRANSLIT', $nomeArquivo)); // Remove acentos e espaços
                    $nomeArquivo .= '.php';
                  ?>
                  <li>
                    <a class="dropdown-item" href="/pap/conteudos/<?= $nomeArquivo ?>">
                      <?= htmlspecialchars($idioma['nome']) ?>
                    </a>
                  </li>
                <?php endforeach; ?>
              <?php else: ?>
                <li><span class="dropdown-item disabled">Nenhuma inscrição</span></li>
              <?php endif; ?>
            </ul>
          </li>
        <?php endif; ?>

        <?php if (isset($_SESSION['autenticado']) && $_SESSION['tipoutilizador'] == 3): ?>
          <li class="nav-item">
            <a class="nav-link" href="/pap/perfil.php">Perfil do Aluno</a>
          </li>
        <?php elseif (isset($_SESSION['autenticado']) && in_array($_SESSION['tipoutilizador'], [1, 2])): ?>
          <li class="nav-item">
            <a class="nav-link" href="/pap/professores/painel-professor.php">Painel Professor</a>
          </li>
        <?php endif; ?>

        <?php if (isset($_SESSION['autenticado']) && $_SESSION['tipoutilizador'] == 1): ?>
          <li class="nav-item">
            <a class="nav-link" href="/pap/admin/painel-admin.php">Painel admin</a>
          </li>
        <?php endif; ?>

        <?php if (isset($_SESSION['autenticado']) && in_array($_SESSION['tipoutilizador'], [1, 2, 3])): ?>
          <li class="nav-item">
            <a class="nav-link" href="https://www.fisk.com.br/fale-conosco">Contacte-nos</a>
          </li>
        <?php endif; ?>

        <?php if (isset($_SESSION['autenticado'])): ?>
          <li class="nav-item">
            <a class="nav-link" href="/pap/logout.php">Logout</a>
          </li>
        <?php else: ?>
          <li class="nav-item">
            <a class="nav-link" href="/pap/login.php">Login</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
