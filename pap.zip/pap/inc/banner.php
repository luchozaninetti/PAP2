<header class="row banner">
    <div class="col-12"></div>
</header>

