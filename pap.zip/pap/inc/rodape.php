<footer class="row vermelho">
	<div class="col-lg-12 col-sm-12 "><p>PAPAPAPAPAPPAPAPAP</p></div>
</footer>