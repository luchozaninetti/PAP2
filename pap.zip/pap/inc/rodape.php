<footer class="footer mt-auto py-3 bg-light border-top">
  <div class="container text-center">
    <span class="text-muted">© <?= date('Y') ?> Fisk Idioma - Direitos reservados.</span><br>
  </div>
</footer>
