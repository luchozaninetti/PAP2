<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	//recuperar dados digitados no formulario
	$email = $_POST['email'];
	$password = md5($_POST['password']);

	require_once('inc/Medoo.php');

	//consultar base de dados
	$registo = $basedados->get("tbutilizadores", "*", [
		"email" => $email,
		"password" => $password
	]);

	//verficar se foi encontrado uma linha com dados corretos
	if ($registo) {
		//criar a sessão porque dados de acesso estão corretos
		$_SESSION['autenticado'] = true;
		$_SESSION['nomeutlizadoR'] = $registo['nome'];
		$_SESSION['tipoutilizador'] = $registo['tipo'];
		$_SESSION['idutilizador'] = $registo['id'];
		$_SESSION['id'] = $registo['id'];


		header('Location: index.php');
	} else {
		echo "<script>
        alert('Dados de Acesso inválidos!');
        window.location.href = 'login.php';
    </script>";
	}
}
