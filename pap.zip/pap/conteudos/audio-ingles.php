<?php
session_start();
require_once('../inc/Medoo.php');

// Idioma: Inglês (id = 2)
$idioma_id = 2;
$idioma = $basedados->get("idioma", "*", ["id" => $idioma_id]);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>FISK - Áudios de Inglês</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">


    <!-- CSS personalizado -->
    <link href="../css/estilos.css" rel="stylesheet">

    <link rel="shortcut icon" href="../images/icone.ico" type="image/x-icon">
</head>

<body>

<?php require_once('../inc/nav.php'); ?>
<?php require_once('../inc/banner.php'); ?>

<main class="container-fluid px-4 mt-4 mb-5">

    <section class="text-center mb-5">
        <h1 class="display-5 fw-bold">Audio de Inglês</h1>
        <p class="text-muted fs-5">Selecione o material de áudio disponível para o curso de inglês.</p>
    </section>

    <section class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-5 g-5 justify-content-between">
        <article class="col">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-primary text-white fw-semibold text-center">
                    Adulto
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><a href="bd-audio/aiming_at_the_sky.php" class="text-decoration-none">Aiming At the Sky</a></li>
                    <li class="list-group-item"><a href="bd-audio/breaking_free.php" class="text-decoration-none">Breaking Free</a></li>
                    <li class="list-group-item"><a href="bd-audio/essentials_1.php" class="text-decoration-none">Essentials 1</a></li>
                    <li class="list-group-item"><a href="bd-audio/essentials_2.php" class="text-decoration-none">Essentials 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/Expanding_Horizons.php" class="text-decoration-none">Expanding Horizons</a></li>
                    <li class="list-group-item"><a href="bd-audio/In_Focus.php" class="text-decoration-none">Fisk In Focus</a></li>
                    <li class="list-group-item"><a href="bd-audio/Fluency_1.php" class="text-decoration-none">Fluency 1</a></li>
                    <li class="list-group-item"><a href="bd-audio/Fluency_2.php" class="text-decoration-none">Fluency 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/Flying_High.php" class="text-decoration-none">Flying High</a></li>
                    <li class="list-group-item"><a href="bd-audio/focus.php" class="text-decoration-none">Focus</a></li>
                    <li class="list-group-item"><a href="bd-audio/focus_online.php" class="text-decoration-none">Focus Online</a></li>
                    <li class="list-group-item"><a href="bd-audio/may_i_help_you.php" class="text-decoration-none">May I Help You</a></li>
                    <li class="list-group-item"><a href="bd-audio/may_i_help_you_1.php" class="text-decoration-none">May I Help You 1</a></li>
                    <li class="list-group-item"><a href="bd-audio/may_i_help_you_2.php" class="text-decoration-none">May I Help You 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/speed_1.php" class="text-decoration-none">Speed 1</a></li>
                    <li class="list-group-item"><a href="bd-audio/speed_2.php" class="text-decoration-none">Speed 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/speed_3.php" class="text-decoration-none">Speed 3</a></li>
                    <li class="list-group-item"><a href="bd-audio/Spreading_Wings.php" class="text-decoration-none">Spreading Wings</a></li>
                    <li class="list-group-item"><a href="bd-audio/Transitions_1.php" class="text-decoration-none">Transitions 1</a></li>
                    <li class="list-group-item"><a href="bd-audio/Transitions_2.php" class="text-decoration-none">Transitions 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/Wings_of_Freedom.php" class="text-decoration-none">Wings of Freedom</a></li>
                    <li class="list-group-item"><a href="../tests/ingles/index-adultos.php" class="text-decoration-none">TESTS</a></li>
                </ul>
            </div>
        </article>

        <article class="col">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-success text-white fw-semibold text-center">
                    Infantil
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><a href="bd-audio/Big_Box_1.php" class="text-decoration-none">Big Box 1</a></li>
                    <li class="list-group-item"><a href="bd-audio/Big_Box__2.php" class="text-decoration-none">Big Box 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/Big_Box__3.php" class="text-decoration-none">Big Box 3</a></li>
                    <li class="list-group-item"><a href="bd-audio/Have_Fun_1.php" class="text-decoration-none">Have Fun 1</a></li>
                    <li class="list-group-item"><a href="bd-audio/Have_Fun_2.php" class="text-decoration-none">Have Fun 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/Have_Fun_3.php" class="text-decoration-none">Have Fun 3</a></li>
                    <li class="list-group-item"><a href="bd-audio/Have_Fun_4.php" class="text-decoration-none">Have Fun 4</a></li>
                    <li class="list-group-item"><a href="bd-audio/Magic_Way_Blue.php" class="text-decoration-none">Magic Way - Blue</a></li>
                    <li class="list-group-item"><a href="bd-audio/Magic_Way_Yellow.php" class="text-decoration-none">Magic Way - Yellow</a></li>
                    <li class="list-group-item"><a href="bd-audio/Playground_1.php" class="text-decoration-none">Playground 1 - New Edition</a></li>
                    <li class="list-group-item"><a href="bd-audio/Playground_2.php" class="text-decoration-none">Playground 2 - New Edition</a></li>
                    <li class="list-group-item"><a href="bd-audio/Playground_3.php" class="text-decoration-none">Playground 3</a></li>
                    <li class="list-group-item"><a href="bd-audio/Playground_4.php" class="text-decoration-none">Playground 4</a></li>
                </ul>
            </div>
        </article>

        <article class="col">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-primary text-white fw-semibold text-center">
                    Teens
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><a href="bd-audio/teens_advanced.php" class="text-decoration-none">Teens Advanced</a></li>
                    <li class="list-group-item"><a href="bd-audio/Teens_Elementary_1.php" class="text-decoration-none">Teens Elementary 1</a></li>
                    <li class="list-group-item"><a href="bd-audio/Teens_Elementary_2.php" class="text-decoration-none">Teens Elementary 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/Teens_Higher_1.php" class="text-decoration-none">Teens Higher 1</a></li>
                    <li class="list-group-item"><a href="bd-audio/Teens_Higher_2.php" class="text-decoration-none">Teens Higher 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/Teens_Intermediate.php" class="text-decoration-none">Teens Intermediate</a></li>
                    <li class="list-group-item"><a href="bd-audio/Teens_Pre-Intermediate.php" class="text-decoration-none">Teens Pre-intermediate</a></li>
                    <li class="list-group-item"><a href="bd-audio/Teens_Upper-Intermediate.php" class="text-decoration-none">Teens Upper-intermediate</a></li>
                    <li class="list-group-item"><a href="../tests/ingles/index-teens.php" class="text-decoration-none">TESTS</a></li>
                </ul>
            </div>
        </article>

        <article class="col">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-success text-white fw-semibold text-center">
                    Teenstation
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><a href="bd-audio/Teenstation_1.php" class="text-decoration-none">Teenstation 1</a></li>
                    <li class="list-group-item"><a href="bd-audio/Teenstation_2.php" class="text-decoration-none">Teenstation 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/Teenstation_3.php" class="text-decoration-none">Teenstation 3</a></li>
                    <li class="list-group-item"><a href="bd-audio/Teenstation_4.php" class="text-decoration-none">Teenstation 4</a></li>
                    <li class="list-group-item"><a href="../tests/ingles/index-teenstation.php" class="text-decoration-none">TESTS</a></li>
                </ul>
            </div>
        </article>

        <article class="col">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-primary text-white fw-semibold text-center">
                    Complementary Material
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><a href="bd-audio/ecce.php" class="text-decoration-none">ECCE</a></li>
                    <li class="list-group-item"><a href="bd-audio/ecpe.php" class="text-decoration-none">ECPE</a></li>
                    <li class="list-group-item"><a href="bd-audio/focusonlinepractice.php" class="text-decoration-none">Focus Online Practice</a></li>
                    <li class="list-group-item"><a href="bd-audio/metvolumea.php" class="text-decoration-none">Met Volume A</a></li>
                    <li class="list-group-item"><a href="bd-audio/metvolume1.php" class="text-decoration-none">Met Volume 1</a></li>
                    <li class="list-group-item"><a href="bd-audio/metvolume2.php" class="text-decoration-none">Met Volume 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/metvolume3.php" class="text-decoration-none">Met Volume 3</a></li>
                    <li class="list-group-item"><a href="bd-audio/newmetvolume1.php" class="text-decoration-none">New Met Volume 1</a></li>
                    <li class="list-group-item"><a href="bd-audio/newmetvolume2.php" class="text-decoration-none">New Met Volume 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/newmetvolume3.php" class="text-decoration-none">New Met Volume 3</a></li>
                    <li class="list-group-item"><a href="bd-audio/toc.php" class="text-decoration-none">TOC</a></li>
                    <li class="list-group-item"><a href="bd-audio/teenstation_songs.php" class="text-decoration-none">Teenstation Songs</a></li>
                    <li class="list-group-item"><a href="bd-audio/teenstation_songs2.php" class="text-decoration-none">Teenstation Songs 2</a></li>
                    <li class="list-group-item"><a href="bd-audio/teenstation_songs3.php" class="text-decoration-none">Teenstation Songs 3</a></li>
                    <li class="list-group-item"><a href="bd-audio/thinking_english.php" class="text-decoration-none">Thinking English</a></li>
                </ul>
            </div>
        </article>
    </section>

</main>

<?php require_once('../inc/rodape.php'); ?>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
