<?php
session_start();
require_once('../inc/Medoo.php');

// Idioma: Espanhol (id = 3, por exemplo)
$idioma_id = 3;
$idioma = $basedados->get("idioma", "*", ["id" => $idioma_id]);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>FISK - Áudios e Vídeos de Espanhol</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- CSS personalizado -->
    <link href="../css/estilos.css" rel="stylesheet">

    <link rel="shortcut icon" href="../images/icone.ico" type="image/x-icon">
</head>

<body>

<?php require_once('../inc/nav.php'); ?>
<?php require_once('../inc/banner.php'); ?>

<main class="container py-4">
    <h1 class="text-center mb-4">Audios e Videos em Ingles</h1>
    <div class="row g-4">
        <div class="col-md-6">
            <div class="card text-white bg-success h-100">
                <div class="card-body text-center">
                    <h5 class="card-title">Audios</h5>
                    <p class="card-text">Audios em ingles para estudo.</p>
                    <a href="../conteudos/audio-ingles.php" class="btn btn-light">Acessar</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card text-white bg-warning h-100">
                <div class="card-body text-center">
                    <h5 class="card-title">Videos</h5>
                    <p class="card-text">Videos em ingles para estudo.</p>
                    <a href="../conteudos/video-ingles.php" class="btn btn-light">Acessar</a>
                </div>
            </div>
        </div>
    </div>
</main>

<?php require_once('../inc/rodape.php'); ?>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
