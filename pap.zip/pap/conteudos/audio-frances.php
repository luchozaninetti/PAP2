<?php
session_start();
require_once('../inc/Medoo.php');

// Idioma: Francês (id = 3)
$idioma_id = 3;
$idioma = $basedados->get("idioma", "*", ["id" => $idioma_id]);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>FISK - Áudios de Francês</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Estilo -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/estilos.css" rel="stylesheet">

    <link rel="shortcut icon" href="../images/icone.ico" type="image/x-icon">
</head>

<body>

<?php require_once('../inc/nav.php'); ?>
<?php require_once('../inc/banner.php'); ?>

<main class="container mt-4 mb-5">

    <section class="text-center mb-5">
        <h1 class="display-5 fw-bold">Audio de Frances</h1>
        <p class="text-muted fs-5">Selecione o material de áudio disponível para o curso de francês.</p>
    </section>

    <section class="row g-4 justify-content-center">
        <?php
        $materiais = [
            [
                'titulo' => 'Latitudes',
                'icone' => 'fa-globe',
                'cor' => 'primary',
                'links' => [
                    ['Latitudes 1 - CD 1', 'bd-audio/Latitudes_1_CD1.php'],
                    ['Latitudes 1 - CD 2', 'bd-audio/Latitudes_1_CD2.php'],
                    ['Latitudes 1 - Cahier', 'bd-audio/Latitudes_1_Cahier.php'],
                    ['Latitudes 2 - CD 1', 'bd-audio/Latitudes_2_CD1.php'],
                    ['Latitudes 2 - CD 2', 'bd-audio/Latitudes_2_CD2.php'],
                    ['Latitudes 2 - Cahier', 'bd-audio/Latitudes_2_Cahier.php'],
                    ['Latitudes 3 - CD 1', 'bd-audio/Latitudes_3_CD1.php'],
                    ['Latitudes 3 - CD 2', 'bd-audio/Latitudes_3_CD2.php'],
                    ['Latitudes 3 - Cahier', 'bd-audio/Latitudes_3_Cahier.php']
                ]
            ],
            [
                'titulo' => 'Saison',
                'icone' => 'fa-book',
                'cor' => 'success',
                'links' => [
                    ['Saison 1.1', 'bd-audio/Saison_1part1.php'],
                    ['Saison 1.2', 'bd-audio/Saison_1part2.php'],
                    ['Saison 2.1', 'bd-audio/Saison_2part1.php'],
                    ['Saison 2.2', 'bd-audio/Saison_2part2.php'],
                    ['Saison 3.1', 'bd-audio/Saison_3part1.php'],
                    ['Saison 3.2', 'bd-audio/Saison_3part2.php']
                ]
            ]
        ];

        foreach ($materiais as $item):
        ?>
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-<?= $item['cor'] ?> text-white">
                    <i class="fa <?= $item['icone'] ?>"></i> <?= $item['titulo'] ?>
                </div>
                <ul class="list-group list-group-flush">
                    <?php foreach ($item['links'] as [$texto, $url]): ?>
                        <li class="list-group-item">
                            <a href="<?= $url ?>" class="text-decoration-none"><?= $texto ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <?php endforeach; ?>
    </section>
</main>

<?php require_once('../inc/rodape.php'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
