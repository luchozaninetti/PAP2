
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Elementary 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
         
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
	
    
	
<li data-title="TEENS ELEMENTARY 1 - LESSON 01 - 01 LESSON 1" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 01/01 LESSON 1.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 01 - 02 EXTRA 1" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 01/02 EXTRA 1.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 02 - 01 LESSON 2" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 02/01 LESSON 2.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 02 - 02 EXTRA 2" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 02/02 EXTRA 2.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 03 - 01 LESSON 3" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 03/01 LESSON 3.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 03 - 02 EXTRA 3" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 03/02 EXTRA 3.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 04 - 01 LESSON 4" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 04/01 LESSON 4.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 04 - 02 EXTRA 4" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 04/02 EXTRA 4.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 05 - 01 LESSON 5" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 05/01 LESSON 5.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 05 - 02 EXTRA 5" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 05/02 EXTRA 5.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 06 - 01 LESSON 6" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 06/01 LESSON 6.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 06 - 02 EXTRA 6" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 06/02 EXTRA 6.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 07 - 01 LESSON 7" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 07/01 LESSON 7.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 07 - 02 EXTRA 7" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 07/02 EXTRA 7.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 08 - 01 LESSON 8" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 08/01 LESSON 8.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 08 - 02 EXTRA 8" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 08/02 EXTRA 8.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 09 - 01 LESSON 9" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 09/01 LESSON 9.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 09 - 02 EXTRA 9" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 09/02 EXTRA 9.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 10 - 01 LESSON 10" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 10/01 LESSON 10.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 10 - 02 EXTRA 10" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 10/02 EXTRA 10.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 11 - 01 LESSON 11" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 11/01 LESSON 11.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 11 - 02 EXTRA 11" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 11/02 EXTRA 11.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 12 - 01 LESSON 12" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 12/01 LESSON 12.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 1 - LESSON 12 - 02 EXTRA 12" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 1/LESSON 12/02 EXTRA 12.mp4" data-poster="Teens_elementary1.jpg" data-free="false"></li>

	
	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
