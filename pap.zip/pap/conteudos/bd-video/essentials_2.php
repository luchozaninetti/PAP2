<?php require_once('../../inc/nav.php'); ?>
<?php require_once('../../inc/Medoo.php'); ?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <title>Fisk - Essentials 2</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css" />

    <!-- Ícones e Favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192" />
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg" />
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;" />
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Essentials 2</h4>
    </div>

    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
    </div>

    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">

        <!-- Vídeos sem legendas -->
        <?php
        $videosSemLegenda = [
            ["The Smart Pack - Season 2 - Teaser", "The Smart Pack - Season 2 - Teaser.mp4"],
            ["01 Vacationning in the US", "Episode 1/01 Vacationning in the US.mp4"],
            ["02 Moving out", "Episode 2/02 Moving out.mp4"],
            ["03 Future talk", "Episode 3/03 Future talk.mp4"],
            ["04 Trouble", "Episode 4/04 Trouble.mp4"],
            ["05 The final page", "Episode 5/05 The final page.mp4"],
        ];

        foreach ($videosSemLegenda as $video) {
            $titulo = $video[0];
            $caminho = "https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Essentials 2/No subtitles/" . $video[1];
            echo <<<HTML
            <div class="col">
                <div class="card h-100">
                    <video class="w-100" controls poster="capa.png">
                        <source src="$caminho" type="video/mp4" />
                        Seu navegador não suporta vídeo.
                    </video>
                    <div class="card-body">
                        <h6 class="card-title text-center">{$titulo} (No Subtitles)</h6>
                    </div>
                </div>
            </div>
HTML;
        }
        ?>

        <!-- Vídeos com legendas -->
        <?php
        $videosComLegenda = [
            ["The Smart Pack - Season 2 - Teaser - Subtitles", "The Smart Pack - Season 2 - Teaser.mp4"],
            ["01 Vacationing in the US - Subtitles", "Episode 1/01 Vacationing in the US - Subtitles.mp4"],
            ["02 Moving out - Subtitles", "Episode 2/02 Moving out - Subtitles.mp4"],
            ["03 Future talk - Subtitles", "Episode 3/03 Future talk - Subtitles.mp4"],
            ["04 Trouble - Subtitles", "Episode 4/04 Trouble - Subtitles.mp4"],
            ["05 The final page - Subtitles", "Episode 5/05 The final page - Subtitles.mp4"],
        ];

        foreach ($videosComLegenda as $video) {
            $titulo = $video[0];
            $caminho = "https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Essentials 2/Subtitles/" . $video[1];
            echo <<<HTML
            <div class="col">
                <div class="card h-100">
                    <video class="w-100" controls poster="capa.png">
                        <source src="$caminho" type="video/mp4" />
                        Seu navegador não suporta vídeo.
                    </video>
                    <div class="card-body">
                        <h6 class="card-title text-center">{$titulo}</h6>
                    </div>
                </div>
            </div>
HTML;
        }
        ?>

    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>

</body>
</html>
