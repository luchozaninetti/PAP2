
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teenstation 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
           
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
	
    
	
<li data-title="Teenstation 2 - INTRODUCTION" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/INTRODUCTION.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 01 - 01 LESSON 01" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 01/01 LESSON 01.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 01 - 02 NEW WORDS" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 01/02 NEW WORDS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 01 - 03 LETS PRACTICE" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 01/03 LETS PRACTICE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 02 - 01 LESSON 02" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 02/01 LESSON 02.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 02 - 02 NEW WORDS" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 02/02 NEW WORDS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 02 - 03 LETS PRACTICE" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 02/03 LETS PRACTICE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 03 - 01 LESSON 03" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 03/01 LESSON 03.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 03 - 02 NEW WORDS" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 03/02 NEW WORDS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 03 - 03 LETS PRACTICE" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 03/03 LETS PRACTICE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 04 - 01 LESSON 04" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 04/01 LESSON 04.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 04 - 02 NEW WORDS" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 04/02 NEW WORDS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 04 - 03 LETS PRACTICE" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 04/03 LETS PRACTICE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 05 - 01 LESSON 05" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 05/01 LESSON 05.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 05 - 02 NEW WORDS" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 05/02 NEW WORDS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 05 - 03 LETS PRACTICE" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 05/03 LETS PRACTICE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 06 - 01 LESSON 06" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 06/01 LESSON 06.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 06 - 02 NEW WORDS" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 06/02 NEW WORDS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 06 - 03 LETS PRACTICE" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 06/03 LETS PRACTICE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 07 - 01 LESSON 07" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 07/01 LESSON 07.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 07 - 02 NEW WORDS" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 07/02 NEW WORDS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 07 - 03 LETS PRACTICE" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 07/03 LETS PRACTICE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 08 - 01 LESSON 08" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 08/01 LESSON 08.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 08 - 02 NEW WORDS" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 08/02 NEW WORDS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 08 - 03 LETS PRACTICE" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 08/03 LETS PRACTICE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 09 - 01 LESSON 09" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 09/01 LESSON 09.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 09 - 02 NEW WORDS" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 09/02 NEW WORDS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 09 - 03 LETS PRACTICE" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 09/03 LETS PRACTICE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 10 - 01 LESSON 10" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 10/01 LESSON 10.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 10 - 02 NEW WORDS" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 10/02 NEW WORDS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 10 - 03 LETS PRACTICE" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 10/03 LETS PRACTICE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 11 - 01 LESSON 11" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 11/01 LESSON 11.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 11 - 02 NEW WORDS" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 11/02 NEW WORDS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 11 - 03 LETS PRACTICE" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 11/03 LETS PRACTICE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 12 - 01 LESSON 12" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 12/01 LESSON 12.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 12 - 02 NEW WORDS" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 12/02 NEW WORDS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 2 - LESSON 12 - 03 LETS PRACTICE" data-artist="Teenstation 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 2/LESSON 12/03 LETS PRACTICE.mp4" data-poster="capa.png" data-free="false"></li>

	
	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
