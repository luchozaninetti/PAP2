
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Higher 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
          
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
	
    
	
<li data-title="01 BEING A TEENAGER - 01 PART 01" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/01 BEING A TEENAGER/01 PART 01.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="01 BEING A TEENAGER - 02 PART 02" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/01 BEING A TEENAGER/02 PART 02.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="01 BEING A TEENAGER - 03 PART 03" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/01 BEING A TEENAGER/03 PART 03.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="01 BEING A TEENAGER - 04 PART 04" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/01 BEING A TEENAGER/04 PART 04.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="01 BEING A TEENAGER - 05 COMPLETE" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/01 BEING A TEENAGER/05 COMPLETE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="02 STUDYNG IN THE USA - 01 PART 01" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/02 STUDYNG IN THE USA/01 PART 01.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="02 STUDYNG IN THE USA - 02 PART 02" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/02 STUDYNG IN THE USA/02 PART 02.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="02 STUDYNG IN THE USA - 03 PART 03" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/02 STUDYNG IN THE USA/03 PART 03.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="02 STUDYNG IN THE USA - 04 PART 04" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/02 STUDYNG IN THE USA/04 PART 04.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="02 STUDYNG IN THE USA - 05 PART 05" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/02 STUDYNG IN THE USA/05 PART 05.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="02 STUDYNG IN THE USA - 06 COMPLETE" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/02 STUDYNG IN THE USA/06 COMPLETE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="03 CONSUMER CULTURE AND THE ENVIRONMENT - 01 PART 01" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/03 CONSUMER CULTURE AND THE ENVIRONMENT/01 PART 01.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="03 CONSUMER CULTURE AND THE ENVIRONMENT - 02 PART 02" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/03 CONSUMER CULTURE AND THE ENVIRONMENT/02 PART 02.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="03 CONSUMER CULTURE AND THE ENVIRONMENT - 03 PART 03" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/03 CONSUMER CULTURE AND THE ENVIRONMENT/03 PART 03.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="03 CONSUMER CULTURE AND THE ENVIRONMENT - 04 COMPLETE" data-artist="TEENS HIGHER 1" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS HIGHER 1/03 CONSUMER CULTURE AND THE ENVIRONMENT/04 COMPLETE.mp4" data-poster="capa.png" data-free="false"></li>

	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
