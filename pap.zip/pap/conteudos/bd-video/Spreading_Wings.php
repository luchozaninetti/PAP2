
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Spreading Wings</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
           
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
	
    
	
<li data-title="Spreading Wings - INTRODUCTION" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/INTRODUCTION.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
<li data-title="Spreading Wings - EPISODE 01 - BUYING A SOUVENIR FOR MOM - 01 EPISODE 1 - BUYING A SOUVENIR FOR MOM" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/EPISODE 01 - BUYING A SOUVENIR FOR MOM/01 EPISODE 1 - BUYING A SOUVENIR FOR MOM.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
<li data-title="Spreading Wings - EPISODE 01 - BUYING A SOUVENIR FOR MOM - THE MUG" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/EPISODE 01 - BUYING A SOUVENIR FOR MOM/THE MUG/THE MUG.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
<li data-title="Spreading Wings - EPISODE 01 - BUYING A SOUVENIR FOR MOM - THE T-SHIRT" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/EPISODE 01 - BUYING A SOUVENIR FOR MOM/THE T-SHIRT/THE T-SHIRT.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
<li data-title="Spreading Wings - EPISODE 02 - AT HOME WITH HENRY - 01 EPISODE 2 - AT HOME WHITH HENRY" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/EPISODE 02 - AT HOME WITH HENRY/01 EPISODE 2 - AT HOME WHITH HENRY.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
<li data-title="Spreading Wings - EPISODE 02 - AT HOME WITH HENRY - NO - DONT BRING HIM A CAN OF SODA" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/EPISODE 02 - AT HOME WITH HENRY/NO/NO - DONT BRING HIM A CAN OF SODA.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
<li data-title="Spreading Wings - EPISODE 02 - AT HOME WITH HENRY - YES - BRING HIM A CAN OF SODA" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/EPISODE 02 - AT HOME WITH HENRY/YES/YES - BRING HIM A CAN OF SODA.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
<li data-title="Spreading Wings - EPISODE 03 - MOM IS STRESSED OUT - 01 EPISODE 3 - MOM IS STRESSED OUT" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/EPISODE 03 - MOM IS STRESSED OUT/01 EPISODE 3 - MOM IS STRESSED OUT.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
<li data-title="Spreading Wings - EPISODE 03 - MOM IS STRESSED OUT - COOK DINNER" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/EPISODE 03 - MOM IS STRESSED OUT/COOK DINNER/COOK DINNER.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
<li data-title="Spreading Wings - EPISODE 03 - MOM IS STRESSED OUT - EAT OUT" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/EPISODE 03 - MOM IS STRESSED OUT/EAT OUT/EAT OUT.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
<li data-title="Spreading Wings - EPISODE 04 - DOING SOMETHING DIFFERENT ON THE WEEKEND - 01 EPISODE 4 - DOING SOMETHING DIFFERENT ON THE WEEKEND" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/EPISODE 04 - DOING SOMETHING DIFFERENT ON THE WEEKEND/01 EPISODE 4 - DOING SOMETHING DIFFERENT ON THE WEEKEND.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
<li data-title="Spreading Wings - EPISODE 04 - DOING SOMETHING DIFFERENT ON THE WEEKEND - A FOOTBALL GAME" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/EPISODE 04 - DOING SOMETHING DIFFERENT ON THE WEEKEND/A FOOTBALL GAME/A FOOTBALL GAME.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
<li data-title="Spreading Wings - EPISODE 04 - DOING SOMETHING DIFFERENT ON THE WEEKEND - FISHING" data-artist="Spreading Wings" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Spreading Wings/EPISODE 04 - DOING SOMETHING DIFFERENT ON THE WEEKEND/FISHING/FISHING.mp4" data-poster="Spreading_wings.jpg" data-free="false"></li>
	
	
	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
