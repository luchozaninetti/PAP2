
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Expanding Horizons</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">

            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
	
    
	
<li data-title="Expanding Horizons - LESSON 01 - LETS WORK IT OUT" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 01/LETS WORK IT OUT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 01 - VERBAL COMBINATIONS - UP DOWN" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 01/VERBAL COMBINATIONS - UP DOWN.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 02 - LETS WORK IT OUT" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 02/LETS WORK IT OUT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 02 - VERBAL COMBINATIONS - BACK" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 02/VERBAL COMBINATIONS - BACK.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 03 - LETS WORK IT OUT" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 03/LETS WORK IT OUT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 03 - VERBAL COMBINATIONS - ALONG" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 03/VERBAL COMBINATIONS - ALONG.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 04 - LETS WORK IT OUT" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 04/LETS WORK IT OUT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 04 - VERBAL COMBINATIONS - IN OUT" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 04/VERBAL COMBINATIONS - IN OUT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 05 - THINKING AND LEARNING VERB+OBJECT+INFINITIVE" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 05/THINKING AND LEARNING VERB+OBJECT+INFINITIVE.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 05 - VERBAL COMBINATIONS BY" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 05/VERBAL COMBINATIONS BY.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 06 - LETS WORK IT OUT" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 06/LETS WORK IT OUT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 06 - VERBAL COMBINATIONS AWAY" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 06/VERBAL COMBINATIONS AWAY.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 07 - THINKING AND LEARNING - PAST PERFECT" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 07/THINKING AND LEARNING - PAST PERFECT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 07 - VERBAL COMBINATIONS - ON OFF" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 07/VERBAL COMBINATIONS - ON OFF.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 08 - LETS WORK IT OUT" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 08/LETS WORK IT OUT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 08 - VERBAL COMBINATIONS - AROUND" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 08/VERBAL COMBINATIONS - AROUND.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 09 - VERBAL COMNINATIONS - OVER" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 09/VERBAL COMNINATIONS - OVER.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 10 - LETS WORK IT OUT" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 10/LETS WORK IT OUT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 11 - THINKING AND LEARNING - WISH+PAST+PERFECT" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 11/THINKING AND LEARNING - WISH+PAST+PERFECT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Expanding Horizons - LESSON 12 - THINKING AND LEARNING - SEQUENCE OF ADJECTIVES" data-artist="Expanding Horizons" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Expanding Horizons/LESSON 12/THINKING AND LEARNING - SEQUENCE OF ADJECTIVES.mp4" data-poster="capa.png" data-free="false"></li>
	
	
	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
