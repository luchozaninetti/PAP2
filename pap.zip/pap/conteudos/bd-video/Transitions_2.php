
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Transitions 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
            
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
	
    
	

<li data-title="Transitions 2 - No Subtitles - L_01" data-artist="Transitions 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Transitions 2/INGLES/ADULTS/TRANSITIONS 2/No Subtitles/L_01.mp4" data-poster="" data-free="false"></li>
<li data-title="Transitions 2 - No Subtitles - L_03" data-artist="Transitions 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Transitions 2/INGLES/ADULTS/TRANSITIONS 2/No Subtitles/L_03.mp4" data-poster="" data-free="false"></li>
<li data-title="Transitions 2 - No Subtitles - L_05" data-artist="Transitions 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Transitions 2/INGLES/ADULTS/TRANSITIONS 2/No Subtitles/L_05.mp4" data-poster="" data-free="false"></li>
<li data-title="Transitions 2 - No Subtitles - L_07" data-artist="Transitions 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Transitions 2/INGLES/ADULTS/TRANSITIONS 2/No Subtitles/L_07.mp4" data-poster="" data-free="false"></li>
<li data-title="Transitions 2 - No Subtitles - L_09" data-artist="Transitions 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Transitions 2/INGLES/ADULTS/TRANSITIONS 2/No Subtitles/L_09.mp4" data-poster="" data-free="false"></li>
<li data-title="Transitions 2 - No Subtitles - Teaser1" data-artist="Transitions 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Transitions 2/INGLES/ADULTS/TRANSITIONS 2/No Subtitles/Teaser1.mp4" data-poster="" data-free="false"></li>
<li data-title="Transitions 2 - Subtitles - L_01_S" data-artist="Transitions 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Transitions 2/INGLES/ADULTS/TRANSITIONS 2/Subtitles/L_01_S.mp4" data-poster="" data-free="false"></li>
<li data-title="Transitions 2 - Subtitles - L_03_S" data-artist="Transitions 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Transitions 2/INGLES/ADULTS/TRANSITIONS 2/Subtitles/L_03_S.mp4" data-poster="" data-free="false"></li>
<li data-title="Transitions 2 - Subtitles - L_05_S" data-artist="Transitions 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Transitions 2/INGLES/ADULTS/TRANSITIONS 2/Subtitles/L_05_S.mp4" data-poster="" data-free="false"></li>
<li data-title="Transitions 2 - Subtitles - L_07_S" data-artist="Transitions 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Transitions 2/INGLES/ADULTS/TRANSITIONS 2/Subtitles/L_07_S.mp4" data-poster="" data-free="false"></li>
<li data-title="Transitions 2 - Subtitles - L_09_S" data-artist="Transitions 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Transitions 2/INGLES/ADULTS/TRANSITIONS 2/Subtitles/L_09_S.mp4" data-poster="" data-free="false"></li>
<li data-title="Transitions 2 - Subtitles - Teaser" data-artist="Transitions 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Transitions 2/INGLES/ADULTS/TRANSITIONS 2/Subtitles/Teaser.mp4" data-poster="" data-free="false"></li>

	
	
	
    
</ul>
</div>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139974229-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-139974229-1');
</script>
