
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teenstation 3</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
           
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
	
    
	
<li data-title="Teenstation 3 - EPISODE 01 - 01 THE BULLETIN BOARD" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 01/01 THE BULLETIN BOARD.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 01 - 02 AT THE SCIENCE CLUB" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 01/02 AT THE SCIENCE CLUB.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 01 - 03 AT THE MYSTERY CLUB" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 01/03 AT THE MYSTERY CLUB.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 02 - 01 THE MACHINE IN THE LAB" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 02/01 THE MACHINE IN THE LAB/01 THE MACHINE IN THE LAB.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 02 - 02 THE BRIGHT BALL" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 02/01 THE MACHINE IN THE LAB/02 THE BRIGHT BALL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 02 - 03 THE BASEBALL GAME" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 02/01 THE MACHINE IN THE LAB/03 THE BASEBALL GAME.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 02 - 01 THE SOUND AT THE MUSIC ROOM" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 02/02 THE SOUND AT THE MUSIC ROOM/01 THE SOUND AT THE MUSIC ROOM.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 02 - 02 THE BASEBALL GAME" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 02/02 THE SOUND AT THE MUSIC ROOM/02 THE BASEBALL GAME.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 02 - 03 THE OLD PHOTO" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 02/02 THE SOUND AT THE MUSIC ROOM/03 THE OLD PHOTO.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 03 - 01 THE TWO SPHERES" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 03/01 THE TWO SPHERES/01 THE TWO SPHERES.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 03 - 02 THE SPHERE WITH THE STAIRS" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 03/01 THE TWO SPHERES/02 THE SPHERE WITH THE STAIRS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 03 - 03 THE SPHERE WITH THE OBJECT" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 03/01 THE TWO SPHERES/03 THE SPHERE WITH THE OBJECT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 03 - 04 ACTIVITY" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 03/01 THE TWO SPHERES/04 ACTIVITY.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 03 - 01 THE GAME AND THE VORTEX" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 03/02 THE GAME AND THE VORTEX/01 THE GAME AND THE VORTEX.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 03 - 02 THE VORTEX" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 03/02 THE GAME AND THE VORTEX/02 THE VORTEX.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 03 - 03 THE INVISIBLE WALL" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 03/02 THE GAME AND THE VORTEX/03 THE INVISIBLE WALL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 03 - 04 ACTIVITY" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 03/02 THE GAME AND THE VORTEX/04 ACTIVITY.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 03 - 01 THE PLACE AND THE OBJECT" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 03/03 THE PLACE AND THE OBJECT/01 THE PLACE AND THE OBJECT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 03 - 02 THE PLACE WITH THE STAIRS" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 03/03 THE PLACE AND THE OBJECT/02 THE PLACE WITH THE STAIRS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 03 - 03 THE OBJECT IN THE LIBRARY" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 03/03 THE PLACE AND THE OBJECT/03 THE OBJECT IN THE LIBRARY.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 04 - 01 THE ROBOT AND THE RINGS" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 04/01 THE ROBOT AND THE RINGS/01 THE ROBOT AND THE RINGS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 04 - 02 BACK HOME" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 04/01 THE ROBOT AND THE RINGS/02 BACK HOME.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 04 - 03 AT THE CAFETERIA" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 04/01 THE ROBOT AND THE RINGS/03 AT THE CAFETERIA.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 04 - 01 THE WIZARD AND THE RINGS" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 04/02 THE WIZARD AND THE RINGS/01 THE WIZARD AND THE RINGS.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 04 - 02 AT THE CAFETERIA" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 04/02 THE WIZARD AND THE RINGS/02 AT THE CAFETERIA.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 04 - 03 ACTIVITY" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 04/02 THE WIZARD AND THE RINGS/03 AT THE MAGIC MOUTAIN" src="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 04 - 03 AT THE MAGIC MOUTAIN" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 04/02 THE WIZARD AND THE RINGS/03 AT THE MAGIC MOUTAIN" src="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 05 - 01 THE RINGS ARE NOT WORKING" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 05/01 THE RINGS ARE NOT WORKING/01 THE RINGS ARE NOT WORKING.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 05 - 02 THE SYMBOL AT THE LIBRARY" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 05/01 THE RINGS ARE NOT WORKING/02 THE SYMBOL AT THE LIBRARY.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 05 - 03 THE DRUMS AT THE MUSIC ROOM" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 05/01 THE RINGS ARE NOT WORKING/03 THE DRUMS AT THE MUSIC ROOM.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 05 - 01 CONCENTRATE ON WHAT" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 05/02 CONCENTRATE ON WHAT/01 CONCENTRATE ON WHAT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 05 - 02 CONCENTRATE ON THE MOMENT" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 05/02 CONCENTRATE ON WHAT/02 CONCENTRATE ON THE MOMENT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 05 - 03 CONCENTRATE ON THE OBJECT" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 05/02 CONCENTRATE ON WHAT/03 CONCENTRATE ON THE OBJECT.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 05 - 01 THE TIME CRYSTAL" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 05/03 THE TIME CRYSTAL/01 THE TIME CRYSTAL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 05 - 02 GOING THROUGH THE VORTEX" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 05/03 THE TIME CRYSTAL/02 GOING THROUGH THE VORTEX.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 05 - 03 GOING THROUGH THE WELL" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 05/03 THE TIME CRYSTAL/03 GOING THROUGH THE WELL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 06 - 01 OUT OF THE VORTEX" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 06/01 OUT OF THE VORTEX.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Teenstation 3 - EPISODE 06 - 02 OUT OF THE DOOR" data-artist="Teenstation 3" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENSTATION/Teenstation 3/EPISODE 06/02 OUT OF THE DOOR.mp4" data-poster="capa.png" data-free="false"></li>

	
	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
