
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Magic Way - Yellow</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
      
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
	
    
	<li data-title="Lesson 01 - Activity 1 - What's your name" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 01/Activity 1 - What's your name.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 02 - 01 Communication" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 02/01 Communication.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 02 - 02 Song - Head, Shoulders, Knees and Toes" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 02/02 Song - Head, Shoulders, Knees and Toes.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 02 - 03 Dance - Head, Shoulders, Knees and Toes" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 02/03 Dance - Head, Shoulders, Knees and Toes.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 03 - Activity 1 - What color" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 03/Activity 1 - What color.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 04 - 01 Communication" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 04/01 Communication.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 04 - 02 Song - Five Little Ducks" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 04/02 Song - Five Little Ducks.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 04 - 03 Dance - Five Little Ducks" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 04/03 Dance - Five Little Ducks.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 05 - Activity 1 - Let's have a picnic" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 05/Activity 1 - Let's have a picnic.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 06 - 01 Communication" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 06/01 Communication.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 06 - 02 Song - Old MacDonald had a Farm" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 06/02 Song - Old MacDonald had a Farm.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 06 - 03 Dance - Old MacDonald had a Farm" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 06/03 Dance - Old MacDonald had a Farm.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 07 - Activity 1 - Nice brown dress" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 07/Activity 1 - Nice brown dress.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 08 - 01 Communication" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 08/01 Communication.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 08 - 02 Song - Rain, Rain, Go away" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 08/02 Song - Rain, Rain, Go away.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 08 - 03 Dance - Rain, Rain, Go away" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 08/03 Dance - Rain, Rain, Go away.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 09 - Activity 1 - Happy birthday" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 09/Activity 1 - Happy birthday.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 10 - 01 Communication" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 10/01 Communication.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 10 - 02 Song - The Wheels on the Bus" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 10/02 Song - The Wheels on the Bus.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Lesson 10 - 03 Dance - The Wheels on the Bus" data-artist="Magic Way - Yellow Book" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/Magic Way - Yellow Book/Lesson 10/03 Dance - The Wheels on the Bus.mp4" data-poster="capa.png" data-free="false"></li>


	
	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
