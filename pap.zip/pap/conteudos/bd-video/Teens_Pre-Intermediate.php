
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Pre-Intermediate</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
            
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
	
    
	
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - INTRODUCTION" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/INTRODUCTION.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 01EP01 - PART 01 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 01/EP01 - PART 01 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 01EP01 - PART 02 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 01/EP01 - PART 02 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 01EP01 - PART 03 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 01/EP01 - PART 03 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 01EP01 - PART 04 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 01/EP01 - PART 04 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 02EP02 - PART 01 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 02/EP02 - PART 01 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 02EP02 - PART 02 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 02/EP02 - PART 02 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 02EP02 - PART 03 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 02/EP02 - PART 03 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 03EP03 - PART 01 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 03/EP03 - PART 01 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 03EP03 - PART 02 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 03/EP03 - PART 02 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 03EP03 - PART 03 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 03/EP03 - PART 03 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 03EP03 - PART 04 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 03/EP03 - PART 04 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 04EP04 - PART 01 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 04/EP04 - PART 01 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 04EP04 - PART 02 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 04/EP04 - PART 02 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 04EP04 - PART 03 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 04/EP04 - PART 03 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - EPISODE 04EP04 - PART 04 CL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/EPISODE 04/EP04 - PART 04 CL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - COM LEGENDA - TEN YEARS LATERTEN YEARS LATER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/COM LEGENDA/TEN YEARS LATER/TEN YEARS LATER.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - INTRODUCTION" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/INTRODUCTION.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 01EP01 - PART 01 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 01/EP01 - PART 01 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 01EP01 - PART 02 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 01/EP01 - PART 02 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 01EP01 - PART 03 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 01/EP01 - PART 03 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 01EP01 - PART 04 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 01/EP01 - PART 04 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 02EP02 - PART 01 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 02/EP02 - PART 01 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 02EP02 - PART 02 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 02/EP02 - PART 02 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 02EP02 - PART 03 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 02/EP02 - PART 03 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 03EP03 - PART 01 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 03/EP03 - PART 01 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 03EP03 - PART 02 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 03/EP03 - PART 02 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 03EP03 - PART 03 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 03/EP03 - PART 03 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 03EP03 - PART 04 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 03/EP03 - PART 04 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 04EP04 - PART 01 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 04/EP04 - PART 01 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 04EP04 - PART 02 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 04/EP04 - PART 02 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 04EP04 - PART 03 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 04/EP04 - PART 03 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - EPISODE 04EP04 - PART 04 SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/EPISODE 04/EP04 - PART 04 SL.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="TEENS PRE-INTERMEDIATE - SEM LEGENDA - TEN YEARS LATERTEN YEARS LATER SL" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS PRE-INTERMEDIATE/TEENS/01 TEENS PRE INTERMEDIATE/SEM LEGENDA/TEN YEARS LATER/TEN YEARS LATER SL.mp4" data-poster="capa.png" data-free="false"></li>
	
	
	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
