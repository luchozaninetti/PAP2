
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Elementary 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
         
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
	
    
	
<li data-title="TEENS ELEMENTARY 2 - DAY 01 - 01 DAY 1 - INTRO" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 01/01 DAY 1 - INTRO.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 01 - They go watch the romantic comedy" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 01/D1 ENDING 1/They go watch the romantic comedy.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 01 - They go watch the horror movie" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 01/D1 ENDING 2/They go watch the horror movie.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 02 - 01 DAY 2 - INTRO" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 02/01 DAY 2 - INTRO.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 02 - Ashley tells Chloe what is happening" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 02/D2 ENDING 1/Ashley tells Chloe what is happening.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 02 - Ashley says everything is fine" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 02/D2 ENDING 2/Ashley says everything is fine.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 03 - 01 DAY 3 - INTRO" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 03/01 DAY 3 - INTRO.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 03 - James is lost" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 03/D3 ENDING 1/James is lost.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 03 - James is not lost" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 03/D3 ENDING 2/James is not lost.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 04 - 01 DAY 4 - INTRO" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 04/01 DAY 4 - INTRO.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 04 - They go to the zoo" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 04/D4 ENDING 1/They go to the zoo.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 04 - They go skateboarding" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 04/D4 ENDING 2/They go skateboarding.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 05 - 01 DAY 5 - INTRO" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 05/01 DAY 5 - INTRO.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 05 - They have a picnic at the park" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 05/D5 ENDING 1/They have a picnic at the park.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 05 - They have an ice cream party" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 05/D5 ENDING 2/They have an ice cream party.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 06 - 01 DAY 6 - INTRO" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 06/01 DAY 6 - INTRO.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 06 - The girls like the idea" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 06/D6 ENDING 1/The girls like the idea.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 06 - The girls dont like the idea" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 06/D6 ENDING 2/The girls dont like the idea.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 07 - 01 DAY 7 - INTRO" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 07/01 DAY 7 - INTRO.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 07 - James likes the idea" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 07/D7 ENDING 1/James likes the idea.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 07 - James doesnt like the idea" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 07/D7 ENDING 2/James doesnt like the idea.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 08 - 01 DAY 8 - INTRO" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 08/01 DAY 8 - INTRO.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 08 - How to reuse plastic bottles" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 08/D8 ENDING 1/How to reuse plastic bottles.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 08 - How to reuse cereal boxes" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 08/D8 ENDING 2/How to reuse cereal boxes.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 09 - 01 DAY 9 - INTRO" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 09/01 DAY 9 - INTRO.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 09 - They give Ethan a chance" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 09/D9 ENDING 1/They give Ethan a chance.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 09 - They dont give Ethan a chance" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 09/D9 ENDING 2/They dont give Ethan a chance.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 10 - 01 DAY 10 - INTRO" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 10/01 DAY 10 - INTRO.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 10 - Ethan played and had an accident" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 10/D10 ENDING 1/Ethan played and had an accident.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 10 - Ethan didnt play" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 10/D10 ENDING 2/Ethan didnt play.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 11 - 01 DAY 11 - INTRO" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 11/01 DAY 11 - INTRO.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 11 - James sells the comic books" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 11/D11 ENDING 1/James sells the comic books.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 11 - James decides not to sell" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 11/D11 ENDING 2/James decides not to sell.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 12 - 01 - DAY 12 - INTRO" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 12/01 - DAY 12 - INTRO.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 12 - Ethan spent his vacation at the beach" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 12/D12 ENDING 1/Ethan spent his vacation at the beach.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>
<li data-title="TEENS ELEMENTARY 2 - DAY 12 - Ethan spent his vacation on a farm" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ELEMENTARY 2/DAY 12/D12 ENDING 2/Ethan spent his vacation on a farm.mp4" data-poster="Teens_elementary2.jpg" data-free="false"></li>

	
	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
