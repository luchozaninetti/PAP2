
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Have Fun 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
            
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
	
<li data-title="HAVE FUN 2 - LESSON 01 - MOVIE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 01/MOVIE.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 01 - PICTURE CORNER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 01/PICTURE CORNER.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 01 - YOUR TURN" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 01/YOUR TURN.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 02 - MOVIE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 02/MOVIE.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 02 - PICTURE CORNER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 02/PICTURE CORNER.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 02 - YOUR TURN" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 02/YOUR TURN.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 03 - MOVIE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 03/MOVIE.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 03 - PICTURE CORNER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 03/PICTURE CORNER.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 03 - YOUR TURN" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 03/YOUR TURN.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 04 - MOVIE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 04/MOVIE.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 04 - PICTURE CORNER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 04/PICTURE CORNER.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 04 - YOUR TURN" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 04/YOUR TURN.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 05 - MOVIE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 05/MOVIE.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 05 - PICTURE CORNER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 05/PICTURE CORNER.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 05 - YOUR TURN" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 05/YOUR TURN.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 06 - MOVIE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 06/MOVIE.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 06 - PICTURE CORNER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 06/PICTURE CORNER.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 06 - YOUR TURN" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 06/YOUR TURN.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 07 - MOVIE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 07/MOVIE.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 07 - PICTURE CORNER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 07/PICTURE CORNER.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 07 - YOUR TURN" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 07/YOUR TURN.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 08 - MOVIE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 08/MOVIE.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 08 - PICTURE CORNER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 08/PICTURE CORNER.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 08 - YOUR TURN" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 08/YOUR TURN.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 09 - MOVIE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 09/MOVIE.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 09 - PICTURE CORNER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 09/PICTURE CORNER.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 09 - YOUR TURN" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 09/YOUR TURN.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 10 - MOVIE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 10/MOVIE.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 10 - PICTURE CORNER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 10/PICTURE CORNER.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 10 - YOUR TURN" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 10/YOUR TURN.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 11 - MOVIE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 11/MOVIE.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 11 - PICTURE CORNER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 11/PICTURE CORNER.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 11 - YOUR TURN" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 11/YOUR TURN.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 12 - MOVIE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 12/MOVIE.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 12 - PICTURE CORNER" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 12/PICTURE CORNER.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="HAVE FUN 2 - LESSON 12 - YOUR TURN" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/HAVE FUN 2/HAVE FUN/02 HAVE FUN 2/LESSON 12/YOUR TURN.mp4" data-poster="capa.png" data-free="false"></li>"

	
	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
