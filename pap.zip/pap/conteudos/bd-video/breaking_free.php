<?php require_once('../../inc/nav.php'); ?>
<?php require_once('../../inc/Medoo.php'); ?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Video.js CSS -->
    <link href="https://vjs.zencdn.net/8.5.2/video-js.css" rel="stylesheet" />

    <!-- Favicon e ícones -->
    <link rel="shortcut icon" href="../../images/icone.ico" type="image/x-icon" />
    <link rel="icon" href="../../images/icone.ico" sizes="192x192" />
    <link rel="apple-touch-icon" sizes="180x180" href="../../images/icone.ico" />

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css" />

    <!-- Bloqueio do clique direito -->
    <script>
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
            alert('Código protegido!');
        });
    </script>
</head>
<body>

<div class="container my-4">

    <!-- Logo no topo -->
    <div class="text-center mb-4">
        <img src="../../images/logo.png" alt="Logo" class="img-fluid" style="max-height: 80px" />
    </div>

    <!-- Título centralizado -->
    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Breaking Free</h4>
    </div>

    <!-- Botão Voltar -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
    </div>

    <!-- Player de vídeo -->
    <div class="mb-4">
        <video
            id="videoPlayer"
            class="video-js vjs-fluid vjs-default-skin shadow-sm rounded"
            controls
            preload="auto"
            poster="../../images/logo.png"
            data-setup='{}'>
            <source src="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Breaking Free/INTRODUCTION.mp4" type="video/mp4" />
            Seu navegador não suporta vídeo HTML5.
        </video>
    </div>

    <!-- Lista de vídeos -->
    <div class="list-group shadow-sm rounded">
        <?php
        $videos = [
            ["INTRODUCTION", "INTRODUCTION"],
            ["EPISODE 01 - FIRST DAY AT COLLEGE/01 EPISODE 1 - FIRST DAY AT COLLEGE", "EPISODE 01 - FIRST DAY AT COLLEGE"],
            ["EPISODE 01 - FIRST DAY AT COLLEGE/ANIMATION DRAWING COURSE/ANIMATION DRAWING COURSE", "ANIMATION DRAWING COURSE"],
            ["EPISODE 01 - FIRST DAY AT COLLEGE/PHOTOGRAPHY COURSE/PHOTOGRAPHY COURSE", "PHOTOGRAPHY COURSE"],
            ["EPISODE 02 - TWO INVITATIONS/01 EPISODE 2 - TWO INVITATIONS", "EPISODE 02 - TWO INVITATIONS"],
            ["EPISODE 02 - TWO INVITATIONS/DINNER/DINNER", "DINNER"],
            ["EPISODE 02 - TWO INVITATIONS/JAZZ CONCERT/JAZZ CONCERT", "JAZZ CONCERT"],
            ["EPISODE 03 - A BIG SURPRISE/01 EPISODE 3 - A BIG SURPRISE", "EPISODE 03 - A BIG SURPRISE"],
            ["EPISODE 03 - A BIG SURPRISE/NO - AT THE MALL/NO - AT THE MALL", "NO - AT THE MALL"],
            ["EPISODE 03 - A BIG SURPRISE/YES - AT THE CD STORE/YES - AT THE CD STORE", "YES - AT THE CD STORE"],
            ["EPISODE 04 - A WEEKEND WITH ANNA AND HENRY/01 EPISODE 4 - A WEEKEND WITH ANNA AND HENRY", "EPISODE 04 - A WEEKEND WITH ANNA AND HENRY"],
            ["EPISODE 04 - A WEEKEND WITH ANNA AND HENRY/A TRIP WITH FRIENDS/A TRIP WITH FRIENDS", "A TRIP WITH FRIENDS"],
            ["EPISODE 04 - A WEEKEND WITH ANNA AND HENRY/STAY HOME/STAY HOME", "STAY HOME"]
        ];

        $first = true;
        foreach ($videos as $video) {
            $path = $video[0];
            $label = $video[1];
            $url = "https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Breaking Free/{$path}.mp4";
            $activeClass = $first ? ' active' : '';
            echo '<button class="list-group-item list-group-item-action' . $activeClass . '" onclick="trocarVideo(\'' . $url . '\', this)">' . htmlspecialchars($label) . '</button>';
            $first = false;
        }
        ?>
    </div>

</div>

<?php require_once('../../inc/rodape.php'); ?>

<!-- Video.js -->
<script src="https://vjs.zencdn.net/8.5.2/video.min.js"></script>

<!-- Bootstrap Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Script de troca de vídeos -->
<script src="../../js/videos.js"></script>

</body>
</html>
