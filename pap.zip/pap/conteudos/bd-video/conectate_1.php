<?php require_once('../../inc/nav.php'); ?>
<?php require_once('../../inc/Medoo.php'); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Video.js CSS -->
    <link href="https://vjs.zencdn.net/8.5.2/video-js.css" rel="stylesheet" />

    <!-- Favicon e ícones -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192" />
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg" />

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css" />
</head>
<body>

<div class="container my-4">
    <!-- Logo no topo -->
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px" />
    </div>

    <!-- Título centralizado -->
    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Conéctate 1</h4>
    </div>

    <!-- Botão Voltar -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
    </div>

    <!-- Player de vídeo centralizado e responsivo -->
    <div class="mb-4">
        <video
            id="videoPlayer"
            class="video-js vjs-fluid vjs-default-skin shadow-sm rounded"
            controls
            preload="auto"
            poster="../../img/logo.jpg"
            data-setup='{}'>
            <source src="https://www.dmzi.com.br/fisk-online/dados/VIDEO/ESPANOL/CONECTATE/CONECTATE 1/COM LEGENDA/PROGRAMA 01.mp4" type="video/mp4" />
            Seu navegador não suporta vídeo HTML5.
        </video>
    </div>

    <!-- Lista de vídeos com botões Bootstrap -->
    <div class="list-group shadow-sm rounded">
        <button class="list-group-item list-group-item-action" onclick="trocarVideo('https://www.dmzi.com.br/fisk-online/dados/VIDEO/ESPANOL/CONECTATE/CONECTATE 1/COM LEGENDA/PROGRAMA 01.mp4')">
            Conéctate 1 - Com Legenda - Programa 01
        </button>
        <button class="list-group-item list-group-item-action" onclick="trocarVideo('https://www.dmzi.com.br/fisk-online/dados/VIDEO/ESPANOL/CONECTATE/CONECTATE 1/COM LEGENDA/PROGRAMA 02.mp4')">
            Conéctate 1 - Com Legenda - Programa 02
        </button>
        <button class="list-group-item list-group-item-action" onclick="trocarVideo('https://www.dmzi.com.br/fisk-online/dados/VIDEO/ESPANOL/CONECTATE/CONECTATE 1/SEM LEGENDA/PROGRAMA 01.mp4')">
            Conéctate 1 - Sem Legenda - Programa 01
        </button>
      
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>

<!-- Video.js JS -->
<script src="https://vjs.zencdn.net/8.5.2/video.min.js"></script>

<script src="../../js/videos.js"></script>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
