
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Playground 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
    
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
	
    
	
<li data-title="PLAYGROUND 2 - 01  Episode 01 Final.mp4 - 01  Episode 01 Final" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/PLAYGROUND 2/01  Episode 01 Final.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="PLAYGROUND 2 - 02 Episode 02 Final.mp4 - 02 Episode 02 Final" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/PLAYGROUND 2/02 Episode 02 Final.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="PLAYGROUND 2 - 03 Episode 03 Final.mp4 - 03 Episode 03 Final" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/PLAYGROUND 2/03 Episode 03 Final.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="PLAYGROUND 2 - 04 Episode 04 Final.mp4 - 04 Episode 04 Final" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/PLAYGROUND 2/04 Episode 04 Final.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="PLAYGROUND 2 - 05 Episode 05 Final.mp4 - 05 Episode 05 Final" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/PLAYGROUND 2/05 Episode 05 Final.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="PLAYGROUND 2 - 06 Episode 06 Final.mp4 - 06 Episode 06 Final" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/PLAYGROUND 2/06 Episode 06 Final.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="PLAYGROUND 2 - 07 Episode 07 Final.mp4 - 07 Episode 07 Final" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/PLAYGROUND 2/07 Episode 07 Final.mp4" data-poster="capa.png" data-free="false"></li>"
<li data-title="PLAYGROUND 2 - 08 Episode 08 Final.mp4 - 08 Episode 08 Final" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/INFANTIL/PLAYGROUND 2/08 Episode 08 Final.mp4" data-poster="capa.png" data-free="false"></li>"

	
	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
