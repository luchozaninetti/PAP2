<?php require_once('../../inc/nav.php'); ?>
<?php require_once('../../inc/Medoo.php'); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <title>Fisk - Essentials 1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Video.js CSS -->
    <link href="https://vjs.zencdn.net/8.5.2/video-js.css" rel="stylesheet" />

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192" />
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg" />

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css" />
</head>
<body>

<div class="container my-4">

    <!-- Logo no topo -->
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px" />
    </div>

    <!-- Título centralizado -->
    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Essentials 1</h4>
    </div>

    <!-- Botão Voltar -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
    </div>

    <!-- Player de vídeo único -->
    <div class="mb-4">
        <video
            id="videoPlayer"
            class="video-js vjs-fluid vjs-default-skin shadow-sm rounded"
            controls
            preload="auto"
            poster="capa.png"
            data-setup='{}'>
            <source src="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Essentials 1/No Subtitles/The Smart Pack - Teaser.mp4" type="video/mp4" />
            Seu navegador não suporta vídeo HTML5.
        </video>
    </div>

    <!-- Lista de vídeos -->
    <div class="list-group shadow-sm rounded" style="max-width: 600px; margin: 0 auto;">
        <?php
        $videos = [
            // Sem legendas
            "No Subtitles/The Smart Pack - Teaser.mp4" => "The Smart Pack - Teaser (No Subtitles)",
            "No Subtitles/Episode 1/01 Meet Adam and Holly.mp4" => "01 Meet Adam and Holly (No Subtitles)",
            "No Subtitles/Episode 2/02 How I Met Holly.mp4" => "02 How I Met Holly (No Subtitles)",
            "No Subtitles/Episode 3/03 I'm Not A Fitness Freak At All.mp4" => "03 I'm Not A Fitness Freak At All (No Subtitles)",
            "No Subtitles/Episode 4/04 - Studying Abroad.mp4" => "04 - Studying Abroad (No Subtitles)",
            "No Subtitles/Episode 5/05 We Always Have Fun.mp4" => "05 We Always Have Fun (No Subtitles)",

            // Com legendas
            "Subtitles/The Smart Pack - Teaser - Subtitles.mp4" => "The Smart Pack - Teaser - Subtitles",
            "Subtitles/Episode 1/01 Meet Adam and Holly - Subtitles.mp4" => "01 Meet Adam and Holly - Subtitles",
            "Subtitles/Episode 2/Episode 2 - How I Met Holly - Subtitles.mp4" => "Episode 2 - How I Met Holly - Subtitles",
            "Subtitles/Episode 3/03 - I'm Not A Fitness Freak At All - Subtitles.mp4" => "03 - I'm Not A Fitness Freak At All - Subtitles",
            "Subtitles/Episode 4/04 - Studying Abroad - Subtitltes.mp4" => "04 - Studying Abroad - Subtitles",
            "Subtitles/Episode 5/05 We Always Have Fun - Subtitles.mp4" => "05 We Always Have Fun - Subtitles",
        ];

        $baseURL = "https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/ADULTOS/Essentials 1/";

        $first = true;
        foreach ($videos as $path => $label) {
            $url = $baseURL . $path;
            $activeClass = $first ? ' active' : '';
            echo '<button class="list-group-item list-group-item-action' . $activeClass . '" onclick="trocarVideo(\'' . $url . '\', this)">' . htmlspecialchars($label) . '</button>';
            $first = false;
        }
        ?>
    </div>

</div>

<script src="../../js/videos.js"></script>

<?php require_once('../../inc/rodape.php'); ?>

<!-- Video.js JS -->
<script src="https://vjs.zencdn.net/8.5.2/video.min.js"></script>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
