
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Saison 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
           
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
<li data-title="Saison 2 - 10_U9_QuitterLaVille_VO" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/10_U9_QuitterLaVille_VO.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 10_U9_QuitterLaVille_VOST" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/10_U9_QuitterLaVille_VOST.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 1_U0_LaFrancophonie" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/1_U0_LaFrancophonie.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 2_U1_Rencontres_VO" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/2_U1_Rencontres_VO.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 2_U1_Rencontres_VOST" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/2_U1_Rencontres_VOST.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 3_U2_Reseaux_VO" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/3_U2_Reseaux_VO.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 3_U2_Reseaux_VOST" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/3_U2_Reseaux_VOST.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 4_U3_LaPresseNumerique" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/4_U3_LaPresseNumerique.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 5_U4_CEtaitMieuxAvant" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/5_U4_CEtaitMieuxAvant.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 6_U5_AvantLeDepart_VO" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/6_U5_AvantLeDepart_VO.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 6_U5_AvantLeDepart_VOST" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/6_U5_AvantLeDepart_VOST.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 7_U6_L-Alimation" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/7_U6_L-Alimation.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 8_U7_ApercuDeLaSociete_VO" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/8_U7_ApercuDeLaSociete_VO.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 8_U7_ApercuDeLaSociete_VOST" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/8_U7_ApercuDeLaSociete_VOST.mp4" data-poster="capa.png" data-free="false"></li>
<li data-title="Saison 2 - 9_U8_UneAppliSolidaire" data-artist="Saison 2" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/FRANCES/Saison 2/9_U8_UneAppliSolidaire.mp4" data-poster="capa.png" data-free="false"></li>

	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
