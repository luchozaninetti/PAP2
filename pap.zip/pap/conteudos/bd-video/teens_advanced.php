
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Advanced</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
          
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
	
    
	
<li data-title="TEENS ADVANCED - EPISODE 01 - 01 - AUSTRALIA" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 01/01 COM LEGENDA/01 - AUSTRALIA.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 01 - 02 - GUINESS WORLD RECORDS" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 01/01 COM LEGENDA/02 - GUINESS WORLD RECORDS.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 01 - 01 - AUSTRALIA" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 01/02 SEM LEGENDA/01 - AUSTRALIA.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 01 - 02 - GUINESS WORLD RECORDS" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 01/02 SEM LEGENDA/02 - GUINESS WORLD RECORDS.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 01 - 01 - AUSTRALIA" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 01/03 QUESTIONS/01 - AUSTRALIA.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 01 - 02 - GUINESS WORLD RECORDS" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 01/03 QUESTIONS/02 - GUINESS WORLD RECORDS.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 02 - 01 - TATTOOS" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 02/01 COM LEGENDA/01 - TATTOOS.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 02 - 02 - MARTIAL ARTS" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 02/01 COM LEGENDA/02 - MARTIAL ARTS.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 02 - 01 - TATTOOS" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 02/02 SEM LEGENDA/01 - TATTOOS.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 02 - 02 - MARTIAL ARTS" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 02/02 SEM LEGENDA/02 - MARTIAL ARTS.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 02 - 01 - TATTOOS" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 02/03 QUESTIONS/01 - TATTOOS.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 02 - 02 - MARTIAL ARTS" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 02/03 QUESTIONS/02 - MARTIAL ARTS.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 03 - 01 - HORROR MOVIES" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 03/01 COM LEGENDA/01 - HORROR MOVIES.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 03 - 02 - SLEEPING" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 03/01 COM LEGENDA/02 - SLEEPING.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 03 - 01 - HORROR MOVIES" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 03/02 SEM LEGENDA/01 - HORROR MOVIES.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 03 - 02 - SLEEPING" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 03/02 SEM LEGENDA/02 - SLEEPING.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 03 - 01 - HORROR MOVIES" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 03/03 QUESTIONS/01 - HORROR MOVIES.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 03 - 02 - SLEEPING" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 03/03 QUESTIONS/02 - SLEEPING.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 04 - 01 - GI JOE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 04/01 COM LEGENDA/01 - GI JOE.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 04 - 02 - HEALTHY EATING FOR TEENAGERS" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 04/01 COM LEGENDA/02 - HEALTHY EATING FOR TEENAGERS.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
<li data-title="TEENS ADVANCED - EPISODE 04 - 01 - GI JOE" data-artist="INFANTIL" data-type="m4v" data-url="https://www.dmzi.com.br/fisk-online/dados/VIDEO/INGLES/TEENS/TEENS ADVANCED/EPISODE 04/02 SEM LEGENDA/01 - GI JOE.mp4" data-poster="teens_advanced.jpg" data-free="false"></li>
	
	
	
	
    
      </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
