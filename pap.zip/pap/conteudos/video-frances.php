<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>FISK - Francês - Vídeos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- CSS personalizado -->
    <link href="../css/estilos.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- Ícones -->
    <link rel="shortcut icon" href="../images/icone.ico" type="image/x-icon" />
    <link rel="icon" href="../images/icone.ico" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../images/icone.ico">

 
</head>
<body>

<?php require_once('../inc/nav.php'); ?>
<?php require_once('../inc/banner.php'); ?>

<main class="container mt-4 mb-5">

    <section class="text-center mb-5">
        <h1 class="display-5 fw-bold">Vídeos de Francês</h1>
        <p class="text-muted fs-5">Escolha a temporada disponível para assistir aos vídeos.</p>
    </section>

    <section class="row justify-content-center g-4">
        <div class="col-md-6 col-lg-4">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h5 class="card-title"><i class="fa-solid fa-film text-primary me-2"></i>Saison 1</h5>
                    <a href="bd-video/saison_1.php" class="btn btn-primary w-100 mt-3">Assistir</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 col-lg-4">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h5 class="card-title"><i class="fa-solid fa-film text-success me-2"></i>Saison 2</h5>
                    <a href="bd-video/saison_2.php" class="btn btn-success w-100 mt-3">Assistir</a>
                </div>
            </div>
        </div>
    </section>

</main>

<?php require_once('../inc/rodape.php'); ?>

<!-- Bootstrap Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139974229-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-139974229-1');
</script>

</body>
</html>
