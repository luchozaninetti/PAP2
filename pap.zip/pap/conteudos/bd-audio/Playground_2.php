
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Playground 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">

            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="lesson 01 - 01 L01.P006 At home" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 01/01 L01.P006 At home.mp3" data-free="false"></li>
<li data-title="lesson 01 - 02 L01.007 Come and Talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 01/02 L01.007 Come and Talk.mp3" data-free="false"></li>
<li data-title="lesson 01 - 03 L01.P007 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 01/03 L01.P007 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 01 - 04 L01.P008 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 01/04 L01.P008 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 01 - 05 L01.P009 What's new (6)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 01/05 L01.P009 What's new (6).mp3" data-free="false"></li>
<li data-title="lesson 01 - 06 L01.P009 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 01/06 L01.P009 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 01 - 07 L01.P010 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 01/07 L01.P010 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 02 - 01 L02.P010 At the park" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 02/01 L02.P010 At the park.mp3" data-free="false"></li>
<li data-title="lesson 02 - 02 L02.P011 Come and Talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 02/02 L02.P011 Come and Talk.mp3" data-free="false"></li>
<li data-title="lesson 02 - 03 L02.P011 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 02/03 L02.P011 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 02 - 04 L02.P012 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 02/04 L02.P012 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 02 - 05 L02.P013 What's new (5)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 02/05 L02.P013 What's new (5).mp3" data-free="false"></li>
<li data-title="lesson 02 - 06 L02.P013 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 02/06 L02.P013 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 02 - 07 L02.P013 Listen up (2)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 02/07 L02.P013 Listen up (2).mp3" data-free="false"></li>
<li data-title="lesson 02 - 08 L02.P016 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 02/08 L02.P016 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 03 - 01 L03.P014 At the playground" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 03/01 L03.P014 At the playground.mp3" data-free="false"></li>
<li data-title="lesson 03 - 02 L03.P014 New words" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 03/02 L03.P014 New words.mp3" data-free="false"></li>
<li data-title="lesson 03 - 03 L03.P015 Come and Talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 03/03 L03.P015 Come and Talk.mp3" data-free="false"></li>
<li data-title="lesson 03 - 04 L03.P15 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 03/04 L03.P15 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 03 - 05 L03.P016 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 03/05 L03.P016 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 03 - 06 L03.P016 What's new (5)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 03/06 L03.P016 What's new (5).mp3" data-free="false"></li>
<li data-title="lesson 03 - 07 L03.P017 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 03/07 L03.P017 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 03 - 08 L03.P022 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 03/08 L03.P022 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 04 - 01 L04.P018 At the park" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 04/01 L04.P018 At the park.mp3" data-free="false"></li>
<li data-title="lesson 04 - 02 L04.P019 Come and Talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 04/02 L04.P019 Come and Talk.mp3" data-free="false"></li>
<li data-title="lesson 04 - 03 L04.P019 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 04/03 L04.P019 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 04 - 04 L04.P020 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 04/04 L04.P020 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 04 - 05 L04.P021 What's new (5)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 04/05 L04.P021 What's new (5).mp3" data-free="false"></li>
<li data-title="lesson 04 - 06 L04.P021 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 04/06 L04.P021 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 04 - 07 L04.P021 Listen up (2)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 04/07 L04.P021 Listen up (2).mp3" data-free="false"></li>
<li data-title="lesson 04 - 08 L04.P028 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 04/08 L04.P028 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 05 - 01 L05.P022 At the playground" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 05/01 L05.P022 At the playground.mp3" data-free="false"></li>
<li data-title="lesson 05 - 02 L05.P022 New words" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 05/02 L05.P022 New words.mp3" data-free="false"></li>
<li data-title="lesson 05 - 03 L05.P023 Come and Talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 05/03 L05.P023 Come and Talk.mp3" data-free="false"></li>
<li data-title="lesson 05 - 04 L05.P023 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 05/04 L05.P023 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 05 - 05 L05.P024 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 05/05 L05.P024 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 05 - 06 L05.P024 What's new (5)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 05/06 L05.P024 What's new (5).mp3" data-free="false"></li>
<li data-title="lesson 05 - 07 L05.P025 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 05/07 L05.P025 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 05 - 08 L05.P034 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 05/08 L05.P034 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 06 - 01 L06.P026 At the park" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 06/01 L06.P026 At the park.mp3" data-free="false"></li>
<li data-title="lesson 06 - 02 L06.P027 Come and Talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 06/02 L06.P027 Come and Talk.mp3" data-free="false"></li>
<li data-title="lesson 06 - 03 L06.P027 Remember this (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 06/03 L06.P027 Remember this (1).mp3" data-free="false"></li>
<li data-title="lesson 06 - 04 L06.P029 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 06/04 L06.P029 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 06 - 05 L06.P042 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 06/05 L06.P042 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 07 - 01 L07.P030 At home" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 07/01 L07.P030 At home.mp3" data-free="false"></li>
<li data-title="lesson 07 - 02 L07.P030 New words" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 07/02 L07.P030 New words.mp3" data-free="false"></li>
<li data-title="lesson 07 - 03 L07.P031 Come and talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 07/03 L07.P031 Come and talk.mp3" data-free="false"></li>
<li data-title="lesson 07 - 04 L07.P031 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 07/04 L07.P031 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 07 - 05 L07.P032 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 07/05 L07.P032 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 07 - 06 L07.P033 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 07/06 L07.P033 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 07 - 07 L07.P048 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 07/07 L07.P048 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 08 - 01 L08.P034 At home" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 08/01 L08.P034 At home.mp3" data-free="false"></li>
<li data-title="lesson 08 - 02 L08.P034 New words" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 08/02 L08.P034 New words.mp3" data-free="false"></li>
<li data-title="lesson 08 - 03 L08.P035 Come and talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 08/03 L08.P035 Come and talk.mp3" data-free="false"></li>
<li data-title="lesson 08 - 04 L08.P035 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 08/04 L08.P035 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 08 - 05 L08.P036 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 08/05 L08.P036 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 08 - 06 L08.P037 What's new (6)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 08/06 L08.P037 What's new (6).mp3" data-free="false"></li>
<li data-title="lesson 08 - 07 L08.P037 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 08/07 L08.P037 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 08 - 08 L08.P037 Listen up (2)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 08/08 L08.P037 Listen up (2).mp3" data-free="false"></li>
<li data-title="lesson 08 - 09 L08.P054 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 08/09 L08.P054 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 09 - 01 L09.P038 At home" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 09/01 L09.P038 At home.mp3" data-free="false"></li>
<li data-title="lesson 09 - 02 L09.P039 Come and talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 09/02 L09.P039 Come and talk.mp3" data-free="false"></li>
<li data-title="lesson 09 - 03 L09.P039 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 09/03 L09.P039 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 09 - 04 L09.P040 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 09/04 L09.P040 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 09 - 05 L09.P041 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 09/05 L09.P041 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 09 - 06 L09.P060 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 09/06 L09.P060 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 10 - 01 L10.P042 At the treehouse" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 10/01 L10.P042 At the treehouse.mp3" data-free="false"></li>
<li data-title="lesson 10 - 02 L10.P042 New words" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 10/02 L10.P042 New words.mp3" data-free="false"></li>
<li data-title="lesson 10 - 03 L10.P043 Come and talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 10/03 L10.P043 Come and talk.mp3" data-free="false"></li>
<li data-title="lesson 10 - 04 L10.P043 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 10/04 L10.P043 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 10 - 05 L10.P044 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 10/05 L10.P044 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 10 - 06 L10.P044 What's new (5)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 10/06 L10.P044 What's new (5).mp3" data-free="false"></li>
<li data-title="lesson 10 - 07 L10.P045 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 10/07 L10.P045 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 10 - 08 L10.P045 Listen up (2)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 10/08 L10.P045 Listen up (2).mp3" data-free="false"></li>
<li data-title="lesson 10 - 09 L10.P066 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 10/09 L10.P066 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 11 - 01 L11.P046 At the playground" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 11/01 L11.P046 At the playground.mp3" data-free="false"></li>
<li data-title="lesson 11 - 02 L11.P046 New words" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 11/02 L11.P046 New words.mp3" data-free="false"></li>
<li data-title="lesson 11 - 03 L11.P047 Come and talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 11/03 L11.P047 Come and talk.mp3" data-free="false"></li>
<li data-title="lesson 11 - 04 L11.P047 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 11/04 L11.P047 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 11 - 05 L11.P048 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 11/05 L11.P048 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 11 - 06 L11.P049 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 11/06 L11.P049 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 11 - 07 L11.P072 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 11/07 L11.P072 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 12 - 01 L12.P050 At the treehouse" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 12/01 L12.P050 At the treehouse.mp3" data-free="false"></li>
<li data-title="lesson 12 - 02 L12.P051 Come and talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 12/02 L12.P051 Come and talk.mp3" data-free="false"></li>
<li data-title="lesson 12 - 03 L12.051 Remember this (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 12/03 L12.051 Remember this (1).mp3" data-free="false"></li>
<li data-title="lesson 12 - 04 L12.P053 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 12/04 L12.P053 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 12 - 05 L12.P078 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 12/05 L12.P078 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 13 - 01 L13.P054 At the park" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 13/01 L13.P054 At the park.mp3" data-free="false"></li>
<li data-title="lesson 13 - 02 L13.P055 Come and talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 13/02 L13.P055 Come and talk.mp3" data-free="false"></li>
<li data-title="lesson 13 - 03 L13.P055 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 13/03 L13.P055 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 13 - 04 L13.P056 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 13/04 L13.P056 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 13 - 05 L13.P057 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 13/05 L13.P057 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 13 - 06 L13.P084 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 13/06 L13.P084 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 14 - 01 L14.P058 At the park" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 14/01 L14.P058 At the park.mp3" data-free="false"></li>
<li data-title="lesson 14 - 02 L14.P059 Come and talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 14/02 L14.P059 Come and talk.mp3" data-free="false"></li>
<li data-title="lesson 14 - 03 L14.P059 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 14/03 L14.P059 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 14 - 04 L14.P060 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 14/04 L14.P060 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 14 - 05 L14.P061 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 14/05 L14.P061 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 14 - 06 L14.P061 Listen up (2)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 14/06 L14.P061 Listen up (2).mp3" data-free="false"></li>
<li data-title="lesson 14 - 07 L14.P090 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 14/07 L14.P090 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 15 - 01 L15.P062 At the park" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 15/01 L15.P062 At the park.mp3" data-free="false"></li>
<li data-title="lesson 15 - 02 L15.P063 Come and talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 15/02 L15.P063 Come and talk.mp3" data-free="false"></li>
<li data-title="lesson 15 - 03 L15.P063 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 15/03 L15.P063 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 15 - 04 L15.P064 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 15/04 L15.P064 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 15 - 05 L15.P064 What's new (5)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 15/05 L15.P064 What's new (5).mp3" data-free="false"></li>
<li data-title="lesson 15 - 06 L15.P065 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 15/06 L15.P065 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 15 - 07 L15.P096 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 15/07 L15.P096 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 16 - 01 L16.P066 At the treehouse" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 16/01 L16.P066 At the treehouse.mp3" data-free="false"></li>
<li data-title="lesson 16 - 02 L16.P067 Come and talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 16/02 L16.P067 Come and talk.mp3" data-free="false"></li>
<li data-title="lesson 16 - 03 L16.P067 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 16/03 L16.P067 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 16 - 04 L16.P068 What's new (3)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 16/04 L16.P068 What's new (3).mp3" data-free="false"></li>
<li data-title="lesson 16 - 05 L16.P069 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 16/05 L16.P069 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 16 - 06 L16.P069 Listen up (2)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 16/06 L16.P069 Listen up (2).mp3" data-free="false"></li>
<li data-title="lesson 16 - 07 L16.P102 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 16/07 L16.P102 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 17 - 01 L17.P070 At the park" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 17/01 L17.P070 At the park.mp3" data-free="false"></li>
<li data-title="lesson 17 - 02 L17.P071 Come and talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 17/02 L17.P071 Come and talk.mp3" data-free="false"></li>
<li data-title="lesson 17 - 03 L17.P071 What's new (1)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 17/03 L17.P071 What's new (1).mp3" data-free="false"></li>
<li data-title="lesson 17 - 04 L17.P073 What's new (5)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 17/04 L17.P073 What's new (5).mp3" data-free="false"></li>
<li data-title="lesson 17 - 05 L17.P073 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 17/05 L17.P073 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 17 - 06 L17.P108 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 17/06 L17.P108 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="lesson 18 - 01 L18.P074 At the playground" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 18/01 L18.P074 At the playground.mp3" data-free="false"></li>
<li data-title="lesson 18 - 02 L18.P075 Come and talk" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 18/02 L18.P075 Come and talk.mp3" data-free="false"></li>
<li data-title="lesson 18 - 03 L18.P076 Remember this (2)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 18/03 L18.P076 Remember this (2).mp3" data-free="false"></li>
<li data-title="lesson 18 - 04 L18.P077 Remember this (4)" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 18/04 L18.P077 Remember this (4).mp3" data-free="false"></li>
<li data-title="lesson 18 - 05 L18.P077 Listen up" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 18/05 L18.P077 Listen up.mp3" data-free="false"></li>
<li data-title="lesson 18 - 06 L18.P114 Act. Book - Listen to this" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/lesson 18/06 L18.P114 Act. Book - Listen to this.mp3" data-free="false"></li>
<li data-title="songs - 01 P081 My Bonnie" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/songs/01 P081 My Bonnie.mp3" data-free="false"></li>
<li data-title="songs - 02 P083 Twinkle twinkle little star" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/songs/02 P083 Twinkle twinkle little star.mp3" data-free="false"></li>
<li data-title="songs - 03 P085 My Toys" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/songs/03 P085 My Toys.mp3" data-free="false"></li>
<li data-title="songs - 04 The alphabet song" data-artist="Playground 2 - New Edition" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 2 - New Edition/songs/04 The alphabet song.mp3" data-free="false"></li>


	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
