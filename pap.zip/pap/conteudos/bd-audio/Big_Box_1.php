
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Big Box 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
           
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
<li data-title="01 - Lesson 01, page 06, STORY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/01 - Lesson 01, page 06, STORY.mp3" data-free="false"></li>
<li data-title="02 - Lesson 01, page 07, LISTEN, POINT, AND SAY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/02 - Lesson 01, page 07, LISTEN, POINT, AND SAY.mp3" data-free="false"></li>
<li data-title="03 - Lesson 01, page 07, LISTEN AND CIRCLE" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/03 - Lesson 01, page 07, LISTEN AND CIRCLE.mp3" data-free="false"></li>
<li data-title="04 - Lesson 01, page 09, LISTEN AND COLOR" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/04 - Lesson 01, page 09, LISTEN AND COLOR.mp3" data-free="false"></li>
<li data-title="05 - Lesson 02, page 12, STORY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/05 - Lesson 02, page 12, STORY.mp3" data-free="false"></li>
<li data-title="06 - Lesson 02, page 13, LISTEN, POINT, AND SAY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/06 - Lesson 02, page 13, LISTEN, POINT, AND SAY.mp3" data-free="false"></li>
<li data-title="07 - Lesson 02, page 13, LISTEN AND CROSS" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/07 - Lesson 02, page 13, LISTEN AND CROSS.mp3" data-free="false"></li>
<li data-title="08 - Lesson 02, page 16, LISTEN AND CIRCLE" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/08 - Lesson 02, page 16, LISTEN AND CIRCLE.mp3" data-free="false"></li>
<li data-title="09 - Lesson 03, page 18, STORY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/09 - Lesson 03, page 18, STORY.mp3" data-free="false"></li>
<li data-title="10 - Lesson 03, page 19, LISTEN, CIRCLE, AND COLOR" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/10 - Lesson 03, page 19, LISTEN, CIRCLE, AND COLOR.mp3" data-free="false"></li>
<li data-title="11 - Lesson 03, page 21, LISTEN AND CIRCLE" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/11 - Lesson 03, page 21, LISTEN AND CIRCLE.mp3" data-free="false"></li>
<li data-title="12 - Lesson 04, page 24, STORY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/12 - Lesson 04, page 24, STORY.mp3" data-free="false"></li>
<li data-title="13 - Lesson 04, page 25, LISTEN, POINT, AND SAY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/13 - Lesson 04, page 25, LISTEN, POINT, AND SAY.mp3" data-free="false"></li>
<li data-title="14 - Lesson 04, page 25, LISTEN AND CIRCLE" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/14 - Lesson 04, page 25, LISTEN AND CIRCLE.mp3" data-free="false"></li>
<li data-title="15 - Lesson 04, page 26, LISTEN, STICK, AND SAY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/15 - Lesson 04, page 26, LISTEN, STICK, AND SAY.mp3" data-free="false"></li>
<li data-title="16 - Lesson 05, page 30, STORY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/16 - Lesson 05, page 30, STORY.mp3" data-free="false"></li>
<li data-title="17 - Lesson 05, page 31, LISTEN, POINT, AND SAY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/17 - Lesson 05, page 31, LISTEN, POINT, AND SAY.mp3" data-free="false"></li>
<li data-title="18 - Lesson 05, page 31, LISTEN AND CIRCLE" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/18 - Lesson 05, page 31, LISTEN AND CIRCLE.mp3" data-free="false"></li>
<li data-title="19 - Lesson 06, page 36, STORY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/19 - Lesson 06, page 36, STORY.mp3" data-free="false"></li>
<li data-title="20 - Lesson 06, page 37, LISTEN, CROSS, AND SAY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/20 - Lesson 06, page 37, LISTEN, CROSS, AND SAY.mp3" data-free="false"></li>
<li data-title="21 - Lesson 06, page 37, LISTEN AND TOUCH" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/21 - Lesson 06, page 37, LISTEN AND TOUCH.mp3" data-free="false"></li>
<li data-title="22 - Lesson 07, page 42, STORY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/22 - Lesson 07, page 42, STORY.mp3" data-free="false"></li>
<li data-title="23 - Lesson 07, page 43, LISTEN, SAY, AND COLOR" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/23 - Lesson 07, page 43, LISTEN, SAY, AND COLOR.mp3" data-free="false"></li>
<li data-title="24 - Lesson 08, page 48, STORY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/24 - Lesson 08, page 48, STORY.mp3" data-free="false"></li>
<li data-title="25 - Lesson 08, page 49, LISTEN, POINT, AND SAY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/25 - Lesson 08, page 49, LISTEN, POINT, AND SAY.mp3" data-free="false"></li>
<li data-title="26 - Lesson 08, page 52, LISTEN AND CIRCLE" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/26 - Lesson 08, page 52, LISTEN AND CIRCLE.mp3" data-free="false"></li>
<li data-title="27 - Lesson 09, page 54, STORY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/27 - Lesson 09, page 54, STORY.mp3" data-free="false"></li>
<li data-title="28 - Lesson 09, page 55, LISTEN, POINT, AND SAY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/28 - Lesson 09, page 55, LISTEN, POINT, AND SAY.mp3" data-free="false"></li>
<li data-title="29 - Lesson 09, page 58, LISTEN, POINT, AND SAY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/29 - Lesson 09, page 58, LISTEN, POINT, AND SAY.mp3" data-free="false"></li>
<li data-title="30 - Lesson 10, page 60, STORY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/30 - Lesson 10, page 60, STORY.mp3" data-free="false"></li>
<li data-title="31 - Lesson 10, page 61, LISTEN, POINT, AND SAY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/31 - Lesson 10, page 61, LISTEN, POINT, AND SAY.mp3" data-free="false"></li>
<li data-title="32 - Lesson 10, page 63, LISTEN AND MATCH" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/32 - Lesson 10, page 63, LISTEN AND MATCH.mp3" data-free="false"></li>
<li data-title="33 - Lesson 11, page 66, STORY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/33 - Lesson 11, page 66, STORY.mp3" data-free="false"></li>
<li data-title="34 - Lesson 11, page 67, LISTEN, POINT, AND SAY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/34 - Lesson 11, page 67, LISTEN, POINT, AND SAY.mp3" data-free="false"></li>
<li data-title="35 - Lesson 11, page 67, LISTEN AND CIRCLE" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/35 - Lesson 11, page 67, LISTEN AND CIRCLE.mp3" data-free="false"></li>
<li data-title="36 - Lesson 12, page 72, STORY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/36 - Lesson 12, page 72, STORY.mp3" data-free="false"></li>
<li data-title="37 - Lesson 12, page 73, LISTEN, POINT, AND SAY" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/37 - Lesson 12, page 73, LISTEN, POINT, AND SAY.mp3" data-free="false"></li>
<li data-title="38 - Lesson 12, page 73, LISTEN AND CROSS" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/38 - Lesson 12, page 73, LISTEN AND CROSS.mp3" data-free="false"></li>
<li data-title="39 - Lesson 12, page 74, LISTEN AND CIRCLE" data-artist="Big Box 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 1/39 - Lesson 12, page 74, LISTEN AND CIRCLE.mp3" data-free="false"></li>


	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
