
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Speed 3</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
            
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="APPENDIX - 47 01 L01 P117 APPENDIX LESSON 1 A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/APPENDIX/47 01 L01 P117 APPENDIX LESSON 1 A.mp3" data-free="false"></li>
<li data-title="APPENDIX - 48 02 L02 P118 APPENDIX LESSON 2 A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/APPENDIX/48 02 L02 P118 APPENDIX LESSON 2 A.mp3" data-free="false"></li>
<li data-title="APPENDIX - 49 03 L02 P118 APPENDIX LESSON 2 B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/APPENDIX/49 03 L02 P118 APPENDIX LESSON 2 B.mp3" data-free="false"></li>
<li data-title="APPENDIX - 50 04 L04 P120 APPENDIX LESSON 4" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/APPENDIX/50 04 L04 P120 APPENDIX LESSON 4.mp3" data-free="false"></li>
<li data-title="APPENDIX - 51 05 L05 P121 APPENDIX LESSON 5 A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/APPENDIX/51 05 L05 P121 APPENDIX LESSON 5 A.mp3" data-free="false"></li>
<li data-title="APPENDIX - 52 06 L06 P122 APPENDIX LESSON 6 A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/APPENDIX/52 06 L06 P122 APPENDIX LESSON 6 A.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 01 01 L01 P006 LISTENING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 01/01 01 L01 P006 LISTENING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 02 02 L01 P007 LANGUAGE STRUCTURE A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 01/02 02 L01 P007 LANGUAGE STRUCTURE A.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 03 03 L01 P007 LANGUAGE STRUCTURE B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 01/03 03 L01 P007 LANGUAGE STRUCTURE B.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 04 04 L01 P007 LANGUAGE STRUCTURE C - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 01/04 04 L01 P007 LANGUAGE STRUCTURE C - CM.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 05 05 L01 P008 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 01/05 05 L01 P008 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 06 06 L01 P008 READING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 01/06 06 L01 P008 READING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 07 07 L01 P009 PRONUNCIATION A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 01/07 07 L01 P009 PRONUNCIATION A.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 08 08 L01 P009 PRONUNCIATION C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 01/08 08 L01 P009 PRONUNCIATION C.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 09 01 L02 P010 LISTENING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 02/09 01 L02 P010 LISTENING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 10 02 L02 P010 LISTENING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 02/10 02 L02 P010 LISTENING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 11 03 L02 P010 LISTENING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 02/11 03 L02 P010 LISTENING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 12 04 L02 P011 LANGUAGE STRUCTURE A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 02/12 04 L02 P011 LANGUAGE STRUCTURE A.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 13 05 L02 P012 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 02/13 05 L02 P012 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 14 06 L02 P012 READING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 02/14 06 L02 P012 READING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 15 07 L02 P013 READING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 02/15 07 L02 P013 READING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 16 08 L02 P013 WRITING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 02/16 08 L02 P013 WRITING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 17 09 L02 P013 WRITING AND SPEAKING C - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 02/17 09 L02 P013 WRITING AND SPEAKING C - CM.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 18 01 L03 P014 LISTENING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 03/18 01 L03 P014 LISTENING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 19 02 L03 P014 LISTENING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 03/19 02 L03 P014 LISTENING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 20 03 L03 P015 LANGUAGE STRUCTURE A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 03/20 03 L03 P015 LANGUAGE STRUCTURE A.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 21 04 L03 P015 LANGUAGE STRUCTURE B - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 03/21 04 L03 P015 LANGUAGE STRUCTURE B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 22 05 L03 P016 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 03/22 05 L03 P016 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 23 06 L03 P017 WRITING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 03/23 06 L03 P017 WRITING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 24 07 L03 P017 PRONUNCIATION A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 03/24 07 L03 P017 PRONUNCIATION A.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 25 08 L03 P017 PRONUNCIATION B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 03/25 08 L03 P017 PRONUNCIATION B.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 26 01 L04 P018 LISTENING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 04/26 01 L04 P018 LISTENING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 27 02 L04 P018 LISTENING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 04/27 02 L04 P018 LISTENING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 28 03 L04 P019 LANGUAGE STRUCTURE - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 04/28 03 L04 P019 LANGUAGE STRUCTURE - CM.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 29 04 L04 P019 LANGUAGE STRUCTURE A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 04/29 04 L04 P019 LANGUAGE STRUCTURE A.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 30 05 L04 P020 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 04/30 05 L04 P020 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 31 05 L04 P020 READING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 04/31 05 L04 P020 READING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 32 07 L04 P020 READING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 04/32 07 L04 P020 READING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 33 08 L04 P021 WRITING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 04/33 08 L04 P021 WRITING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 34 01 L05 P022 LISTENING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 05/34 01 L05 P022 LISTENING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 35 02 L05 P022 LISTENING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 05/35 02 L05 P022 LISTENING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 36 03 L05 P023 LANGUAGE STRUCTURE A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 05/36 03 L05 P023 LANGUAGE STRUCTURE A.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 37 04 L05 P023 LANGUAGE STRUCTURE B - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 05/37 04 L05 P023 LANGUAGE STRUCTURE B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 38 05 L05 P024 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 05/38 05 L05 P024 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 39 06 L05 P024 READING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 05/39 06 L05 P024 READING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 40 07 L05 P024 READING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 05/40 07 L05 P024 READING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 41 08 L05 P025 WRITING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 05/41 08 L05 P025 WRITING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 42 09 L05 P025 PRONUNCIATION A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 05/42 09 L05 P025 PRONUNCIATION A.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 43 10 L05 P025 PRONUNCIATION B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 05/43 10 L05 P025 PRONUNCIATION B.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 44 01 L06 P028 LISTENING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 06/44 01 L06 P028 LISTENING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 45 02 L06 P028 LISTENING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 06/45 02 L06 P028 LISTENING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 46 03 L06 P029 LANGUAGE STRUCTURE A - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 06/46 03 L06 P029 LANGUAGE STRUCTURE A - CM.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 47 04 L06 P029 LANGUAGE STRUCTURE B - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 06/47 04 L06 P029 LANGUAGE STRUCTURE B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 48 05 L06 P030 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 06/48 05 L06 P030 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 49 06 L06 P031 WRITING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 06/49 06 L06 P031 WRITING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 50 01 L07 P032 LISTENING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 07/50 01 L07 P032 LISTENING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 51 02 L07 P032 LISTENING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 07/51 02 L07 P032 LISTENING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 52 03 L07 P033 LANGUAGE STRUCTURE A - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 07/52 03 L07 P033 LANGUAGE STRUCTURE A - CM.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 53 03 L07 P034 READING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 07/53 03 L07 P034 READING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 54 06 L07 P035 WRITING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 07/54 06 L07 P035 WRITING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 55 05 L07 P035 PRONUNCIATION A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 07/55 05 L07 P035 PRONUNCIATION A.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 56 07 L07 P035 PRONUNCIATION B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 07/56 07 L07 P035 PRONUNCIATION B.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 57 01 L08 P036 LISTENING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 08/57 01 L08 P036 LISTENING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 58 02 L08  P036 LISTENING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 08/58 02 L08  P036 LISTENING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 59 03 L08 P037 LANGUAGE STRUCTURE A - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 08/59 03 L08 P037 LANGUAGE STRUCTURE A - CM.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 60 04 L08 P038 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 08/60 04 L08 P038 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 61 05 L08 P039 READING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 08/61 05 L08 P039 READING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 01 01 L09 P040 LISTENING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 09/01 01 L09 P040 LISTENING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 02 02 L09 P041 LISTENING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 09/02 02 L09 P041 LISTENING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 03 03 L09 P041 LANGUAGE STRUCTURE A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 09/03 03 L09 P041 LANGUAGE STRUCTURE A.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 04 04 L09 P041 LANGUAGE STRUCTURE B - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 09/04 04 L09 P041 LANGUAGE STRUCTURE B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 05 05 L09 P042 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 09/05 05 L09 P042 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 06 06 L09 P042 READING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 09/06 06 L09 P042 READING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 07 07 L09 P043 PRONUNCIATION A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 09/07 07 L09 P043 PRONUNCIATION A.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 08 08 L09 P043 PRONUNCIATION B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 09/08 08 L09 P043 PRONUNCIATION B.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 09 01 L10 P044 LISTENING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 10/09 01 L10 P044 LISTENING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 10 02 L10 P045 LANGUAGE STRUCTURE A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 10/10 02 L10 P045 LANGUAGE STRUCTURE A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 11 03 L10 P045 LANGUAGE STRUCTURE B - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 10/11 03 L10 P045 LANGUAGE STRUCTURE B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 12 04 L10 P046 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 10/12 04 L10 P046 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 13 05 L10 P046 READING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 10/13 05 L10 P046 READING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 14 06 L10 P047 WRITING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 10/14 06 L10 P047 WRITING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 15 01 L11 P050 LISTENING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 11/15 01 L11 P050 LISTENING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 16 02 L11 P051 LANGUAGE STRUCTURE A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 11/16 02 L11 P051 LANGUAGE STRUCTURE A.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 17 03 L11 P051 LANGUAGE STRUCTURE B - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 11/17 03 L11 P051 LANGUAGE STRUCTURE B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 18 04 L11 P052 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 11/18 04 L11 P052 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 19 05 L11 P052 READING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 11/19 05 L11 P052 READING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 20 06 L11 P053 PRONUNCIATION A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 11/20 06 L11 P053 PRONUNCIATION A.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 21 07 L11 P053 PRONUNCIATION B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 11/21 07 L11 P053 PRONUNCIATION B.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 22 01 L12 P054 LISTENING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 12/22 01 L12 P054 LISTENING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 23 02 L12 P054 LISTENING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 12/23 02 L12 P054 LISTENING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 24 03 L12 P055 LANGUAGE STRUCTURE A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 12/24 03 L12 P055 LANGUAGE STRUCTURE A.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 25 04 L12 P055 LANGUAGE STRUCTURE B - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 12/25 04 L12 P055 LANGUAGE STRUCTURE B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 26 05 L12 P056 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 12/26 05 L12 P056 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 27 06 L12 P056 READING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 12/27 06 L12 P056 READING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 13 - 28 01 L13 P058 LISTENING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 13/28 01 L13 P058 LISTENING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 13 - 29 02 L13 P058 LISTENING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 13/29 02 L13 P058 LISTENING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 13 - 30 03 L13 P059 LANGUAGE STRUCTURE A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 13/30 03 L13 P059 LANGUAGE STRUCTURE A.mp3" data-free="false"></li>
<li data-title="LESSON 13 - 31 04 L13 P059 LANGUAGE STRUCTURE B - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 13/31 04 L13 P059 LANGUAGE STRUCTURE B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 13 - 32 05 L13 P060 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 13/32 05 L13 P060 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 13 - 33 06 L13 P060 READING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 13/33 06 L13 P060 READING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 13 - 34 07 L13 P061 PRONUNCIATION A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 13/34 07 L13 P061 PRONUNCIATION A.mp3" data-free="false"></li>
<li data-title="LESSON 13 - 35 08 L13 P061 PRONUNCIATION B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 13/35 08 L13 P061 PRONUNCIATION B.mp3" data-free="false"></li>
<li data-title="LESSON 14 - 36 01 L14 P062 LISTENING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 14/36 01 L14 P062 LISTENING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 14 - 37 02 L14 P063 LANGUAGE STRUCTURE A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 14/37 02 L14 P063 LANGUAGE STRUCTURE A.mp3" data-free="false"></li>
<li data-title="LESSON 14 - 38 03 L14 P063 LANGUAGE STRUCTURE B - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 14/38 03 L14 P063 LANGUAGE STRUCTURE B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 14 - 39 04 L14 P064 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 14/39 04 L14 P064 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 14 - 40 05 L14 P064 READING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 14/40 05 L14 P064 READING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 15 - 41 01 L15 P066 LISTENING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 15/41 01 L15 P066 LISTENING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 15 - 42 02 L15 P066 LISTENING AND SPEAKING C" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 15/42 02 L15 P066 LISTENING AND SPEAKING C.mp3" data-free="false"></li>
<li data-title="LESSON 15 - 43 03 L15 P067 LANGUAGE STRUCTURE B - CM" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 15/43 03 L15 P067 LANGUAGE STRUCTURE B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 15 - 44 04 L15 P068 READING AND SPEAKING A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 15/44 04 L15 P068 READING AND SPEAKING A.mp3" data-free="false"></li>
<li data-title="LESSON 15 - 45 05 L15 P068 READING AND SPEAKING B" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 15/45 05 L15 P068 READING AND SPEAKING B.mp3" data-free="false"></li>
<li data-title="LESSON 15 - 46 06 L15 P069 PRONUNCIATION A" data-artist="Speed 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 3/LESSON 15/46 06 L15 P069 PRONUNCIATION A.mp3" data-free="false"></li>


	



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
