
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Have Fun 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
   
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="lesson 01 - 01 L01.P008 Picture corner" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 01/01 L01.P008 Picture corner.mp3" data-free="false"></li>
<li data-title="lesson 01 - 02 L01.P08 What's going on" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 01/02 L01.P08 What's going on.mp3" data-free="false"></li>
<li data-title="lesson 01 - 03 L01.P010 Vocabulary (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 01/03 L01.P010 Vocabulary (A).mp3" data-free="false"></li>
<li data-title="lesson 01 - 04 L01.P010 Check this out (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 01/04 L01.P010 Check this out (A).mp3" data-free="false"></li>
<li data-title="lesson 01 - 05 L01.P011 Check this out (B)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 01/05 L01.P011 Check this out (B).mp3" data-free="false"></li>
<li data-title="lesson 01 - 06 L01.P012 Your turn (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 01/06 L01.P012 Your turn (A).mp3" data-free="false"></li>
<li data-title="lesson 01 - 07 L01.P012 Your turn (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 01/07 L01.P012 Your turn (D).mp3" data-free="false"></li>
<li data-title="lesson 01 - 08 L01.P013 Fun time (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 01/08 L01.P013 Fun time (A).mp3" data-free="false"></li>
<li data-title="lesson 02 - 01 L02.P014 Picture corner" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 02/01 L02.P014 Picture corner.mp3" data-free="false"></li>
<li data-title="lesson 02 - 02 L02.P014 What's going on" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 02/02 L02.P014 What's going on.mp3" data-free="false"></li>
<li data-title="lesson 02 - 03 L02.P016 Vocabulary (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 02/03 L02.P016 Vocabulary (A).mp3" data-free="false"></li>
<li data-title="lesson 02 - 04 L02.P016-17 Check this out (A) (B)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 02/04 L02.P016-17 Check this out (A) (B).mp3" data-free="false"></li>
<li data-title="lesson 02 - 05 L02.P018 Check this out (C)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 02/05 L02.P018 Check this out (C).mp3" data-free="false"></li>
<li data-title="lesson 02 - 06 L02.P018 Your turn (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 02/06 L02.P018 Your turn (A).mp3" data-free="false"></li>
<li data-title="lesson 02 - 07 L02.P019 Your turn (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 02/07 L02.P019 Your turn (D).mp3" data-free="false"></li>
<li data-title="lesson 02 - 08 L02.P019 Fun time (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 02/08 L02.P019 Fun time (A).mp3" data-free="false"></li>
<li data-title="lesson 03 - 01 L03.P020 Picture corner" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 03/01 L03.P020 Picture corner.mp3" data-free="false"></li>
<li data-title="lesson 03 - 02 L03.P020 What's going on" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 03/02 L03.P020 What's going on.mp3" data-free="false"></li>
<li data-title="lesson 03 - 03 L03.P022 Vocabulary (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 03/03 L03.P022 Vocabulary (A).mp3" data-free="false"></li>
<li data-title="lesson 03 - 04 L03.P022-23 Check this out (A) (B)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 03/04 L03.P022-23 Check this out (A) (B).mp3" data-free="false"></li>
<li data-title="lesson 03 - 05 L03.P023 Check this out (C)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 03/05 L03.P023 Check this out (C).mp3" data-free="false"></li>
<li data-title="lesson 03 - 06 L03.P024 Your turn (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 03/06 L03.P024 Your turn (A).mp3" data-free="false"></li>
<li data-title="lesson 03 - 07 L03.P024 Your turn (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 03/07 L03.P024 Your turn (D).mp3" data-free="false"></li>
<li data-title="lesson 03 - 08 L03.P025 Fun time (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 03/08 L03.P025 Fun time (A).mp3" data-free="false"></li>
<li data-title="lesson 04 - 01 L04.P026 Picture corner" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 04/01 L04.P026 Picture corner.mp3" data-free="false"></li>
<li data-title="lesson 04 - 02 L04.P026 What's going on" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 04/02 L04.P026 What's going on.mp3" data-free="false"></li>
<li data-title="lesson 04 - 03 L04.P028 Vocabulary (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 04/03 L04.P028 Vocabulary (A).mp3" data-free="false"></li>
<li data-title="lesson 04 - 04 L04.P028-29 Check this out (A) (B) (C)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 04/04 L04.P028-29 Check this out (A) (B) (C).mp3" data-free="false"></li>
<li data-title="lesson 04 - 05 L04.P030 Check this out (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 04/05 L04.P030 Check this out (D).mp3" data-free="false"></li>
<li data-title="lesson 04 - 06 L04.P030 Your turn (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 04/06 L04.P030 Your turn (A).mp3" data-free="false"></li>
<li data-title="lesson 04 - 07 L04.P030 Your turn (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 04/07 L04.P030 Your turn (D).mp3" data-free="false"></li>
<li data-title="lesson 04 - 08 L04.P031 Fun time (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 04/08 L04.P031 Fun time (A).mp3" data-free="false"></li>
<li data-title="lesson 05 - 01 L05.P034 Picture corner" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 05/01 L05.P034 Picture corner.mp3" data-free="false"></li>
<li data-title="lesson 05 - 02 L05.P034 What's going on" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 05/02 L05.P034 What's going on.mp3" data-free="false"></li>
<li data-title="lesson 05 - 03 L05.P036 Vocabulary (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 05/03 L05.P036 Vocabulary (A).mp3" data-free="false"></li>
<li data-title="lesson 05 - 04 L05.P036-37 Check this out (A) (B) (C)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 05/04 L05.P036-37 Check this out (A) (B) (C).mp3" data-free="false"></li>
<li data-title="lesson 05 - 05 L05.P038 Check this out (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 05/05 L05.P038 Check this out (D).mp3" data-free="false"></li>
<li data-title="lesson 05 - 06 L05.P038 Your turn (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 05/06 L05.P038 Your turn (A).mp3" data-free="false"></li>
<li data-title="lesson 05 - 07 L05.P038 Your turn (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 05/07 L05.P038 Your turn (D).mp3" data-free="false"></li>
<li data-title="lesson 05 - 08 L05.P039 Fun time (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 05/08 L05.P039 Fun time (A).mp3" data-free="false"></li>
<li data-title="lesson 06 - 01 L06.P042 Picture corner" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 06/01 L06.P042 Picture corner.mp3" data-free="false"></li>
<li data-title="lesson 06 - 02 L06.P042 What's going on" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 06/02 L06.P042 What's going on.mp3" data-free="false"></li>
<li data-title="lesson 06 - 03 L06.P044 Vocabulary (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 06/03 L06.P044 Vocabulary (A).mp3" data-free="false"></li>
<li data-title="lesson 06 - 04 L06.P044 Check this out (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 06/04 L06.P044 Check this out (A).mp3" data-free="false"></li>
<li data-title="lesson 06 - 05 L06.P045 Check this out (B)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 06/05 L06.P045 Check this out (B).mp3" data-free="false"></li>
<li data-title="lesson 06 - 06 L06.P046 Your turn (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 06/06 L06.P046 Your turn (A).mp3" data-free="false"></li>
<li data-title="lesson 06 - 07 L06.P046 Your turn (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 06/07 L06.P046 Your turn (D).mp3" data-free="false"></li>
<li data-title="lesson 06 - 08 L06.P047 Fun time (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 06/08 L06.P047 Fun time (A).mp3" data-free="false"></li>
<li data-title="lesson 07 - 01 L07.P048 Picture corner" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 07/01 L07.P048 Picture corner.mp3" data-free="false"></li>
<li data-title="lesson 07 - 02 L07.P048 What's going on" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 07/02 L07.P048 What's going on.mp3" data-free="false"></li>
<li data-title="lesson 07 - 03 L07.P050 Vocabulary (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 07/03 L07.P050 Vocabulary (A).mp3" data-free="false"></li>
<li data-title="lesson 07 - 04 L07.P050-51 Check this out (A) (B) (C)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 07/04 L07.P050-51 Check this out (A) (B) (C).mp3" data-free="false"></li>
<li data-title="lesson 07 - 05 L07.P052 Check this out (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 07/05 L07.P052 Check this out (D).mp3" data-free="false"></li>
<li data-title="lesson 07 - 06 L07.P052 Your turn (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 07/06 L07.P052 Your turn (A).mp3" data-free="false"></li>
<li data-title="lesson 07 - 07 L07.P053 Your turn (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 07/07 L07.P053 Your turn (D).mp3" data-free="false"></li>
<li data-title="lesson 07 - 08 L07.P054 Fun time (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 07/08 L07.P054 Fun time (A).mp3" data-free="false"></li>
<li data-title="lesson 08 - 01 L08.P056 Picture corner" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 08/01 L08.P056 Picture corner.mp3" data-free="false"></li>
<li data-title="lesson 08 - 02 L08.P056 What's going on" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 08/02 L08.P056 What's going on.mp3" data-free="false"></li>
<li data-title="lesson 08 - 03 L08.P058 Vocabulary (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 08/03 L08.P058 Vocabulary (A).mp3" data-free="false"></li>
<li data-title="lesson 08 - 04 L08.P058-59 Check this out (A) (B)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 08/04 L08.P058-59 Check this out (A) (B).mp3" data-free="false"></li>
<li data-title="lesson 08 - 05 L08.P059 Check this out (C)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 08/05 L08.P059 Check this out (C).mp3" data-free="false"></li>
<li data-title="lesson 08 - 06 L08.P060 Your turn (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 08/06 L08.P060 Your turn (A).mp3" data-free="false"></li>
<li data-title="lesson 08 - 07 L08.P061 Your turn (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 08/07 L08.P061 Your turn (D).mp3" data-free="false"></li>
<li data-title="lesson 08 - 08 L08.P061 Fun time (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 08/08 L08.P061 Fun time (A).mp3" data-free="false"></li>
<li data-title="lesson 09 - 01 L09.P066 Picture corner" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 09/01 L09.P066 Picture corner.mp3" data-free="false"></li>
<li data-title="lesson 09 - 02 L09.P066 What's going on" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 09/02 L09.P066 What's going on.mp3" data-free="false"></li>
<li data-title="lesson 09 - 03 L09.P068 Vocabulary (A) (B)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 09/03 L09.P068 Vocabulary (A) (B).mp3" data-free="false"></li>
<li data-title="lesson 09 - 04 L09.P068 Check this out (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 09/04 L09.P068 Check this out (A).mp3" data-free="false"></li>
<li data-title="lesson 09 - 05 L09.P069 Check this out (B)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 09/05 L09.P069 Check this out (B).mp3" data-free="false"></li>
<li data-title="lesson 09 - 06 L09.P070 Your turn (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 09/06 L09.P070 Your turn (A).mp3" data-free="false"></li>
<li data-title="lesson 09 - 07 L09.P070 Your turn (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 09/07 L09.P070 Your turn (D).mp3" data-free="false"></li>
<li data-title="lesson 09 - 08 L09.P070 Fun time (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 09/08 L09.P070 Fun time (A).mp3" data-free="false"></li>
<li data-title="lesson 10 - 01 L10.P072 Picture corner" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 10/01 L10.P072 Picture corner.mp3" data-free="false"></li>
<li data-title="lesson 10 - 02 L10.P072 What's going on" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 10/02 L10.P072 What's going on.mp3" data-free="false"></li>
<li data-title="lesson 10 - 03 L10.P074 Vocabulary (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 10/03 L10.P074 Vocabulary (A).mp3" data-free="false"></li>
<li data-title="lesson 10 - 04 L10.P074-76 Check this out (A) (B)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 10/04 L10.P074-76 Check this out (A) (B).mp3" data-free="false"></li>
<li data-title="lesson 10 - 05 L10.P076 Check this out (C)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 10/05 L10.P076 Check this out (C).mp3" data-free="false"></li>
<li data-title="lesson 10 - 06 L10.P076 Your turn (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 10/06 L10.P076 Your turn (A).mp3" data-free="false"></li>
<li data-title="lesson 10 - 07 L10.P077 Your turn (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 10/07 L10.P077 Your turn (D).mp3" data-free="false"></li>
<li data-title="lesson 10 - 08 L10.P077 Fun time (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 10/08 L10.P077 Fun time (A).mp3" data-free="false"></li>
<li data-title="lesson 11 - 01 L11.P080 Picture corner" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 11/01 L11.P080 Picture corner.mp3" data-free="false"></li>
<li data-title="lesson 11 - 02 L11.P080 What's going on" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 11/02 L11.P080 What's going on.mp3" data-free="false"></li>
<li data-title="lesson 11 - 03 L11.P082 Vocabulary (A) (B)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 11/03 L11.P082 Vocabulary (A) (B).mp3" data-free="false"></li>
<li data-title="lesson 11 - 04 L11.P083 Check this out (A) (B)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 11/04 L11.P083 Check this out (A) (B).mp3" data-free="false"></li>
<li data-title="lesson 11 - 05 L11.P084 Check this out (C)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 11/05 L11.P084 Check this out (C).mp3" data-free="false"></li>
<li data-title="lesson 11 - 06 L11.P084 Your turn (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 11/06 L11.P084 Your turn (A).mp3" data-free="false"></li>
<li data-title="lesson 11 - 07 L11.P085 Your turn (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 11/07 L11.P085 Your turn (D).mp3" data-free="false"></li>
<li data-title="lesson 11 - 08 L11.P086 Fun time (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 11/08 L11.P086 Fun time (A).mp3" data-free="false"></li>
<li data-title="lesson 12 - 01 L12.P090 Picture corner" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 12/01 L12.P090 Picture corner.mp3" data-free="false"></li>
<li data-title="lesson 12 - 02 L12.P090 What's going on" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 12/02 L12.P090 What's going on.mp3" data-free="false"></li>
<li data-title="lesson 12 - 03 L12.P092 Vocabulary (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 12/03 L12.P092 Vocabulary (A).mp3" data-free="false"></li>
<li data-title="lesson 12 - 04 L12.P093 Check this out (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 12/04 L12.P093 Check this out (A).mp3" data-free="false"></li>
<li data-title="lesson 12 - 05 L12.P093 Check this out (B)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 12/05 L12.P093 Check this out (B).mp3" data-free="false"></li>
<li data-title="lesson 12 - 06 L12.P094 Your turn (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 12/06 L12.P094 Your turn (A).mp3" data-free="false"></li>
<li data-title="lesson 12 - 07 L12.P094 Your turn (D)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 12/07 L12.P094 Your turn (D).mp3" data-free="false"></li>
<li data-title="lesson 12 - 08 L12.P095 Fun time (A)" data-artist="Have Fun 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 2/lesson 12/08 L12.P095 Fun time (A).mp3" data-free="false"></li>


	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

