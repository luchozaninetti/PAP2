
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Have Fun 4</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
      
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="lesson 00 - 01 Introduction P008" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 00/01 Introduction P008.mp3" data-free="false"></li>
<li data-title="lesson 01 - 01 L01.P011 The map" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 01/01 L01.P011 The map.mp3" data-free="false"></li>
<li data-title="lesson 01 - 02 L01.P013 Radar 1" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 01/02 L01.P013 Radar 1.mp3" data-free="false"></li>
<li data-title="lesson 01 - 03 L01.P013 Stop 1A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 01/03 L01.P013 Stop 1A.mp3" data-free="false"></li>
<li data-title="lesson 01 - 04 L01.P014 Stop 2B" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 01/04 L01.P014 Stop 2B.mp3" data-free="false"></li>
<li data-title="lesson 01 - 05 L01.P015 Radar 2" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 01/05 L01.P015 Radar 2.mp3" data-free="false"></li>
<li data-title="lesson 01 - 06 L01.P015 Check the sign A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 01/06 L01.P015 Check the sign A.mp3" data-free="false"></li>
<li data-title="lesson 01 - 07 L01.P018 Destination" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 01/07 L01.P018 Destination.mp3" data-free="false"></li>
<li data-title="lesson 02 - 01 L02.P021 The map" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 02/01 L02.P021 The map.mp3" data-free="false"></li>
<li data-title="lesson 02 - 02 L02.P023 Radar 1" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 02/02 L02.P023 Radar 1.mp3" data-free="false"></li>
<li data-title="lesson 02 - 03 L02.P023 Stop 1A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 02/03 L02.P023 Stop 1A.mp3" data-free="false"></li>
<li data-title="lesson 02 - 04 L02.P024 Stop 2B" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 02/04 L02.P024 Stop 2B.mp3" data-free="false"></li>
<li data-title="lesson 02 - 05 L02.P025 Radar 2" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 02/05 L02.P025 Radar 2.mp3" data-free="false"></li>
<li data-title="lesson 02 - 06 L02.P025 Check the sign A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 02/06 L02.P025 Check the sign A.mp3" data-free="false"></li>
<li data-title="lesson 02 - 07 L02.P028 Destination" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 02/07 L02.P028 Destination.mp3" data-free="false"></li>
<li data-title="lesson 03 - 01 L03.P031 The map" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 03/01 L03.P031 The map.mp3" data-free="false"></li>
<li data-title="lesson 03 - 02 L03.P033 Radar 1" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 03/02 L03.P033 Radar 1.mp3" data-free="false"></li>
<li data-title="lesson 03 - 03 L03.P033 Stop 1A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 03/03 L03.P033 Stop 1A.mp3" data-free="false"></li>
<li data-title="lesson 03 - 04 L03.P034 Stop 2B" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 03/04 L03.P034 Stop 2B.mp3" data-free="false"></li>
<li data-title="lesson 03 - 05 L03.P035 Radar 2" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 03/05 L03.P035 Radar 2.mp3" data-free="false"></li>
<li data-title="lesson 03 - 06 L03.P035 Check the sign A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 03/06 L03.P035 Check the sign A.mp3" data-free="false"></li>
<li data-title="lesson 03 - 07 L03.P038 Destination" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 03/07 L03.P038 Destination.mp3" data-free="false"></li>
<li data-title="lesson 04 - 01 L04.P041 The map" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 04/01 L04.P041 The map.mp3" data-free="false"></li>
<li data-title="lesson 04 - 02 L04.P043 Radar 1" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 04/02 L04.P043 Radar 1.mp3" data-free="false"></li>
<li data-title="lesson 04 - 03 L04.P043 Stop 1A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 04/03 L04.P043 Stop 1A.mp3" data-free="false"></li>
<li data-title="lesson 04 - 04 L04.P044 Stop 2B" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 04/04 L04.P044 Stop 2B.mp3" data-free="false"></li>
<li data-title="lesson 04 - 05 L04.P045 Radar 2" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 04/05 L04.P045 Radar 2.mp3" data-free="false"></li>
<li data-title="lesson 04 - 06 L04.P045 Check the sign A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 04/06 L04.P045 Check the sign A.mp3" data-free="false"></li>
<li data-title="lesson 04 - 07 L04.P048 Destination" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 04/07 L04.P048 Destination.mp3" data-free="false"></li>
<li data-title="lesson 05 - 01 L05.P053 The map" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 05/01 L05.P053 The map.mp3" data-free="false"></li>
<li data-title="lesson 05 - 02 L05.P055 Radar 1" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 05/02 L05.P055 Radar 1.mp3" data-free="false"></li>
<li data-title="lesson 05 - 03 L05.P055 Stop 1A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 05/03 L05.P055 Stop 1A.mp3" data-free="false"></li>
<li data-title="lesson 05 - 04 L05.P056 Stop 2B" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 05/04 L05.P056 Stop 2B.mp3" data-free="false"></li>
<li data-title="lesson 05 - 05 L05.P057 Radar 2" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 05/05 L05.P057 Radar 2.mp3" data-free="false"></li>
<li data-title="lesson 05 - 06 L05.P057 Check the sign A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 05/06 L05.P057 Check the sign A.mp3" data-free="false"></li>
<li data-title="lesson 05 - 07 L05.P060 Destination" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 05/07 L05.P060 Destination.mp3" data-free="false"></li>
<li data-title="lesson 06 - 01 L06.P063 The map" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 06/01 L06.P063 The map.mp3" data-free="false"></li>
<li data-title="lesson 06 - 02 L06.P065 Radar 1" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 06/02 L06.P065 Radar 1.mp3" data-free="false"></li>
<li data-title="lesson 06 - 03 L06.P065 Stop 1A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 06/03 L06.P065 Stop 1A.mp3" data-free="false"></li>
<li data-title="lesson 06 - 04 L06.P066 Stop 2B" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 06/04 L06.P066 Stop 2B.mp3" data-free="false"></li>
<li data-title="lesson 06 - 05 L06.P066 Radar 2" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 06/05 L06.P066 Radar 2.mp3" data-free="false"></li>
<li data-title="lesson 06 - 06 L06.P067 Check the sign A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 06/06 L06.P067 Check the sign A.mp3" data-free="false"></li>
<li data-title="lesson 06 - 07 L06.P070 Destination" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 06/07 L06.P070 Destination.mp3" data-free="false"></li>
<li data-title="lesson 07 - 01 L07.P073 The map" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 07/01 L07.P073 The map.mp3" data-free="false"></li>
<li data-title="lesson 07 - 02 L07.P075 Radar 1" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 07/02 L07.P075 Radar 1.mp3" data-free="false"></li>
<li data-title="lesson 07 - 03 L07.P075 Stop 1A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 07/03 L07.P075 Stop 1A.mp3" data-free="false"></li>
<li data-title="lesson 07 - 04 L07.P076-77 Stop 2B, 2C" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 07/04 L07.P076-77 Stop 2B, 2C.mp3" data-free="false"></li>
<li data-title="lesson 07 - 05 L07.P077 Radar 2" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 07/05 L07.P077 Radar 2.mp3" data-free="false"></li>
<li data-title="lesson 07 - 06 L07.P077 Check the sign A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 07/06 L07.P077 Check the sign A.mp3" data-free="false"></li>
<li data-title="lesson 07 - 07 L07.P080 Destination" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 07/07 L07.P080 Destination.mp3" data-free="false"></li>
<li data-title="lesson 08 - 01 L08.P083 The map" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 08/01 L08.P083 The map.mp3" data-free="false"></li>
<li data-title="lesson 08 - 02 L08.P085 Radar 1" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 08/02 L08.P085 Radar 1.mp3" data-free="false"></li>
<li data-title="lesson 08 - 03 L08.P085 Stop 1A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 08/03 L08.P085 Stop 1A.mp3" data-free="false"></li>
<li data-title="lesson 08 - 04 L08.P086 Stop 2B" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 08/04 L08.P086 Stop 2B.mp3" data-free="false"></li>
<li data-title="lesson 08 - 05 L08.P087 Radar 2" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 08/05 L08.P087 Radar 2.mp3" data-free="false"></li>
<li data-title="lesson 08 - 06 L08.P087 Check the sign A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 08/06 L08.P087 Check the sign A.mp3" data-free="false"></li>
<li data-title="lesson 08 - 07 L08.P090 Destination" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 08/07 L08.P090 Destination.mp3" data-free="false"></li>
<li data-title="lesson 09 - 01 L09.P095 The map" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 09/01 L09.P095 The map.mp3" data-free="false"></li>
<li data-title="lesson 09 - 02 L09.P97 Radar 1" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 09/02 L09.P97 Radar 1.mp3" data-free="false"></li>
<li data-title="lesson 09 - 03 L09.P097 Stop 1A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 09/03 L09.P097 Stop 1A.mp3" data-free="false"></li>
<li data-title="lesson 09 - 04 L09.P098 Stop 2B" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 09/04 L09.P098 Stop 2B.mp3" data-free="false"></li>
<li data-title="lesson 09 - 05 L09.P098 Radar 2" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 09/05 L09.P098 Radar 2.mp3" data-free="false"></li>
<li data-title="lesson 09 - 06 L09.P099 Check the sign A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 09/06 L09.P099 Check the sign A.mp3" data-free="false"></li>
<li data-title="lesson 09 - 07 L09.P102 Destination" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 09/07 L09.P102 Destination.mp3" data-free="false"></li>
<li data-title="lesson 10 - 01 L10.P105 The map" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 10/01 L10.P105 The map.mp3" data-free="false"></li>
<li data-title="lesson 10 - 02 L10.P107 Radar 1" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 10/02 L10.P107 Radar 1.mp3" data-free="false"></li>
<li data-title="lesson 10 - 03 L10.P107 Stop 1A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 10/03 L10.P107 Stop 1A.mp3" data-free="false"></li>
<li data-title="lesson 10 - 04 L10.P108 Stop 2B" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 10/04 L10.P108 Stop 2B.mp3" data-free="false"></li>
<li data-title="lesson 10 - 05 L10.P109 Radar 2" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 10/05 L10.P109 Radar 2.mp3" data-free="false"></li>
<li data-title="lesson 10 - 06 L10.P109 Check the sign A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 10/06 L10.P109 Check the sign A.mp3" data-free="false"></li>
<li data-title="lesson 10 - 07 L10.P112 Destination" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 10/07 L10.P112 Destination.mp3" data-free="false"></li>
<li data-title="lesson 11 - 01 L11.P115 The map" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 11/01 L11.P115 The map.mp3" data-free="false"></li>
<li data-title="lesson 11 - 02 L11.P117 Radar 1" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 11/02 L11.P117 Radar 1.mp3" data-free="false"></li>
<li data-title="lesson 11 - 03 L11.P117 Stop 1A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 11/03 L11.P117 Stop 1A.mp3" data-free="false"></li>
<li data-title="lesson 11 - 04 L11.P118 Stop 2B" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 11/04 L11.P118 Stop 2B.mp3" data-free="false"></li>
<li data-title="lesson 11 - 05 L11.P119 Radar 2" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 11/05 L11.P119 Radar 2.mp3" data-free="false"></li>
<li data-title="lesson 11 - 06 L11.P119 Check the sign A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 11/06 L11.P119 Check the sign A.mp3" data-free="false"></li>
<li data-title="lesson 11 - 07 L11.P122 Destination" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 11/07 L11.P122 Destination.mp3" data-free="false"></li>
<li data-title="lesson 12 - 01 L12.P125 The map" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 12/01 L12.P125 The map.mp3" data-free="false"></li>
<li data-title="lesson 12 - 02 L12.P126 Radar 1" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 12/02 L12.P126 Radar 1.mp3" data-free="false"></li>
<li data-title="lesson 12 - 03 L12.P127 Stop 1A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 12/03 L12.P127 Stop 1A.mp3" data-free="false"></li>
<li data-title="lesson 12 - 04 L12.P 128 Stop 2B" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 12/04 L12.P 128 Stop 2B.mp3" data-free="false"></li>
<li data-title="lesson 12 - 05 L12.P128 Radar 2" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 12/05 L12.P128 Radar 2.mp3" data-free="false"></li>
<li data-title="lesson 12 - 06 L12.P129 Check the sign A" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 12/06 L12.P129 Check the sign A.mp3" data-free="false"></li>
<li data-title="lesson 12 - 07 L12.P132 Destination" data-artist="Have Fun 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 4/lesson 12/07 L12.P132 Destination.mp3" data-free="false"></li>


	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
