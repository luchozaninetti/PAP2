
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Breaking Free</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
           
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Lesson 01 - 01 L01 P006 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/01 L01 P006 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 02 L01 P007 Immediate Conversation (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/02 L01 P007 Immediate Conversation (C).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 03 L01 P008 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/03 L01 P008 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 04 L01 P008 Speaking (CMat P05)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/04 L01 P008 Speaking (CMat P05).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 05 L01 P008 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/05 L01 P008 Working.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 06 L01 P009 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/06 L01 P009 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 07 L01 P009 Speaking" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/07 L01 P009 Speaking.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 08 L01 P009 Speaking (CMat P06)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/08 L01 P009 Speaking (CMat P06).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 09 L01 P010 Working - B" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/09 L01 P010 Working - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 10 L01 P010 Speaking (CMat P06)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/10 L01 P010 Speaking (CMat P06).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 11 L01 P011 Speaking " data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/11 L01 P011 Speaking .mp3" data-free="false"></li>
<li data-title="Lesson 01 - 12 L01 P011 Speaking (CMat P06)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/12 L01 P011 Speaking (CMat P06).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 13 L01 P012 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/13 L01 P012 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 14 L01 P012 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/14 L01 P012 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 15 L01 P012 Immediate Conversation C (CMat P07)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/15 L01 P012 Immediate Conversation C (CMat P07).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 16 L01 P013 Listening " data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/16 L01 P013 Listening .mp3" data-free="false"></li>
<li data-title="Lesson 01 - 17 L01 P013 Checking the words" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 01/17 L01 P013 Checking the words.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 01 L02 P014 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/01 L02 P014 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 02 - 02 L02 P015 Immediate Conversation (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/02 L02 P015 Immediate Conversation (C).mp3" data-free="false"></li>
<li data-title="Lesson 02 - 03 L02 P016 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/03 L02 P016 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 04 L02 P016 Speaking (CMat - P09)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/04 L02 P016 Speaking (CMat - P09).mp3" data-free="false"></li>
<li data-title="Lesson 02 - 05 L02 P016 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/05 L02 P016 Working.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 06 L02 P017 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/06 L02 P017 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 07 L02 P017 Speaking (CMat - P10)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/07 L02 P017 Speaking (CMat - P10).mp3" data-free="false"></li>
<li data-title="Lesson 02 - 08 L02 P018 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/08 L02 P018 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 09 L02 P018 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/09 L02 P018 Working.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 10 L02 P018 Speaking (CMat - P10)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/10 L02 P018 Speaking (CMat - P10).mp3" data-free="false"></li>
<li data-title="Lesson 02 - 11 L02 P019 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/11 L02 P019 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 12 L02 P019 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/12 L02 P019 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 13 L02 P019 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/13 L02 P019 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 02 - 14 L02 P019 Immediate Conversation (B) (CMat P11)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/14 L02 P019 Immediate Conversation (B) (CMat P11).mp3" data-free="false"></li>
<li data-title="Lesson 02 - 15 L02 P020 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/15 L02 P020 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 16 L02 P021 Checking the words" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 02/16 L02 P021 Checking the words.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 01 L03 P022 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/01 L03 P022 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 03 - 02 L03 P023 Immediate Conversation (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/02 L03 P023 Immediate Conversation (C).mp3" data-free="false"></li>
<li data-title="Lesson 03 - 03 L03 P024 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/03 L03 P024 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 04 L03 P024 Speaking (CMat P13)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/04 L03 P024 Speaking (CMat P13).mp3" data-free="false"></li>
<li data-title="Lesson 03 - 05 L03 P024  Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/05 L03 P024  Working.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 06 L03 P025  Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/06 L03 P025  Learning.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 07 L03 P025  Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/07 L03 P025  Working.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 08 L03 P025  Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/08 L03 P025  Learning.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 09 L03 P026  Speaking (CMat P14)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/09 L03 P026  Speaking (CMat P14).mp3" data-free="false"></li>
<li data-title="Lesson 03 - 10 L03 P026 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/10 L03 P026 Working.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 11 L03 P026  Speaking (CMat P14)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/11 L03 P026  Speaking (CMat P14).mp3" data-free="false"></li>
<li data-title="Lesson 03 - 12 L03 P027  Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/12 L03 P027  Listening.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 13 L03 P027 Speaking" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/13 L03 P027 Speaking.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 14 L03 P027 Speaking (CMat P14) " data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/14 L03 P027 Speaking (CMat P14) .mp3" data-free="false"></li>
<li data-title="Lesson 03 - 15 L03 P027 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/15 L03 P027 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 16 L03 P028 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/16 L03 P028 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 03 - 17 L03 P028 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/17 L03 P028 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 18 L03 P029 Checking the words" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 03/18 L03 P029 Checking the words.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 01 L04 P030 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/01 L04 P030 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 04 - 02 L04 P031 Immediate Conversation (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/02 L04 P031 Immediate Conversation (C).mp3" data-free="false"></li>
<li data-title="Lesson 04 - 03 L04 P032 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/03 L04 P032 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 04 L04 P032 Speaking (CMat P17)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/04 L04 P032 Speaking (CMat P17).mp3" data-free="false"></li>
<li data-title="Lesson 04 - 05 L04 P033 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/05 L04 P033 Working.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 06 L04 P033 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/06 L04 P033 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 07 L04 P033 Learning (CMat P17)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/07 L04 P033 Learning (CMat P17).mp3" data-free="false"></li>
<li data-title="Lesson 04 - 08 L04 P034 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/08 L04 P034 Working.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 09 L04 P034 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/09 L04 P034 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 10 L04 P035 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/10 L04 P035 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 11 L04 P035 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/11 L04 P035 Working.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 12 L04 P035 Speaking (CMat P19)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/12 L04 P035 Speaking (CMat P19).mp3" data-free="false"></li>
<li data-title="Lesson 04 - 13 L04 P036 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/13 L04 P036 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 04 - 14 L04 P037 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/14 L04 P037 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 15 L04 P037 Checking the words" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 04/15 L04 P037 Checking the words.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 01 L05 P038 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/01 L05 P038 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 05 - 02 L05 P039 Immediate Conversation (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/02 L05 P039 Immediate Conversation (C).mp3" data-free="false"></li>
<li data-title="Lesson 05 - 03 L05 P040 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/03 L05 P040 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 04 L05 P040 Contractions with will" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/04 L05 P040 Contractions with will.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 05 L05 P040 Speaking (CMat P21)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/05 L05 P040 Speaking (CMat P21).mp3" data-free="false"></li>
<li data-title="Lesson 05 - 06 L05 P041 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/06 L05 P041 Working.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 07 L05 P041 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/07 L05 P041 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 08 L05 P041 Contractions with would" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/08 L05 P041 Contractions with would.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 09 L05 P042 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/09 L05 P042 Working.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 10 L05 P042 Speaking (CMat P22)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/10 L05 P042 Speaking (CMat P22).mp3" data-free="false"></li>
<li data-title="Lesson 05 - 11 L05 P042 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/11 L05 P042 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 12 L05 P043 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/12 L05 P043 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 13 L05 P043 Learning (CMat  P22)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/13 L05 P043 Learning (CMat  P22).mp3" data-free="false"></li>
<li data-title="Lesson 05 - 14 L05 P043 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/14 L05 P043 Working.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 15 L05 P043 Learning " data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/15 L05 P043 Learning .mp3" data-free="false"></li>
<li data-title="Lesson 05 - 16 L05 P044 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/16 L05 P044 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 05 - 17 L05 P045 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/17 L05 P045 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 18 L05 P045 Checking the words" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 05/18 L05 P045 Checking the words.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 01 L06 P046 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/01 L06 P046 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 06 - 02 L06 P047 Immediate Conversation (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/02 L06 P047 Immediate Conversation (C).mp3" data-free="false"></li>
<li data-title="Lesson 06 - 03 L06 P048 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/03 L06 P048 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 04 L06 P048 Regular Verbs" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/04 L06 P048 Regular Verbs.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 05 L06 P048 Speaking (CMat P25)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/05 L06 P048 Speaking (CMat P25).mp3" data-free="false"></li>
<li data-title="Lesson 06 - 06 L06 P048 - 049 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/06 L06 P048 - 049 Working.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 07 L06 P049 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/07 L06 P049 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 08 L06 P049 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/08 L06 P049 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 09 L06 P049 Speaking (CMat P26)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/09 L06 P049 Speaking (CMat P26).mp3" data-free="false"></li>
<li data-title="Lesson 06 - 10 L06 P050 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/10 L06 P050 Working.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 11 L06 P051 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/11 L06 P051 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 12 L06 P052 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/12 L06 P052 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 06 - 13 L06 P053 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/13 L06 P053 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 14 L06 P053 Checking the words" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 06/14 L06 P053 Checking the words.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 01 L07 P058 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/01 L07 P058 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 07 - 02 L07 P059 Immediate Conversation (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/02 L07 P059 Immediate Conversation (C).mp3" data-free="false"></li>
<li data-title="Lesson 07 - 03 L07 P060 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/03 L07 P060 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 04 L07 P060 Irregular Verbs" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/04 L07 P060 Irregular Verbs.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 05 L07 P060 Speaking (CMat P29)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/05 L07 P060 Speaking (CMat P29).mp3" data-free="false"></li>
<li data-title="Lesson 07 - 06 L07 P060 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/06 L07 P060 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 07 L07 P061 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/07 L07 P061 Working.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 08 L07 P061 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/08 L07 P061 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 09 L07 P062 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/09 L07 P062 Working.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 10 L07 P063 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/10 L07 P063 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 11 L07 P064 Speaking (CMat P31)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/11 L07 P064 Speaking (CMat P31).mp3" data-free="false"></li>
<li data-title="Lesson 07 - 12 L07 P064 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/12 L07 P064 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 07 - 13 L07 P065 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/13 L07 P065 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 14 L07 P065 Checking the words" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 07/14 L07 P065 Checking the words.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 01 L08 P066 Immediate Conversation (A) " data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/01 L08 P066 Immediate Conversation (A) .mp3" data-free="false"></li>
<li data-title="Lesson 08 - 02 L08 P067 Immediate Conversation (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/02 L08 P067 Immediate Conversation (C).mp3" data-free="false"></li>
<li data-title="Lesson 08 - 03 L08 P068 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/03 L08 P068 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 04 L08 P068 Speaking (CMat P33)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/04 L08 P068 Speaking (CMat P33).mp3" data-free="false"></li>
<li data-title="Lesson 08 - 05 L08 P068 Speaking " data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/05 L08 P068 Speaking .mp3" data-free="false"></li>
<li data-title="Lesson 08 - 06 L08 P069 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/06 L08 P069 Working.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 07 L08 P069 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/07 L08 P069 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 08 L08 P070 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/08 L08 P070 Working.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 09 L08 P070 Speaking (CMat P34) " data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/09 L08 P070 Speaking (CMat P34) .mp3" data-free="false"></li>
<li data-title="Lesson 08 - 10 L08 P070 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/10 L08 P070 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 11 L08 P071 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/11 L08 P071 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 12 L08 P071 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/12 L08 P071 Working.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 13 L08 P072 Immediate Conversation (A) " data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/13 L08 P072 Immediate Conversation (A) .mp3" data-free="false"></li>
<li data-title="Lesson 08 - 14 L08 P073 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/14 L08 P073 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 15 L08 P073 Checking the words" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 08/15 L08 P073 Checking the words.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 01 L09 P074 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/01 L09 P074 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 09 - 02 L09 P075 Immediate Conversation (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/02 L09 P075 Immediate Conversation (C).mp3" data-free="false"></li>
<li data-title="Lesson 09 - 03 L09 P076 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/03 L09 P076 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 04 L09 P076 Contractions with am - are - is" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/04 L09 P076 Contractions with am - are - is.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 05 L09 P076 Speaking (CMat P37)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/05 L09 P076 Speaking (CMat P37).mp3" data-free="false"></li>
<li data-title="Lesson 09 - 06 L09 P077 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/06 L09 P077 Working.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 07 L09 P077 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/07 L09 P077 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 08 L09 P077 Speaking (CMat P38)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/08 L09 P077 Speaking (CMat P38).mp3" data-free="false"></li>
<li data-title="Lesson 09 - 09 L09 P078 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/09 L09 P078 Working.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 10 L09 P078 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/10 L09 P078 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 11 L09 P079 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/11 L09 P079 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 12 L09 P079 Speaking (CMat P38)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/12 L09 P079 Speaking (CMat P38).mp3" data-free="false"></li>
<li data-title="Lesson 09 - 13 L09 P079 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/13 L09 P079 Working.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 14 L09 P080 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/14 L09 P080 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 15 L09 P081 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/15 L09 P081 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 09 - 16 L09 P081 Checking the words" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 09/16 L09 P081 Checking the words.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 01 L10 P082 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 10/01 L10 P082 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 10 - 02 L10 P083 Immediate Conversation (B)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 10/02 L10 P083 Immediate Conversation (B).mp3" data-free="false"></li>
<li data-title="Lesson 10 - 03 L10 P084 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 10/03 L10 P084 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 04 L10 P084 Speaking (CMat P41)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 10/04 L10 P084 Speaking (CMat P41).mp3" data-free="false"></li>
<li data-title="Lesson 10 - 05 L10 P085 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 10/05 L10 P085 Working.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 06 L10 P085 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 10/06 L10 P085 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 07 L10 P086 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 10/07 L10 P086 Working.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 08 L10 P086 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 10/08 L10 P086 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 09 L10 P087 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 10/09 L10 P087 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 10 L10 P088 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 10/10 L10 P088 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 10 - 11 L10 P089 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 10/11 L10 P089 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 12  L10 P089 Checking the words" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 10/12  L10 P089 Checking the words.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 01 L11 P090 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/01 L11 P090 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 11 - 02 L11 P091 Immediate Conversation (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/02 L11 P091 Immediate Conversation (C).mp3" data-free="false"></li>
<li data-title="Lesson 11 - 03 L11 P092 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/03 L11 P092 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 04 L11 P092 Speaking (CMat P45)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/04 L11 P092 Speaking (CMat P45).mp3" data-free="false"></li>
<li data-title="Lesson 11 - 05 L11 P093 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/05 L11 P093 Working.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 06 L11 P093 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/06 L11 P093 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 07 L11 P093 Speaking" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/07 L11 P093 Speaking.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 08 L11 P093 Speaking (CMat P45)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/08 L11 P093 Speaking (CMat P45).mp3" data-free="false"></li>
<li data-title="Lesson 11 - 09 L11 P094 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/09 L11 P094 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 10 L11 P094 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/10 L11 P094 Working.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 11 L11 P094 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/11 L11 P094 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 12 L11 P095 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/12 L11 P095 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 14 L11 P095 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/14 L11 P095 Working.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 15 L11 P096 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/15 L11 P096 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 16 L11 P096 Immediate Conversation" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/16 L11 P096 Immediate Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 17 L11 P097 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/17 L11 P097 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 18 L11 P097 Checking the words" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 11/18 L11 P097 Checking the words.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 01 L12 P098 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/01 L12 P098 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 12 - 02 L12 P099 Immediate Conversation (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/02 L12 P099 Immediate Conversation (C).mp3" data-free="false"></li>
<li data-title="Lesson 12 - 03 L12 P100 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/03 L12 P100 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 04 L12 P100 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/04 L12 P100 Working.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 05 L12 P101 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/05 L12 P101 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 06 L12 P101 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/06 L12 P101 Working.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 07 L12 P102 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/07 L12 P102 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 08 L12 P102 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/08 L12 P102 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 09 L12 P102 Working" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/09 L12 P102 Working.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 10 L12 P103 Learning" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/10 L12 P103 Learning.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 11 L12 P104 Speaking (A) " data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/11 L12 P104 Speaking (A) .mp3" data-free="false"></li>
<li data-title="Lesson 12 - 12 L12 P104 Immediate Conversation (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/12 L12 P104 Immediate Conversation (A).mp3" data-free="false"></li>
<li data-title="Lesson 12 - 13 L12 P104 Listening" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/13 L12 P104 Listening.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 14 L12 P105 Checking the words" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Lesson 12/14 L12 P105 Checking the words.mp3" data-free="false"></li>
<li data-title="Review 1 - 01 Review Exercises 1 P056 Listening (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Review 1/01 Review Exercises 1 P056 Listening (A).mp3" data-free="false"></li>
<li data-title="Review 1 - 02 Review Exercises 1 P056 Listening (B)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Review 1/02 Review Exercises 1 P056 Listening (B).mp3" data-free="false"></li>
<li data-title="Review 1 - 03 Review Exercises 1 P057 Listening (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Review 1/03 Review Exercises 1 P057 Listening (C).mp3" data-free="false"></li>
<li data-title="Review 1 - 04 Review Exercises 1 P057 Listening (D)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Review 1/04 Review Exercises 1 P057 Listening (D).mp3" data-free="false"></li>
<li data-title="Review 2 - 01 P108 Review Exercises 2 (A)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Review 2/01 P108 Review Exercises 2 (A).mp3" data-free="false"></li>
<li data-title="Review 2 - 02 P108 Review Exercises 2 (B)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Review 2/02 P108 Review Exercises 2 (B).mp3" data-free="false"></li>
<li data-title="Review 2 - 03 P109 Review Exercises 2 (C)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Review 2/03 P109 Review Exercises 2 (C).mp3" data-free="false"></li>
<li data-title="Review 2 - 04 P109 Review Exercises 2 (D)" data-artist="Breaking Free" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Breaking Free/Review 2/04 P109 Review Exercises 2 (D).mp3" data-free="false"></li>

	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

