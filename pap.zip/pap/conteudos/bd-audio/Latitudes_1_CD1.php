
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Latitudes 1 - CD 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
        
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
<li data-title="01 Lat 1.1 - 01 Latitudes1CD1.1" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/01 Latitudes1CD1.1.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 02 Latitudes1CD1.2" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/02 Latitudes1CD1.2.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 03 Latitudes1CD1.3" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/03 Latitudes1CD1.3.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 04 Latitudes1CD1.4" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/04 Latitudes1CD1.4.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 05 Latitudes1CD1.5" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/05 Latitudes1CD1.5.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 06 Latitudes1CD1.6" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/06 Latitudes1CD1.6.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 07 Latitudes1CD1.7" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/07 Latitudes1CD1.7.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 08 Latitudes1CD1.8" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/08 Latitudes1CD1.8.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 09 Latitudes1CD1.9" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/09 Latitudes1CD1.9.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 10 Latitudes1CD1.10" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/10 Latitudes1CD1.10.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 11 Latitudes1CD1.11" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/11 Latitudes1CD1.11.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 12 Latitudes1CD1.12" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/12 Latitudes1CD1.12.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 13 Latitudes1CD1.13" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/13 Latitudes1CD1.13.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 14 Latitudes1CD1.14" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/14 Latitudes1CD1.14.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 15 Latitudes1CD1.15" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/15 Latitudes1CD1.15.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 16 Latitudes1CD1.16" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/16 Latitudes1CD1.16.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 17 Latitudes1CD1.17" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/17 Latitudes1CD1.17.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 18 Latitudes1CD1.18" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/18 Latitudes1CD1.18.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 19 Latitudes1CD1.19" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/19 Latitudes1CD1.19.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 20 Latitudes1CD1.20" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/20 Latitudes1CD1.20.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 21 Latitudes1CD1.21" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/21 Latitudes1CD1.21.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 22 Latitudes1CD1.22" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/22 Latitudes1CD1.22.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 23 Latitudes1CD1.23" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/23 Latitudes1CD1.23.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 24 Latitudes1CD1.24" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/24 Latitudes1CD1.24.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 25 Latitudes1CD1.25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/25 Latitudes1CD1.25.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 26 Latitudes1CD1.26" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/26 Latitudes1CD1.26.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 27 Latitudes1CD1.27" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/27 Latitudes1CD1.27.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 28 Latitudes1CD1.28" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/28 Latitudes1CD1.28.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 29 Latitudes1CD1.29" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/29 Latitudes1CD1.29.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 30 Latitudes1CD1.30" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/30 Latitudes1CD1.30.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 31 Latitudes1CD1.31" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/31 Latitudes1CD1.31.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 32 Latitudes1CD1.32" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/32 Latitudes1CD1.32.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 33 Latitudes1CD1.33" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/33 Latitudes1CD1.33.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 34 Latitudes1CD1.34" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/34 Latitudes1CD1.34.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 35 Latitudes1CD1.35" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/35 Latitudes1CD1.35.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 36 Latitudes1CD1.36" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/36 Latitudes1CD1.36.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 37 Latitudes1CD1.37" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/37 Latitudes1CD1.37.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 38 Latitudes1CD1.38" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/38 Latitudes1CD1.38.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 39 Latitudes1CD1.39" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/39 Latitudes1CD1.39.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 40 Latitudes1CD1.40" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/40 Latitudes1CD1.40.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 41 Latitudes1CD1.41" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/41 Latitudes1CD1.41.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 42 Latitudes1CD1.42" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/42 Latitudes1CD1.42.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 43 Latitudes1CD1.43" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/43 Latitudes1CD1.43.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 44 Latitudes1CD1.44" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/44 Latitudes1CD1.44.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 45 Latitudes1CD1.45" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/45 Latitudes1CD1.45.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 46 Latitudes1CD1.46" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/46 Latitudes1CD1.46.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 47 Latitudes1CD1.47" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/47 Latitudes1CD1.47.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 48 Latitudes1CD1.48" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/48 Latitudes1CD1.48.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 49 Latitudes1CD1.49" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/49 Latitudes1CD1.49.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 50 Latitudes1CD1.50" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/50 Latitudes1CD1.50.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 51 Latitudes1CD1.51" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/51 Latitudes1CD1.51.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 52 Latitudes1CD1.52" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/52 Latitudes1CD1.52.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 53 Latitudes1CD1.53" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/53 Latitudes1CD1.53.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 54 Latitudes1CD1.54" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/54 Latitudes1CD1.54.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 55 Latitudes1CD1.55" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/55 Latitudes1CD1.55.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 56 Latitudes1CD1.56" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/56 Latitudes1CD1.56.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 57 Latitudes1CD1.57" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/57 Latitudes1CD1.57.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 58 Latitudes1CD1.58" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/58 Latitudes1CD1.58.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 59 Latitudes1CD1.59" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/59 Latitudes1CD1.59.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 60 Latitudes1CD1.60" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/60 Latitudes1CD1.60.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 61 Latitudes1CD1.61" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/61 Latitudes1CD1.61.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 62 Latitudes1CD1.62" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/62 Latitudes1CD1.62.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 63 Latitudes1CD1.63" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/63 Latitudes1CD1.63.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 64 Latitudes1CD1.64" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/64 Latitudes1CD1.64.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 65 Latitudes1CD1.65" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/65 Latitudes1CD1.65.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 66 Latitudes1CD1.66" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/66 Latitudes1CD1.66.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 67 Latitudes1CD1.67" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/67 Latitudes1CD1.67.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 68 Latitudes1CD1.68" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/68 Latitudes1CD1.68.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 69 Latitudes1CD1.69" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/69 Latitudes1CD1.69.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 70 Latitudes1CD1.70" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/70 Latitudes1CD1.70.mp3" data-free="false"></li>
<li data-title="01 Lat 1.1 - 71 Latitudes1CD1.71" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/01 Lat 1.1/71 Latitudes1CD1.71.mp3" data-free="false"></li>



	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
