
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Flying High</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
      
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Lesson 00 - 01 Flying High (CMat P04)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 00/01 Flying High (CMat P04).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 01 L01 P008 Start off - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 01/01 L01 P008 Start off - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 02 L01 P009 Start off - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 01/02 L01 P009 Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 03 L01 P010 Check this out - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 01/03 L01 P010 Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 04 L01 P011 Your say - A (CMat P06)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 01/04 L01 P011 Your say - A (CMat P06).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 05 L01 P011 Your say - B (CMat P07)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 01/05 L01 P011 Your say - B (CMat P07).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 06 L01 P012 It sounds good - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 01/06 L01 P012 It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 07 L01 P012 It sounds good - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 01/07 L01 P012 It sounds good - C.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 08 L01 P014 Homework - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 01/08 L01 P014 Homework - A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 09 L01 P014 Homework - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 01/09 L01 P014 Homework - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 10 L01 P014 Homework - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 01/10 L01 P014 Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 11 L01 P015 Homework - E" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 01/11 L01 P015 Homework - E.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 01 L02 P016  Start off - A2" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 02/01 L02 P016  Start off - A2.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 02 L02 P016  Start off - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 02/02 L02 P016  Start off - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 03 L02 P017  Start off - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 02/03 L02 P017  Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 04 L02 P017  Start off - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 02/04 L02 P017  Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 05 L02 P018  Check this out - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 02/05 L02 P018  Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 06 L02 P019  Your say - A (CMat - P10)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 02/06 L02 P019  Your say - A (CMat - P10).mp3" data-free="false"></li>
<li data-title="Lesson 02 - 07 L02 P020  It sounds good - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 02/07 L02 P020  It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 08 L02 P020  It sounds good - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 02/08 L02 P020  It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 09 L02 P020  It sounds good - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 02/09 L02 P020  It sounds good - C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 10 L02 P023  Homework - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 02/10 L02 P023  Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 11 L02 P023  Homework - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 02/11 L02 P023  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 01 L03 P024 Start off - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 03/01 L03 P024 Start off - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 02 L03 P025 Start off - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 03/02 L03 P025 Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 03 L03 P026 Check this out - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 03/03 L03 P026 Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 04 L03 P027 Your say - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 03/04 L03 P027 Your say - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 05 L03 P027 Your say - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 03/05 L03 P027 Your say - C.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 06 L03 P028  It sounds good - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 03/06 L03 P028  It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 07 L03 P028  It sounds good - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 03/07 L03 P028  It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 08 L03 P029  Hands on - Preparation  A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 03/08 L03 P029  Hands on - Preparation  A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 09 L03 P029  Hands on - Action (CMat P15)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 03/09 L03 P029  Hands on - Action (CMat P15).mp3" data-free="false"></li>
<li data-title="Lesson 03 - 10 L03 P030  Homework - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 03/10 L03 P030  Homework - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 11 L03 P031  Homework - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 03/11 L03 P031  Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 12 L03 P031  Homework - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 03/12 L03 P031  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 01 L04 P032  Start off - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 04/01 L04 P032  Start off - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 02 L04 P033  Start off - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 04/02 L04 P033  Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 03 L04 P034  Check this out - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 04/03 L04 P034  Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 04 L04 P035  Your say - A (CMat P17)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 04/04 L04 P035  Your say - A (CMat P17).mp3" data-free="false"></li>
<li data-title="Lesson 04 - 05 L04 P035  Your say - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 04/05 L04 P035  Your say - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 06 L04 P036  It sounds good - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 04/06 L04 P036  It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 07 L04 P036  It sounds good - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 04/07 L04 P036  It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 08 L04 P036  It sounds good - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 04/08 L04 P036  It sounds good - C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 09 L04 P037  Hands on - Action B (CMat P18)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 04/09 L04 P037  Hands on - Action B (CMat P18).mp3" data-free="false"></li>
<li data-title="Lesson 04 - 10 L04 P038  Homework - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 04/10 L04 P038  Homework - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 11 L04 P039  Homework - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 04/11 L04 P039  Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 12 L04 P039  Homework - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 04/12 L04 P039  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 01 L05 P041  Start off - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 05/01 L05 P041  Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 02 L05 P041  Start off - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 05/02 L05 P041  Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 03 L05 P042  Check this out - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 05/03 L05 P042  Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 04 L05 P043  Your say - A(CMat P21)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 05/04 L05 P043  Your say - A(CMat P21).mp3" data-free="false"></li>
<li data-title="Lesson 05 - 05 L05 P043  Your say - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 05/05 L05 P043  Your say - C.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 06 L05 P044  It sounds good - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 05/06 L05 P044  It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 07 L05 P044  It sounds good - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 05/07 L05 P044  It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 08 L05 P047  Homework - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 05/08 L05 P047  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 01 L06 P048  Start off - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 06/01 L06 P048  Start off - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 02 L06 P049  Start off - B2" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 06/02 L06 P049  Start off - B2.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 03 L06 P049  Start off - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 06/03 L06 P049  Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 04 L06 P049  Start off - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 06/04 L06 P049  Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 05 L06 P050  Check this out - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 06/05 L06 P050  Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 06 L06 P051  Your say - A2 (CMat P23)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 06/06 L06 P051  Your say - A2 (CMat P23).mp3" data-free="false"></li>
<li data-title="Lesson 06 - 07 L06 P051  Your say - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 06/07 L06 P051  Your say - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 08 L06 P052  It sounds good - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 06/08 L06 P052  It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 09 L06 P052  It sounds good - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 06/09 L06 P052  It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 10 L06 P052  It sounds good - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 06/10 L06 P052  It sounds good - C.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 11 L06 P054  Homework - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 06/11 L06 P054  Homework - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 12 L06 P055  Homework - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 06/12 L06 P055  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 01 L07 P063 Start off - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 07/01 L07 P063 Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 02 L07 P063 Start off - D (CMat P25)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 07/02 L07 P063 Start off - D (CMat P25).mp3" data-free="false"></li>
<li data-title="Lesson 07 - 03 L07 P064 Check this out - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 07/03 L07 P064 Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 04 L07 P065 Your say - A (CMat P26)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 07/04 L07 P065 Your say - A (CMat P26).mp3" data-free="false"></li>
<li data-title="Lesson 07 - 05 L07 P065 Your say - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 07/05 L07 P065 Your say - C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 06 L07 P066 It sounds good - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 07/06 L07 P066 It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 07 L07 P066 It sounds good - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 07/07 L07 P066 It sounds good - C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 08 L07 P069  Homework - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 07/08 L07 P069  Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 09 L07 P069  Homework - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 07/09 L07 P069  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 01 L08 P071 Start off - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 08/01 L08 P071 Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 02 L08 P072  Check this out - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 08/02 L08 P072  Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 03 L08 P073  Your say - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 08/03 L08 P073  Your say - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 04 L08 P073  Your say - B (CMat P29)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 08/04 L08 P073  Your say - B (CMat P29).mp3" data-free="false"></li>
<li data-title="Lesson 08 - 05 L08 P074  It sounds good - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 08/05 L08 P074  It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 06 L08 P074  It sounds good - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 08/06 L08 P074  It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 07 L08 P074  It sounds good - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 08/07 L08 P074  It sounds good - C.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 08 L08 P077  Homework - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 08/08 L08 P077  Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 09 L08 P077  Homework - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 08/09 L08 P077  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 01 L09 P079  Start off - E" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 09/01 L09 P079  Start off - E.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 02 L09 P080  Check this out - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 09/02 L09 P080  Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 03 L09 P081  Your say - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 09/03 L09 P081  Your say - B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 04 L09 P081  Your say - B (CMat P32)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 09/04 L09 P081  Your say - B (CMat P32).mp3" data-free="false"></li>
<li data-title="Lesson 09 - 05 L09 P081  Your say - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 09/05 L09 P081  Your say - C.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 06 L09 P082  It sounds good - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 09/06 L09 P082  It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 07 L09 P082  It sounds good - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 09/07 L09 P082  It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 08 L09 P082  It sounds good - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 09/08 L09 P082  It sounds good - C.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 09 L09 P085  Homework - E" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 09/09 L09 P085  Homework - E.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 01 L10 P087  Start off - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 10/01 L10 P087  Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 02 L10 P087  Start off - E" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 10/02 L10 P087  Start off - E.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 03 L10 P088  Check this out - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 10/03 L10 P088  Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 04 L10 P089  Your say - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 10/04 L10 P089  Your say - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 05 L10 P089  Your say - B (CMat P35)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 10/05 L10 P089  Your say - B (CMat P35).mp3" data-free="false"></li>
<li data-title="Lesson 10 - 06 L10 P090  It sounds good - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 10/06 L10 P090  It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 07 L10 P090  It sounds good - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 10/07 L10 P090  It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 08 L10 P093  Homework - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 10/08 L10 P093  Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 09 L10 P093  Homework - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 10/09 L10 P093  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 01 L11 P095  Start off - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 11/01 L11 P095  Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 02 L11 P095  Start off - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 11/02 L11 P095  Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 03 L11 P095  Start off - E (CMat P37)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 11/03 L11 P095  Start off - E (CMat P37).mp3" data-free="false"></li>
<li data-title="Lesson 11 - 04 L11 P096  Check this out - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 11/04 L11 P096  Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 05 L11 P097  Your say - A (CMat P38)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 11/05 L11 P097  Your say - A (CMat P38).mp3" data-free="false"></li>
<li data-title="Lesson 11 - 06 L11 P097  Your say - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 11/06 L11 P097  Your say - C.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 07 L11 P098  It sounds good - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 11/07 L11 P098  It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 08 L11 P098  It sounds good - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 11/08 L11 P098  It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 09 L11 P101  Homework - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 11/09 L11 P101  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 10 L11 P101  Homework - E" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 11/10 L11 P101  Homework - E.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 01 L12 P103  Start off - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 12/01 L12 P103  Start off - B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 02 L12 P103  Start off - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 12/02 L12 P103  Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 03 L12 P103  Start off - D (CMat P40)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 12/03 L12 P103  Start off - D (CMat P40).mp3" data-free="false"></li>
<li data-title="Lesson 12 - 04 L12 P104  Check this out - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 12/04 L12 P104  Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 05 L12 P105  Your say - B (CMat P41)" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 12/05 L12 P105  Your say - B (CMat P41).mp3" data-free="false"></li>
<li data-title="Lesson 12 - 06 L12 P105  Your say - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 12/06 L12 P105  Your say - C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 07 L12 P106  It sounds good - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 12/07 L12 P106  It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 08 L12 P106  It sounds good - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 12/08 L12 P106  It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 09 L12 P106  It sounds good - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 12/09 L12 P106  It sounds good - C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 10 L12 P109  Homework - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 12/10 L12 P109  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 11 L12 P109  Homework - E" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Lesson 12/11 L12 P109  Homework - E.mp3" data-free="false"></li>
<li data-title="Review 1 - 01 Review 1 P060 - Listening - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Review 1/01 Review 1 P060 - Listening - A.mp3" data-free="false"></li>
<li data-title="Review 1 - 02 Review 1 P061 - Listening - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Review 1/02 Review 1 P061 - Listening - B.mp3" data-free="false"></li>
<li data-title="Review 1 - 03 Review 1 P061 - Listening - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Review 1/03 Review 1 P061 - Listening - C.mp3" data-free="false"></li>
<li data-title="Review 1 - 04 Review 1 P061 - Listening - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Review 1/04 Review 1 P061 - Listening - D.mp3" data-free="false"></li>
<li data-title="Review 2 - 01 Review 2  P114  Listening - A" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Review 2/01 Review 2  P114  Listening - A.mp3" data-free="false"></li>
<li data-title="Review 2 - 02 Review 2  P114  Listening - B" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Review 2/02 Review 2  P114  Listening - B.mp3" data-free="false"></li>
<li data-title="Review 2 - 03 Review 2  P115  Listening - C" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Review 2/03 Review 2  P115  Listening - C.mp3" data-free="false"></li>
<li data-title="Review 2 - 04 Review 2  P115  Listening - D" data-artist="Flying High" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Flying High/Review 2/04 Review 2  P115  Listening - D.mp3" data-free="false"></li>


	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
