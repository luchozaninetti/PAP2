
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Advanced</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
          
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
<li data-title="Lesson 01 - 01 L1p06 Kick-off - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 01/01 L1p06 Kick-off - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 02 L1p07 Speaking & Listening - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 01/02 L1p07 Speaking & Listening - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 03 L1p08 Language Structure - D"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 01/03 L1p08 Language Structure - D.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 04 L1p08 Reading & Speaking - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 01/04 L1p08 Reading & Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 05 L1p09 Listening & Writing - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 01/05 L1p09 Listening & Writing - A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 06 L1p10 Listening & Writing - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 01/06 L1p10 Listening & Writing - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 07 L1p10 Speaking Naturally - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 01/07 L1p10 Speaking Naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 01 L2p12 Kick-off - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 02/01 L2p12 Kick-off - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 02 L2p13 Reading & Speaking -B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 02/02 L2p13 Reading & Speaking -B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 03 L2p14 Language Structure - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 02/03 L2p14 Language Structure - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 04 L2p14 Language Structure - C - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 02/04 L2p14 Language Structure - C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 05 L2p14 Language Structure - C - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 02/05 L2p14 Language Structure - C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 06 L2p15 Curiosity - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 02/06 L2p15 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 07 L2p15 Speaking Naturally - C"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 02/07 L2p15 Speaking Naturally - C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 08 L2p16 Speaking & Listening - C - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 02/08 L2p16 Speaking & Listening - C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 09 L2p16 Speaking & Listening - D"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 02/09 L2p16 Speaking & Listening - D.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 10 L2p17 Writing - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 02/10 L2p17 Writing - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 01 L3p18 Kick-off - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 03/01 L3p18 Kick-off - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 02 L3p19 Listening & Speaking - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 03/02 L3p19 Listening & Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 03 L3p20 Language Structure - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 03/03 L3p20 Language Structure - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 04 L3p20 Language Structure - C"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 03/04 L3p20 Language Structure - C.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 05 L3p21 Reading & Speaking - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 03/05 L3p21 Reading & Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 06 L3p22 Speaking & Writing - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 03/06 L3p22 Speaking & Writing - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 07 L3p23 Speaking - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 03/07 L3p23 Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 08 L3p23 Curiosity - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 03/08 L3p23 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 01 L4p28 Kick-off - C"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 04/01 L4p28 Kick-off - C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 02 L4p29 Speaking & Listening - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 04/02 L4p29 Speaking & Listening - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 03 L4p30 Language Structure - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 04/03 L4p30 Language Structure - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 04 L4p30 Verbal Combinations - C - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 04/04 L4p30 Verbal Combinations - C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 05 L4p31 Reading & Speaking -B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 04/05 L4p31 Reading & Speaking -B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 06 L4p32 Writing and Speaking - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 04/06 L4p32 Writing and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 07 L4p32 Writing & Speaking - C - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 04/07 L4p32 Writing & Speaking - C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 08 L4p33 Speaking Naturally - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 04/08 L4p33 Speaking Naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 01 L5p34 Kick-off - C - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 05/01 L5p34 Kick-off - C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 02 L5p35 Reading & Listening - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 05/02 L5p35 Reading & Listening - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 03 L5p35 Reading & Listening - C"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 05/03 L5p35 Reading & Listening - C.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 04 L5p36 Language Structure - C - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 05/04 L5p36 Language Structure - C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 05 L5p37 Verbal Combinations - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 05/05 L5p37 Verbal Combinations - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 06 L5p37 Speaking Naturally - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 05/06 L5p37 Speaking Naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 07 L5p38 Writing & Speaking - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 05/07 L5p38 Writing & Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 08 L5p39 Curiosity - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 05/08 L5p39 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 01 L6p41 Listening & Speaking - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 06/01 L6p41 Listening & Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 02 L6p42 Language Structure - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 06/02 L6p42 Language Structure - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 03 L6p43 Verbal Combinations - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 06/03 L6p43 Verbal Combinations - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 04 L6p43 Reading & Speaking - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 06/04 L6p43 Reading & Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 05 L6p45 Speaking Naturally - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 06/05 L6p45 Speaking Naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 06 L6p45 Curiosity - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 06/06 L6p45 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 01 L7p57 Listening & Speaking - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 07/01 L7p57 Listening & Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 02 L7p57 Listening & Speaking - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 07/02 L7p57 Listening & Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 03 L7p58  Language Structure - D"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 07/03 L7p58  Language Structure - D.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 04 L7p59 Reading & Speaking - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 07/04 L7p59 Reading & Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 05 L7p60 Writing - B - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 07/05 L7p60 Writing - B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 06 L7p60 Writing D - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 07/06 L7p60 Writing D - CM.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 07 L7p61 Speaking Naturally - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 07/07 L7p61 Speaking Naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 08 L7p61 Curiosity - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 07/08 L7p61 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 01 L8p63 Listening & Speaking - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 08/01 L8p63 Listening & Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 02 L8p64 Language Structure 1 - C - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 08/02 L8p64 Language Structure 1 - C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 03 L8p65 Reading & Speaking - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 08/03 L8p65 Reading & Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 04 L8p66 Speaking - C - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 08/04 L8p66 Speaking - C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 05 L8p66 Speaking Naturally - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 08/05 L8p66 Speaking Naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 06 L8p67 Curiosity - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 08/06 L8p67 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 01 L9p68 Kick-off - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 09/01 L9p68 Kick-off - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 02 L9p69 Listening & Speaking - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 09/02 L9p69 Listening & Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 03 L9p70 Language Structure 1 - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 09/03 L9p70 Language Structure 1 - B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 04 L9p71 Verbal Combinations - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 09/04 L9p71 Verbal Combinations - B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 05 L9p72 Reading & Speaking - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 09/05 L9p72 Reading & Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 06 L9p72 Curiosity - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 09/06 L9p72 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 07 L9p73 Speaking Naturally - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 09/07 L9p73 Speaking Naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 01 L10p78 Kick-off - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 10/01 L10p78 Kick-off - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 02 L10p79 Listening & Speaking - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 10/02 L10p79 Listening & Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 03 L10p79 Language Structure 1 - B - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 10/03 L10p79 Language Structure 1 - B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 04 L10p82 Reading & Speaking - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 10/04 L10p82 Reading & Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 05 L10p83 Speaking Naturally - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 10/05 L10p83 Speaking Naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 06 L10p83 Speaking - C - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 10/06 L10p83 Speaking - C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 07 L10p83 Curiosity - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 10/07 L10p83 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 01 L11p84 Kick-off - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 11/01 L11p84 Kick-off - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 02 L11p85 Listening & Speaking - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 11/02 L11p85 Listening & Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 03 L11p85 Language Structure 1 - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 11/03 L11p85 Language Structure 1 - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 04 L11p86 Language Structure 2 - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 11/04 L11p86 Language Structure 2 - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 05 L11p87 Speaking & Reading - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 11/05 L11p87 Speaking & Reading - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 06 L11p89 Speaking Naturally - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 11/06 L11p89 Speaking Naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 07 L11p89 Curiosity - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 11/07 L11p89 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 01 L12p90 Kick-off - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 12/01 L12p90 Kick-off - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 02 L12p90 Kick-off -C - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 12/02 L12p90 Kick-off -C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 03 L12p91 Speaking & Listening - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 12/03 L12p91 Speaking & Listening - B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 04 L12p92 Language Structure 2 - D - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 12/04 L12p92 Language Structure 2 - D - CM.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 05 L12p94 Speaking & Reading - C"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 12/05 L12p94 Speaking & Reading - C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 06 L12p95 Speaking Naturally - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 12/06 L12p95 Speaking Naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 07 L12p95 Curiosity - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Lesson 12/07 L12p95 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Review 1 - Review 1 - p54 - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Review/Review 1/Review 1 - p54 - A.mp3" data-free="false"></li>
<li data-title="Review 1 - Review 1 - p54 - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Review/Review 1/Review 1 - p54 - B.mp3" data-free="false"></li>
<li data-title="Review 1 - Review 1 - p54 - C"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Review/Review 1/Review 1 - p54 - C.mp3" data-free="false"></li>
<li data-title="Review 1 - Review 1 - p55 - D"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Review/Review 1/Review 1 - p55 - D.mp3" data-free="false"></li>
<li data-title="Review 2 - Review 2 p104 - A"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Review/Review 2/Review 2 p104 - A.mp3" data-free="false"></li>
<li data-title="Review 2 - Review 2 p105 - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Review/Review 2/Review 2 p105 - B.mp3" data-free="false"></li>
<li data-title="Review 2 - Review 2 p105 - C"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Review/Review 2/Review 2 p105 - C.mp3" data-free="false"></li>
<li data-title="Review 2 - Review 2 p105- D"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Review/Review 2/Review 2 p105- D.mp3" data-free="false"></li>
<li data-title="Time out 1 - Time out 1 p 25 - Progress Check - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Time Out/Time out 1/Time out 1 p 25 - Progress Check - B.mp3" data-free="false"></li>
<li data-title="Time out 1 - Time out 1 p 25 - Speak up - E - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Time Out/Time out 1/Time out 1 p 25 - Speak up - E - CM.mp3" data-free="false"></li>
<li data-title="Time out 1 - Time out 1 p 26 -  Game - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Time Out/Time out 1/Time out 1 p 26 -  Game - CM.mp3" data-free="false"></li>
<li data-title="Time out 2 - Time out 2 p47 - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Time Out/Time out 2/Time out 2 p47 - B.mp3" data-free="false"></li>
<li data-title="Time out 2 - Time out 2 p48 - Game - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Time Out/Time out 2/Time out 2 p48 - Game - CM.mp3" data-free="false"></li>
<li data-title="Time out 3 - Time out 3 - p75 - Progress Check - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Time Out/Time out 3/Time out 3 - p75 - Progress Check - B.mp3" data-free="false"></li>
<li data-title="Time out 3 - Time out 3 - p75 - Speak up - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Time Out/Time out 3/Time out 3 - p75 - Speak up - CM.mp3" data-free="false"></li>
<li data-title="Time out 4 - Time out 4 - p97 - Progress Chcek - B"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Time Out/Time out 4/Time out 4 - p97 - Progress Chcek - B.mp3" data-free="false"></li>
<li data-title="Time out 4 - Time out 4 - p98 - Game - A - CM"data-artist="Teens Advanced"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Advanced/Time Out/Time out 4/Time out 4 - p98 - Game - A - CM.mp3" data-free="false"></li>


	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
