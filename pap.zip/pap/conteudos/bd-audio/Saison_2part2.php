
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Saison 2.2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
          
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->

<li data-title="Saison 2 - Unite 5 - b. MF - Piste 38" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/b. MF - Piste 38.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - c. MF - Piste 39" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/c. MF - Piste 39.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - d. Cahier - Piste 31 - Activite 2" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/d. Cahier - Piste 31 - Activite 2.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - e. Cahier - Piste 32 - Activite 3" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/e. Cahier - Piste 32 - Activite 3.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - f. Cahier - Piste 33 - Activite 7" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/f. Cahier - Piste 33 - Activite 7.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - g. Cahier - Piste 34 - Activite 10" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/g. Cahier - Piste 34 - Activite 10.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - h. Cahier - Piste 35 - Activite 13" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/h. Cahier - Piste 35 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - i. Cahier - Piste 37 - Activite 15" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/i. Cahier - Piste 37 - Activite 15.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - j. Cahier - Piste 38 - Activite 16" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/j. Cahier - Piste 38 - Activite 16.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - k. MF - Piste 40" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/k. MF - Piste 40.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - l. MF - Piste 41" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/l. MF - Piste 41.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - m. MF - Piste 42" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/m. MF - Piste 42.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - n. MF - Piste 43" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/n. MF - Piste 43.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - o. MF - Piste 44" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/o. MF - Piste 44.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 5 - p. Unite 5 - DELF A2" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 5/p. Unite 5 - DELF A2.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - b. MF - Piste 46" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/b. MF - Piste 46.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - c. MF - Piste 47" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/c. MF - Piste 47.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - d. Cahier - Piste 41 - Activite 19" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/d. Cahier - Piste 41 - Activite 19.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - e. MF - Piste 48" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/e. MF - Piste 48.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - f. Cahier - Piste 38 - Activite 12" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/f. Cahier - Piste 38 - Activite 12.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - g. Cahier - Piste 39 - Activite 13" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/g. Cahier - Piste 39 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - h. Cahier - Piste 40 - Activite 16" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/h. Cahier - Piste 40 - Activite 16.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - i. MF - Piste 49" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/i. MF - Piste 49.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - j. Cahier - Piste 42 - Activite 21" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/j. Cahier - Piste 42 - Activite 21.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - k. MF - Piste 50" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/k. MF - Piste 50.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - l. MF - Piste 51" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/l. MF - Piste 51.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - m. MF - Piste 52" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/m. MF - Piste 52.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 6 - o. MF - DELF A2 Epreuve blanche - Unite 6" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 6/o. MF - DELF A2 Epreuve blanche - Unite 6.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 7 - b. MF - Piste 54" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 7/b. MF - Piste 54.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 7 - c. MF - Piste 55" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 7/c. MF - Piste 55.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 7 - d. Cahier - Piste 43 - Activite 7" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 7/d. Cahier - Piste 43 - Activite 7.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 7 - e. Cahier - Piste 44 - Activite 13" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 7/e. Cahier - Piste 44 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 7 - f. MF - Piste 56" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 7/f. MF - Piste 56.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 7 - g. MF - Piste 57" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 7/g. MF - Piste 57.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 7 - h. Cahier - Piste 45 - Activite 22" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 7/h. Cahier - Piste 45 - Activite 22.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 7 - i. MF - Piste 58" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 7/i. MF - Piste 58.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 7 - j. MF - Piste 59" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 7/j. MF - Piste 59.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 7 - k. MF - Piste 60" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 7/k. MF - Piste 60.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 7 - l. Cahier - Piste 46 - Activite 25" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 7/l. Cahier - Piste 46 - Activite 25.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 7 - m. Unite 7 - DELF B1" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 7/m. Unite 7 - DELF B1.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - b. MF - Piste 62" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/b. MF - Piste 62.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - c. MF - Piste 63" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/c. MF - Piste 63.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - d. Cahier - Piste 48 - Activite 7" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/d. Cahier - Piste 48 - Activite 7.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - e. Cahier - Piste 50 - Activite 13" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/e. Cahier - Piste 50 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - f. Cahier - Piste 49 - Activite 10" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/f. Cahier - Piste 49 - Activite 10.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - g. MF - Piste 64" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/g. MF - Piste 64.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - h. Cahier - Piste 51" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/h. Cahier - Piste 51.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - j. MF - Piste 65" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/j. MF - Piste 65.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - k. Cahier - Piste 52" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/k. Cahier - Piste 52.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - l. MF - Piste 66" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/l. MF - Piste 66.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - m. MF - Piste 67" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/m. MF - Piste 67.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - n. MF - Piste 68" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/n. MF - Piste 68.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 8 - o. MF - DELF B1 - Unite 8" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 8/o. MF - DELF B1 - Unite 8.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 9 - b. MF - Piste 70" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 9/b. MF - Piste 70.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 9 - c. Cahier - Piste 54 - Activite 7" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 9/c. Cahier - Piste 54 - Activite 7.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 9 - d. Cahier - Piste 53 - Activite 3" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 9/d. Cahier - Piste 53 - Activite 3.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 9 - e. Cahier - Piste 55 - Activite 13" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 9/e. Cahier - Piste 55 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 9 - f. Cahier - Piste 57 - Activite 19" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 9/f. Cahier - Piste 57 - Activite 19.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 9 - g. MF - Piste 71" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 9/g. MF - Piste 71.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 9 - h. Cahier - Piste 56 - Activite 16" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 9/h. Cahier - Piste 56 - Activite 16.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 9 - i. MF - Phonetique - Jeu" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 9/i. MF - Phonetique - Jeu.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 9 - j. MF - Piste 73" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 9/j. MF - Piste 73.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 9 - k. Cahier - Piste 58 - Activite 23" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 9/k. Cahier - Piste 58 - Activite 23.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 9 - l. MF - DELF B1 - Unite 9" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.2/Saison 2 - Unite 9/l. MF - DELF B1 - Unite 9.mp3" data-free="false"></li>



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

