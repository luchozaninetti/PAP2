
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Wings of Freedom</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
      
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Lesson 00 - 01 Exercise C P07" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 00/01 Exercise C P07.mp3" data-free="false"></li>
<li data-title="Lesson 00 - 02 Exercise E P07 (CMat P04)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 00/02 Exercise E P07 (CMat P04).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 01 L01 P008 Get set! C" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/01 L01 P008 Get set! C.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 02 L01 P009 Get set! F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/02 L01 P009 Get set! F.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 03 L01 P009 Get set! G" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/03 L01 P009 Get set! G.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 04 L01 P009 Get set! I" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/04 L01 P009 Get set! I.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 05 L01 P010 Get set! J" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/05 L01 P010 Get set! J.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 06 L01 P011 Get it right - E(CMat P07)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/06 L01 P011 Get it right - E(CMat P07).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 07 L01 P012 Pick this up - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/07 L01 P012 Pick this up - A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 08 L01 P013 Pick this up - C" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/08 L01 P013 Pick this up - C.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 09 L01 P013 Pick this up - D(CMat P08)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/09 L01 P013 Pick this up - D(CMat P08).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 10 L01 P013 Pick this up - E" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/10 L01 P013 Pick this up - E.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 11 L01 P014 Show what you know - B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/11 L01 P014 Show what you know - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 12 L01 P014 Show what you know - C" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/12 L01 P014 Show what you know - C.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 13 L01 P015 Show what you know - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 01/13 L01 P015 Show what you know - F.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 01 L02 P016 Get set! D " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/01 L02 P016 Get set! D .mp3" data-free="false"></li>
<li data-title="Lesson 02 - 02 L02 P017 Get it right - B " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/02 L02 P017 Get it right - B .mp3" data-free="false"></li>
<li data-title="Lesson 02 - 03 L02 P018 Get it right - D " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/03 L02 P018 Get it right - D .mp3" data-free="false"></li>
<li data-title="Lesson 02 - 04 L02 P018 Get it right - G " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/04 L02 P018 Get it right - G .mp3" data-free="false"></li>
<li data-title="Lesson 02 - 05 L02 P019 Get it right - I " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/05 L02 P019 Get it right - I .mp3" data-free="false"></li>
<li data-title="Lesson 02 - 06 L02 P019 Get it right - J " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/06 L02 P019 Get it right - J .mp3" data-free="false"></li>
<li data-title="Lesson 02 - 07 L02 P019 Get it right - L" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/07 L02 P019 Get it right - L.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 08 L02 P020 Pick this up - A " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/08 L02 P020 Pick this up - A .mp3" data-free="false"></li>
<li data-title="Lesson 02 - 09 L02 P020 Pick this up - D " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/09 L02 P020 Pick this up - D .mp3" data-free="false"></li>
<li data-title="Lesson 02 - 10 L02 P021 Pick this up - E" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/10 L02 P021 Pick this up - E.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 11 L02 P022 Show what you know - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/11 L02 P022 Show what you know - A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 12 L02 P022 Show what you know - B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/12 L02 P022 Show what you know - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 13 L02 P023 Show what you know - E" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 02/13 L02 P023 Show what you know - E.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 01 L03 P026 Get set! B " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 03/01 L03 P026 Get set! B .mp3" data-free="false"></li>
<li data-title="Lesson 03 - 02 L03 P027 Get set! E " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 03/02 L03 P027 Get set! E .mp3" data-free="false"></li>
<li data-title="Lesson 03 - 03 L03 P027 Get set! G (CMat P13) " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 03/03 L03 P027 Get set! G (CMat P13) .mp3" data-free="false"></li>
<li data-title="Lesson 03 - 04 L03 P028 Get it right - B " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 03/04 L03 P028 Get it right - B .mp3" data-free="false"></li>
<li data-title="Lesson 03 - 05 L03 P028 Get it right - C " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 03/05 L03 P028 Get it right - C .mp3" data-free="false"></li>
<li data-title="Lesson 03 - 06 L03 P030 Pick this up - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 03/06 L03 P030 Pick this up - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 07 L03 P031 Pick this up - D" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 03/07 L03 P031 Pick this up - D.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 08 L03 P031 Pick this up - E" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 03/08 L03 P031 Pick this up - E.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 09 L03 P031 Pick this up - G" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 03/09 L03 P031 Pick this up - G.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 10 L03 P032 Show what you know - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 03/10 L03 P032 Show what you know - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 11 L03 P033 Show what you know - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 03/11 L03 P033 Show what you know - F.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 01 L04 P034 Get set! B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/01 L04 P034 Get set! B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 02 L04 P035 Get set! F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/02 L04 P035 Get set! F.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 03 L04 P035 Get set! H" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/03 L04 P035 Get set! H.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 04 L04 P037 Get it right - G" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/04 L04 P037 Get it right - G.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 05 L04 P037 Get it right - I" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/05 L04 P037 Get it right - I.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 06 L04 P037 Get it right - K" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/06 L04 P037 Get it right - K.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 07 L04 P038 Pick this up - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/07 L04 P038 Pick this up - A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 08 L04 P038 Pick this up - B (CMat P19)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/08 L04 P038 Pick this up - B (CMat P19).mp3" data-free="false"></li>
<li data-title="Lesson 04 - 09 L04 P039 Pick this up - E" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/09 L04 P039 Pick this up - E.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 10 L04 P039 Pick this up - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/10 L04 P039 Pick this up - F.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 11 L04 P039 Pick this up - G" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/11 L04 P039 Pick this up - G.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 12 L04 P040 Show what you know - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/12 L04 P040 Show what you know - A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 13 L04 P040 Show what you know - C" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/13 L04 P040 Show what you know - C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 14 L04 P041 Show what you know - G" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 04/14 L04 P041 Show what you know - G.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 01 L05 P044 Get set! - B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 05/01 L05 P044 Get set! - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 02 L05 P045 Get it right - B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 05/02 L05 P045 Get it right - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 03 L05 P045 Get it right - D" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 05/03 L05 P045 Get it right - D.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 04 L05 P046 Get it right - H" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 05/04 L05 P046 Get it right - H.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 05 L05 P047 Pick this up - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 05/05 L05 P047 Pick this up - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 06 L05 P047 Pick this up - C (CMat P23)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 05/06 L05 P047 Pick this up - C (CMat P23).mp3" data-free="false"></li>
<li data-title="Lesson 05 - 07 L05 P048 Pick this up - D " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 05/07 L05 P048 Pick this up - D .mp3" data-free="false"></li>
<li data-title="Lesson 05 - 08 L05 P048 Pick this up - H" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 05/08 L05 P048 Pick this up - H.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 09 L05 P049 Pick this up - J" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 05/09 L05 P049 Pick this up - J.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 10 L05 P050 Show what you know - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 05/10 L05 P050 Show what you know - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 11 L05 P050 Show what you know - B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 05/11 L05 P050 Show what you know - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 12 L05 P051 Show what you know - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 05/12 L05 P051 Show what you know - F.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 01 L06 P053 Get it right - D" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 06/01 L06 P053 Get it right - D.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 02 L06 P054 Get it right - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 06/02 L06 P054 Get it right - F.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 03 L06 P054 Get it right - H" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 06/03 L06 P054 Get it right - H.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 04 L06 P054 Get it right - J" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 06/04 L06 P054 Get it right - J.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 05 L06 P055 Pick this up - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 06/05 L06 P055 Pick this up - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 06 L06 P055 Pick this up - C (CMat P27)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 06/06 L06 P055 Pick this up - C (CMat P27).mp3" data-free="false"></li>
<li data-title="Lesson 06 - 07 L06 P056 Pick this up - D" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 06/07 L06 P056 Pick this up - D.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 08 L06 P056 Pick this up - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 06/08 L06 P056 Pick this up - F.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 09 L06 P057 Pick this up - M" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 06/09 L06 P057 Pick this up - M.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 10 L06 P058 Show what you know - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 06/10 L06 P058 Show what you know - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 11 L06 P059 Show what you know - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 06/11 L06 P059 Show what you know - F.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 01 L07 P064  Get set! - B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 07/01 L07 P064  Get set! - B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 02 L07 P064  Get set! - D" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 07/02 L07 P064  Get set! - D.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 03 L07 P065  Get set! - E" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 07/03 L07 P065  Get set! - E.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 04 L07 P065  Get set!  F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 07/04 L07 P065  Get set!  F.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 05 L07 P066  Get it right - C" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 07/05 L07 P066  Get it right - C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 06 L07 P066  Get it right - D (CMat P30)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 07/06 L07 P066  Get it right - D (CMat P30).mp3" data-free="false"></li>
<li data-title="Lesson 07 - 07 L07 P066  Get it right - E " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 07/07 L07 P066  Get it right - E .mp3" data-free="false"></li>
<li data-title="Lesson 07 - 08 L07 P067  Pick this up - A " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 07/08 L07 P067  Pick this up - A .mp3" data-free="false"></li>
<li data-title="Lesson 07 - 09 L07 P068  Pick this up - E " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 07/09 L07 P068  Pick this up - E .mp3" data-free="false"></li>
<li data-title="Lesson 07 - 10 L07 P068  Pick this up - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 07/10 L07 P068  Pick this up - F.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 11 L07 P070  Show what you know - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 07/11 L07 P070  Show what you know - A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 12 L07 P070  Show what you know - C" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 07/12 L07 P070  Show what you know - C.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 01 L08 P072 Get set! C " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 08/01 L08 P072 Get set! C .mp3" data-free="false"></li>
<li data-title="Lesson 08 - 02 L08 P073 Get set! G " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 08/02 L08 P073 Get set! G .mp3" data-free="false"></li>
<li data-title="Lesson 08 - 03 L08 P073 Get set! J " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 08/03 L08 P073 Get set! J .mp3" data-free="false"></li>
<li data-title="Lesson 08 - 04 L08 P074 Get it right - A " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 08/04 L08 P074 Get it right - A .mp3" data-free="false"></li>
<li data-title="Lesson 08 - 05 L08 P075 Get it right - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 08/05 L08 P075 Get it right - F.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 06 L08 P075 Get it right - H" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 08/06 L08 P075 Get it right - H.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 07 L08 P076 Pick this up - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 08/07 L08 P076 Pick this up - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 08 L08 P076 Pick this up - C (CMat P37)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 08/08 L08 P076 Pick this up - C (CMat P37).mp3" data-free="false"></li>
<li data-title="Lesson 08 - 09 L08 P077 Pick this up - D " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 08/09 L08 P077 Pick this up - D .mp3" data-free="false"></li>
<li data-title="Lesson 08 - 10 L08 P077 Pick this up - E" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 08/10 L08 P077 Pick this up - E.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 11 L08 P079 Show what you know - D" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 08/11 L08 P079 Show what you know - D.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 12 L08 P079 Show what you know - E" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 08/12 L08 P079 Show what you know - E.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 01 L09 P82 Get set! C " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 09/01 L09 P82 Get set! C .mp3" data-free="false"></li>
<li data-title="Lesson 09 - 02 L09 P82 Get set! E" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 09/02 L09 P82 Get set! E.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 03 L09 P83 Get it right - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 09/03 L09 P83 Get it right - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 04 L09 P84 Get it right - D" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 09/04 L09 P84 Get it right - D.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 05 L09 P84 Get it right - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 09/05 L09 P84 Get it right - F.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 06 L09 P85 Get it right - I" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 09/06 L09 P85 Get it right - I.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 07 L09 P86 Pick this up - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 09/07 L09 P86 Pick this up - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 08 L09 P86 Pick this up - B (CMat P40)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 09/08 L09 P86 Pick this up - B (CMat P40).mp3" data-free="false"></li>
<li data-title="Lesson 09 - 09 L09 P87 Pick this up - D" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 09/09 L09 P87 Pick this up - D.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 10 L09 P87 Pick this up - E" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 09/10 L09 P87 Pick this up - E.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 11 L09 P88 Show what you know - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 09/11 L09 P88 Show what you know - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 12 L09 P89 Show what you know - D" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 09/12 L09 P89 Show what you know - D.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 01 L10 P090 Get set! B " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/01 L10 P090 Get set! B .mp3" data-free="false"></li>
<li data-title="Lesson 10 - 02 L10 P091 Get set! E " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/02 L10 P091 Get set! E .mp3" data-free="false"></li>
<li data-title="Lesson 10 - 03 L10 P091 Get set! H " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/03 L10 P091 Get set! H .mp3" data-free="false"></li>
<li data-title="Lesson 10 - 04 L10 P092 Get it right - A " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/04 L10 P092 Get it right - A .mp3" data-free="false"></li>
<li data-title="Lesson 10 - 05 L10 P093 Get it right - E " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/05 L10 P093 Get it right - E .mp3" data-free="false"></li>
<li data-title="Lesson 10 - 06 L10 P093 Get it right - G" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/06 L10 P093 Get it right - G.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 07 L10 P094 Pick this up - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/07 L10 P094 Pick this up - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 08 L10 P094 Pick this up - B (CMat P43)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/08 L10 P094 Pick this up - B (CMat P43).mp3" data-free="false"></li>
<li data-title="Lesson 10 - 09 L10 P094 Pick this up - C (CMat P44)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/09 L10 P094 Pick this up - C (CMat P44).mp3" data-free="false"></li>
<li data-title="Lesson 10 - 10 L10 P095 Pick this up - D " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/10 L10 P095 Pick this up - D .mp3" data-free="false"></li>
<li data-title="Lesson 10 - 11 L10 P095 Pick this up - E" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/11 L10 P095 Pick this up - E.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 12 L10 P096 Show what you know - B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/12 L10 P096 Show what you know - B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 13 L10 P097 Show what you know - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 10/13 L10 P097 Show what you know - F.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 01 L11 P100 Get set! B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/01 L11 P100 Get set! B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 02 L11 P100 Get set! D" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/02 L11 P100 Get set! D.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 03 L11 P101 Get set! G" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/03 L11 P101 Get set! G.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 04 L11 P101 Get set! I" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/04 L11 P101 Get set! I.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 05 L11 P102 Get it right - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/05 L11 P102 Get it right - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 06 L11 P102 Get it right - B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/06 L11 P102 Get it right - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 07 L11 P103 Get it right - C" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/07 L11 P103 Get it right - C.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 08 L11 P103 Get it right - E" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/08 L11 P103 Get it right - E.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 09 L11 P104 Pick this up - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/09 L11 P104 Pick this up - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 10 L11 P105 Pick this up - C (CMat P48)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/10 L11 P105 Pick this up - C (CMat P48).mp3" data-free="false"></li>
<li data-title="Lesson 11 - 11 L11 P105 Pick this up - D" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/11 L11 P105 Pick this up - D.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 12 L11 P105 Pick this up - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/12 L11 P105 Pick this up - F.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 13 L11 P106 Show what you know - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/13 L11 P106 Show what you know - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 14 L11 P107 Show what you know - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 11/14 L11 P107 Show what you know - F.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 01 L12 P108 Get set! C " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 12/01 L12 P108 Get set! C .mp3" data-free="false"></li>
<li data-title="Lesson 12 - 02 L12 P109 Get set! F " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 12/02 L12 P109 Get set! F .mp3" data-free="false"></li>
<li data-title="Lesson 12 - 03 L12 P110  Get it right - B " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 12/03 L12 P110  Get it right - B .mp3" data-free="false"></li>
<li data-title="Lesson 12 - 04 L12 P110  Get it right - D " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 12/04 L12 P110  Get it right - D .mp3" data-free="false"></li>
<li data-title="Lesson 12 - 05 L12 P111  Get it right - F " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 12/05 L12 P111  Get it right - F .mp3" data-free="false"></li>
<li data-title="Lesson 12 - 06 L12 P111  Get it right - I " data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 12/06 L12 P111  Get it right - I .mp3" data-free="false"></li>
<li data-title="Lesson 12 - 07 L12 P111  Get it right - K (CMat P50)" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 12/07 L12 P111  Get it right - K (CMat P50).mp3" data-free="false"></li>
<li data-title="Lesson 12 - 08 L12 P112  Pick this up - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 12/08 L12 P112  Pick this up - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 09 L12 P113  Pick this up - D" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 12/09 L12 P113  Pick this up - D.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 10 L12 P114  Show what you know - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 12/10 L12 P114  Show what you know - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 11 L12 P114  Show what you know - B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 12/11 L12 P114  Show what you know - B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 12 L12 P115  Show what you know - F" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Lesson 12/12 L12 P115  Show what you know - F.mp3" data-free="false"></li>
<li data-title="Review 1 - 01 Review 1 P063 Listening - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Review 1/01 Review 1 P063 Listening - A.mp3" data-free="false"></li>
<li data-title="Review 1 - 02 Review 1 P063 Listening - B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Review 1/02 Review 1 P063 Listening - B.mp3" data-free="false"></li>
<li data-title="Review 1 - 03 Review 1 P063 Listening - C" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Review 1/03 Review 1 P063 Listening - C.mp3" data-free="false"></li>
<li data-title="Review 2 - 01 Review 2 P119 Listening - A" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Review 2/01 Review 2 P119 Listening - A.mp3" data-free="false"></li>
<li data-title="Review 2 - 02 Review 2 P119 Listening - B" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Review 2/02 Review 2 P119 Listening - B.mp3" data-free="false"></li>
<li data-title="Review 2 - 03 Review 2 P119 Listening - C" data-artist="Wings of Freedom" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Wings of Freedom/Review 2/03 Review 2 P119 Listening - C.mp3" data-free="false"></li>


	



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
