
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Speed 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
      
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Lesson 1 - 01 L1p06 Conversation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/01 L1p06 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 02 L1p06 Listening & Reading" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/02 L1p06 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 03 L1p07 Vocabulary - Balloon" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/03 L1p07 Vocabulary - Balloon.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 04 L1p07 Vocabulary - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/04 L1p07 Vocabulary - A.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 05 L1p08 Vocabulary - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/05 L1p08 Vocabulary - D.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 06 L1p08 Vocabualry - E" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/06 L1p08 Vocabualry - E.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 07 L1p08 Vocabulary - F - Who" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/07 L1p08 Vocabulary - F - Who.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 08 L1p08 Vocabulary - G - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/08 L1p08 Vocabulary - G - CM.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 09 L1p08 Language Bricks - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/09 L1p08 Language Bricks - A.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 10 L1p09 Language Bricks - C" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/10 L1p09 Language Bricks - C.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 11 L1p10 Language Bricks - E - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/11 L1p10 Language Bricks - E - CM.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 12 L1p10 Language Bricks - F" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/12 L1p10 Language Bricks - F.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 13 L1p11 Pronunciation - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/13 L1p11 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 14 L1p11 Pronunciation - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 1/14 L1p11 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 01 L2p12 Conversation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/01 L2p12 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 02 L2p12 Listening & Reading" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/02 L2p12 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 03 L2p13 Vocabulary - Balloon" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/03 L2p13 Vocabulary - Balloon.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 04 L2p13 Vocabulary - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/04 L2p13 Vocabulary - A.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 05 L2p13 Vocabulary - B - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/05 L2p13 Vocabulary - B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 06 L2p13 Vocabulary - C" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/06 L2p13 Vocabulary - C.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 07 L2p14 Vocabulary - E- CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/07 L2p14 Vocabulary - E- CM.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 08 L2p14 Vocabulary - F - Plural of nouns" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/08 L2p14 Vocabulary - F - Plural of nouns.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 09 L2p14 Vocabulary - F - noun+s" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/09 L2p14 Vocabulary - F - noun+s.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 10 L2p14 Vocabulary - G" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/10 L2p14 Vocabulary - G.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 11 L2p14 Vocabulary - H" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/11 L2p14 Vocabulary - H.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 12 L2p15 Language Bricks - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/12 L2p15 Language Bricks - A.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 13 L2p15 Language Bricks - C - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/13 L2p15 Language Bricks - C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 14 L2p16 Language Bricks - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/14 L2p16 Language Bricks - D.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 15 L2p17 Pronunciation - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/15 L2p17 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 16 L2p17 Pronunciation - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 2/16 L2p17 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 01 L3p18 Conversation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 3/01 L3p18 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 02 L3p18 Listening & Reading" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 3/02 L3p18 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 03 L3p19 Vocabulary - Balloon" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 3/03 L3p19 Vocabulary - Balloon.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 04 L3p19 Vocabulary - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 3/04 L3p19 Vocabulary - A.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 05 L3p20 Vocabulary - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 3/05 L3p20 Vocabulary - D.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 06 L3p20 Vocabulary - F" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 3/06 L3p20 Vocabulary - F.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 07 L3p20 Vocabulary - G" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 3/07 L3p20 Vocabulary - G.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 08 L3p21 Language Bricks - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 3/08 L3p21 Language Bricks - A.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 09 L3p21 Language Bricks - C" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 3/09 L3p21 Language Bricks - C.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 10 L3p22 Reading... - B - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 3/10 L3p22 Reading... - B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 11 L3p23 Pronunciation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 3/11 L3p23 Pronunciation.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 01 L4p24 Conversation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/01 L4p24 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 02 L4p24 Listening & Reading" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/02 L4p24 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 03 L4p25 Vocabulary - Balloon" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/03 L4p25 Vocabulary - Balloon.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 04 L4p25 Vocabulary - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/04 L4p25 Vocabulary - A.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 05 L4p25 Vocabulary - C" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/05 L4p25 Vocabulary - C.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 06 L4p26 Vocabulary - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/06 L4p26 Vocabulary - D.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 07 L4p26 Language Bricks - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/07 L4p26 Language Bricks - A.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 08 L4p26 Language Bricks - B - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/08 L4p26 Language Bricks - B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 09 L4p27 Language Bricks - E" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/09 L4p27 Language Bricks - E.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 10 L4p27 Language Bricks - F" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/10 L4p27 Language Bricks - F.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 11 L4p28 Language Bricks - G" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/11 L4p28 Language Bricks - G.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 11 L4p29 Pronunciation - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/11 L4p29 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 13 L4p29 Pronunciation - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 4/13 L4p29 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 01 L5p30 Conversation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/01 L5p30 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 02 L5p30 Listening & Reading" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/02 L5p30 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 03 L5p31 Vocabulary - Balloon" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/03 L5p31 Vocabulary - Balloon.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 04 L5p31 Vocabulary - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/04 L5p31 Vocabulary - A.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 05 L5p31 Vocabulary - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/05 L5p31 Vocabulary - B.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 06 L5p31 Vocabulary - C" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/06 L5p31 Vocabulary - C.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 07 L5p32 Vocabulary - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/07 L5p32 Vocabulary - D.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 08 L5p32 Language Bricks - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/08 L5p32 Language Bricks - A.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 09 L5p33 Language Bricks - C" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/09 L5p33 Language Bricks - C.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 10 L5p33 Language Bricks - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/10 L5p33 Language Bricks - D.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 11 L5p33 Language Bricks - E" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/11 L5p33 Language Bricks - E.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 12 L5p34 Language Bricks - F" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/12 L5p34 Language Bricks - F.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 13 L5p35 Pronunciation - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/13 L5p35 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 14 L5p35 Pronunciation - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 5/14 L5p35 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 01 L6p36 Conversation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/01 L6p36 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 02 L6p36 Listening & Reading" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/02 L6p36 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 03 L6p37 Vocabulary - Balloon" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/03 L6p37 Vocabulary - Balloon.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 04 L6p37 Vocabulary - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/04 L6p37 Vocabulary - A.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 05 L6p37 Vocabulary - C" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/05 L6p37 Vocabulary - C.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 06 L6p38 Vocabulary - E" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/06 L6p38 Vocabulary - E.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 07 L6p38 Vocabulary - F" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/07 L6p38 Vocabulary - F.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 08 L6p38 Vocabulary - G" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/08 L6p38 Vocabulary - G.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 09 L6p38 Vocabulary - H - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/09 L6p38 Vocabulary - H - CM.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 10 L6p39 Language Bricks - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/10 L6p39 Language Bricks - A.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 11 L6p39 Language Bricks - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/11 L6p39 Language Bricks - B.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 12 L6p39 Language Bricks - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/12 L6p39 Language Bricks - D.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 13 L6p40 Language Bricks - F" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/13 L6p40 Language Bricks - F.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 14 L6p41 Pronunciation - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/14 L6p41 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 15 L6p41 Pronunciation - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 6/15 L6p41 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 01 L7p42 Conversation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/01 L7p42 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 02 L7p42 Listening & Reading" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/02 L7p42 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 03 L7p43 Vocabulary - Balloon" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/03 L7p43 Vocabulary - Balloon.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 04 L7p43 Vocabulary - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/04 L7p43 Vocabulary - A.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 05 L7p44 Vocabulary - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/05 L7p44 Vocabulary - D.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 06 L7p44 Vocabulary - F - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/06 L7p44 Vocabulary - F - CM.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 07 L7p44 Vocabulary - G" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/07 L7p44 Vocabulary - G.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 08 L7p44 Vocabulary - Drinks" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/08 L7p44 Vocabulary - Drinks.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 09 L7p44 Vocabulary - H" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/09 L7p44 Vocabulary - H.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 10 L7p45 Language Bricks - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/10 L7p45 Language Bricks - A.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 11 L7p46 Language Bricks - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/11 L7p46 Language Bricks - D.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 12 L7p47 Pronunciation - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/12 L7p47 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 13 L7p47 Pronunciation - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 7/13 L7p47 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 01 L8p48 Conversation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/01 L8p48 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 02 L8p48 Listening & Reading" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/02 L8p48 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 03 L8p49 Vocabulary - Balloon" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/03 L8p49 Vocabulary - Balloon.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 04 L8p49 Vocabulary - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/04 L8p49 Vocabulary - A.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 05 L8p49 Vocabulary - C" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/05 L8p49 Vocabulary - C.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 06 L8p50 Vocabulary - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/06 L8p50 Vocabulary - D.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 07 L8p50 Vocabulary - F - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/07 L8p50 Vocabulary - F - CM.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 08 L8p50 Vocabulary - G" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/08 L8p50 Vocabulary - G.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 09 L8p50 Vocabulary - H" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/09 L8p50 Vocabulary - H.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 10 L8p51 Language Bricks - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/10 L8p51 Language Bricks - A.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 11 L8p51 Language Bricks - B - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/11 L8p51 Language Bricks - B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 12 L8p51 Language Bricks - C" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/12 L8p51 Language Bricks - C.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 13 L8p52 Language Bricks - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/13 L8p52 Language Bricks - D.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 14 L8p53 Pronunciation - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/14 L8p53 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 15 L8p53 Pronunciation - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 8/15 L8p53 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 01 L9p54 Conversation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/01 L9p54 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 02 L9p54 Listening & Reading" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/02 L9p54 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 03 L9p55 Vocabulary - Balloon" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/03 L9p55 Vocabulary - Balloon.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 04 L9p55 Vocabulary - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/04 L9p55 Vocabulary - A.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 05 L9p55 Vocabulary - C" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/05 L9p55 Vocabulary - C.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 06 L9p56 Vocabulary - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/06 L9p56 Vocabulary - D.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 07 L9p56 Vocabulary - E - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/07 L9p56 Vocabulary - E - CM.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 08 L9p56 Vocabulary - F" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/08 L9p56 Vocabulary - F.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 09 L9p56 Vocabulary - G" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/09 L9p56 Vocabulary - G.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 10 L9p56 Vocabulary - Allergens" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/10 L9p56 Vocabulary - Allergens.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 11 L9p57 Language Bricks - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/11 L9p57 Language Bricks - A.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 12 L9p58 Language Bricks - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/12 L9p58 Language Bricks - D.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 13 L9p59 Pronunciation - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/13 L9p59 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 14 L9p59 Pronunciation - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 9/14 L9p59 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 01 L10p60 Conversation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/01 L10p60 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 02 L10p60 Listening & Reading" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/02 L10p60 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 03 L10p61 Vocabulary - Balloon" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/03 L10p61 Vocabulary - Balloon.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 04 L10p61 Vocabulary - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/04 L10p61 Vocabulary - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 05 L10p61 Vocab. - B - Useful adjectives" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/05 L10p61 Vocab. - B - Useful adjectives.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 06 L10p62 Vocabulary - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/06 L10p62 Vocabulary - D.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 07 L10p62 Vocabulary - E" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/07 L10p62 Vocabulary - E.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 08 L10p62 Vocabulary - F - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/08 L10p62 Vocabulary - F - CM.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 09 L10p63 Language Bricks - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/09 L10p63 Language Bricks - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 10 L10p63 Language Bricks - Adjectives" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/10 L10p63 Language Bricks - Adjectives.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 11 L10p64 Language Bricks - C" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/11 L10p64 Language Bricks - C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 12 L10p65 Pronunciation - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/12 L10p65 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 13 L10p65 Pronunciation - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 10/13 L10p65 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 01 L11p66 Conversation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/01 L11p66 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 02 L11p66 Listening & Reading" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/02 L11p66 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 03 L11p67 Vocabulary - Balloon" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/03 L11p67 Vocabulary - Balloon.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 04 L11p67 Vocabulary - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/04 L11p67 Vocabulary - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 05 L11p67 Vocabulary - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/05 L11p67 Vocabulary - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 06 L11p67 Vocabulary - Map" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/06 L11p67 Vocabulary - Map.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 07 L11p68 Vocabulary - C - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/07 L11p68 Vocabulary - C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 08 L11p68 Vocabulary - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/08 L11p68 Vocabulary - D.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 09 L11p68 Vocabulary - F" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/09 L11p68 Vocabulary - F.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 10 L11p69 Language Bricks - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/10 L11p69 Language Bricks - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 11 L11p69 Language Bricks - B - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/11 L11p69 Language Bricks - B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 12 L11p70 Language Bricks - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/12 L11p70 Language Bricks - D.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 13 L11p71 Pronunciation - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/13 L11p71 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 14 L11p71 Pronunciation - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 11/14 L11p71 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 01 L12p72 Conversation" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/01 L12p72 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 02 L12p72 Listening& Reading" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/02 L12p72 Listening& Reading.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 03 L12p73 Vocabulary - Balloon" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/03 L12p73 Vocabulary - Balloon.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 04 L12p73 Vocabulary - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/04 L12p73 Vocabulary - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 05 L12p74 Vocabulary - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/05 L12p74 Vocabulary - D.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 06 L12p74 Vocabulary - E - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/06 L12p74 Vocabulary - E - CM.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 07 L12p74 Vocabulary - F" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/07 L12p74 Vocabulary - F.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 08 L12p75 Language Bricks - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/08 L12p75 Language Bricks - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 09 L12p75 Language Bricks - B - CM" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/09 L12p75 Language Bricks - B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 10 L12p75 Language Bricks - C" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/10 L12p75 Language Bricks - C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 11 L12p75 Language Bricks - Words" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/11 L12p75 Language Bricks - Words.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 12 L12p76 Language Bricks - D" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/12 L12p76 Language Bricks - D.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 13 L12p77 Pronunciation - A" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/13 L12p77 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 14 L12p77 Pronunciation - B" data-artist="Speed 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 2/Lesson 12/14 L12p77 Pronunciation - B.mp3" data-free="false"></li>


	



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
