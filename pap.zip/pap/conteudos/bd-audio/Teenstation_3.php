
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teenstation 3</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">

            <!-- ADICIONE OS DEMAIS ÁUDIOS-->




<li data-title="Lesson 01 - 01 L01 p06 Sparks A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/01 L01 p06 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 02 L01 p07 Sparks B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/02 L01 p07 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 03 L01 p08 Discoveries A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/03 L01 p08 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 04 L01 p08 Discoveries C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/04 L01 p08 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 05 L01 p09 Discoveries D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/05 L01 p09 Discoveries D.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 06 L01 p09 Explorations A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/06 L01 p09 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 07 L01 p10 Explorations B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/07 L01 p10 Explorations B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 08 L01 p10 Explorations C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/08 L01 p10 Explorations C.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 09 L01 p10 Language File" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/09 L01 p10 Language File.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 10 L01 p10 Explorations D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/10 L01 p10 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 11 L01 p11 Explorations E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/11 L01 p11 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 12 L01 p11 Explorations E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/12 L01 p11 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 13 L01 p11 Explorations F" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/13 L01 p11 Explorations F.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 14 L01 p12 Reflections A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 01/14 L01 p12 Reflections A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 01 L02 p14 Sparks A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 02/01 L02 p14 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 02 L02 p15 Sparks C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 02/02 L02 p15 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 03 L02 p16 Discoveries A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 02/03 L02 p16 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 04 L02 p16 Discoveries B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 02/04 L02 p16 Discoveries B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 05 L02 p16 Discoveries C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 02/05 L02 p16 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 06 L02 p17 Pronunciation File" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 02/06 L02 p17 Pronunciation File.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 07 L02 p18 Explorations A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 02/07 L02 p18 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 08 L02 p18 Explorations B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 02/08 L02 p18 Explorations B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 09 L02 p19 Explorations D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 02/09 L02 p19 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 10 L02 p19 Explorations D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 02/10 L02 p19 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 11 L02 p19 Explorations E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 02/11 L02 p19 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 12 L02 p21 Reflections C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 02/12 L02 p21 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 01 L03 p22 Sparks A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 03/01 L03 p22 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 02 L03 p23 Sparks C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 03/02 L03 p23 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 03 L03 p24 Discoveries A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 03/03 L03 p24 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 04 L03 p24 Discoveries A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 03/04 L03 p24 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 05 L03 p24 Discoveries B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 03/05 L03 p24 Discoveries B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 06 L03 p25 Discoveries D-E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 03/06 L03 p25 Discoveries D-E.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 07 L03 p25 Discoveries F" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 03/07 L03 p25 Discoveries F.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 08 L03 p26 Explorations A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 03/08 L03 p26 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 09 L03 p26 Explorations C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 03/09 L03 p26 Explorations C.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 10 L03 p27 Language File" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 03/10 L03 p27 Language File.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 11 L03 p27 Explorations E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 03/11 L03 p27 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 12 L03 p28 Reflections A " data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 03/12 L03 p28 Reflections A .mp3" data-free="false"></li>
<li data-title="Lesson 04 - 01 L04 p30 Sparks A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/01 L04 p30 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 02 L04 p31 Sparks B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/02 L04 p31 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 03 L04 p32 Discoveries A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/03 L04 p32 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 04 L04 p32 Discoveries A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/04 L04 p32 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 05 L04 p32 Discoveries B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/05 L04 p32 Discoveries B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 06 L04 p33 Discoveries C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/06 L04 p33 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 07 L04 p33 Discoveries D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/07 L04 p33 Discoveries D.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 08 L04 p33 Discoveries E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/08 L04 p33 Discoveries E.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 09 L04 p34 Explorations A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/09 L04 p34 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 10 L04 p35 Explorations C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/10 L04 p35 Explorations C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 11 L04 p35 Explorations D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/11 L04 p35 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 12 L04 p35 Pronunciation File" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/12 L04 p35 Pronunciation File.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 13 L04 p36 Reflections A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 04/13 L04 p36 Reflections A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 01 L05 p38 Sparks B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 05/01 L05 p38 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 02 L05 p39 Sparks C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 05/02 L05 p39 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 03 L05 p40 Discoveries B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 05/03 L05 p40 Discoveries B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 04 L05 p41 Discoveries C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 05/04 L05 p41 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 05 L05 p41 Discoveries D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 05/05 L05 p41 Discoveries D.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 06 L05 p41 Explorations A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 05/06 L05 p41 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 07 L05 p42 Explorations B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 05/07 L05 p42 Explorations B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 08 L05 p43 Explorations E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 05/08 L05 p43 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 09 L05 p44 Reflections B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 05/09 L05 p44 Reflections B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 10 L05 p45 Reflections D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 05/10 L05 p45 Reflections D.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 01 L06 p46 Sparks B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 06/01 L06 p46 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 02 L06 p47 Sparks C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 06/02 L06 p47 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 03 L06 p48 Discoveries A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 06/03 L06 p48 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 04 L06 p49 Discoveries B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 06/04 L06 p49 Discoveries B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 05 L06 p49 Discoveries C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 06/05 L06 p49 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 06 L06 p50 Explorations A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 06/06 L06 p50 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 07 L06 p50 Explorations B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 06/07 L06 p50 Explorations B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 08 L06 p50 Explorations C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 06/08 L06 p50 Explorations C.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 09 L06 p51 Explorations D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 06/09 L06 p51 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 10 L06 p51 Pronunciation File" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 06/10 L06 p51 Pronunciation File.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 11 L06 p53 Reflections E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 06/11 L06 p53 Reflections E.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 12 L06 p53 Reflections F" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 06/12 L06 p53 Reflections F.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 01 L07 p60 Sparks A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/01 L07 p60 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 02 L07 p61 Sparks C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/02 L07 p61 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 03 L07 p62 Discoveries A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/03 L07 p62 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 04 L07 p62 Discoveries A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/04 L07 p62 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 05 L07 p62 Discoveries B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/05 L07 p62 Discoveries B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 06 L07 p63 Language File" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/06 L07 p63 Language File.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 07 L07 p63 Discoveries D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/07 L07 p63 Discoveries D.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 08 L07 p63 Pronunciation File" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/08 L07 p63 Pronunciation File.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 09 L07 p63 Pronunciation File" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/09 L07 p63 Pronunciation File.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 10 L07 p64 Explorations A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/10 L07 p64 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 11 L07 p64 Explorations B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/11 L07 p64 Explorations B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 12 L07 p65 Explorations C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/12 L07 p65 Explorations C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 13 L07 p65 Explorations D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/13 L07 p65 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 14 L07 p66 Reflections C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/14 L07 p66 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 15 L07 p66 Reflections D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 07/15 L07 p66 Reflections D.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 01 L08 p68 Sparks A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 08/01 L08 p68 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 02 L08 p69 Sparks C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 08/02 L08 p69 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 03 L08 p70 Discoveries A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 08/03 L08 p70 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 04 L08 p70 Language File" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 08/04 L08 p70 Language File.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 05 L08 p71 Discoveries C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 08/05 L08 p71 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 06 L08 p71 Pronunciation File" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 08/06 L08 p71 Pronunciation File.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 07 L08 p72 Explorations A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 08/07 L08 p72 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 08 L08 p73 Explorations D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 08/08 L08 p73 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 09 L08 p73 Explorations E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 08/09 L08 p73 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 10 L08 p74 Reflections C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 08/10 L08 p74 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 11 L08 p74 Reflections D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 08/11 L08 p74 Reflections D.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 01 L09 p76 Sparks A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 09/01 L09 p76 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 02 L09 p77 Sparks B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 09/02 L09 p77 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 03 L09 p78 Discoveries A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 09/03 L09 p78 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 04 L09 p79 Discoveries C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 09/04 L09 p79 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 05 L09 p79 Discoveries E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 09/05 L09 p79 Discoveries E.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 06 L09 p80 Explorations A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 09/06 L09 p80 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 07 L09 p80 Explorations B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 09/07 L09 p80 Explorations B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 08 L09 p81 Explorations D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 09/08 L09 p81 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 09 L09 p81 Explorations E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 09/09 L09 p81 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 10 L09 p82 Reflections B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 09/10 L09 p82 Reflections B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 11 L09 p82 Reflections C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 09/11 L09 p82 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 01 L10 p84 Sparks B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 10/01 L10 p84 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 02 L10 p85 Sparks C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 10/02 L10 p85 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 03 L10 p86 Discoveries B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 10/03 L10 p86 Discoveries B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 04 L10 p87 Discoveries D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 10/04 L10 p87 Discoveries D.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 05 L10 p88 Discoveries G" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 10/05 L10 p88 Discoveries G.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 06 L10 p88 Explorations A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 10/06 L10 p88 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 07 L10 p89 Explorations D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 10/07 L10 p89 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 08 L10 p89 Pronunciation File" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 10/08 L10 p89 Pronunciation File.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 09 L10 p90 Reflections B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 10/09 L10 p90 Reflections B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 10 L10 p91 Reflections E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 10/10 L10 p91 Reflections E.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 01 L11 p92 Sparks(Verbs)" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 11/01 L11 p92 Sparks(Verbs).mp3" data-free="false"></li>
<li data-title="Lesson 11 - 02 L11 p92 Sparks B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 11/02 L11 p92 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 03 L11 p93 Sparks D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 11/03 L11 p93 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 04 L11 p94 Discoveries B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 11/04 L11 p94 Discoveries B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 05 L11 p95 Discoveries E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 11/05 L11 p95 Discoveries E.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 06 L11 p95 Discoveries E" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 11/06 L11 p95 Discoveries E.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 07 L11 p95 Discoveries F" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 11/07 L11 p95 Discoveries F.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 08 L11 p96 Explorations A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 11/08 L11 p96 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 09 L11 p96 Explorations B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 11/09 L11 p96 Explorations B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 10 L11 p97 Explorations D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 11/10 L11 p97 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 11 L11 p98 Reflections B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 11/11 L11 p98 Reflections B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 12 L11 p99 Reflections C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 11/12 L11 p99 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 01 L12 p100 Sparks B " data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 12/01 L12 p100 Sparks B .mp3" data-free="false"></li>
<li data-title="Lesson 12 - 02 L12 p101 Sparks C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 12/02 L12 p101 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 03 L12 p103 Discoveries D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 12/03 L12 p103 Discoveries D.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 04 L12 p104 Pronunciation File" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 12/04 L12 p104 Pronunciation File.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 05 L12 p104 Explorations A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 12/05 L12 p104 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 06 L12 p104 Explorations B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 12/06 L12 p104 Explorations B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 07 L12 p105 Explorations C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 12/07 L12 p105 Explorations C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 08 L12 p105 Explorations C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 12/08 L12 p105 Explorations C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 09 L12 p106 Reflections A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 12/09 L12 p106 Reflections A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 10 L12 p106 Reflections B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 12/10 L12 p106 Reflections B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 11 L12 p107 Reflections D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Lesson 12/11 L12 p107 Reflections D.mp3" data-free="false"></li>
<li data-title="Review 1 - 01 Review 1 p58 Listening A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Review 1/01 Review 1 p58 Listening A.mp3" data-free="false"></li>
<li data-title="Review 1 - 02 Review 1 p58 Listening B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Review 1/02 Review 1 p58 Listening B.mp3" data-free="false"></li>
<li data-title="Review 1 - 03 Review 1 p59 Listening C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Review 1/03 Review 1 p59 Listening C.mp3" data-free="false"></li>
<li data-title="Review 1 - 04 Review 1 p59 Listening D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Review 1/04 Review 1 p59 Listening D.mp3" data-free="false"></li>
<li data-title="Review 2 - 01 Review 2 p112 Listening A" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Review 2/01 Review 2 p112 Listening A.mp3" data-free="false"></li>
<li data-title="Review 2 - 02 Review 2 p112 Listening B" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Review 2/02 Review 2 p112 Listening B.mp3" data-free="false"></li>
<li data-title="Review 2 - 03 Review 2 p113 Listening C" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Review 2/03 Review 2 p113 Listening C.mp3" data-free="false"></li>
<li data-title="Review 2 - 04 Review 2 p113 Listening D" data-artist="Teenstation 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 3/Review 2/04 Review 2 p113 Listening D.mp3" data-free="false"></li>





	



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
