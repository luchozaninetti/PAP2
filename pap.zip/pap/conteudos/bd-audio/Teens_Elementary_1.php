
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Elementary 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
         
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    


<li data-title="APPENDIX 1 - 01 APPENDIX 1 P32 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/APPENDIX 1/01 APPENDIX 1 P32 A.mp3" data-free="false"></li>
<li data-title="APPENDIX 1 - 02 APPENDIX 1 PAGE 32 B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/APPENDIX 1/02 APPENDIX 1 PAGE 32 B.mp3" data-free="false"></li>
<li data-title="APPENDIX 2 - 01 APPENDIX 2 P88 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/APPENDIX 2/01 APPENDIX 2 P88 A.mp3" data-free="false"></li>
<li data-title="APPENDIX 2 - 02 APPENDIX 2 P88 B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/APPENDIX 2/02 APPENDIX 2 P88 B.mp3" data-free="false"></li>
<li data-title="ELEMENTARY ENGLISH TO GO - 01 L00 P06 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/ELEMENTARY ENGLISH TO GO/01 L00 P06 A.mp3" data-free="false"></li>
<li data-title="ELEMENTARY ENGLISH TO GO - 02 L00 P06 D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/ELEMENTARY ENGLISH TO GO/02 L00 P06 D.mp3" data-free="false"></li>
<li data-title="ELEMENTARY ENGLISH TO GO - 03 L00 P06 D THE ALPHABET RAP"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/ELEMENTARY ENGLISH TO GO/03 L00 P06 D THE ALPHABET RAP.mp3" data-free="false"></li>
<li data-title="ELEMENTARY ENGLISH TO GO - 04 L00 P06 D - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/ELEMENTARY ENGLISH TO GO/04 L00 P06 D - CM.mp3" data-free="false"></li>
<li data-title="ELEMENTARY ENGLISH TO GO - 05 L00 P06 E - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/ELEMENTARY ENGLISH TO GO/05 L00 P06 E - CM.mp3" data-free="false"></li>
<li data-title="ELEMENTARY ENGLISH TO GO - 06 L00 P06 F"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/ELEMENTARY ENGLISH TO GO/06 L00 P06 F.mp3" data-free="false"></li>
<li data-title="ELEMENTARY ENGLISH TO GO - 07 L00 P06 G"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/ELEMENTARY ENGLISH TO GO/07 L00 P06 G.mp3" data-free="false"></li>
<li data-title="ELEMENTARY ENGLISH TO GO - 08 L00 P06 G - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/ELEMENTARY ENGLISH TO GO/08 L00 P06 G - CM.mp3" data-free="false"></li>
<li data-title="ELEMENTARY ENGLISH TO GO - 09 L00 P07 J"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/ELEMENTARY ENGLISH TO GO/09 L00 P07 J.mp3" data-free="false"></li>
<li data-title="ELEMENTARY ENGLISH TO GO - 10 L00 P07 K - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/ELEMENTARY ENGLISH TO GO/10 L00 P07 K - CM.mp3" data-free="false"></li>
<li data-title="ELEMENTARY ENGLISH TO GO - 11 L00 P07 L"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/ELEMENTARY ENGLISH TO GO/11 L00 P07 L.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 01 L1 P08 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 1/01 L1 P08 A.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 02 L1 P08 C - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 1/02 L1 P08 C - CM.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 03 L1 P09 D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 1/03 L1 P09 D.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 04 L1 P10 GRAMMAR A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 1/04 L1 P10 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 05 L1 P11 VOCABULARY A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 1/05 L1 P11 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 06 L1 P11 SPEAKING AND WRITING A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 1/06 L1 P11 SPEAKING AND WRITING A.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 07 L1 P12 HOLLYS DIARY"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 1/07 L1 P12 HOLLYS DIARY.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 08 L1 P15 EXERCISES B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 1/08 L1 P15 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 09 L1 P15 EXERCISES C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 1/09 L1 P15 EXERCISES C.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 10 L1 P15 EXERCISES D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 1/10 L1 P15 EXERCISES D.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 11 L1 P15 EXERCISES E"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 1/11 L1 P15 EXERCISES E.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 01 L02 P16 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/01 L02 P16 A.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 02 L02 P16 B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/02 L02 P16 B.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 03 L02 P16 C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/03 L02 P16 C.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 04 L02 P17 E"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/04 L02 P17 E.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 05 L02 P17 G"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/05 L02 P17 G.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 06 L02 P18 GRAMMAR A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/06 L02 P18 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 07 L02 P18 GRAMMAR A CONTRACTIONS"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/07 L02 P18 GRAMMAR A CONTRACTIONS.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 08 L02 P18 GRAMMAR B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/08 L02 P18 GRAMMAR B.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 09 L02 P18 GRAMMAR C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/09 L02 P18 GRAMMAR C.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 10 L02 P18 GRAMMAR E - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/10 L02 P18 GRAMMAR E - CM.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 11 L02 P19 VOCABULARY A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/11 L02 P19 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 12 L02 P19 SPEAKING AND WRITING A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/12 L02 P19 SPEAKING AND WRITING A.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 13 L02 20 HOLLYS DIARY"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/13 L02 20 HOLLYS DIARY.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 14 L02 P22 EXERCISES A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/14 L02 P22 EXERCISES A.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 15 L02 P22 EXERCISES B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/15 L02 P22 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 16 L02 P23 EXERCISES C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/16 L02 P23 EXERCISES C.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 17 L02 P23 EXERCISES D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/17 L02 P23 EXERCISES D.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 18 L02 P23 EXERCISES E"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 2/18 L02 P23 EXERCISES E.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 01 L03 P24 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/01 L03 P24 A.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 02 L03 P24 C - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/02 L03 P24 C - CM.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 03 L03 P25 D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/03 L03 P25 D.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 04 L03 P25 F"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/04 L03 P25 F.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 05 L03 P26 GRAMMAR C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/05 L03 P26 GRAMMAR C.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 06 L03 P26 GRAMMAR D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/06 L03 P26 GRAMMAR D.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 07 L03 P27 VOCABULARY A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/07 L03 P27 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 08 L03 P27 VOCABULARY B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/08 L03 P27 VOCABULARY B.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 09 L03 P27 VOCABULARY C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/09 L03 P27 VOCABULARY C.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 10 L03 P27 SPEAKING AND WRITING - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/10 L03 P27 SPEAKING AND WRITING - CM.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 11 L03 P28 HOLLYS DIARY"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/11 L03 P28 HOLLYS DIARY.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 12 L03 P30 EXERCISES A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/12 L03 P30 EXERCISES A.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 13 L03 P31 EXERCISES B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/13 L03 P31 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 14 L03 P31 EXERCISES C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/14 L03 P31 EXERCISES C.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 15 L03 P31 EXERCISES D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 3/15 L03 P31 EXERCISES D.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 01 L04 P34 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 4/01 L04 P34 A.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 02 L04 P34 B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 4/02 L04 P34 B.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 03 L04 P35 E"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 4/03 L04 P35 E.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 04 L04 P35 G"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 4/04 L04 P35 G.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 05 L04 P36 GRAMMAR A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 4/05 L04 P36 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 06 L04 P36 GRAMMAR  C - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 4/06 L04 P36 GRAMMAR  C - CM.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 07 L04 P37 VOCABULARY A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 4/07 L04 P37 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 08 L04 P37 VOCABULARY B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 4/08 L04 P37 VOCABULARY B.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 09 L04 P38 HOLLYS DIARY"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 4/09 L04 P38 HOLLYS DIARY.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 10 L04 P41 EXERCISES D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 4/10 L04 P41 EXERCISES D.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 11 L04 P41 EXERCISES E"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 4/11 L04 P41 EXERCISES E.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 12 L04 P41 EXERCISES F"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 4/12 L04 P41 EXERCISES F.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 01 L5 P42 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 5/01 L5 P42 A.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 02 L5 P43 D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 5/02 L5 P43 D.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 03 L5 P43 F"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 5/03 L5 P43 F.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 04 L5 P44 GRAMMAR A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 5/04 L5 P44 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 05 L5 P44 GRAMMAR B - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 5/05 L5 P44 GRAMMAR B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 06 L5 P44 GRAMMAR C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 5/06 L5 P44 GRAMMAR C.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 07 L5 P45 GRAMMAR E"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 5/07 L5 P45 GRAMMAR E.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 08 L5 P45 VOCABULARY A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 5/08 L5 P45 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 09 L5 P45 VOCABULARY C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 5/09 L5 P45 VOCABULARY C.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 10 L5 P46 HOLLYS DIARY"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 5/10 L5 P46 HOLLYS DIARY.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 11 L5 P49 EXERCISES E"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 5/11 L5 P49 EXERCISES E.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 12 L5 P49 EXERCISES F"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 5/12 L5 P49 EXERCISES F.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 01 L06 P50 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/01 L06 P50 A.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 02 L06 P50 B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/02 L06 P50 B.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 03 L06 P51 D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/03 L06 P51 D.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 04 L06 P51 F"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/04 L06 P51 F.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 05 L06 P52 GRAMMAR A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/05 L06 P52 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 06 L06 P52 GRAMMAR C - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/06 L06 P52 GRAMMAR C - CM.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 07 L06 P52 GRAMMAR D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/07 L06 P52 GRAMMAR D.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 08 L06 P53 VOCABULARY A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/08 L06 P53 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 09 L06 P53 VOCABULARY B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/09 L06 P53 VOCABULARY B.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 10 L06 P53 VOCABULARY C - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/10 L06 P53 VOCABULARY C - CM.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 11 L06 P54 HOLLYS DIARY"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/11 L06 P54 HOLLYS DIARY.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 12 L06 P56 EXERCISES A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/12 L06 P56 EXERCISES A.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 13 L06 P57 EXERCISES B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 6/13 L06 P57 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 01 L07 P64 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/01 L07 P64 A.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 02 L07 P64 B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/02 L07 P64 B.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 03 L07 P65 D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/03 L07 P65 D.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 04 L07 P65 F"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/04 L07 P65 F.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 05 L07 P66 GRAMMAR A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/05 L07 P66 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 06 L07 P66 GRAMMAR B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/06 L07 P66 GRAMMAR B.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 07 L07 P66 GRAMMAR C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/07 L07 P66 GRAMMAR C.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 08 L07 P66 GRAMMAR D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/08 L07 P66 GRAMMAR D.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 09 L07 P66 GRAMMAR  E - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/09 L07 P66 GRAMMAR  E - CM.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 10 L07 P67 VOCABULARY A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/10 L07 P67 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 11 L07 P67 SPEAKING AND WRITING A - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/11 L07 P67 SPEAKING AND WRITING A - CM.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 12 L07 P68 HOLLYS DIARY"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/12 L07 P68 HOLLYS DIARY.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 13 L07 P70 EXERCISES A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/13 L07 P70 EXERCISES A.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 14 L07 P70 EXERCISES B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/14 L07 P70 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 15 L07 P71 EXERCISES D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 7/15 L07 P71 EXERCISES D.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 01 L08 P72 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/01 L08 P72 A.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 02 L08 P72 B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/02 L08 P72 B.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 03 L08 P73 E"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/03 L08 P73 E.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 04 L08 P73 G"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/04 L08 P73 G.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 05 L08 P74 GRAMMAR A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/05 L08 P74 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 06 L08 P74 GRAMMAR D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/06 L08 P74 GRAMMAR D.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 07 L08 P74 GRAMMAR F - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/07 L08 P74 GRAMMAR F - CM.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 08 L08 P75 VOCABULARY A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/08 L08 P75 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 09 L08 P75 VOCABULARY B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/09 L08 P75 VOCABULARY B.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 10 L08 P75 SPEAKING AND WRITING A - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/10 L08 P75 SPEAKING AND WRITING A - CM.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 11 L08 P76 HOLLYS DIARY"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/11 L08 P76 HOLLYS DIARY.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 12 L08 P78 EXERCISES A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/12 L08 P78 EXERCISES A.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 13 L08 P78 EXERCISES B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/13 L08 P78 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 14 L08 P79 EXERCISES D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/14 L08 P79 EXERCISES D.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 15 L08 P79 EXERCISES E"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 8/15 L08 P79 EXERCISES E.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 01 L09 P80 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 9/01 L09 P80 A.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 02 L09 P81 D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 9/02 L09 P81 D.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 03 L09 P82 GRAMMAR A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 9/03 L09 P82 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 04 L09 P82 GRAMMAR D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 9/04 L09 P82 GRAMMAR D.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 05 L09 P83 VOCABULARY A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 9/05 L09 P83 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 06 L09 P83 VOCABULARY B and C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 9/06 L09 P83 VOCABULARY B and C.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 07 L09 P83 SPEAKING AND WRITING A - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 9/07 L09 P83 SPEAKING AND WRITING A - CM.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 08 L09 P84 HOLLYS DIARY"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 9/08 L09 P84 HOLLYS DIARY.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 01 L10 P90 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/01 L10 P90 A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 02 L10 P90 C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/02 L10 P90 C.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 03 L10 P91 D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/03 L10 P91 D.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 04 L10 P91 F"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/04 L10 P91 F.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 05 L10 P92 GRAMMAR A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/05 L10 P92 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 06 L10 P92 GRAMMAR B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/06 L10 P92 GRAMMAR B.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 07 L10 P92 GRAMMAR C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/07 L10 P92 GRAMMAR C.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 08 L10 P92 VOCABULARY A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/08 L10 P92 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 09 L10 P93 VOCABULARY B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/09 L10 P93 VOCABULARY B.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 10 L10 P93 VOCABULARY C - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/10 L10 P93 VOCABULARY C - CM.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 11 L10 P93 VOCABULARY D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/11 L10 P93 VOCABULARY D.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 12 L10 P94 HOLLYS DIARY"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/12 L10 P94 HOLLYS DIARY.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 13 L10 P96 EXERCISES A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/13 L10 P96 EXERCISES A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 14 L10 P96 EXERCISES B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/14 L10 P96 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 15 L10 P97 EXERCISES C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 10/15 L10 P97 EXERCISES C.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 01 L11 P98 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 11/01 L11 P98 A.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 02 L11 P98 B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 11/02 L11 P98 B.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 03 L11 P99 D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 11/03 L11 P99 D.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 04 L11 P99 F"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 11/04 L11 P99 F.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 05 L11 P100 GRAMMAR A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 11/05 L11 P100 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 06 L11 P100 GRAMMAR C - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 11/06 L11 P100 GRAMMAR C - CM.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 07 L11 P100 GRAMMAR E"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 11/07 L11 P100 GRAMMAR E.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 08 L11 P101 VOCABULARY A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 11/08 L11 P101 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 09 L11 P101 VOCABULARY C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 11/09 L11 P101 VOCABULARY C.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 10 L11 P102 HOLLYS DIARY"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 11/10 L11 P102 HOLLYS DIARY.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 11 L11 P104 EXERCISES A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 11/11 L11 P104 EXERCISES A.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 12 L11 P105 EXERCISES D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 11/12 L11 P105 EXERCISES D.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 01 L12 P106 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/01 L12 P106 A.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 02 L12 P106 B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/02 L12 P106 B.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 03 L12 P106 C - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/03 L12 P106 C - CM.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 04 L12 P107 D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/04 L12 P107 D.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 05 L12 P107 F"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/05 L12 P107 F.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 06 L12 P107  F - CM"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/06 L12 P107  F - CM.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 07 L12 P108 GRAMMAR A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/07 L12 P108 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 08 L12 P108 GRAMMAR E"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/08 L12 P108 GRAMMAR E.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 09 L12 P109 VOCABULARY A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/09 L12 P109 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 10 L12 P109 VOCABULARY B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/10 L12 P109 VOCABULARY B.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 11 L12 P110 HOLLYS DIARY"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/11 L12 P110 HOLLYS DIARY.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 12 L12 P112 EXERCISES A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/12 L12 P112 EXERCISES A.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 13 L12 P113 EXERCISES C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/LESSON 12/13 L12 P113 EXERCISES C.mp3" data-free="false"></li>
<li data-title="REVIEW 1 - 01 REVIEW 1 P62 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/REVIEW 1/01 REVIEW 1 P62 A.mp3" data-free="false"></li>
<li data-title="REVIEW 1 - 02 REVIEW 1 P62 B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/REVIEW 1/02 REVIEW 1 P62 B.mp3" data-free="false"></li>
<li data-title="REVIEW 1 - 03 REVIEW 1 P63 C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/REVIEW 1/03 REVIEW 1 P63 C.mp3" data-free="false"></li>
<li data-title="REVIEW 1 - 04 REVIEW 1 P63 D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/REVIEW 1/04 REVIEW 1 P63 D.mp3" data-free="false"></li>
<li data-title="REVIEW 2 - 01 REVIEW 2 P118 A"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/REVIEW 2/01 REVIEW 2 P118 A.mp3" data-free="false"></li>
<li data-title="REVIEW 2 - 02 REVIEW 2 P118 B"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/REVIEW 2/02 REVIEW 2 P118 B.mp3" data-free="false"></li>
<li data-title="REVIEW 2 - 03 REVIEW 2 P119 C"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/REVIEW 2/03 REVIEW 2 P119 C.mp3" data-free="false"></li>
<li data-title="REVIEW 2 - 04 REVIEW 2 P119 D"data-artist="Teens Elementary 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 1/REVIEW 2/04 REVIEW 2 P119 D.mp3" data-free="false"></li>



	



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
