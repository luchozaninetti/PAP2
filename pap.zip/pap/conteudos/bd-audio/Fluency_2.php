
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Fluency 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
           
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="LESSON 01 - 01.L1 P008 KICK IT OFF B CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 01/01.L1 P008 KICK IT OFF B CM.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 02. L1 P008 WORD BOOSTER 1" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 01/02. L1 P008 WORD BOOSTER 1.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 03. L1 P009 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 01/03. L1 P009 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 04. L1 P010 LEARNING A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 01/04. L1 P010 LEARNING A.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 05. L1 P010 LEARNING B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 01/05. L1 P010 LEARNING B.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 06. L1 P010 LANGUAGE BOOSTER 1" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 01/06. L1 P010 LANGUAGE BOOSTER 1.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 07. L1 P011 READING B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 01/07. L1 P011 READING B.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 08. L1 P012 VOCABULARY A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 01/08. L1 P012 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 09. L1 P012 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 01/09. L1 P012 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 10. L1 P013 SOUNDS GOOD A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 01/10. L1 P013 SOUNDS GOOD A.mp3" data-free="false"></li>
<li data-title="LESSON 01 - 11. L1 P013 FLUENCY" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 01/11. L1 P013 FLUENCY.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 01. L2 P016 KICK IT OFF B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 02/01. L2 P016 KICK IT OFF B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 02. L2 P016 WORD BOOSTER 2 - BIG ANIMALS" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 02/02. L2 P016 WORD BOOSTER 2 - BIG ANIMALS.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 03. L2 P016 WORD BOOSTER 2 - INSECTS" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 02/03. L2 P016 WORD BOOSTER 2 - INSECTS.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 04. L2 P016 VOCABULARY A - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 02/04. L2 P016 VOCABULARY A - CM.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 05. L2 P017 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 02/05. L2 P017 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 06. L2 P018 LEARNING A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 02/06. L2 P018 LEARNING A.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 07. L2 P019 READING - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 02/07. L2 P019 READING - B.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 08. L2 P020 VOCABULARY A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 02/08. L2 P020 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 09. L2 P020 VOCABULARY B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 02/09. L2 P020 VOCABULARY B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 10. L2 P020 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 02/10. L2 P020 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 11. L2 P021 SOUNDS GOOD A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 02/11. L2 P021 SOUNDS GOOD A.mp3" data-free="false"></li>
<li data-title="LESSON 02 - 12. L2 P021 FLUENCY" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 02/12. L2 P021 FLUENCY.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 01 L3 P026 KICK IT OFF! B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 03/01 L3 P026 KICK IT OFF! B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 02. L3 P026 WORD BOOSTER 3 - WORDS" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 03/02. L3 P026 WORD BOOSTER 3 - WORDS.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 03 L3P026 WORD BOOSTER 3 - EXERCISE" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 03/03 L3P026 WORD BOOSTER 3 - EXERCISE.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 04. L3 P026 WORD BOOSTER 3 - ADJECTIVES" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 03/04. L3 P026 WORD BOOSTER 3 - ADJECTIVES.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 05. L3 P027 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 03/05. L3 P027 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 06. L3 P028 LEARNING A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 03/06. L3 P028 LEARNING A.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 07. L3 P028 LEARNING C - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 03/07. L3 P028 LEARNING C - CM.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 08. L3 P029 READING B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 03/08. L3 P029 READING B.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 09. L3 P030 VOCABULARY A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 03/09. L3 P030 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 10. L3 P030 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 03/10. L3 P030 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 11. L3 P031 SOUNDS GOOD A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 03/11. L3 P031 SOUNDS GOOD A.mp3" data-free="false"></li>
<li data-title="LESSON 03 - 12. L3 P031 FLUENCY" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 03/12. L3 P031 FLUENCY.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 01. L4 P034 KICK IT OFF! B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 04/01. L4 P034 KICK IT OFF! B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 02. L4 P034 WORD BOOSTER 4" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 04/02. L4 P034 WORD BOOSTER 4.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 03 L4 P035 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 04/03 L4 P035 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 04 L4 P036 LEARNING A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 04/04 L4 P036 LEARNING A.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 05. L4 P037 READING B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 04/05. L4 P037 READING B.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 06. L4 P038 VOCABULARY A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 04/06. L4 P038 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 07. L04 P038 VOCABULARY B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 04/07. L04 P038 VOCABULARY B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 08. L4 P038 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 04/08. L4 P038 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 09 L4 P039 SOUNDS GOOD A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 04/09 L4 P039 SOUNDS GOOD A.mp3" data-free="false"></li>
<li data-title="LESSON 04 - 10. L4 P039 FLUENCY" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 04/10. L4 P039 FLUENCY.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 01.L05 P044 KICK IT OFF B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 05/01.L05 P044 KICK IT OFF B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 02 L5 P044 WORD BOOSTER 5" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 05/02 L5 P044 WORD BOOSTER 5.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 03 L5 P044 VOCABULARY A - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 05/03 L5 P044 VOCABULARY A - CM.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 04 L5 P044 VOCABULARY B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 05/04 L5 P044 VOCABULARY B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 05 L5 P045 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 05/05 L5 P045 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 06 L5 P046 LEARNING A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 05/06 L5 P046 LEARNING A.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 07 L5P047 READING B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 05/07 L5P047 READING B.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 08 L5 P048 VOCABULARY A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 05/08 L5 P048 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 09 L5 P048 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 05/09 L5 P048 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 10 L5 P049 SOUNDS GOOD A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 05/10 L5 P049 SOUNDS GOOD A.mp3" data-free="false"></li>
<li data-title="LESSON 05 - 11 L5 P049 FLUENCY" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 05/11 L5 P049 FLUENCY.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 01 L06 P056 KICK IT OFF B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 06/01 L06 P056 KICK IT OFF B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 02 L6 P056 WORD BOOSTER 6" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 06/02 L6 P056 WORD BOOSTER 6.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 03 L06 P056 VOCABULARY A - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 06/03 L06 P056 VOCABULARY A - CM.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 04. L6 P057 LISTENING A -B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 06/04. L6 P057 LISTENING A -B.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 05 L6 P058 LEARNING A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 06/05 L6 P058 LEARNING A.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 06. L6 P059 READING B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 06/06. L6 P059 READING B.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 07. L6 P060 VOCABULARY A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 06/07. L6 P060 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 08 L6 P060 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 06/08 L6 P060 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 09 L6 P061 SOUNDS GOOD A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 06/09 L6 P061 SOUNDS GOOD A.mp3" data-free="false"></li>
<li data-title="LESSON 06 - 10 L6 P061 FLUENCY" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 06/10 L6 P061 FLUENCY.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 01 L7 P066 KICK IT OFF B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 07/01 L7 P066 KICK IT OFF B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 02 L7 P066 WORD BOOSTER 7" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 07/02 L7 P066 WORD BOOSTER 7.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 03 L07 P66 VOCABULARY A - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 07/03 L07 P66 VOCABULARY A - CM.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 04 L7 P067 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 07/04 L7 P067 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 05 L7 P068 LEARNING A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 07/05 L7 P068 LEARNING A.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 06 L7 P069 READING B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 07/06 L7 P069 READING B.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 07 L7 P070 VOCABULARY A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 07/07 L7 P070 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 08 L7 P070 LISTENING A-B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 07/08 L7 P070 LISTENING A-B.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 09 L7 P071 SOUNDS GOOD A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 07/09 L7 P071 SOUNDS GOOD A.mp3" data-free="false"></li>
<li data-title="LESSON 07 - 10 L7 P071 FLUENCY" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 07/10 L7 P071 FLUENCY.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 01. L8 P074 KICK IT OFF B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 08/01. L8 P074 KICK IT OFF B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 02. L8 P074 WORD BOOSTER 8" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 08/02. L8 P074 WORD BOOSTER 8.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 03. L8 P075 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 08/03. L8 P075 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 04. L8 P076 LEARNING A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 08/04. L8 P076 LEARNING A.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 05. L8 P077 READING B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 08/05. L8 P077 READING B.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 06. L8 P078 VOCABULARY A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 08/06. L8 P078 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 07. L8 P078 VOCABULARY B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 08/07. L8 P078 VOCABULARY B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 08. L8 P078 LISTENING A -B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 08/08. L8 P078 LISTENING A -B.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 09. L8 P079 SOUNDS GOOD A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 08/09. L8 P079 SOUNDS GOOD A.mp3" data-free="false"></li>
<li data-title="LESSON 08 - 10. L8 P079 FLUENCY" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 08/10. L8 P079 FLUENCY.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 01. L9 P084 KICK IT OFF B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 09/01. L9 P084 KICK IT OFF B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 02 L9 P084 WORD BOOSTER 9" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 09/02 L9 P084 WORD BOOSTER 9.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 03. L9 P085 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 09/03. L9 P085 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 04. L9 P086 LEARNING A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 09/04. L9 P086 LEARNING A.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 05. L9 P087 READING B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 09/05. L9 P087 READING B.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 06. L9 P088 VOCABULARY A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 09/06. L9 P088 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 07. L9 P088 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 09/07. L9 P088 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 08. L9 P089 SOUNDS GOOD A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 09/08. L9 P089 SOUNDS GOOD A.mp3" data-free="false"></li>
<li data-title="LESSON 09 - 09. L9 P089 FLUENCY" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 09/09. L9 P089 FLUENCY.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 01. L10 KICK IT OFF B - CM" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 10/01. L10 KICK IT OFF B - CM.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 02. L10 P092 WORD BOOSTER 10" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 10/02. L10 P092 WORD BOOSTER 10.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 03. L10 P093 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 10/03. L10 P093 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 04. L10 P094 LEARNING A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 10/04. L10 P094 LEARNING A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 05. L10 P095 READING B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 10/05. L10 P095 READING B.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 06. L10 P096 VOCABULARY A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 10/06. L10 P096 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 07. L10 P096 LISTENING A - B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 10/07. L10 P096 LISTENING A - B.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 08. L10 P097 SOUNDS GOOD A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 10/08. L10 P097 SOUNDS GOOD A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 09. L10 P097 FLUENCY" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/LESSON 10/09. L10 P097 FLUENCY.mp3" data-free="false"></li>
<li data-title="PRONUNCIATION (FLUENCY BOOSTER) - 01 FB1 P023 PRONUNCIATION A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/PRONUNCIATION (FLUENCY BOOSTER)/01 FB1 P023 PRONUNCIATION A.mp3" data-free="false"></li>
<li data-title="PRONUNCIATION (FLUENCY BOOSTER) - 02 FB2 P041 PRONUNCIATION A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/PRONUNCIATION (FLUENCY BOOSTER)/02 FB2 P041 PRONUNCIATION A.mp3" data-free="false"></li>
<li data-title="PRONUNCIATION (FLUENCY BOOSTER) - 03 FB3 P063 PRONUNCIATION A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/PRONUNCIATION (FLUENCY BOOSTER)/03 FB3 P063 PRONUNCIATION A.mp3" data-free="false"></li>
<li data-title="PRONUNCIATION (FLUENCY BOOSTER) - 04 FB4 P081 PRONUNCIATION A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/PRONUNCIATION (FLUENCY BOOSTER)/04 FB4 P081 PRONUNCIATION A.mp3" data-free="false"></li>
<li data-title="PRONUNCIATION (FLUENCY BOOSTER) - 05 FB5 P099 PRONUNCIATION A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/PRONUNCIATION (FLUENCY BOOSTER)/05 FB5 P099 PRONUNCIATION A.mp3" data-free="false"></li>
<li data-title="WRAP IT UP 1 - 01 WU1 EXERCISE A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/WRAP IT UP 1/01 WU1 EXERCISE A.mp3" data-free="false"></li>
<li data-title="WRAP IT UP 1 - 02 WU1 EXERCISE B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/WRAP IT UP 1/02 WU1 EXERCISE B.mp3" data-free="false"></li>
<li data-title="WRAP IT UP 1 - 03 WU1 EXERCISE C" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/WRAP IT UP 1/03 WU1 EXERCISE C.mp3" data-free="false"></li>
<li data-title="WRAP IT UP 2 - 01 WU2 EXERCISE A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/WRAP IT UP 2/01 WU2 EXERCISE A.mp3" data-free="false"></li>
<li data-title="WRAP IT UP 2 - 02 WU2 EXERCISE B" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/WRAP IT UP 2/02 WU2 EXERCISE B.mp3" data-free="false"></li>
<li data-title="WRAP IT UP 2 - 03 WU2 EXERCISE C" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/WRAP IT UP 2/03 WU2 EXERCISE C.mp3" data-free="false"></li>
<li data-title="WRITING BANK - 01 WB1 P125 EXERCISE A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/WRITING BANK/01 WB1 P125 EXERCISE A.mp3" data-free="false"></li>
<li data-title="WRITING BANK - 02 WB2 P126 EXERCISE A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/WRITING BANK/02 WB2 P126 EXERCISE A.mp3" data-free="false"></li>
<li data-title="WRITING BANK - 03 WB3 P127 EXERCISE A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/WRITING BANK/03 WB3 P127 EXERCISE A.mp3" data-free="false"></li>
<li data-title="WRITING BANK - 04 WB4 P128 EXERCISE A" data-artist="Fluency 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fluency 2/WRITING BANK/04 WB4 P128 EXERCISE A.mp3" data-free="false"></li>



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
