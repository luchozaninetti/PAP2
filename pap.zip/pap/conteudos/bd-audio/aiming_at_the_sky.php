
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Aiming at the Sky</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
            
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Lesson 00 - 01 P007 Aiming at the Sky (CMat P05)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 00/01 P007 Aiming at the Sky (CMat P05).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 01 L01 P008 Start off (B) Words" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 01/01 L01 P008 Start off (B) Words.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 02 L01 P008 Start off (B) Text" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 01/02 L01 P008 Start off (B) Text.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 03 L01 P009 Start off (C) " data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 01/03 L01 P009 Start off (C) .mp3" data-free="false"></li>
<li data-title="Lesson 01 - 04 L01 P009 Start off - D (CMat P07)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 01/04 L01 P009 Start off - D (CMat P07).mp3" data-free="false"></li>
<li data-title="Lesson 01 - 05 L01 P010 Check this out (A) " data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 01/05 L01 P010 Check this out (A) .mp3" data-free="false"></li>
<li data-title="Lesson 01 - 06 L01 P010 Check this out (C) " data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 01/06 L01 P010 Check this out (C) .mp3" data-free="false"></li>
<li data-title="Lesson 01 - 07 L01 P012 Your say 2 - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 01/07 L01 P012 Your say 2 - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 08 L01 P013 It sounds good" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 01/08 L01 P013 It sounds good.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 09 L01 P013  Words to remember" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 01/09 L01 P013  Words to remember.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 10 L01 P014  Homework - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 01/10 L01 P014  Homework - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 11 L01 P015  Homework - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 01/11 L01 P015  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 01 L02 P017 Start off - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/01 L02 P017 Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 02 L02 P017 Start off - C (CMat P10)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/02 L02 P017 Start off - C (CMat P10).mp3" data-free="false"></li>
<li data-title="Lesson 02 - 03 L02 P017 Start off - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/03 L02 P017 Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 04 L02 P018 Check this out - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/04 L02 P018 Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 05 L02 P019 Your say 1- A (CMat P12)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/05 L02 P019 Your say 1- A (CMat P12).mp3" data-free="false"></li>
<li data-title="Lesson 02 - 06 L02 P020 Your say 2- A (CMat P13)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/06 L02 P020 Your say 2- A (CMat P13).mp3" data-free="false"></li>
<li data-title="Lesson 02 - 07 L02 P021 It sounds good - A " data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/07 L02 P021 It sounds good - A .mp3" data-free="false"></li>
<li data-title="Lesson 02 - 08 L02 P021 It sounds good - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/08 L02 P021 It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 09 L02 P021 It sounds good - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/09 L02 P021 It sounds good - C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 10 L02 P021 Words to remember " data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/10 L02 P021 Words to remember .mp3" data-free="false"></li>
<li data-title="Lesson 02 - 11 L02 P022 Homework - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/11 L02 P022 Homework - A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 12 L02 P023 Homework - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/12 L02 P023 Homework - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 13 L02 P023 Homework - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/13 L02 P023 Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 14 L02 P024 Conversation Plus 1(CMat P14-15)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 02/14 L02 P024 Conversation Plus 1(CMat P14-15).mp3" data-free="false"></li>
<li data-title="Lesson 03 - 01 L03 P026 Start off - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 03/01 L03 P026 Start off - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 02 L03 P027 Start off - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 03/02 L03 P027 Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 03 L03 P027 Start off - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 03/03 L03 P027 Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 04 L03 P027 Start off - E (CMat P17)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 03/04 L03 P027 Start off - E (CMat P17).mp3" data-free="false"></li>
<li data-title="Lesson 03 - 05 L03 P028 Check this out - A " data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 03/05 L03 P028 Check this out - A .mp3" data-free="false"></li>
<li data-title="Lesson 03 - 06 L03 P030 Your say - B-1(CMat P18)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 03/06 L03 P030 Your say - B-1(CMat P18).mp3" data-free="false"></li>
<li data-title="Lesson 03 - 07 L03 P030 Your say - B-2" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 03/07 L03 P030 Your say - B-2.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 08 L03 P031 It sounds good - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 03/08 L03 P031 It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 09 L03 P031 It sounds good - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 03/09 L03 P031 It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 10 L03 P031 Words to remember" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 03/10 L03 P031 Words to remember.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 11 L03 P033  Homework - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 03/11 L03 P033  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 12 L03 P033  Homework - E" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 03/12 L03 P033  Homework - E.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 01 L04 P034  Start off - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/01 L04 P034  Start off - A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 02 L04 P035  Start off - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/02 L04 P035  Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 03 L04 P035  Start off - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/03 L04 P035  Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 04 L04 P035  Start off - E (CMat P19)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/04 L04 P035  Start off - E (CMat P19).mp3" data-free="false"></li>
<li data-title="Lesson 04 - 05 L04 P036  Check this out - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/05 L04 P036  Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 06 L04 P038  Your say 2 - A (CMat P22)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/06 L04 P038  Your say 2 - A (CMat P22).mp3" data-free="false"></li>
<li data-title="Lesson 04 - 07 L04 P038  Your say 2-B " data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/07 L04 P038  Your say 2-B .mp3" data-free="false"></li>
<li data-title="Lesson 04 - 08 L04 P039 It sounds good - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/08 L04 P039 It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 09 L04 P039 It sounds good - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/09 L04 P039 It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 10 L04 P039 It sounds good - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/10 L04 P039 It sounds good - C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 11 L04 P039  Words to remember" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/11 L04 P039  Words to remember.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 12 L04 P040  Homework - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/12 L04 P040  Homework - A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 13 L04 P040  Homework - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/13 L04 P040  Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 14 L04 P041  Homework - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/14 L04 P041  Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 15 L04 P041  Homework - E" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 04/15 L04 P041  Homework - E.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 01 L05 P045 Start off - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 05/01 L05 P045 Start off - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 02 L05 P046 Start off - E(CMat P24)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 05/02 L05 P046 Start off - E(CMat P24).mp3" data-free="false"></li>
<li data-title="Lesson 05 - 03 L05 P047 Check this out - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 05/03 L05 P047 Check this out - D.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 04 L05 P048  Your Say - C (CMat - P26)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 05/04 L05 P048  Your Say - C (CMat - P26).mp3" data-free="false"></li>
<li data-title="Lesson 05 - 05 L05 P048  Your Say - E" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 05/05 L05 P048  Your Say - E.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 06 L05 P049  It sounds good - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 05/06 L05 P049  It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 07 L05 P049  It sounds good - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 05/07 L05 P049  It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 08 L05 P049  Words to remember" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 05/08 L05 P049  Words to remember.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 09 L05 P050  Homework - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 05/09 L05 P050  Homework - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 10 L05 P050  Homework - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 05/10 L05 P050  Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 11 L05 P051  Homework - E" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 05/11 L05 P051  Homework - E.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 01 L06 P053  Start off - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/01 L06 P053  Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 02 L06 P053  Start off - E (CMat P29)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/02 L06 P053  Start off - E (CMat P29).mp3" data-free="false"></li>
<li data-title="Lesson 06 - 03 L06 P054  Check this out - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/03 L06 P054  Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 04 L06 P055  Check this out - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/04 L06 P055  Check this out - D.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 05 L06 P055  Your Say 1- A (CMat - P30)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/05 L06 P055  Your Say 1- A (CMat - P30).mp3" data-free="false"></li>
<li data-title="Lesson 06 - 06 L06 P055  Your Say 1- B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/06 L06 P055  Your Say 1- B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 07 L06 P056  Study note 2" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/07 L06 P056  Study note 2.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 08 L06 P057 It sounds good - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/08 L06 P057 It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 09 L06 P057 Words to remember" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/09 L06 P057 Words to remember.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 10 L06 P058 Homework - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/10 L06 P058 Homework - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 11 L06 P059 Homework - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/11 L06 P059 Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 12 L06 P059 Homework - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/12 L06 P059 Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 13 L06 P061 Conversation Plus 3 (CMat P33)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 06/13 L06 P061 Conversation Plus 3 (CMat P33).mp3" data-free="false"></li>
<li data-title="Lesson 07 - 01 L07 P067 Start off - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 07/01 L07 P067 Start off - B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 02 L07 P067 Start off - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 07/02 L07 P067 Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 03 L07 P068 Check this out - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 07/03 L07 P068 Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 04 L07 P068 Check this out - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 07/04 L07 P068 Check this out - D.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 05 L07 P069 Study note 1- B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 07/05 L07 P069 Study note 1- B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 06 L07 P069 Study note 1- C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 07/06 L07 P069 Study note 1- C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 07 L07 P069 Your say 1 (CMat P36)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 07/07 L07 P069 Your say 1 (CMat P36).mp3" data-free="false"></li>
<li data-title="Lesson 07 - 08 L07 P071 It sounds good - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 07/08 L07 P071 It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 09 L07 P071 Words to remember" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 07/09 L07 P071 Words to remember.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 10 L07 P072 Homework - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 07/10 L07 P072 Homework - B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 11 L07 P073 Homework - E" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 07/11 L07 P073 Homework - E.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 12 L07 P073 Homework - F" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 07/12 L07 P073 Homework - F.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 01 L08 P075 Start off - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 08/01 L08 P075 Start off - B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 02 L08 P075 Start off - D (CMat P39)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 08/02 L08 P075 Start off - D (CMat P39).mp3" data-free="false"></li>
<li data-title="Lesson 08 - 03 L08 P076 Check this out - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 08/03 L08 P076 Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 04 L08 P076 Check this out - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 08/04 L08 P076 Check this out - D.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 05 L08 P077 Your say - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 08/05 L08 P077 Your say - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 06 L08 P078 Your say - C (CMat P41)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 08/06 L08 P078 Your say - C (CMat P41).mp3" data-free="false"></li>
<li data-title="Lesson 08 - 07 L08 P079 It sounds good - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 08/07 L08 P079 It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 08 L08 P079 Words to remember" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 08/08 L08 P079 Words to remember.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 09 L08 P080 Homework - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 08/09 L08 P080 Homework - B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 10 L08 P081 Homework - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 08/10 L08 P081 Homework - D.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 11 Conversation Plus 4 - A (CMat P42)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 08/11 Conversation Plus 4 - A (CMat P42).mp3" data-free="false"></li>
<li data-title="Lesson 08 - 12 Conversation Plus 4 - B-2" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 08/12 Conversation Plus 4 - B-2.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 01 L09 P084 Start off - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 09/01 L09 P084 Start off - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 02 L09 P084 Start off - A (CMat P44)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 09/02 L09 P084 Start off - A (CMat P44).mp3" data-free="false"></li>
<li data-title="Lesson 09 - 03 L09 P085 Start off - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 09/03 L09 P085 Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 04 L09 P085 Start off - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 09/04 L09 P085 Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 05 L09 P085 Start off - E (CMat P44)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 09/05 L09 P085 Start off - E (CMat P44).mp3" data-free="false"></li>
<li data-title="Lesson 09 - 06 L09 P086 Check this out - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 09/06 L09 P086 Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 07 L09 P087 Your say 1 - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 09/07 L09 P087 Your say 1 - B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 08 L09 P088 Your say 2 - B(CMat P47)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 09/08 L09 P088 Your say 2 - B(CMat P47).mp3" data-free="false"></li>
<li data-title="Lesson 09 - 09 L09 P089 It sounds good - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 09/09 L09 P089 It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 10 L09 P089 Words to remember" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 09/10 L09 P089 Words to remember.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 11 L09 P090 Homework - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 09/11 L09 P090 Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 12 L09 P091 Homework - E" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 09/12 L09 P091 Homework - E.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 01 L10 P092 Start off - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/01 L10 P092 Start off - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 02 L10 P093 Start off - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/02 L10 P093 Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 03 L10 P093 Start off - E (CMat P 49)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/03 L10 P093 Start off - E (CMat P 49).mp3" data-free="false"></li>
<li data-title="Lesson 10 - 04 L10 P094 Check this out - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/04 L10 P094 Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 05 L10 P094 Check this out - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/05 L10 P094 Check this out - C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 06 L10 P096 Your say 1 - B (CMat P50)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/06 L10 P096 Your say 1 - B (CMat P50).mp3" data-free="false"></li>
<li data-title="Lesson 10 - 07 L10 P096 Your say 2 - A (CMat P51)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/07 L10 P096 Your say 2 - A (CMat P51).mp3" data-free="false"></li>
<li data-title="Lesson 10 - 08 L10 P097 It sounds good - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/08 L10 P097 It sounds good - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 09 L10 P097 It sounds good - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/09 L10 P097 It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 10 L10 P097 Words to remember" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/10 L10 P097 Words to remember.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 11 L10 P098 Homework - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/11 L10 P098 Homework - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 12 L10 P098 Homework - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/12 L10 P098 Homework - B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 13 L10 P099 Homework - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/13 L10 P099 Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 14 L10 P099 Homework - E" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 10/14 L10 P099 Homework - E.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 01 L11 P104 Start off - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 11/01 L11 P104 Start off - D.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 02 L11 P104 Check this out - A " data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 11/02 L11 P104 Check this out - A .mp3" data-free="false"></li>
<li data-title="Lesson 11 - 03 L11 P105 Your say 1 - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 11/03 L11 P105 Your say 1 - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 04 L11 P106 Your say 2 (CMat P56)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 11/04 L11 P106 Your say 2 (CMat P56).mp3" data-free="false"></li>
<li data-title="Lesson 11 - 05 L11 P107 It sounds good - A " data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 11/05 L11 P107 It sounds good - A .mp3" data-free="false"></li>
<li data-title="Lesson 11 - 06 L11 P107 It sounds good - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 11/06 L11 P107 It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 07 L11 P107 Words to remember" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 11/07 L11 P107 Words to remember.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 08 L11 P108 Homework - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 11/08 L11 P108 Homework - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 09 L11 P108 Homework - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 11/09 L11 P108 Homework - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 10 L11 P108 Homework - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 11/10 L11 P108 Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 11 L11 P109 Homework - F" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 11/11 L11 P109 Homework - F.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 01 L12 P110 Start off - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 12/01 L12 P110 Start off - C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 02 L12 P112 Check this out - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 12/02 L12 P112 Check this out - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 03 L12 P113 Study note - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 12/03 L12 P113 Study note - B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 04 L12 P114 Your say - A (CMat P59)" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 12/04 L12 P114 Your say - A (CMat P59).mp3" data-free="false"></li>
<li data-title="Lesson 12 - 05 L12 P114 Your say - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 12/05 L12 P114 Your say - B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 06 L12 P115  It sounds good - A " data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 12/06 L12 P115  It sounds good - A .mp3" data-free="false"></li>
<li data-title="Lesson 12 - 07 L12 P115  It sounds good - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 12/07 L12 P115  It sounds good - B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 08 L12 P115  Words to remember" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 12/08 L12 P115  Words to remember.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 09 L12 P116  Homework - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 12/09 L12 P116  Homework - B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 10 L12 P116  Homework - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 12/10 L12 P116  Homework - C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 11 L12 P117  Homework - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Lesson 12/11 L12 P117  Homework - D.mp3" data-free="false"></li>
<li data-title="Review 1 - 01 Review 1 P064 - Listening - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Review 1/01 Review 1 P064 - Listening - A.mp3" data-free="false"></li>
<li data-title="Review 1 - 02 Review 1 P064 - Listening - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Review 1/02 Review 1 P064 - Listening - B.mp3" data-free="false"></li>
<li data-title="Review 1 - 03 Review 1 P065 - Listening - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Review 1/03 Review 1 P065 - Listening - C.mp3" data-free="false"></li>
<li data-title="Review 1 - 04 Review 1 P065 - Listening - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Review 1/04 Review 1 P065 - Listening - D.mp3" data-free="false"></li>
<li data-title="Review 2 - 01 Review 2  P122 - Listening - A" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Review 2/01 Review 2  P122 - Listening - A.mp3" data-free="false"></li>
<li data-title="Review 2 - 02 Review 2  P123 - Listening - B" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Review 2/02 Review 2  P123 - Listening - B.mp3" data-free="false"></li>
<li data-title="Review 2 - 03 Review 2  P123 - Listening - C" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Review 2/03 Review 2  P123 - Listening - C.mp3" data-free="false"></li>
<li data-title="Review 2 - 04 Review 2  P123 - Listening - D" data-artist="Aiming At the Sky" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Aiming At the Sky/Review 2/04 Review 2  P123 - Listening - D.mp3" data-free="false"></li>



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
