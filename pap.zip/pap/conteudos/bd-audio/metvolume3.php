
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Complementary - MET Volume 3</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
        
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  1 GENERAL INSTRUCTIONS" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  1 GENERAL INSTRUCTIONS.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  2 PART 1 INSTRUCTIONS" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  2 PART 1 INSTRUCTIONS.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  3" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  3.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  4" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  4.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  5" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  5.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  6" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  6.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  7" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  7.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  8" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  8.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  9" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  9.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  10" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  10.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  11" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  11.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  12" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  12.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  13" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  13.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  14" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  14.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  15" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  15.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  16" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  16.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  17" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  17.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  18" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  18.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  19" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  19.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  20" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  20.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  21" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  21.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  22" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  22.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  23" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  23.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  24" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  24.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  25" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  25.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  26" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  26.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  27" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  27.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  28" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  28.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  29" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  29.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  30" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  30.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  31" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  31.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  32" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  32.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  33" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  33.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  34" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  34.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  35" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  35.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  36" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  36.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  37" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  37.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  38" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  38.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  39" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  39.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  40" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  40.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  41" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  41.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  42" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  42.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  43" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  43.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  44" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  44.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  45" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  45.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  46" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  46.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  47" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  47.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  48" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  48.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  49" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  49.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  50" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  50.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  51" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  51.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 1 - Track  52" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 1 - Track  52.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  53 PART 3 INSTRUCTIONS" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  53 PART 3 INSTRUCTIONS.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  54" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  54.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  55" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  55.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  56" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  56.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  57" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  57.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  58" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  58.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  59" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  59.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  60" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  60.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  61" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  61.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  62" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  62.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  63" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  63.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  64" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  64.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  65" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  65.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  66" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  66.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  67" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  67.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  68" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  68.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  69" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  69.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  70" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  70.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  71" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  71.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  72" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  72.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  73" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  73.mp3" data-free="false"></li>
<li data-title="Complementary - MET Volume 3 - MET Volume 3 - Part 2 - Track  74" data-artist="MET Volume 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/CM/MET Volume 3/MET Volume 3 - Part 2 - Track  74.mp3" data-free="false"></li>






	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
