
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Conectate 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
   
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Modulo 1 - 01.Modulo1 unidad1 p06 Ej1" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/01.Modulo1 unidad1 p06 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 02.Modulo1 unidad1 p07 Ej3" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/02.Modulo1 unidad1 p07 Ej3.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 03.Modulo1 unidad1 p08 Ej4" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/03.Modulo1 unidad1 p08 Ej4.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 04.Modulo1 unidad1 p08 Ej6" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/04.Modulo1 unidad1 p08 Ej6.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 05.Modulo1 unidad1 p09 Ej10 resp dialogo1" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/05.Modulo1 unidad1 p09 Ej10 resp dialogo1.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 06.Modulo1 unidad1 p09 Ej10 resp dialogo2" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/06.Modulo1 unidad1 p09 Ej10 resp dialogo2.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 07.Modulo1 unidad1 p09 Ej10 resp dialogo3" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/07.Modulo1 unidad1 p09 Ej10 resp dialogo3.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 08.Modulo1 unidad1 p09 Ej10 resp dialogo4" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/08.Modulo1 unidad1 p09 Ej10 resp dialogo4.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 09.Modulo1 unidad1 p10 Ej 11" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/09.Modulo1 unidad1 p10 Ej 11.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 10.Modulo 1 unidad1 p11 Ej15 ParteA" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/10.Modulo 1 unidad1 p11 Ej15 ParteA.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 11.Modulo1 unidad1 p11 Ej15 ParteB contesta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/11.Modulo1 unidad1 p11 Ej15 ParteB contesta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 12.Modulo1 unidad1 p11 Ej15 PartB pregunta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/12.Modulo1 unidad1 p11 Ej15 PartB pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 13.Juega con los sonidos p17" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 01/13.Juega con los sonidos p17.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 01.Modulo1 unidad2 p18 Ej1" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 02/01.Modulo1 unidad2 p18 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 02.Modulo1 unidad2 p21 Ej4 contesta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 02/02.Modulo1 unidad2 p21 Ej4 contesta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 03.Modulo1 unidad2 p21 Ej4 pregunta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 02/03.Modulo1 unidad2 p21 Ej4 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 04.Modulo1 unidad2 p24 Ej11" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 02/04.Modulo1 unidad2 p24 Ej11.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 05.Modulo1 unidad2 p24 Ej12" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 02/05.Modulo1 unidad2 p24 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 06.Modulo1 unidad2 p24 Ej13 ParteA" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 02/06.Modulo1 unidad2 p24 Ej13 ParteA.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 07.Modulo1 unidad2 p24 Ej13 ParteB" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 02/07.Modulo1 unidad2 p24 Ej13 ParteB.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 08.Juega con los sonidos p29" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 02/08.Juega con los sonidos p29.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 01.Modulo1 unidad3 p30 Ej1" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/01.Modulo1 unidad3 p30 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 02.Modulo1 unidad3 p31 Ej3" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/02.Modulo1 unidad3 p31 Ej3.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 03.Modulo1 unidad3 p31 Ej4" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/03.Modulo1 unidad3 p31 Ej4.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 04.Modulo1 unidad3 p32 Ej6 contesta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/04.Modulo1 unidad3 p32 Ej6 contesta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 05.Modulo1 unidad3 p32 Ej6 pregunta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/05.Modulo1 unidad3 p32 Ej6 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 06.Modulo1 unidad3 p32 Ej7" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/06.Modulo1 unidad3 p32 Ej7.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 07.Modulo1 unidad3 p33 Ej8" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/07.Modulo1 unidad3 p33 Ej8.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 08.Modulo1 unidad3 p34 Ej9 contesta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/08.Modulo1 unidad3 p34 Ej9 contesta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 09.Modulo1 unidad3 p34 Ej9 pregunta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/09.Modulo1 unidad3 p34 Ej9 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 10.Modulo1 unidad3 p34 Ej10" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/10.Modulo1 unidad3 p34 Ej10.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 11.Modulo1 unidad3 p34 Ej11" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/11.Modulo1 unidad3 p34 Ej11.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 12.Modulo1 unidad3 p35 Ej13" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/12.Modulo1 unidad3 p35 Ej13.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 13.Juega con los sonidos p39" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 03/13.Juega con los sonidos p39.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 01.Modulo1 unidad4 p40 Ej1" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/01.Modulo1 unidad4 p40 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 02.Modulo1 unidad4 p41 Ej4 contesta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/02.Modulo1 unidad4 p41 Ej4 contesta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 03.Modulo1 unidad4 p42 Ej5 pregunta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/03.Modulo1 unidad4 p42 Ej5 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 04.Modulo1 unidad4 p42 Ej7" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/04.Modulo1 unidad4 p42 Ej7.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 05.Modulo1 unidad4 p43 Ej8" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/05.Modulo1 unidad4 p43 Ej8.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 06.Modulo1 unidad4 p44 Ej11 contesta dialogo1" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/06.Modulo1 unidad4 p44 Ej11 contesta dialogo1.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 07.Modulo1 unidad4 p44 Ej11 contesta dialogo2" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/07.Modulo1 unidad4 p44 Ej11 contesta dialogo2.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 08.Modulo1 unidad4 p44 Ej11 contesta dialogo3" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/08.Modulo1 unidad4 p44 Ej11 contesta dialogo3.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 09.Modulo1 unidad4 p44 Ej11 preguntar dialogo4" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/09.Modulo1 unidad4 p44 Ej11 preguntar dialogo4.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 10.Modulo1 unidad4 p44 Ej11 preguntar dialogo5" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/10.Modulo1 unidad4 p44 Ej11 preguntar dialogo5.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 11.Modulo1 unidad4 p45 Ej12" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/11.Modulo1 unidad4 p45 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 12.Modulo1 unidad4 p45 Ej14 contestar" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/12.Modulo1 unidad4 p45 Ej14 contestar.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 13.Modulo1 unidad4 p45 Ej14 preguntar" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/13.Modulo1 unidad4 p45 Ej14 preguntar.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 14.Modulo1 unidad4 p46 Ej16 contestar" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 1/Unidad 04/14.Modulo1 unidad4 p46 Ej16 contestar.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 01.Modulo2 unidad5 p54 Ej1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 05/01.Modulo2 unidad5 p54 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 02.Modulo2 unidad5 p55 Ej5 ronda 1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 05/02.Modulo2 unidad5 p55 Ej5 ronda 1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 03.Modulo2 unidad5 p55 Ej5 ronda2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 05/03.Modulo2 unidad5 p55 Ej5 ronda2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 04.Modulo2 unidad5 p55 Ej5 ronda3" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 05/04.Modulo2 unidad5 p55 Ej5 ronda3.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 05.Modulo2 unidad5 p56 Ej6" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 05/05.Modulo2 unidad5 p56 Ej6.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 06.Modulo2 unidad5 p57 Ej9 dialogo1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 05/06.Modulo2 unidad5 p57 Ej9 dialogo1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 07.Modulo2 unidad5 p57 Ej9 dialogo2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 05/07.Modulo2 unidad5 p57 Ej9 dialogo2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 08.Modulo2 unidad5 p57 Ej9 dialogo3" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 05/08.Modulo2 unidad5 p57 Ej9 dialogo3.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 09.Modulo2 unidad5 p57 Ej9 dialogo4" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 05/09.Modulo2 unidad5 p57 Ej9 dialogo4.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 10.Modulo2 unidad5 p58 Ej10" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 05/10.Modulo2 unidad5 p58 Ej10.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 11.Modulo2 unidad5 p58 Ej13" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 05/11.Modulo2 unidad5 p58 Ej13.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 12.Juega con los sonidos p63" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 05/12.Juega con los sonidos p63.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 01.Modulo2 unidad6 p64 Ej1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 06/01.Modulo2 unidad6 p64 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 02.Modulo2 unidad6 p67 Ej8" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 06/02.Modulo2 unidad6 p67 Ej8.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 03.Modulo2 unidad6 p68 Ej11" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 06/03.Modulo2 unidad6 p68 Ej11.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 04.Modulo2 unidad6 p69 Ej14 contesta" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 06/04.Modulo2 unidad6 p69 Ej14 contesta.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 05.Modulo2 unidad6 p69 Ej14 pregunta" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 06/05.Modulo2 unidad6 p69 Ej14 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 06.Juega con los sonidos p75" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 06/06.Juega con los sonidos p75.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 01.Modulo2 unidad7 p76 Ej1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 07/01.Modulo2 unidad7 p76 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 02.Modulo2 unidad7 p77 Ej2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 07/02.Modulo2 unidad7 p77 Ej2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 03.Modulo2 unidad7 p78 Ej4" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 07/03.Modulo2 unidad7 p78 Ej4.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 04.Modulo2 unidad7 p80 Ej9" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 07/04.Modulo2 unidad7 p80 Ej9.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 05.Modulo2 unidad7 p81 Ej11" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 07/05.Modulo2 unidad7 p81 Ej11.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 06.Modulo2 unidad7 p82 Ej13" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 07/06.Modulo2 unidad7 p82 Ej13.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 07.Modulo2 unidad7 p82 Ej13 contesta" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 07/07.Modulo2 unidad7 p82 Ej13 contesta.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 08.Juega con los sonidos p89" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 07/08.Juega con los sonidos p89.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 01.Modulo2 unidad8 p90 Ej1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/01.Modulo2 unidad8 p90 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 02.Modulo2 unidad8 p92 Ej4 dialogo1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/02.Modulo2 unidad8 p92 Ej4 dialogo1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 03.Modulo2 unidad8 p92 Ej4 dialogo2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/03.Modulo2 unidad8 p92 Ej4 dialogo2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 04.Modulo2 unidad8 p92 Ej4 dialogo3" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/04.Modulo2 unidad8 p92 Ej4 dialogo3.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 05.Modulo2 unidad8 p92 Ej4 dialogo4" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/05.Modulo2 unidad8 p92 Ej4 dialogo4.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 06.Modulo2 unidad8 p93 Ej6 contesta" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/06.Modulo2 unidad8 p93 Ej6 contesta.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 07.Modulo2 unidad8 p93 Ej6 pregunta" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/07.Modulo2 unidad8 p93 Ej6 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 08.Modulo2 unidad8 p94 Ej8" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/08.Modulo2 unidad8 p94 Ej8.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 09.Modulo2 unidad8 p97 Ej12 casillaA1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/09.Modulo2 unidad8 p97 Ej12 casillaA1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 10.Modulo2 unidad8 p97 Ej12 casillaA2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/10.Modulo2 unidad8 p97 Ej12 casillaA2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 11.Modulo2 unidad8 p97 Ej12 casillaA3" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/11.Modulo2 unidad8 p97 Ej12 casillaA3.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 12.Modulo2 unidad8 p97 Ej12 casillaB1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/12.Modulo2 unidad8 p97 Ej12 casillaB1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 13.Modulo2 unidad8 p97 Ej12 casillaB2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/13.Modulo2 unidad8 p97 Ej12 casillaB2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 14.Modulo2 unidad8 p97 Ej12 casillaB3" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/14.Modulo2 unidad8 p97 Ej12 casillaB3.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 15.Modulo2 unidad8 p97 Ej12 casillaC1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/15.Modulo2 unidad8 p97 Ej12 casillaC1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 16.Modulo2 unidad8 p97 Ej12 casillaC2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/16.Modulo2 unidad8 p97 Ej12 casillaC2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 17.Modulo2 unidad8 p97 Ej12 casillaC3" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/17.Modulo2 unidad8 p97 Ej12 casillaC3.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 18.Modulo2 unidad8 p98 Ej16" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 2/Unidad 08/18.Modulo2 unidad8 p98 Ej16.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 01.Modulo3 unidad9 p106 Ej2" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 09/01.Modulo3 unidad9 p106 Ej2.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 02.Modulo3 unidad9 p106 Ej4 dialogo1" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 09/02.Modulo3 unidad9 p106 Ej4 dialogo1.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 03.Modulo3 unidad9 p106 Ej4 dialogo2" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 09/03.Modulo3 unidad9 p106 Ej4 dialogo2.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 04.Modulo3 unidad9 p106 Ej4 dialogo3" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 09/04.Modulo3 unidad9 p106 Ej4 dialogo3.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 05.Modulo3  unidad9 p106 Ej4 dialogo4" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 09/05.Modulo3  unidad9 p106 Ej4 dialogo4.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 06.Modulo3 unidad9 p106 Ej5" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 09/06.Modulo3 unidad9 p106 Ej5.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 07.Modulo3 unidad9 p107 Ej6" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 09/07.Modulo3 unidad9 p107 Ej6.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 08.Modulo3 unidad9 p109 Ej12" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 09/08.Modulo3 unidad9 p109 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 09.Modulo3 unidad9 p110 Ej15" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 09/09.Modulo3 unidad9 p110 Ej15.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 10.Juega con los sonidos p116" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 09/10.Juega con los sonidos p116.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 01.Modulo3 unidad10 p117 Ej1" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 10/01.Modulo3 unidad10 p117 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 02.Modulo3 unidad10 p120 Ej5" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 10/02.Modulo3 unidad10 p120 Ej5.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 03.Modulo3 unidad10 p120 Ej6 contesta" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 10/03.Modulo3 unidad10 p120 Ej6 contesta.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 04.Modulo3 unidad10 p120 Ej6 pregunta" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 10/04.Modulo3 unidad10 p120 Ej6 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 05.Modulo3 unidad10 p122 Ej9" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 10/05.Modulo3 unidad10 p122 Ej9.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 06.Juega con los sonidos p125" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 10/06.Juega con los sonidos p125.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 01.Modulo3 unidad11 p126 Ej1" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 11/01.Modulo3 unidad11 p126 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 02.Modulo3 unidad11 p128 Ej6" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 11/02.Modulo3 unidad11 p128 Ej6.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 03.Modulo3 unidad11 p128 Ej6 contesta" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 11/03.Modulo3 unidad11 p128 Ej6 contesta.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 04.Modulo3 unidad11 p130 Ej10" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 11/04.Modulo3 unidad11 p130 Ej10.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 05.Modulo3 unidad11 p130 Ej11" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 11/05.Modulo3 unidad11 p130 Ej11.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 06.Juega con los sonidos p135" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 11/06.Juega con los sonidos p135.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 01.Modulo3 unidad12 p136 Ej1" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 12/01.Modulo3 unidad12 p136 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 02.Modulo3 unidad12 p138 Ej5" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 12/02.Modulo3 unidad12 p138 Ej5.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 03.Modulo3 unidad12 p139 Ej6" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 12/03.Modulo3 unidad12 p139 Ej6.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 04.Modulo3 unidad12 p139 Ej7" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 12/04.Modulo3 unidad12 p139 Ej7.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 05.Modulo3 unidad12 p140 Ej10" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 12/05.Modulo3 unidad12 p140 Ej10.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 06.Modulo3 unidad12 p141 Ej11 contesta" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 12/06.Modulo3 unidad12 p141 Ej11 contesta.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 07.Modulo3 unidad12 p141 Ej11 pregunta" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 12/07.Modulo3 unidad12 p141 Ej11 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 08.Juega con los sonidos p145" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 1/Modulo 3/Unidad 12/08.Juega con los sonidos p145.mp3" data-free="false"></li>



	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
