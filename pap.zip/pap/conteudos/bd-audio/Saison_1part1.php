
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Saison 1.1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
           
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
<li data-title="Saison 1 - Unite 0 - b. MF - Piste 1" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/b. MF - Piste 1.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - c. Saluer" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/c. Saluer.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - d. MF - Piste 2" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/d. MF - Piste 2.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - e. Ca va" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/e. Ca va.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - f. Cahier - Piste 3 - Activite 4" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/f. Cahier - Piste 3 - Activite 4.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - g. MF - Piste 3" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/g. MF - Piste 3.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - h. Alphabet" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/h. Alphabet.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - i. Cahier - Piste 5 - Activite 8" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/i. Cahier - Piste 5 - Activite 8.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - j. S appeler" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/j. S appeler.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - k. MF - Piste 4" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/k. MF - Piste 4.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - l. MF - Piste 5" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/l. MF - Piste 5.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - m. Quelques nationalites" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/m. Quelques nationalites.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - n. MF - Piste 6" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/n. MF - Piste 6.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - o. MF - Piste 7" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/o. MF - Piste 7.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - p. MF - Piste 8" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/p. MF - Piste 8.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - q. Cahier - Piste 4 - Activite 5" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/q. Cahier - Piste 4 - Activite 5.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - r. Cahier - Piste 1 - Activite 1" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/r. Cahier - Piste 1 - Activite 1.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - s. Couleurs" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/s. Couleurs.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - t. MF - Piste 9" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/t. MF - Piste 9.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - u. Nombres 0-20" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/u. Nombres 0-20.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - v. Nombres 21-69" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/v. Nombres 21-69.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - w. MF - Piste 10" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/w. MF - Piste 10.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - x. Cahier - Piste 2 - Activite 3" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/x. Cahier - Piste 2 - Activite 3.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - y. Cahier - Piste 7 - Activite 15" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/y. Cahier - Piste 7 - Activite 15.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - z. Cahier - Piste 8 - Activite 16" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/z. Cahier - Piste 8 - Activite 16.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - z1. MF - Piste 11" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/z1. MF - Piste 11.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - z2. MF - Piste 12" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/z2. MF - Piste 12.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - z3. Mois de l annee" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/z3. Mois de l annee.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - z4. Cahier - Piste 6 - Activite 12" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/z4. Cahier - Piste 6 - Activite 12.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - z5. MF - Piste 13" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/z5. MF - Piste 13.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 0 - z6. Cahier - Piste 10 - Bilan - Activite 5" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 0/z6. Cahier - Piste 10 - Bilan - Activite 5.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - b. MF - Piste 14" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/b. MF - Piste 14.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - c. MF - Piste 15" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/c. MF - Piste 15.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - d. Cahier - Piste 11 - Activite 1" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/d. Cahier - Piste 11 - Activite 1.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - e. MF - Piste 16" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/e. MF - Piste 16.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - f. Cahier - Piste 14 - Activite 13" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/f. Cahier - Piste 14 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - g. Cahier - Piste 15 - Activite 15" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/g. Cahier - Piste 15 - Activite 15.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - h. MF - Piste 17" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/h. MF - Piste 17.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - i. Cahier - Piste 16 - Activite 16" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/i. Cahier - Piste 16 - Activite 16.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - k. Cahier - Piste 12 - Activite 8" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/k. Cahier - Piste 12 - Activite 8.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - l. Cahier - Piste 13 - Activite 10" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/l. Cahier - Piste 13 - Activite 10.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - m. MF - Piste 18" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/m. MF - Piste 18.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - n. MF - Piste 19" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/n. MF - Piste 19.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - o. Cahier - Piste 17 - Activite 20" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/o. Cahier - Piste 17 - Activite 20.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - p. MF - Piste 20" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/p. MF - Piste 20.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - q. MF - Piste 21" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/q. MF - Piste 21.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - r. Extra - Les nombres 70-1000" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/r. Extra - Les nombres 70-1000.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - s. MF - Piste 22" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/s. MF - Piste 22.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - t. Cahier - Piste 18 - Activite 25" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/t. Cahier - Piste 18 - Activite 25.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - u. Cahier - Piste 19 - Bilan 2" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/u. Cahier - Piste 19 - Bilan 2.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - v. Cahier - Piste 20 - Bilan 3" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/v. Cahier - Piste 20 - Bilan 3.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - w. Cahier - Piste 21 - BIlan 9" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/w. Cahier - Piste 21 - BIlan 9.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 1 - x. MF - DELF A1 - Unite 1" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 1/x. MF - DELF A1 - Unite 1.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - b. MF - Piste 23" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/b. MF - Piste 23.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - c. Cahier - Piste 22 - Activite 3" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/c. Cahier - Piste 22 - Activite 3.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - d. MF - Piste 24" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/d. MF - Piste 24.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - e. MF - Piste 25" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/e. MF - Piste 25.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - f. Cahier - Piste 23 - Activite 13" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/f. Cahier - Piste 23 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - h. MF - Piste 26" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/h. MF - Piste 26.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - i. MF - Piste 27" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/i. MF - Piste 27.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - j. Cahier - Piste 24 - Activite 19" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/j. Cahier - Piste 24 - Activite 19.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - k. MF - Piste 28" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/k. MF - Piste 28.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - l. MF - Piste 29" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/l. MF - Piste 29.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - m. MF - Piste 30" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/m. MF - Piste 30.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - n. Cahier - Piste 25 - Bilan 8" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/n. Cahier - Piste 25 - Bilan 8.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 2 - o. MF - DELF A1 - Unite 2" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 2/o. MF - DELF A1 - Unite 2.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - b. MF - Piste 31" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/b. MF - Piste 31.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - c. MF - Piste 32" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/c. MF - Piste 32.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - d. Cahier - Piste 27 - Activite 7" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/d. Cahier - Piste 27 - Activite 7.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - e. Cahier - Piste 26 - Activite 3" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/e. Cahier - Piste 26 - Activite 3.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - f. Cahier - Piste 29 - Activite 12" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/f. Cahier - Piste 29 - Activite 12.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - g. Cahier - Piste 30 - Activite 13" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/g. Cahier - Piste 30 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - h. Cahier - Piste 32 - Activite 19" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/h. Cahier - Piste 32 - Activite 19.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - i. MF - Piste 33" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/i. MF - Piste 33.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - k. Communication - Demander et dire l heure" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/k. Communication - Demander et dire l heure.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - l. Cahier - Piste 28 - Activite 10" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/l. Cahier - Piste 28 - Activite 10.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - m. Cahier - Piste 31 - Activite 16" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/m. Cahier - Piste 31 - Activite 16.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - n. MF - Piste 34" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/n. MF - Piste 34.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - o. Cahier - Piste 33 - Activite 22" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/o. Cahier - Piste 33 - Activite 22.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - p. MF - Piste 35" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/p. MF - Piste 35.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - q. MF - Piste 36" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/q. MF - Piste 36.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - r. MF - Piste 37" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/r. MF - Piste 37.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - s. Chanson - Rose - La liste" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/s. Chanson - Rose - La liste.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 3 - t. MF - DELF A1 - Unite 3" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 3/t. MF - DELF A1 - Unite 3.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - b. MF - Piste 39" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/b. MF - Piste 39.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - c. Cahier - Piste 34 - Activite 3" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/c. Cahier - Piste 34 - Activite 3.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - d. MF - Piste 40" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/d. MF - Piste 40.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - e. MF - Piste 41" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/e. MF - Piste 41.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - f. Cahier - Piste 35 - Activite 10" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/f. Cahier - Piste 35 - Activite 10.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - g. Cahier - Piste 36 - Activite 13" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/g. Cahier - Piste 36 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - h. Cahier - Piste 37 - Activite 16" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/h. Cahier - Piste 37 - Activite 16.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - i. MF - Piste 42" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/i. MF - Piste 42.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - j. MF - Piste 43" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/j. MF - Piste 43.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - k. Cahier - Piste 38 - Activite 19" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/k. Cahier - Piste 38 - Activite 19.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - l. Cahier - Piste 39 - Activite 22" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/l. Cahier - Piste 39 - Activite 22.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - m. MF - Piste 44" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/m. MF - Piste 44.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - n. MF - Piste 45" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/n. MF - Piste 45.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - o. MF - Piste 46" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/o. MF - Piste 46.mp3" data-free="false"></li>
<li data-title="Saison 1 - Unite 4 - p. MF - DELF A1 - Unite 4" data-artist="Saison 1" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 1/Saison 1.1/Saison 1 - Unite 4/p. MF - DELF A1 - Unite 4.mp3" data-free="false"></li>

	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
