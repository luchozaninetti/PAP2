
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Toefl A</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
           
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Toefl vol A - 01 Exercise A1 p.357" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Appendix A/01 Exercise A1 p.357.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 02 Exercise A2 p.357" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Appendix A/02 Exercise A2 p.357.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 03 Exercise A3 p.357" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Appendix A/03 Exercise A3 p.357.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 04 Exercise A4 p.357" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Appendix A/04 Exercise A4 p.357.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 05 Exercise A5 p.357" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Appendix A/05 Exercise A5 p.357.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 06 Exercise A6 p.357" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Appendix A/06 Exercise A6 p.357.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 07 Exercise A7 p.357" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Appendix A/07 Exercise A7 p.357.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 08 Exercise A8 p.357" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Appendix A/08 Exercise A8 p.357.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 09 Exercise A9 p.357" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Appendix A/09 Exercise A9 p.357.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 10 Exercise A10 p.357" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Appendix A/10 Exercise A10 p.357.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 11 Exercise A11 p.357" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Appendix A/11 Exercise A11 p.357.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 01 Practice Test Section 1 Part A p.331" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Complete practice test/01 Practice Test Section 1 Part A p.331.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 02 Practice Test Section 1 Part A p.332" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Complete practice test/02 Practice Test Section 1 Part A p.332.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 03 Practice Test Section 1 Part A p.333" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Complete practice test/03 Practice Test Section 1 Part A p.333.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 04 Practice Test Section 1 Part B p.334" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Complete practice test/04 Practice Test Section 1 Part B p.334.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 05 Practice Test Section 1 Part C p.335" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Complete practice test/05 Practice Test Section 1 Part C p.335.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 06 Practice Test Section 1 Part C p.336" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Complete practice test/06 Practice Test Section 1 Part C p.336.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 01 Toefl Exercise 1 p.13" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/01 Toefl Exercise 1 p.13.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 02 Toefl Exercise 2 p.15" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/02 Toefl Exercise 2 p.15.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 03 Toefl Exercise 3 p.17" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/03 Toefl Exercise 3 p.17.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 04 Toefl Exercise (skills 1-3) p.18" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/04 Toefl Exercise (skills 1-3) p.18.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 05 Toefl Exercise 4 p.21" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/05 Toefl Exercise 4 p.21.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 06 Toefl Exercise 5 p.23" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/06 Toefl Exercise 5 p.23.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 07 Toefl Exercise 6 p.25" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/07 Toefl Exercise 6 p.25.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 08 Toefl Exercise (skills 4-6) p.26" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/08 Toefl Exercise (skills 4-6) p.26.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 09 Toefl Review Exercise (skills 1-6) p.27" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/09 Toefl Review Exercise (skills 1-6) p.27.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 10 Toefl Exercise 7 p.29" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/10 Toefl Exercise 7 p.29.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 11 Toefl Exercise 8 p.31" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/11 Toefl Exercise 8 p.31.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 12 Toefl Exercise 9 p.33" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/12 Toefl Exercise 9 p.33.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 13 Toefl Exercise 10 p.35" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/13 Toefl Exercise 10 p.35.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 14 Toefl Exercise (skills 7-10)  p.36" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/14 Toefl Exercise (skills 7-10)  p.36.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 15 Toefl Review Exercise (1-10) p. 37" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/15 Toefl Review Exercise (1-10) p. 37.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 16 Toefl Exercise 11 p. 39" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/16 Toefl Exercise 11 p. 39.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 17 Toefl Exercise 12 p. 42" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/17 Toefl Exercise 12 p. 42.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 18 Toefl Exercise 13 p. 44" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/18 Toefl Exercise 13 p. 44.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 19 Toefl Exercise (skills 11-13) p. 45" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/19 Toefl Exercise (skills 11-13) p. 45.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 20 Toefl Review Exercise (skills 1-13) p. 46" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/20 Toefl Review Exercise (skills 1-13) p. 46.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 21 Toefl Exercise 14 p. 48" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/21 Toefl Exercise 14 p. 48.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 22 Toefl Exercise 15 p. 50" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/22 Toefl Exercise 15 p. 50.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 23 Toefl Exercise (skills 14-15) p. 51" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/23 Toefl Exercise (skills 14-15) p. 51.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 24 Toefl Review Exercise (skills 1-15) p. 52" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/24 Toefl Review Exercise (skills 1-15) p. 52.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 25 Toefl Exercise 16 p. 54" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/25 Toefl Exercise 16 p. 54.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 26 Toefl Exercise 17 p. 56" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/26 Toefl Exercise 17 p. 56.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 27 Toefl Exercise (skills 16-17) p. 57" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/27 Toefl Exercise (skills 16-17) p. 57.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 28 Toefl Review Exercise (skills 1-17) p. 57" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part A/28 Toefl Review Exercise (skills 1-17) p. 57.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 01 Exercise 20 p.65" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part B/01 Exercise 20 p.65.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 02 Exercise 21 p.66" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part B/02 Exercise 21 p.66.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 03 Toefl Exercise 22 p.68" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part B/03 Toefl Exercise 22 p.68.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 04 Toefl Review Exercise (skills 18-22)  p.69" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part B/04 Toefl Review Exercise (skills 18-22)  p.69.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 01 Exercise 25 p.76" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part C/01 Exercise 25 p.76.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 02 Exercise 26 p.77" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part C/02 Exercise 26 p.77.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 03 Toefl Exercise 27 p.79" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part C/03 Toefl Exercise 27 p.79.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 04 Toefl Review Exercise (skills 23-27) p.80" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Exercises Part C/04 Toefl Review Exercise (skills 23-27) p.80.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 01 Post-test Section 1 Part A p.81" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Post-Test/01 Post-test Section 1 Part A p.81.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 02 Post-test Section 1 Part A p.82" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Post-Test/02 Post-test Section 1 Part A p.82.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 03 Post-test Section 1 Part B p.84" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Post-Test/03 Post-test Section 1 Part B p.84.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 04 Post-test Section 1 Part C p.85" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Post-Test/04 Post-test Section 1 Part C p.85.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 05 Post-test Section 1 Part C p.86" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Post-Test/05 Post-test Section 1 Part C p.86.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 01 Diagnostic Pre-test Part A p.3" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Pre-Test/01 Diagnostic Pre-test Part A p.3.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 02 Diagnostic Pre-test Part A p.4" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Pre-Test/02 Diagnostic Pre-test Part A p.4.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 03 Diagnostic Pre-test Part A p.5" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Pre-Test/03 Diagnostic Pre-test Part A p.5.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 04 Diagnostic Pre-test Part A p.6" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Pre-Test/04 Diagnostic Pre-test Part A p.6.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 05 Diagnostic Pre-test Part B p.7" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Pre-Test/05 Diagnostic Pre-test Part B p.7.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 06 Diagnostic Pre-test Part C p.8" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Pre-Test/06 Diagnostic Pre-test Part C p.8.mp3" data-free="false"></li>
<li data-title="Toefl vol A - 07 Diagnostic Pre-test Part C p.9" data-artist="Toefl vol A" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol A/Pre-Test/07 Diagnostic Pre-test Part C p.9.mp3" data-free="false"></li>


	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

