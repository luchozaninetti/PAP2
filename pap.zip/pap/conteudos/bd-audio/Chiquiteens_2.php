
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Chiquiteens 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
         
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Leccion 00 - 01 L 00, p. 06, unid. 1, Ej. 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/01 L 00, p. 06, unid. 1, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 02 L 00, p. 07, unid. 1, Ej. 3" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/02 L 00, p. 07, unid. 1, Ej. 3.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 03 L 00, p. 08, unid. 1, Ej. 6" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/03 L 00, p. 08, unid. 1, Ej. 6.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 04 L 00, p. 09, unid. 1, En accion, dialogo 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/04 L 00, p. 09, unid. 1, En accion, dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 05 L 00, p. 09, unid. 1, En accion, dialogo 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/05 L 00, p. 09, unid. 1, En accion, dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 06 L 00, p. 09, unid. 1, En accion, dialogo 3" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/06 L 00, p. 09, unid. 1, En accion, dialogo 3.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 07 L 00, p. 09, unid. 1, En accion, dialogo 4" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/07 L 00, p. 09, unid. 1, En accion, dialogo 4.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 08 L 00, p.10, unid 1, Ej. 9" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/08 L 00, p.10, unid 1, Ej. 9.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 09 L 00, p.11, unid 1, Ej. 10" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/09 L 00, p.11, unid 1, Ej. 10.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 10 L 00, p.11, unid 1, Ej. 11" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/10 L 00, p.11, unid 1, Ej. 11.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 11 L 00, p.13, unid 2, Ej. 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/11 L 00, p.13, unid 2, Ej. 2.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 12 L 00, p.14, unid 2, Ej. 3" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/12 L 00, p.14, unid 2, Ej. 3.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 13 L 00, p.14, unid 2, Ej. 5" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/13 L 00, p.14, unid 2, Ej. 5.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 14 L 00, p.15, unid 2, Ej. 6" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/14 L 00, p.15, unid 2, Ej. 6.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 15 L 00, p.16, unid 2, Ej. 7 contesta" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/15 L 00, p.16, unid 2, Ej. 7 contesta.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 16 L 00, p.16, unid 2, Ej. 7 pregunta" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/16 L 00, p.16, unid 2, Ej. 7 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 17 L 00, p.16, unid 2, En accion" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 00/17 L 00, p.16, unid 2, En accion.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 01 L 01, p.17, Ej. 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 01/01 L 01, p.17, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 02 L 01, p.19, Ej. 5" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 01/02 L 01, p.19, Ej. 5.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 03 L 01, p. 21, En accion, dialogo 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 01/03 L 01, p. 21, En accion, dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 04 L 01, p. 21, En accion, dialogo 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 01/04 L 01, p. 21, En accion, dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 05 L 01, p. 21, En accion, dialogo 3" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 01/05 L 01, p. 21, En accion, dialogo 3.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 06 L 01, p. 21, En accion, dialogo 4" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 01/06 L 01, p. 21, En accion, dialogo 4.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 01 L 02 , p. 22 , Ej. 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 02/01 L 02 , p. 22 , Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 02 L 02 , p. 24 , En accion" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 02/02 L 02 , p. 24 , En accion.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 03 L 02 , p. 24 , Ej. 5, dialogo 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 02/03 L 02 , p. 24 , Ej. 5, dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 04 L 02 , p. 24 , Ej. 5, dialogo 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 02/04 L 02 , p. 24 , Ej. 5, dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 05 L 02 , p. 24 , Ej. 5, dialogo 3" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 02/05 L 02 , p. 24 , Ej. 5, dialogo 3.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 06 L 02 , p. 24 , Ej. 5, dialogo 4" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 02/06 L 02 , p. 24 , Ej. 5, dialogo 4.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 07 L 02 , p. 25 , En acci�n, dialogo 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 02/07 L 02 , p. 25 , En acci�n, dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 08 L 02 , p. 25 , En acci�n, dialogo 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 02/08 L 02 , p. 25 , En acci�n, dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 09 Ortografia y acentuacion, p. 64" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 02/09 Ortografia y acentuacion, p. 64.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 01 L 03 , p. 26 , Ej. 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 03/01 L 03 , p. 26 , Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 02 L 03 , p. 30 , Ej. 6" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 03/02 L 03 , p. 30 , Ej. 6.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 03 L 03 , p. 30 , En accion" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 03/03 L 03 , p. 30 , En accion.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 04 L 03 , p. 31 , Ej. 7" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 03/04 L 03 , p. 31 , Ej. 7.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 05 Ortografia y acentuacion, p. 65" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 03/05 Ortografia y acentuacion, p. 65.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 01 L 04 , p. 32 , Ej. 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/01 L 04 , p. 32 , Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 02 L 04 , p. 33 , Ej. 3" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/02 L 04 , p. 33 , Ej. 3.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 03 L 04 , p. 34 , Ej. 4 dialogo 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/03 L 04 , p. 34 , Ej. 4 dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 04 L 04 , p. 34 , Ej. 4 dialogo 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/04 L 04 , p. 34 , Ej. 4 dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 05 L 04 , p. 34 , Ej. 5 dialogo 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/05 L 04 , p. 34 , Ej. 5 dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 06 L 04 , p. 34 , Ej. 5 dialogo 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/06 L 04 , p. 34 , Ej. 5 dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 07 L 04 , p. 35 , Ej. 7" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/07 L 04 , p. 35 , Ej. 7.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 08 L 04 , p. 35 , En accion, dialogo 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/08 L 04 , p. 35 , En accion, dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 09 L 04 , p. 35 , En accion, dialogo 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/09 L 04 , p. 35 , En accion, dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 10 L 04 , p. 35 , En accion, dialogo 3" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/10 L 04 , p. 35 , En accion, dialogo 3.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 11 L 04 , p. 35 , En accion, dialogo 4" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/11 L 04 , p. 35 , En accion, dialogo 4.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 12 L 04 , p. 35 , En accion, dialogo 5" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/12 L 04 , p. 35 , En accion, dialogo 5.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 13 Ortografia y acentuacion, p. 66" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 04/13 Ortografia y acentuacion, p. 66.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 01 L05 , Ej. 02" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 05/01 L05 , Ej. 02.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 02 L05 , Ej. 10" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 05/02 L05 , Ej. 10.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 01 L06 p. 38, Ej. 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 06/01 L06 p. 38, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 02  L06  p. 42,  En accion, dialogo 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 06/02  L06  p. 42,  En accion, dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 03  L06  p. 42,  En accion, dialogo 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 06/03  L06  p. 42,  En accion, dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 04  L06  p. 42,  Ej. 7" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 06/04  L06  p. 42,  Ej. 7.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 05 Ortografia y acentuacion , p. 67, ej. 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 06/05 Ortografia y acentuacion , p. 67, ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 06 Ortografia y acentuacion , p. 67, ej. 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 06/06 Ortografia y acentuacion , p. 67, ej. 2.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 01 L07  p. 47,  En accion" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 07/01 L07  p. 47,  En accion.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 02 L07  p. 48,  En accion" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 07/02 L07  p. 48,  En accion.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 03 L07  p. 48,  Ej. 8" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 07/03 L07  p. 48,  Ej. 8.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 04 Ortografia y acentuacion, p. 68, ej. 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 07/04 Ortografia y acentuacion, p. 68, ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 05 Ortografia y acentuacion, p. 68, ej. 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 07/05 Ortografia y acentuacion, p. 68, ej. 2.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 01 L08  p. 49,  Ej. 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 08/01 L08  p. 49,  Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 02 L08  p. 49,  En accion, contesta" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 08/02 L08  p. 49,  En accion, contesta.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 03 L08  p. 49,  En accion, pregunta" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 08/03 L08  p. 49,  En accion, pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 04 L08  p. 52,  Ej. 5" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 08/04 L08  p. 52,  Ej. 5.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 05 L08  p. 53,  Ej. 7" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 08/05 L08  p. 53,  Ej. 7.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 06 Ortografia y acentuacion, p. 69, ej. 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 08/06 Ortografia y acentuacion, p. 69, ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 07 Ortografia y acentuacion, p. 69, ej. 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 08/07 Ortografia y acentuacion, p. 69, ej. 2.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 01 L 09 p. 54, Introduccion" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 09/01 L 09 p. 54, Introduccion.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 02 L 09 p. 57, En accion" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 09/02 L 09 p. 57, En accion.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 03 L 09  p. 59, Ej. 8 " data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 09/03 L 09  p. 59, Ej. 8 .mp3" data-free="false"></li>
<li data-title="Leccion 09 - 04 Ortografia y acentuacion, p. 70, ej. 1" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 09/04 Ortografia y acentuacion, p. 70, ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 05 Ortografia y acentuacion, p. 70, ej. 2" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 09/05 Ortografia y acentuacion, p. 70, ej. 2.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 01 L 10, Ej. 5" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 10/01 L 10, Ej. 5.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 02 L 10, Ej. 8" data-artist="Chiquiteens 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 2/Leccion 10/02 L 10, Ej. 8.mp3" data-free="false"></li>


	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

