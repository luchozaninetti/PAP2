
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Transitions 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
            
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="LESSON 1 - 01 L1 P06 STARTING OFF 3 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/01 L1 P06 STARTING OFF 3 CM.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 02 L1 P06 LISTENING B1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/02 L1 P06 LISTENING B1.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 03 L1 P06 LISTENING B3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/03 L1 P06 LISTENING B3.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 04 L1 P07 WORDS & EXPRESSIONS C1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/04 L1 P07 WORDS & EXPRESSIONS C1.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 05 L1 P07 WORDS & EXPRESSIONS C3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/05 L1 P07 WORDS & EXPRESSIONS C3.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 06 L1 P07 CONVERSATION 3 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/06 L1 P07 CONVERSATION 3 CM.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 07 L1 P08 LEARN THIS C" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/07 L1 P08 LEARN THIS C.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 08 L1 P09 READ THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/08 L1 P09 READ THIS.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 09 L1 P10 LEARN THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/09 L1 P10 LEARN THIS.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 10 L1 P10 LEARN THIS B CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/10 L1 P10 LEARN THIS B CM.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 11 L1 P11 SAYING IT RIGHT A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/11 L1 P11 SAYING IT RIGHT A.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 12 L1 P11 SAYING IT RIGHT B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/12 L1 P11 SAYING IT RIGHT B.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 13 L1 P11 MAKING IT PERSONAL" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/13 L1 P11 MAKING IT PERSONAL.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 14 P13 CONNECTIONS 1 A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 1/14 P13 CONNECTIONS 1 A.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 01 L2 P14 STARTING OFF 3 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/01 L2 P14 STARTING OFF 3 CM.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 02 L2 P14 LISTENING B1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/02 L2 P14 LISTENING B1.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 03 L2 P14 LISTENING B3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/03 L2 P14 LISTENING B3.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 04 L2 P15 WORDS & EXPRESSIONS C1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/04 L2 P15 WORDS & EXPRESSIONS C1.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 05 L2 P15 WORDS & EXPRESSIONS 3 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/05 L2 P15 WORDS & EXPRESSIONS 3 CM.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 06 L2 P15 WORDS & EXPRESSIONS 3 PART 2 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/06 L2 P15 WORDS & EXPRESSIONS 3 PART 2 CM.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 07 L2 P15 WORDS & EXPRESSIONS C3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/07 L2 P15 WORDS & EXPRESSIONS C3.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 08 L2 P15 CONVERSATION 3 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/08 L2 P15 CONVERSATION 3 CM.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 09 L2 P16 LEARNING THIS B CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/09 L2 P16 LEARNING THIS B CM.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 10 L2 P16 LEARN THIS C" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/10 L2 P16 LEARN THIS C.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 11 L2 P17 READ THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/11 L2 P17 READ THIS.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 12 L2 P18 LEARN THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/12 L2 P18 LEARN THIS.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 13 L2 P18 LEARN THIS C CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/13 L2 P18 LEARN THIS C CM.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 14 L2 P19 SAYING IT RIGHT A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/14 L2 P19 SAYING IT RIGHT A.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 15 L2 P19 SAYING IT RIGHT B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/15 L2 P19 SAYING IT RIGHT B.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 16 L2 P19 MAKING IT PERSONAL" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/16 L2 P19 MAKING IT PERSONAL.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 17 L2 P21 CONNECTIONS 2 A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 2/17 L2 P21 CONNECTIONS 2 A.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 01 L3 P22 STARTING OFF 3 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/01 L3 P22 STARTING OFF 3 CM.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 02 L3 P22 LISTENING B1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/02 L3 P22 LISTENING B1.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 03 L3 P22 LISTENING B3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/03 L3 P22 LISTENING B3.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 04 L3 P23 WORDS & EXPRESSIONS 1 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/04 L3 P23 WORDS & EXPRESSIONS 1 CM.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 05 L3 P23 WORDS & EXPRESSIONS C1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/05 L3 P23 WORDS & EXPRESSIONS C1.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 06 L3 P23 WORDS & EXPRESSIONS C2" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/06 L3 P23 WORDS & EXPRESSIONS C2.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 07 L3 P23 CONVERSATION 3 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/07 L3 P23 CONVERSATION 3 CM.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 08 L3 P24 LEARN THIS B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/08 L3 P24 LEARN THIS B.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 09 L3 P24 LEARN THIS C CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/09 L3 P24 LEARN THIS C CM.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 10 L3 P25 READ THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/10 L3 P25 READ THIS.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 11 L3 P26 LEARN THIS B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/11 L3 P26 LEARN THIS B.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 12 L3 P27 SAYING IT RIGHT A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/12 L3 P27 SAYING IT RIGHT A.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 13 L3 P27 SAYING IT RIGHT B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/13 L3 P27 SAYING IT RIGHT B.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 14 L3 P27 MAKING IT PERSONAL" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/14 L3 P27 MAKING IT PERSONAL.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 15 P29 CONNECTIONS 3 A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 3/15 P29 CONNECTIONS 3 A.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 01 L4 P30 STARTING OFF 3 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/01 L4 P30 STARTING OFF 3 CM.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 02 L4 P30 LISTENING B1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/02 L4 P30 LISTENING B1.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 03 L4 P30 LISTENING B3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/03 L4 P30 LISTENING B3.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 04 L4 P31 WORDS & EXPRESSIONS 1 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/04 L4 P31 WORDS & EXPRESSIONS 1 CM.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 05 L4 P31 WORDS & EXPRESSIONS C1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/05 L4 P31 WORDS & EXPRESSIONS C1.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 06 L4 P31 WORDS & EXPRESSIONS C2" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/06 L4 P31 WORDS & EXPRESSIONS C2.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 07 L4 P31 CONVERSATION 2 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/07 L4 P31 CONVERSATION 2 CM.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 08 L4 P32 LEARN THIS C" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/08 L4 P32 LEARN THIS C.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 09 L4 P33 READ THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/09 L4 P33 READ THIS.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 10 L4 P34 LEARN THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/10 L4 P34 LEARN THIS.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 11 L4 P35 SAYING IT RIGHT A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/11 L4 P35 SAYING IT RIGHT A.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 12 L4 P35 SAYING IT RIGHT B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/12 L4 P35 SAYING IT RIGHT B.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 13 L4 P35 MAKING IT PERSONAL" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/13 L4 P35 MAKING IT PERSONAL.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 14 P37 CONNECTIONS 4 A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 4/14 P37 CONNECTIONS 4 A.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 01 L5 P38 STARTING OFF 3 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 5/01 L5 P38 STARTING OFF 3 CM.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 02 L5 P38 LISTENING B1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 5/02 L5 P38 LISTENING B1.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 03 L5 P38 LISTENING B3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 5/03 L5 P38 LISTENING B3.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 04 L5 P39 WORDS & EXPRESSIONS C1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 5/04 L5 P39 WORDS & EXPRESSIONS C1.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 05 L5 P39 WORDS & EXPRESSIONS C3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 5/05 L5 P39 WORDS & EXPRESSIONS C3.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 06 L5 P39 CONVERSATION 2 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 5/06 L5 P39 CONVERSATION 2 CM.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 07 L5 P40 LEARN THIS C" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 5/07 L5 P40 LEARN THIS C.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 08 L5 P41 READ THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 5/08 L5 P41 READ THIS.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 09 L5 P42 LEARN THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 5/09 L5 P42 LEARN THIS.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 10 L5 P43 SAYING IT RIGHT A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 5/10 L5 P43 SAYING IT RIGHT A.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 11 L5 P43 SAYING IT RIGHT B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 5/11 L5 P43 SAYING IT RIGHT B.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 12 P45 CONNECTIONS 5 A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 5/12 P45 CONNECTIONS 5 A.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 01 L6 P50 STARTING OFF 2 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 6/01 L6 P50 STARTING OFF 2 CM.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 02 L6 P50 LISTENING B1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 6/02 L6 P50 LISTENING B1.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 03 L6 P50 LISTENING B3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 6/03 L6 P50 LISTENING B3.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 04 L6 P51 WORDS & EXPRESSIONS C1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 6/04 L6 P51 WORDS & EXPRESSIONS C1.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 05 L6 P51 WORDS 7 EXPRESSIONS C2" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 6/05 L6 P51 WORDS 7 EXPRESSIONS C2.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 06 L6 P51 CONVERSATION 2 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 6/06 L6 P51 CONVERSATION 2 CM.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 07 L6 P52 LEARN THIS C" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 6/07 L6 P52 LEARN THIS C.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 08 L6 P53 READ THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 6/08 L6 P53 READ THIS.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 09 L6 P55 SAYING IT RIGHT A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 6/09 L6 P55 SAYING IT RIGHT A.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 10 L6 P55 SAYING IT RIGHT B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 6/10 L6 P55 SAYING IT RIGHT B.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 11 L6 P55 MAKING IT PERSONAL" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 6/11 L6 P55 MAKING IT PERSONAL.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 12 P57 CONNECTIONS 6 A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 6/12 P57 CONNECTIONS 6 A.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 01 L7 P58 STARTING OFF 3 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/01 L7 P58 STARTING OFF 3 CM.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 02 L7 P58 LISTENING B1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/02 L7 P58 LISTENING B1.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 03 L7 P58 LISTENING B3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/03 L7 P58 LISTENING B3.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 04 L7 P59 WORDS & EXPRESSIONS 1 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/04 L7 P59 WORDS & EXPRESSIONS 1 CM.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 05 L7 P59 WORDS & EXPRESSIONS C1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/05 L7 P59 WORDS & EXPRESSIONS C1.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 06 L7 P59 WORDS & EXPRESSIONS C2" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/06 L7 P59 WORDS & EXPRESSIONS C2.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 07 L7 P59 CONVERSATION 2 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/07 L7 P59 CONVERSATION 2 CM.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 08 L7 P60 LEARN THIS C" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/08 L7 P60 LEARN THIS C.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 09 L7 P61 READ THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/09 L7 P61 READ THIS.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 10 L7 P62 LEARN THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/10 L7 P62 LEARN THIS.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 11 L7 P63 SAYING IT RIGHT A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/11 L7 P63 SAYING IT RIGHT A.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 12 L7 P63 SAYING IT RIGHT B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/12 L7 P63 SAYING IT RIGHT B.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 13 L7 P63 MAKING IT PERSONAL" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/13 L7 P63 MAKING IT PERSONAL.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 14 P65 CONNECTIONS 7 A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 7/14 P65 CONNECTIONS 7 A.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 01 L8 P66 STARTING OFF 2 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/01 L8 P66 STARTING OFF 2 CM.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 02 L8 P66 LISTENING B1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/02 L8 P66 LISTENING B1.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 03 L8 P66 LISTENING B3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/03 L8 P66 LISTENING B3.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 04 L8 P67 WORDS & EXPRESSIONS 1 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/04 L8 P67 WORDS & EXPRESSIONS 1 CM.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 05 L8 P67 WORDS & EXPRESSIONS C1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/05 L8 P67 WORDS & EXPRESSIONS C1.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 06 L8 P67 WORDS & EXPRESSIONS C2" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/06 L8 P67 WORDS & EXPRESSIONS C2.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 07 L8 P67 CONVERSATION 3 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/07 L8 P67 CONVERSATION 3 CM.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 08 L8 P68 LEARN THIS C" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/08 L8 P68 LEARN THIS C.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 09 L8 P69 READ THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/09 L8 P69 READ THIS.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 10 L8 P70 LEARN THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/10 L8 P70 LEARN THIS.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 11 L8 P71 SAYING IT RIGHT A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/11 L8 P71 SAYING IT RIGHT A.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 12 L8 P71 SAYING IT RIGHT B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/12 L8 P71 SAYING IT RIGHT B.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 13 L8 P71 MAKING IT PERSONAL" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/13 L8 P71 MAKING IT PERSONAL.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 14 P73 CONNECTIONS 8 A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 8/14 P73 CONNECTIONS 8 A.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 01 L9 P74 STARTING OFF 2 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 9/01 L9 P74 STARTING OFF 2 CM.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 02 L9 P74 LISTENING B1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 9/02 L9 P74 LISTENING B1.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 03 L9 P74 LISTENING B3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 9/03 L9 P74 LISTENING B3.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 04 L9 P75 WORDS & EXPRESSIONS C1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 9/04 L9 P75 WORDS & EXPRESSIONS C1.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 05 L9 P75 WORDS & EXPRESSIONS C2" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 9/05 L9 P75 WORDS & EXPRESSIONS C2.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 06 L9 P75 CONVERSATION 2 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 9/06 L9 P75 CONVERSATION 2 CM.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 07 L9 P76 LEARN THIS C" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 9/07 L9 P76 LEARN THIS C.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 08 L9 P77 READ THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 9/08 L9 P77 READ THIS.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 09 L9 P78 LEARN THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 9/09 L9 P78 LEARN THIS.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 10 L9 P79 SAYING IT RIGHT" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 9/10 L9 P79 SAYING IT RIGHT.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 11 L9 P79 MAKING IT PERSONAL" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 9/11 L9 P79 MAKING IT PERSONAL.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 12 P81 CONNECTIONS 9 A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 9/12 P81 CONNECTIONS 9 A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 01 L10 P82 LISTENING B1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 10/01 L10 P82 LISTENING B1.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 02 L10 P82 LISTENING B3" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 10/02 L10 P82 LISTENING B3.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 03 L10 P83 WORDS & EXPRESSIONS C1" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 10/03 L10 P83 WORDS & EXPRESSIONS C1.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 04 L10 P83 WORDS & EXPRESSIONS C2" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 10/04 L10 P83 WORDS & EXPRESSIONS C2.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 05 L10 P83 CONVERSATION 2 CM" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 10/05 L10 P83 CONVERSATION 2 CM.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 06 L10 P84 LEARN THIS C" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 10/06 L10 P84 LEARN THIS C.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 07 L10 P85 READ THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 10/07 L10 P85 READ THIS.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 08 L10 P86 LEARN THIS" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 10/08 L10 P86 LEARN THIS.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 09 L10 P87 SAYING IT RIGHT A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 10/09 L10 P87 SAYING IT RIGHT A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 10 L10 P87 SAYING IT RIGHT B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 10/10 L10 P87 SAYING IT RIGHT B.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 11 L10 P87 MAKING IT PERSONAL" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 10/11 L10 P87 MAKING IT PERSONAL.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 12 P89 CONNECTIONS 10 A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/LESSON 10/12 P89 CONNECTIONS 10 A.mp3" data-free="false"></li>
<li data-title="REVIEW 1 - 01 P48 REVIEW 1 EX A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/REVIEW 1/01 P48 REVIEW 1 EX A.mp3" data-free="false"></li>
<li data-title="REVIEW 1 - 02 P48 REVEIW 1 EX B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/REVIEW 1/02 P48 REVEIW 1 EX B.mp3" data-free="false"></li>
<li data-title="REVIEW 1 - 03 P48 REVIEW 1 EX C" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/REVIEW 1/03 P48 REVIEW 1 EX C.mp3" data-free="false"></li>
<li data-title="REVIEW 1 - 04 P49 REVIEW 1 EX D" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/REVIEW 1/04 P49 REVIEW 1 EX D.mp3" data-free="false"></li>
<li data-title="REVIEW 2 - 01 P92 REVIEW 2 EX A" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/REVIEW 2/01 P92 REVIEW 2 EX A.mp3" data-free="false"></li>
<li data-title="REVIEW 2 - 02 P92 REVIEW 2 EX B" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/REVIEW 2/02 P92 REVIEW 2 EX B.mp3" data-free="false"></li>
<li data-title="REVIEW 2 - 03 P92 REVIEW 2 EX C" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/REVIEW 2/03 P92 REVIEW 2 EX C.mp3" data-free="false"></li>
<li data-title="REVIEW 2 - 04 P93 REVIEW 2 EX D" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/REVIEW 2/04 P93 REVIEW 2 EX D.mp3" data-free="false"></li>
<li data-title="WORKBOOK - 01 WB L1 P103 EXERCISE E" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/WORKBOOK/01 WB L1 P103 EXERCISE E.mp3" data-free="false"></li>
<li data-title="WORKBOOK - 02 WB L2 P105 EXERCISE F" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/WORKBOOK/02 WB L2 P105 EXERCISE F.mp3" data-free="false"></li>
<li data-title="WORKBOOK - 03 WB L3 P107 EXERCISE E" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/WORKBOOK/03 WB L3 P107 EXERCISE E.mp3" data-free="false"></li>
<li data-title="WORKBOOK - 04 WB L4 P109 EXERCISE F" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/WORKBOOK/04 WB L4 P109 EXERCISE F.mp3" data-free="false"></li>
<li data-title="WORKBOOK - 05 WB L5 P111 EXERCISE E" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/WORKBOOK/05 WB L5 P111 EXERCISE E.mp3" data-free="false"></li>
<li data-title="WORKBOOK - 06 WB L6 P113 EXERCISE F" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/WORKBOOK/06 WB L6 P113 EXERCISE F.mp3" data-free="false"></li>
<li data-title="WORKBOOK - 07 WB L7 P115 EXERCISE E" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/WORKBOOK/07 WB L7 P115 EXERCISE E.mp3" data-free="false"></li>
<li data-title="WORKBOOK - 08 WB L8 P117 EXERCISE F" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/WORKBOOK/08 WB L8 P117 EXERCISE F.mp3" data-free="false"></li>
<li data-title="WORKBOOK - 09 WB L9 P119 EXERCISE F" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/WORKBOOK/09 WB L9 P119 EXERCISE F.mp3" data-free="false"></li>
<li data-title="WORKBOOK - 10 WB L10 P121 EXERCISE E" data-artist="Transitions 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Transitions 1/WORKBOOK/10 WB L10 P121 EXERCISE E.mp3" data-free="false"></li>





	



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
