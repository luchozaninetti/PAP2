
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Fun At School</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
     
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->

	<li data-title="01. Lesson 1 - What's going on - Characters - p.8" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 01\01. Lesson 1 - What's going on - Characters - p.8.mp3" data-free="false"></li>
<li data-title="02. Lesson 1 - What's going on - Story - pages 8 and 9" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 01\02. Lesson 1 - What's going on - Story - pages 8 and 9.mp3" data-free="false"></li>
<li data-title="03. Lesson 1 - Picture Corner - p.9" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 01\03. Lesson 1 - Picture Corner - p.9.mp3" data-free="false"></li>
<li data-title="04. Lesson 1 - Vocabulary - p.10" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 01\04. Lesson 1 - Vocabulary - p.10.mp3" data-free="false"></li>
<li data-title="05. Lesson 1 - Check this out - A - p.10" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 01\05. Lesson 1 - Check this out - A - p.10.mp3" data-free="false"></li>
<li data-title="06. Lesson 1 - Check this out - B - p.10" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 01\06. Lesson 1 - Check this out - B - p.10.mp3" data-free="false"></li>
<li data-title="07. Lesson 1 - Check this out - E - page 11 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 01\07. Lesson 1 - Check this out - E - page 11 - Listening.mp3" data-free="false"></li>
<li data-title="08. Lesson 1 - Your turn - A - p.12" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 01\08. Lesson 1 - Your turn - A - p.12.mp3" data-free="false"></li>
<li data-title="09. Lesson 1 - Your turn - D - p.12 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 01\09. Lesson 1 - Your turn - D - p.12 - Listening.mp3" data-free="false"></li>
<li data-title="10. Lesson 1 - Fun time - A - p.13" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 01\10. Lesson 1 - Fun time - A - p.13.mp3" data-free="false"></li>
<li data-title="Song - If you're happy and you know it" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 01\Song - If you're happy and you know it.mp3" data-free="false"></li>
<li data-title="01. Lesson 2 - What's going on - Story - pages 14 and 15" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 02\01. Lesson 2 - What's going on - Story - pages 14 and 15.mp3" data-free="false"></li>
<li data-title="02. Lesson 2 - Picture corner - p.15" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 02\02. Lesson 2 - Picture corner - p.15.mp3" data-free="false"></li>
<li data-title="03. Lesson 2 - Vocabulary - A - p.16" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 02\03. Lesson 2 - Vocabulary - A - p.16.mp3" data-free="false"></li>
<li data-title="04. Lesson 2 - Check this out - A - p.16" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 02\04. Lesson 2 - Check this out - A - p.16.mp3" data-free="false"></li>
<li data-title="05. Lesson 2 - Check this out - B - p.16" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 02\05. Lesson 2 - Check this out - B - p.16.mp3" data-free="false"></li>
<li data-title="06. Lesson 2 - Check this out - D - p.17" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 02\06. Lesson 2 - Check this out - D - p.17.mp3" data-free="false"></li>
<li data-title="07. Lesson 2 - Check this out - F - p.18 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 02\07. Lesson 2 - Check this out - F - p.18 - Listening.mp3" data-free="false"></li>
<li data-title="08. Lesson 2 - Your turn - A - p.18" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 02\08. Lesson 2 - Your turn - A - p.18.mp3" data-free="false"></li>
<li data-title="09. Lesson 2 - Your turn - C - p.19 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 02\09. Lesson 2 - Your turn - C - p.19 - Listening.mp3" data-free="false"></li>
<li data-title="10. Lesson 2 - Fun time - A - p.19" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 02\10. Lesson 2 - Fun time - A - p.19.mp3" data-free="false"></li>
<li data-title="01. Lesson 3 - What's going on - Story - pages 20 and 21" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 03\01. Lesson 3 - What's going on - Story - pages 20 and 21.mp3" data-free="false"></li>
<li data-title="02. Lesson 3 - Picture corner - p.21" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 03\02. Lesson 3 - Picture corner - p.21.mp3" data-free="false"></li>
<li data-title="03. Lesson 3 - Vocabulary - p.22" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 03\03. Lesson 3 - Vocabulary - p.22.mp3" data-free="false"></li>
<li data-title="04. Lesson 3 - Check this out - A - p.22" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 03\04. Lesson 3 - Check this out - A - p.22.mp3" data-free="false"></li>
<li data-title="05. Lesson 3 - Check this out - B - p.22" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 03\05. Lesson 3 - Check this out - B - p.22.mp3" data-free="false"></li>
<li data-title="06. Lesson 3 - Check this out - C - p.23" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 03\06. Lesson 3 - Check this out - C - p.23.mp3" data-free="false"></li>
<li data-title="07. Lesson 3 - Check this out - E - p.23 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 03\07. Lesson 3 - Check this out - E - p.23 - Listening.mp3" data-free="false"></li>
<li data-title="08. Lesson 3 - Your turn - A - p.24" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 03\08. Lesson 3 - Your turn - A - p.24.mp3" data-free="false"></li>
<li data-title="09. Lesson 3 - Your turn - D - p.24 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 03\09. Lesson 3 - Your turn - D - p.24 - Listening.mp3" data-free="false"></li>
<li data-title="10. Lesson 3 - Fun time - A -p.25" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 03\10. Lesson 3 - Fun time - A -p.25.mp3" data-free="false"></li>
<li data-title="01. Lesson 4 - What's going on - Story - pages 26 and 27" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 04\01. Lesson 4 - What's going on - Story - pages 26 and 27.mp3" data-free="false"></li>
<li data-title="02. Lesson 4 - Picture corner - p.27" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 04\02. Lesson 4 - Picture corner - p.27.mp3" data-free="false"></li>
<li data-title="03. Lesson 4 - Vocabulary - A - p.28" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 04\03. Lesson 4 - Vocabulary - A - p.28.mp3" data-free="false"></li>
<li data-title="04. Lesson 4 - Check this out - A - p.28" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 04\04. Lesson 4 - Check this out - A - p.28.mp3" data-free="false"></li>
<li data-title="05. Lesson 4 - Check this out - C - p.29" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 04\05. Lesson 4 - Check this out - C - p.29.mp3" data-free="false"></li>
<li data-title="06. Lesson 4 - Check this out - E - p.29" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 04\06. Lesson 4 - Check this out - E - p.29.mp3" data-free="false"></li>
<li data-title="07. Lesson 4 - Check this out - G - p.30 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 04\07. Lesson 4 - Check this out - G - p.30 - Listening.mp3" data-free="false"></li>
<li data-title="08. Lesson 4 - Your turn - A - p.30" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 04\08. Lesson 4 - Your turn - A - p.30.mp3" data-free="false"></li>
<li data-title="09. Lesson 4 - Your turn - C - p.30 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 04\09. Lesson 4 - Your turn - C - p.30 - Listening.mp3" data-free="false"></li>
<li data-title="10. Lesson 4 - Fun time - A - p.31" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 04\10. Lesson 4 - Fun time - A - p.31.mp3" data-free="false"></li>
<li data-title="Song - Goodbye Song" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 04\Song - Goodbye Song.mp3" data-free="false"></li>
<li data-title="01. Lesson 5 - What's going on - Characters - p.36" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 05\01. Lesson 5 - What's going on - Characters - p.36.mp3" data-free="false"></li>
<li data-title="02. Lesson 5 - What's going on - Story - pages 36 and 37" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 05\02. Lesson 5 - What's going on - Story - pages 36 and 37.mp3" data-free="false"></li>
<li data-title="03. Lesson 5 - Picture corner - p.37" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 05\03. Lesson 5 - Picture corner - p.37.mp3" data-free="false"></li>
<li data-title="04. Lesson 5 - Vocabulary - p.38" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 05\04. Lesson 5 - Vocabulary - p.38.mp3" data-free="false"></li>
<li data-title="05. Lesson 5 - Check this out - A - p.38" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 05\05. Lesson 5 - Check this out - A - p.38.mp3" data-free="false"></li>
<li data-title="06. Lesson 5 - Check this out - C - p.39" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 05\06. Lesson 5 - Check this out - C - p.39.mp3" data-free="false"></li>
<li data-title="07. Lesson 5 - Check this out - E - p.39" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 05\07. Lesson 5 - Check this out - E - p.39.mp3" data-free="false"></li>
<li data-title="08. Lesson 5 - Check this out - G - p.40 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 05\08. Lesson 5 - Check this out - G - p.40 - Listening.mp3" data-free="false"></li>
<li data-title="09. Lesson 5 - Your turn - A - p.40" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 05\09. Lesson 5 - Your turn - A - p.40.mp3" data-free="false"></li>
<li data-title="10. Lesson 5 - Your turn - C - p.40 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 05\10. Lesson 5 - Your turn - C - p.40 - Listening.mp3" data-free="false"></li>
<li data-title="11. Lesson 5 - Fun time - A - p.41" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 05\11. Lesson 5 - Fun time - A - p.41.mp3" data-free="false"></li>
<li data-title="Song - The Greetings Song" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 05\Song - The Greetings Song.mp3" data-free="false"></li>
<li data-title="01. Lesson 6 - What's going on - Story - pages 44 and 45" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 06\01. Lesson 6 - What's going on - Story - pages 44 and 45.mp3" data-free="false"></li>
<li data-title="02. Lesson 6 - Picture corner - p.45" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 06\02. Lesson 6 - Picture corner - p.45.mp3" data-free="false"></li>
<li data-title="03. Lesson 6 - Vocabulary - p.46" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 06\03. Lesson 6 - Vocabulary - p.46.mp3" data-free="false"></li>
<li data-title="04. Lesson 6 - Check this out - A - p.46" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 06\04. Lesson 6 - Check this out - A - p.46.mp3" data-free="false"></li>
<li data-title="05. Lesson 6 - Check this out - D - p.47 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 06\05. Lesson 6 - Check this out - D - p.47 - Listening.mp3" data-free="false"></li>
<li data-title="06. Lesson 6 - Your turn - A - p.48" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 06\06. Lesson 6 - Your turn - A - p.48.mp3" data-free="false"></li>
<li data-title="07. Lesson 6 - Your turn - D - p.48 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 06\07. Lesson 6 - Your turn - D - p.48 - Listening.mp3" data-free="false"></li>
<li data-title="08. Lesson 6 - Fun time - A - p.49" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 06\08. Lesson 6 - Fun time - A - p.49.mp3" data-free="false"></li>
<li data-title="01. Lesson 7 - What's going on - Story - pages 50 and 51" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 07\01. Lesson 7 - What's going on - Story - pages 50 and 51.mp3" data-free="false"></li>
<li data-title="02. Lesson 7 - Picture corner - p.51" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 07\02. Lesson 7 - Picture corner - p.51.mp3" data-free="false"></li>
<li data-title="03. Lesson 7 - Vocabulary - p.52" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 07\03. Lesson 7 - Vocabulary - p.52.mp3" data-free="false"></li>
<li data-title="04. Lesson 7 - Check this out - A - p.52" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 07\04. Lesson 7 - Check this out - A - p.52.mp3" data-free="false"></li>
<li data-title="05. Lesson 7 - Check this out - D - p.53" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 07\05. Lesson 7 - Check this out - D - p.53.mp3" data-free="false"></li>
<li data-title="06. Lesson 7 - Check this out - F - p.53" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 07\06. Lesson 7 - Check this out - F - p.53.mp3" data-free="false"></li>
<li data-title="07. Lesson 7 - Check this out - H - p.54 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 07\07. Lesson 7 - Check this out - H - p.54 - Listening.mp3" data-free="false"></li>
<li data-title="08. Lesson 7 - Your turn - A - p.54" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 07\08. Lesson 7 - Your turn - A - p.54.mp3" data-free="false"></li>
<li data-title="09. Lesson 7 - Your turn - C - p.54 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 07\09. Lesson 7 - Your turn - C - p.54 - Listening.mp3" data-free="false"></li>
<li data-title="10. Lesson 7 - Fun time - A - p.55" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 07\10. Lesson 7 - Fun time - A - p.55.mp3" data-free="false"></li>
<li data-title="01. Lesson 8 - What's going on - pages 56 and 57" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 08\01. Lesson 8 - What's going on - pages 56 and 57.mp3" data-free="false"></li>
<li data-title="02. Lesson 8 - Picture corner - p.57" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 08\02. Lesson 8 - Picture corner - p.57.mp3" data-free="false"></li>
<li data-title="03. Lesson 8 - Vocabulary - A - p.58" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 08\03. Lesson 8 - Vocabulary - A - p.58.mp3" data-free="false"></li>
<li data-title="04. Lesson 8 - Check this out - A - p.58" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 08\04. Lesson 8 - Check this out - A - p.58.mp3" data-free="false"></li>
<li data-title="05. Lesson 8 - Check this out - C - p.59" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 08\05. Lesson 8 - Check this out - C - p.59.mp3" data-free="false"></li>
<li data-title="06. Lesson 8 - Check this out - E - p.59 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 08\06. Lesson 8 - Check this out - E - p.59 - Listening.mp3" data-free="false"></li>
<li data-title="07. Lesson 8 - Your turn - A - p.60" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 08\07. Lesson 8 - Your turn - A - p.60.mp3" data-free="false"></li>
<li data-title="08. Lesson 8 - Your turn - C - p.60 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 08\08. Lesson 8 - Your turn - C - p.60 - Listening.mp3" data-free="false"></li>
<li data-title="09. Lesson 8 - Fun time - A - p.60" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 08\09. Lesson 8 - Fun time - A - p.60.mp3" data-free="false"></li>
<li data-title="01. Lesson 9 - What's going on - Characters - p.68" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 09\01. Lesson 9 - What's going on - Characters - p.68.mp3" data-free="false"></li>
<li data-title="02. Lesson 9 - What's going on - Story - pages 68 and 69" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 09\02. Lesson 9 - What's going on - Story - pages 68 and 69.mp3" data-free="false"></li>
<li data-title="03. Lesson 9 - Picture corner - p.69" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 09\03. Lesson 9 - Picture corner - p.69.mp3" data-free="false"></li>
<li data-title="04. Lesson 9 - Vocabulary - A - p.70" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 09\04. Lesson 9 - Vocabulary - A - p.70.mp3" data-free="false"></li>
<li data-title="05. Lesson 9 - Vocabulary - B - p.70" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 09\05. Lesson 9 - Vocabulary - B - p.70.mp3" data-free="false"></li>
<li data-title="06. Lesson 9 - Check this out - A - p.70" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 09\06. Lesson 9 - Check this out - A - p.70.mp3" data-free="false"></li>
<li data-title="07. Lesson 9 - Check this out - C - p.71" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 09\07. Lesson 9 - Check this out - C - p.71.mp3" data-free="false"></li>
<li data-title="08. Lesson 9 - Check this out - D - p.71 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 09\08. Lesson 9 - Check this out - D - p.71 - Listening.mp3" data-free="false"></li>
<li data-title="09. Lesson 9 - Your turn - A - p.72" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 09\09. Lesson 9 - Your turn - A - p.72.mp3" data-free="false"></li>
<li data-title="10. Lesson 9 - Your turn - C - p.72 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 09\10. Lesson 9 - Your turn - C - p.72 - Listening.mp3" data-free="false"></li>
<li data-title="11. Lesson 9 - Fun time - A - p.72" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 09\11. Lesson 9 - Fun time - A - p.72.mp3" data-free="false"></li>
<li data-title="Song - The Alphabet Song" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 09\Song - The Alphabet Song.mp3" data-free="false"></li>
<li data-title="01. Lesson 10 - What's going on - Story - pages 74 and 75" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 10\01. Lesson 10 - What's going on - Story - pages 74 and 75.mp3" data-free="false"></li>
<li data-title="02. Lesson 10 - Picture corner - p.75" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 10\02. Lesson 10 - Picture corner - p.75.mp3" data-free="false"></li>
<li data-title="03. Lesson 10 - Vocabulary - A - p.76" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 10\03. Lesson 10 - Vocabulary - A - p.76.mp3" data-free="false"></li>
<li data-title="04. Lesson 10 - Check this out - A - p.76" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 10\04. Lesson 10 - Check this out - A - p.76.mp3" data-free="false"></li>
<li data-title="05. Lesson 10 - Check this out - E - page 78" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 10\05. Lesson 10 - Check this out - E - page 78.mp3" data-free="false"></li>
<li data-title="06. Lesson 10 - Check this out - G - p. 78 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 10\06. Lesson 10 - Check this out - G - p. 78 - Listening.mp3" data-free="false"></li>
<li data-title="07. Lesson 10 - Your turn - A - p.78" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 10\07. Lesson 10 - Your turn - A - p.78.mp3" data-free="false"></li>
<li data-title="08. Lesson 10 - Your turn - C - p.79 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 10\08. Lesson 10 - Your turn - C - p.79 - Listening.mp3" data-free="false"></li>
<li data-title="09. Lesson 10 - Fun time - A - p.79" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 10\09. Lesson 10 - Fun time - A - p.79.mp3" data-free="false"></li>
<li data-title="01. Lesson 11 - What's going on - Story - pages 82 and 83" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 11\01. Lesson 11 - What's going on - Story - pages 82 and 83.mp3" data-free="false"></li>
<li data-title="02. Lesson 11 - Picture corner - p.83" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 11\02. Lesson 11 - Picture corner - p.83.mp3" data-free="false"></li>
<li data-title="03. Lesson 11 - Vocabulary - A - p.84" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 11\03. Lesson 11 - Vocabulary - A - p.84.mp3" data-free="false"></li>
<li data-title="04. Lesson 11 - Vocabulary - B - p.84" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 11\04. Lesson 11 - Vocabulary - B - p.84.mp3" data-free="false"></li>
<li data-title="05. Lesson 11 - Check this out - A - p.85" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 11\05. Lesson 11 - Check this out - A - p.85.mp3" data-free="false"></li>
<li data-title="06. Lesson 11 - Check this out - D - p.85 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 11\06. Lesson 11 - Check this out - D - p.85 - Listening.mp3" data-free="false"></li>
<li data-title="07. Lesson 11 - Check this out - E - p.86" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 11\07. Lesson 11 - Check this out - E - p.86.mp3" data-free="false"></li>
<li data-title="08. Lesson 11 - Your turn - A - p.86" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 11\08. Lesson 11 - Your turn - A - p.86.mp3" data-free="false"></li>
<li data-title="09. Lesson 11 - Your turn - C - p.87 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 11\09. Lesson 11 - Your turn - C - p.87 - Listening.mp3" data-free="false"></li>
<li data-title="10. Lesson 11 - Fun time - A - p.88" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 11\10. Lesson 11 - Fun time - A - p.88.mp3" data-free="false"></li>
<li data-title="01. Lesson 12 - What's going on - Story - pages 92 and 93" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 12\01. Lesson 12 - What's going on - Story - pages 92 and 93.mp3" data-free="false"></li>
<li data-title="02. Lesson 12 - Picture corner - p.93" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 12\02. Lesson 12 - Picture corner - p.93.mp3" data-free="false"></li>
<li data-title="03. Lesson 12 - Vocabulary - A - p.94" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 12\03. Lesson 12 - Vocabulary - A - p.94.mp3" data-free="false"></li>
<li data-title="04. Lesson 12 - Check this out - A - p.95" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 12\04. Lesson 12 - Check this out - A - p.95.mp3" data-free="false"></li>
<li data-title="05. Lesson 12 - Check this out - C - p.95 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 12\05. Lesson 12 - Check this out - C - p.95 - Listening.mp3" data-free="false"></li>
<li data-title="06. Lesson 12 - Your turn - A - p.96" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 12\06. Lesson 12 - Your turn - A - p.96.mp3" data-free="false"></li>
<li data-title="07. Lesson 12 - Your turn - C - p.96 - Listening" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 12\07. Lesson 12 - Your turn - C - p.96 - Listening.mp3" data-free="false"></li>
<li data-title="08. Lesson 12 - Fun time - A - p.97" data-artist="FUN AT SCHOOL" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online\dados\AUDIO\INGLES\INFANTIL\FUN AT SCHOOL\LESSON 12\08. Lesson 12 - Fun time - A - p.97.mp3" data-free="false"></li>


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
