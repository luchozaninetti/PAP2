
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Elementary 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
           
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="APPENDIX 1 - 01 COMMUNICATION ACTIVITY 1 P30 B CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/APPENDIX 1/01 COMMUNICATION ACTIVITY 1 P30 B CM.mp3" data-free="false"></li>
<li data-title="APPENDIX 1 - 02 PRONUNCIATION P30 B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/APPENDIX 1/02 PRONUNCIATION P30 B.mp3" data-free="false"></li>
<li data-title="APPENDIX 2 - 01 PRONUNCIATION P87 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/APPENDIX 2/01 PRONUNCIATION P87 A.mp3" data-free="false"></li>
<li data-title="APPENDIX 2 - 02 PRONUNCIATION P87 B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/APPENDIX 2/02 PRONUNCIATION P87 B.mp3" data-free="false"></li>
<li data-title="APPENDIX 2 - 03 PRONUNCIATION P87 C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/APPENDIX 2/03 PRONUNCIATION P87 C.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 01 L1 P06 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/01 L1 P06 A.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 02 L1 P06 B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/02 L1 P06 B.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 03 L1 P06 C CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/03 L1 P06 C CM.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 04 L1 P07 D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/04 L1 P07 D.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 05 L1 P07 F"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/05 L1 P07 F.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 06 L1 P07 F CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/06 L1 P07 F CM.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 07 L1 P08 GRAMMAR A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/07 L1 P08 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 08 L1 P08 GRAMMAR CONTRACTIONS"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/08 L1 P08 GRAMMAR CONTRACTIONS.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 09 L1 P08 GRAMMAR B CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/09 L1 P08 GRAMMAR B CM.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 10 L1 P08 GRAMMAR C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/10 L1 P08 GRAMMAR C.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 11 L1 P09 VOCABULARY A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/11 L1 P09 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 12 L1 P09 VOCABULARY B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/12 L1 P09 VOCABULARY B.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 13 L1 P10 SPEAKING AND WRITING A CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/13 L1 P10 SPEAKING AND WRITING A CM.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 14 L1 P11 DAY 1"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/14 L1 P11 DAY 1.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 15 L1 P13 EXERCISES B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/15 L1 P13 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 1 - 16 L1 P13 EXERCISES C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 1/16 L1 P13 EXERCISES C.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 01 L2 P14 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/01 L2 P14 A.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 02 L2 P14 A CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/02 L2 P14 A CM.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 03 L2 P14 C CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/03 L2 P14 C CM.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 04 L2 P14 D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/04 L2 P14 D.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 05 L2 P15 E"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/05 L2 P15 E.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 06 L2 P15 G"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/06 L2 P15 G.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 07 L2 P15 G CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/07 L2 P15 G CM.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 08 L2 P16 GRAMMAR A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/08 L2 P16 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 09 L2 P16 GRAMMAR C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/09 L2 P16 GRAMMAR C.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 10 L2 P16 GRAMMAR D CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/10 L2 P16 GRAMMAR D CM.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 11 L2 P17 VOCABULARY A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/11 L2 P17 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 12 L2 P17 VOCABULARY C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/12 L2 P17 VOCABULARY C.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 13 L2 P18 SPEAKING AND WRITING A CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/13 L2 P18 SPEAKING AND WRITING A CM.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 14 L2 P19 DAY 2"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/14 L2 P19 DAY 2.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 15 L2 P20 EXERCISES A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/15 L2 P20 EXERCISES A.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 16 L2 P20 EXERCISES B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/16 L2 P20 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 2 - 17 L2 P21 EXERCISES E"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 2/17 L2 P21 EXERCISES E.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 01 L3 P22 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/01 L3 P22 A.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 02 L3 P22 C CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/02 L3 P22 C CM.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 03 L3 P22 D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/03 L3 P22 D.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 04 L3 P23 E"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/04 L3 P23 E.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 05 L3 P23 G"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/05 L3 P23 G.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 06 L3 P24 GRAMMAR A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/06 L3 P24 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 07 L3 P24 GRAMMAR C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/07 L3 P24 GRAMMAR C.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 08 L3 P25 VOCABULARY A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/08 L3 P25 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 09 L3 P25 VOCABULARY C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/09 L3 P25 VOCABULARY C.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 10 L3 P25 VOCABULARY D CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/10 L3 P25 VOCABULARY D CM.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 11 L3 P27 DAY 3"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/11 L3 P27 DAY 3.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 12 L3 P28 EXERCISES B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/12 L3 P28 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 3 - 13 L3 P29 EXERCISES D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 3/13 L3 P29 EXERCISES D.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 01 L4 P32 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/01 L4 P32 A.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 02 L4 P32 B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/02 L4 P32 B.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 03 L4 P33 D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/03 L4 P33 D.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 04 L4 P33 F"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/04 L4 P33 F.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 05 L4 P33 F CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/05 L4 P33 F CM.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 06 L4 P34 GRAMMAR A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/06 L4 P34 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 07 L4 P34 GRAMMAR CONTRACTIONS"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/07 L4 P34 GRAMMAR CONTRACTIONS.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 08 L4 P34 GRAMMAR D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/08 L4 P34 GRAMMAR D.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 09 L4 P35 VOCABULARY A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/09 L4 P35 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 10 L4 P35 VOCABULARY B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/10 L4 P35 VOCABULARY B.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 11 L4 P36 SPEAKING AND WRITING A CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/11 L4 P36 SPEAKING AND WRITING A CM.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 12 L4 P37 DAY 4"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/12 L4 P37 DAY 4.mp3" data-free="false"></li>
<li data-title="LESSON 4 - 13 L4 P39 EXERCISES E"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 4/13 L4 P39 EXERCISES E.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 01 L5 P40 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 5/01 L5 P40 A.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 02 L5 P41 D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 5/02 L5 P41 D.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 03 L5 P41 F"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 5/03 L5 P41 F.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 04 L5 P41 F CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 5/04 L5 P41 F CM.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 05 L5 P42 GRAMMAR A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 5/05 L5 P42 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 06 L5 P42 GRAMMAR D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 5/06 L5 P42 GRAMMAR D.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 07 L5 P43 VOCABULARY A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 5/07 L5 P43 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 08 L5 P43 VOCABULARY D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 5/08 L5 P43 VOCABULARY D.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 09 L5 P45 DAY 5"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 5/09 L5 P45 DAY 5.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 10 L5 P46 EXERCISES A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 5/10 L5 P46 EXERCISES A.mp3" data-free="false"></li>
<li data-title="LESSON 5 - 11 L5 P46 EXERCISES B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 5/11 L5 P46 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 01 L6 P48 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 6/01 L6 P48 A.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 02 L6 P48 B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 6/02 L6 P48 B.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 03 L6 P49 D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 6/03 L6 P49 D.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 04 L6 P49 F"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 6/04 L6 P49 F.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 05 L6 P50 GRAMMAR A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 6/05 L6 P50 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 06 L6 P50 GRAMMAR E"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 6/06 L6 P50 GRAMMAR E.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 07 L6 P51 VOCABULARY A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 6/07 L6 P51 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 08 L6 P51 VOCABULARY B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 6/08 L6 P51 VOCABULARY B.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 09 L6 P51 VOCABULARY C CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 6/09 L6 P51 VOCABULARY C CM.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 10 L6 P51 VOCABULARY D CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 6/10 L6 P51 VOCABULARY D CM.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 11 L6 P53 DAY 6"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 6/11 L6 P53 DAY 6.mp3" data-free="false"></li>
<li data-title="LESSON 6 - 12 L6 P55 EXERCISES F"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 6/12 L6 P55 EXERCISES F.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 01 L7 P62 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/01 L7 P62 A.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 02 L7 P62 B CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/02 L7 P62 B CM.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 03 L7 P62 C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/03 L7 P62 C.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 04 L7 P63 D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/04 L7 P63 D.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 05 L7 P63 F"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/05 L7 P63 F.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 06 L7 P64 GRAMMAR A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/06 L7 P64 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 07 L7 P64 GRAMMAR C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/07 L7 P64 GRAMMAR C.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 08 L7 P64 GRAMMAR REGULAR VERBS"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/08 L7 P64 GRAMMAR REGULAR VERBS.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 09 L7 P65 GRAMMAR E"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/09 L7 P65 GRAMMAR E.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 10 L7 P65 VOCABULARY A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/10 L7 P65 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 11 L7 P66 SPEAKING AND WRITING A CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/11 L7 P66 SPEAKING AND WRITING A CM.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 12 L7 P67 DAY 7"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/12 L7 P67 DAY 7.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 13 L7 P68 EXERCISES B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/13 L7 P68 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 14 L7 P69 EXERCISES D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/14 L7 P69 EXERCISES D.mp3" data-free="false"></li>
<li data-title="LESSON 7 - 15 L7 P69 EXERCISES E"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 7/15 L7 P69 EXERCISES E.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 01 L8 P70 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/01 L8 P70 A.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 02 L8 P70 C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/02 L8 P70 C.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 03 L8 P71 D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/03 L8 P71 D.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 04 L8 P71 G"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/04 L8 P71 G.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 05 L8 P71 G CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/05 L8 P71 G CM.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 06 L8 P72 GRAMMAR A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/06 L8 P72 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 07 L8 P72 GRAMMAR C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/07 L8 P72 GRAMMAR C.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 08 L8 P72 GRAMMAR D CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/08 L8 P72 GRAMMAR D CM.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 09 L8 P73 VOCABULARY A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/09 L8 P73 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 10 L8 P73 VOCABULARY B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/10 L8 P73 VOCABULARY B.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 11 L8 P75 DAY 8"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/11 L8 P75 DAY 8.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 12 L8 P76 EXERCISES B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/12 L8 P76 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 13 L8 P77 EXERCISES C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/13 L8 P77 EXERCISES C.mp3" data-free="false"></li>
<li data-title="LESSON 8 - 14 L8 P77 EXERCISES D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 8/14 L8 P77 EXERCISES D.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 01 L9 P78 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 9/01 L9 P78 A.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 02 L9 P78 D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 9/02 L9 P78 D.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 03 L9 P79 E"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 9/03 L9 P79 E.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 04 L9 P79 G"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 9/04 L9 P79 G.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 05 L9 P80 GRAMMAR POSSESSIVES"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 9/05 L9 P80 GRAMMAR POSSESSIVES.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 06 L9 P80 GRAMMAR A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 9/06 L9 P80 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 07 L9 P80 GRAMMAR D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 9/07 L9 P80 GRAMMAR D.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 08 L9 P81 VOCABULARY A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 9/08 L9 P81 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 09 L9 P81 VOCABULARY C CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 9/09 L9 P81 VOCABULARY C CM.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 10 L9 P83 DAY 9"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 9/10 L9 P83 DAY 9.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 11 L9 P85 EXERCISES C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 9/11 L9 P85 EXERCISES C.mp3" data-free="false"></li>
<li data-title="LESSON 9 - 12 L9 P85 EXERCISES D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 9/12 L9 P85 EXERCISES D.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 01 L10 P88 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 10/01 L10 P88 A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 02 L10 P89 C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 10/02 L10 P89 C.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 03 L10 P89 E"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 10/03 L10 P89 E.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 04 L10 P89 F"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 10/04 L10 P89 F.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 05 L10 P90 GRAMMAR A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 10/05 L10 P90 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 06 L10 P90 GRAMMAR C CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 10/06 L10 P90 GRAMMAR C CM.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 07 L10 P90 GRAMMAR D CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 10/07 L10 P90 GRAMMAR D CM.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 08 L10 P91 VOCABULARY A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 10/08 L10 P91 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 09 L10 P91 VOCABULARY C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 10/09 L10 P91 VOCABULARY C.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 10 L10 P93 DAY 10"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 10/10 L10 P93 DAY 10.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 11 L10 P94 EXERCISES A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 10/11 L10 P94 EXERCISES A.mp3" data-free="false"></li>
<li data-title="LESSON 10 - 12 L10 P95 EXERCISES B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 10/12 L10 P95 EXERCISES B.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 01 L11 P96 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 11/01 L11 P96 A.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 02 L11 P96 B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 11/02 L11 P96 B.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 03 L11 P97 E"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 11/03 L11 P97 E.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 04 L11 P97 G"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 11/04 L11 P97 G.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 05 L11 P98 GRAMMAR A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 11/05 L11 P98 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 06 L11 P98 GRAMMAR D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 11/06 L11 P98 GRAMMAR D.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 07 L11 P99 VOCABULARY A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 11/07 L11 P99 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 08 L11 P99 VOCABULARY B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 11/08 L11 P99 VOCABULARY B.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 09 L11 P101 DAY 11"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 11/09 L11 P101 DAY 11.mp3" data-free="false"></li>
<li data-title="LESSON 11 - 10 L11 P103 EXERCISES C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 11/10 L11 P103 EXERCISES C.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 01 L12 P104 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 12/01 L12 P104 A.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 02 L12 P104 B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 12/02 L12 P104 B.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 03 L12 P105 E"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 12/03 L12 P105 E.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 04 L12 P105 G"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 12/04 L12 P105 G.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 05 L12 P105 H"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 12/05 L12 P105 H.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 06 L12 P106 GRAMMAR A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 12/06 L12 P106 GRAMMAR A.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 07 L12 P106 GRAMMAR D CM"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 12/07 L12 P106 GRAMMAR D CM.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 08 L12 P107 VOCABULARY A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 12/08 L12 P107 VOCABULARY A.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 09 L12 P107 VOCABULARY D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 12/09 L12 P107 VOCABULARY D.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 10 L12 P109 DAY 12"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 12/10 L12 P109 DAY 12.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 11 L12 P110 EXERCISES A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 12/11 L12 P110 EXERCISES A.mp3" data-free="false"></li>
<li data-title="LESSON 12 - 12 L12 P110 EXERCISES C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/LESSON 12/12 L12 P110 EXERCISES C.mp3" data-free="false"></li>
<li data-title="REVIEW 1 - 01 REVIEW 1 P60 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/REVIEW 1/01 REVIEW 1 P60 A.mp3" data-free="false"></li>
<li data-title="REVIEW 1 - 02 REVIEW 1 P60 B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/REVIEW 1/02 REVIEW 1 P60 B.mp3" data-free="false"></li>
<li data-title="REVIEW 1 - 03 REVIEW 1 P61 C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/REVIEW 1/03 REVIEW 1 P61 C.mp3" data-free="false"></li>
<li data-title="REVIEW 1 - 04 REVIEW 1 P61 D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/REVIEW 1/04 REVIEW 1 P61 D.mp3" data-free="false"></li>
<li data-title="REVIEW 2 - 01 REVIEW 2 P116 A"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/REVIEW 2/01 REVIEW 2 P116 A.mp3" data-free="false"></li>
<li data-title="REVIEW 2 - 02 REVIEW 2 P116 B"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/REVIEW 2/02 REVIEW 2 P116 B.mp3" data-free="false"></li>
<li data-title="REVIEW 2 - 03 REVIEW 2 P117 C"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/REVIEW 2/03 REVIEW 2 P117 C.mp3" data-free="false"></li>
<li data-title="REVIEW 2 - 04 REVIEW 2 P117 D"data-artist="Teens Elementary 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Elementary 2/REVIEW 2/04 REVIEW 2 P117 D.mp3" data-free="false"></li>

	



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
