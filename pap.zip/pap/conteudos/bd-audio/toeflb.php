
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Toefl B</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
            
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Toefl vol B - 01  Practice Test 1 Section 1 Part A p.17" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 1/01  Practice Test 1 Section 1 Part A p.17.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 02 Practice Test 1 Section 1 Part A p.18" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 1/02 Practice Test 1 Section 1 Part A p.18.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 03 Practice Test 1 Section 1 Part A p.19" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 1/03 Practice Test 1 Section 1 Part A p.19.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 04 Practice Test 1 Section 1 Part A p.20" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 1/04 Practice Test 1 Section 1 Part A p.20.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 05 Practice Test 1 Section 1 Part B p.21" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 1/05 Practice Test 1 Section 1 Part B p.21.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 06 Practice Test 1 Section 1 Part C p.22" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 1/06 Practice Test 1 Section 1 Part C p.22.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 07 Practice Test 1 Section 1 Part C p.23" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 1/07 Practice Test 1 Section 1 Part C p.23.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 01 Practice Test 2 Section 1 Part A p.43" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 2/01 Practice Test 2 Section 1 Part A p.43.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 02 Practice Test 2 Section 1 Part A p.44" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 2/02 Practice Test 2 Section 1 Part A p.44.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 03 Practice Test 2 Section 1 Part A p.45" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 2/03 Practice Test 2 Section 1 Part A p.45.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 04 Practice Test 2 Section 1 Part B p.46" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 2/04 Practice Test 2 Section 1 Part B p.46.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 05 Practice Test 2 Section 1 Part C p.47" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 2/05 Practice Test 2 Section 1 Part C p.47.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 06 Practice Test 2 Section 1 Part C p.48" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 2/06 Practice Test 2 Section 1 Part C p.48.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 01 Practice Test 3 Section 1 Part A p.67" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 3/01 Practice Test 3 Section 1 Part A p.67.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 02 Practice Test 3 Section 1 Part A p.68" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 3/02 Practice Test 3 Section 1 Part A p.68.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 03 Practice Test 3 Section 1 Part A p.69" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 3/03 Practice Test 3 Section 1 Part A p.69.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 04 Practice Test 3 Section 1 Part B p.70" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 3/04 Practice Test 3 Section 1 Part B p.70.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 05 Practice Test 3 Section 1 Part C p.71" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 3/05 Practice Test 3 Section 1 Part C p.71.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 06 Practice Test 3 Section 1 Part C p.72" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 3/06 Practice Test 3 Section 1 Part C p.72.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 01 Practice Test 4 Section 1 Part A p.91" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 4/01 Practice Test 4 Section 1 Part A p.91.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 02 Practice Test 4 Section 1 Part A p.92" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 4/02 Practice Test 4 Section 1 Part A p.92.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 03 Practice Test 4 Section 1 Part A p.93" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 4/03 Practice Test 4 Section 1 Part A p.93.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 04 Practice Test 4 Section 1 Part B p.94" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 4/04 Practice Test 4 Section 1 Part B p.94.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 05 Practice Test 4 Section 1 Part C p.95" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 4/05 Practice Test 4 Section 1 Part C p.95.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 06 Practice Test 4 Section 1 Part C p.96" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 4/06 Practice Test 4 Section 1 Part C p.96.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 01 Practice Test 5 Section 1 Part A p.115" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 5/01 Practice Test 5 Section 1 Part A p.115.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 02 Practice Test 5 Section 1 Part A p.116" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 5/02 Practice Test 5 Section 1 Part A p.116.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 03 Practice Test 5 Section 1 Part A p.117" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 5/03 Practice Test 5 Section 1 Part A p.117.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 04 Practice Test 5 Section 1 Part B p.118" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 5/04 Practice Test 5 Section 1 Part B p.118.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 05 Practice Test 5 Section 1 Part C p.119" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 5/05 Practice Test 5 Section 1 Part C p.119.mp3" data-free="false"></li>
<li data-title="Toefl vol B - 06 Practice Test 5 Section 1 Part C p.120" data-artist="Toefl vol B" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Toefl vol A e B/Toefl vol B/Practice Test 5/06 Practice Test 5 Section 1 Part C p.120.mp3" data-free="false"></li>


	



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
