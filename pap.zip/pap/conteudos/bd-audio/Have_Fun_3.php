
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Have Fun 3</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
      
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="lesson 00 - 01 Introduction P008" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 00/01 Introduction P008.mp3" data-free="false"></li>
<li data-title="lesson 01 - 01 L01.P011 Let's investigate" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 01/01 L01.P011 Let's investigate.mp3" data-free="false"></li>
<li data-title="lesson 01 - 02 L01.P013 Ears only" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 01/02 L01.P013 Ears only.mp3" data-free="false"></li>
<li data-title="lesson 01 - 03 L01.P013 Red alert 1A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 01/03 L01.P013 Red alert 1A.mp3" data-free="false"></li>
<li data-title="lesson 01 - 04 L01.P014 Red alert 2B" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 01/04 L01.P014 Red alert 2B.mp3" data-free="false"></li>
<li data-title="lesson 01 - 05 L01.P015 Red alert 3C" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 01/05 L01.P015 Red alert 3C.mp3" data-free="false"></li>
<li data-title="lesson 01 - 06 L01.P015 The bugging operation" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 01/06 L01.P015 The bugging operation.mp3" data-free="false"></li>
<li data-title="lesson 01 - 07 L01.P015 Pass it on A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 01/07 L01.P015 Pass it on A.mp3" data-free="false"></li>
<li data-title="lesson 01 - 08 L01.P018 The scene" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 01/08 L01.P018 The scene.mp3" data-free="false"></li>
<li data-title="lesson 02 - 01 L02.P021 Let's investigate" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 02/01 L02.P021 Let's investigate.mp3" data-free="false"></li>
<li data-title="lesson 02 - 02 L02.P023 Ears only" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 02/02 L02.P023 Ears only.mp3" data-free="false"></li>
<li data-title="lesson 02 - 03 L02.P023-24 Red alert 1 A1, A2" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 02/03 L02.P023-24 Red alert 1 A1, A2.mp3" data-free="false"></li>
<li data-title="lesson 02 - 04 L02.P024 Red alert 2B" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 02/04 L02.P024 Red alert 2B.mp3" data-free="false"></li>
<li data-title="lesson 02 - 05 L02.P025 Red alert 3C" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 02/05 L02.P025 Red alert 3C.mp3" data-free="false"></li>
<li data-title="lesson 02 - 06 L02.P026 The bugging operation" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 02/06 L02.P026 The bugging operation.mp3" data-free="false"></li>
<li data-title="lesson 02 - 07 L02.P026 Pass it on A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 02/07 L02.P026 Pass it on A.mp3" data-free="false"></li>
<li data-title="lesson 02 - 08 L02.P028 The scene" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 02/08 L02.P028 The scene.mp3" data-free="false"></li>
<li data-title="lesson 03 - 01 L03.P031 Let's investigate" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 03/01 L03.P031 Let's investigate.mp3" data-free="false"></li>
<li data-title="lesson 03 - 02 L03.P033 Ears only" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 03/02 L03.P033 Ears only.mp3" data-free="false"></li>
<li data-title="lesson 03 - 03 L03.P033 Red alert 1A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 03/03 L03.P033 Red alert 1A.mp3" data-free="false"></li>
<li data-title="lesson 03 - 04 L03.P034 Red alert 2 B1, B2" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 03/04 L03.P034 Red alert 2 B1, B2.mp3" data-free="false"></li>
<li data-title="lesson 03 - 05 L03.P034 Red alert 3C" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 03/05 L03.P034 Red alert 3C.mp3" data-free="false"></li>
<li data-title="lesson 03 - 06 L03.P035 The bugging operation" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 03/06 L03.P035 The bugging operation.mp3" data-free="false"></li>
<li data-title="lesson 03 - 07 L03.P036 Pass it on A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 03/07 L03.P036 Pass it on A.mp3" data-free="false"></li>
<li data-title="lesson 03 - 08 L03.P038 The scene" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 03/08 L03.P038 The scene.mp3" data-free="false"></li>
<li data-title="lesson 04 - 01 L04.P041 Let's investigate" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 04/01 L04.P041 Let's investigate.mp3" data-free="false"></li>
<li data-title="lesson 04 - 02 L04.P043 Ears only" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 04/02 L04.P043 Ears only.mp3" data-free="false"></li>
<li data-title="lesson 04 - 03 L04.P043 Red alert 1A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 04/03 L04.P043 Red alert 1A.mp3" data-free="false"></li>
<li data-title="lesson 04 - 04 L04.P044 Red alert 2B" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 04/04 L04.P044 Red alert 2B.mp3" data-free="false"></li>
<li data-title="lesson 04 - 05 L04.P045 Red alert 3C" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 04/05 L04.P045 Red alert 3C.mp3" data-free="false"></li>
<li data-title="lesson 04 - 06 L04.P045 The bugging operation" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 04/06 L04.P045 The bugging operation.mp3" data-free="false"></li>
<li data-title="lesson 04 - 07 L04.P046 Pass it on A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 04/07 L04.P046 Pass it on A.mp3" data-free="false"></li>
<li data-title="lesson 04 - 08 L04.P048 The scene" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 04/08 L04.P048 The scene.mp3" data-free="false"></li>
<li data-title="lesson 05 - 01 L05.P053 Let's investigate" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 05/01 L05.P053 Let's investigate.mp3" data-free="false"></li>
<li data-title="lesson 05 - 02 L05.P054 Ears only" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 05/02 L05.P054 Ears only.mp3" data-free="false"></li>
<li data-title="lesson 05 - 03 L05.P055 Red alert 1A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 05/03 L05.P055 Red alert 1A.mp3" data-free="false"></li>
<li data-title="lesson 05 - 04 L05.P057 Red alert 2B" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 05/04 L05.P057 Red alert 2B.mp3" data-free="false"></li>
<li data-title="lesson 05 - 05 L05.P057 Red alert 3C" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 05/05 L05.P057 Red alert 3C.mp3" data-free="false"></li>
<li data-title="lesson 05 - 06 L05.P058 The bugging operation" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 05/06 L05.P058 The bugging operation.mp3" data-free="false"></li>
<li data-title="lesson 05 - 07 L05.P058 Pass it on A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 05/07 L05.P058 Pass it on A.mp3" data-free="false"></li>
<li data-title="lesson 05 - 08 L05.P060 The scene" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 05/08 L05.P060 The scene.mp3" data-free="false"></li>
<li data-title="lesson 06 - 01 L06.P063 Let's investigate" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 06/01 L06.P063 Let's investigate.mp3" data-free="false"></li>
<li data-title="lesson 06 - 02 L06.P065 Ears only" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 06/02 L06.P065 Ears only.mp3" data-free="false"></li>
<li data-title="lesson 06 - 03 L06.P065 Red alert 1A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 06/03 L06.P065 Red alert 1A.mp3" data-free="false"></li>
<li data-title="lesson 06 - 04 L06.P066 Red alert 2B" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 06/04 L06.P066 Red alert 2B.mp3" data-free="false"></li>
<li data-title="lesson 06 - 05 L06.P067 Red alert 3C" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 06/05 L06.P067 Red alert 3C.mp3" data-free="false"></li>
<li data-title="lesson 06 - 06 L06.P067 The bugging operation" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 06/06 L06.P067 The bugging operation.mp3" data-free="false"></li>
<li data-title="lesson 06 - 07 L06.P068 Pass it on A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 06/07 L06.P068 Pass it on A.mp3" data-free="false"></li>
<li data-title="lesson 06 - 08 L06.P070 The scene" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 06/08 L06.P070 The scene.mp3" data-free="false"></li>
<li data-title="lesson 07 - 01 L07.P073 Let's investigate" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 07/01 L07.P073 Let's investigate.mp3" data-free="false"></li>
<li data-title="lesson 07 - 02 L07.P075 Ears only" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 07/02 L07.P075 Ears only.mp3" data-free="false"></li>
<li data-title="lesson 07 - 03 L07.P075 Red alert 1A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 07/03 L07.P075 Red alert 1A.mp3" data-free="false"></li>
<li data-title="lesson 07 - 04 L07.P076 Red alert 2B" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 07/04 L07.P076 Red alert 2B.mp3" data-free="false"></li>
<li data-title="lesson 07 - 05 L07.P076 Red alert 3C" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 07/05 L07.P076 Red alert 3C.mp3" data-free="false"></li>
<li data-title="lesson 07 - 06 L07.P077 The bugging operation" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 07/06 L07.P077 The bugging operation.mp3" data-free="false"></li>
<li data-title="lesson 07 - 07 L07.P078 Pass it on A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 07/07 L07.P078 Pass it on A.mp3" data-free="false"></li>
<li data-title="lesson 07 - 08 L07.P80 The scene" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 07/08 L07.P80 The scene.mp3" data-free="false"></li>
<li data-title="lesson 08 - 01 L08.P083 Let's investigate" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 08/01 L08.P083 Let's investigate.mp3" data-free="false"></li>
<li data-title="lesson 08 - 02 L08.P085 Ears only" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 08/02 L08.P085 Ears only.mp3" data-free="false"></li>
<li data-title="lesson 08 - 03 L08.P085 Red alert 1A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 08/03 L08.P085 Red alert 1A.mp3" data-free="false"></li>
<li data-title="lesson 08 - 04 L08.P086 Red alert 2B" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 08/04 L08.P086 Red alert 2B.mp3" data-free="false"></li>
<li data-title="lesson 08 - 05 L08.P087 Red alert 3C" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 08/05 L08.P087 Red alert 3C.mp3" data-free="false"></li>
<li data-title="lesson 08 - 06 L08.P087 The bugging operation" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 08/06 L08.P087 The bugging operation.mp3" data-free="false"></li>
<li data-title="lesson 08 - 07 L08.P087 Pass it on A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 08/07 L08.P087 Pass it on A.mp3" data-free="false"></li>
<li data-title="lesson 08 - 08 L08.P090 The scene" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 08/08 L08.P090 The scene.mp3" data-free="false"></li>
<li data-title="lesson 09 - 01 L09.P095 Let's investigate" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 09/01 L09.P095 Let's investigate.mp3" data-free="false"></li>
<li data-title="lesson 09 - 02 L09.P097 Ears only" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 09/02 L09.P097 Ears only.mp3" data-free="false"></li>
<li data-title="lesson 09 - 03 L09.P097 Red alert 1A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 09/03 L09.P097 Red alert 1A.mp3" data-free="false"></li>
<li data-title="lesson 09 - 04 L09.P098 Red alert 2B" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 09/04 L09.P098 Red alert 2B.mp3" data-free="false"></li>
<li data-title="lesson 09 - 05 L09.P099 Red alert 3C" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 09/05 L09.P099 Red alert 3C.mp3" data-free="false"></li>
<li data-title="lesson 09 - 06 L09.P099 The bugging operation" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 09/06 L09.P099 The bugging operation.mp3" data-free="false"></li>
<li data-title="lesson 09 - 07 L09.P100 Pass it on A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 09/07 L09.P100 Pass it on A.mp3" data-free="false"></li>
<li data-title="lesson 09 - 08 L09.P102 The scene" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 09/08 L09.P102 The scene.mp3" data-free="false"></li>
<li data-title="lesson 10 - 01 L10.P105 Let's investigate" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 10/01 L10.P105 Let's investigate.mp3" data-free="false"></li>
<li data-title="lesson 10 - 02 L10.P107 Ears only" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 10/02 L10.P107 Ears only.mp3" data-free="false"></li>
<li data-title="lesson 10 - 03 L10.P107 Red alert 1A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 10/03 L10.P107 Red alert 1A.mp3" data-free="false"></li>
<li data-title="lesson 10 - 04 L10.P108 Red alert 2B" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 10/04 L10.P108 Red alert 2B.mp3" data-free="false"></li>
<li data-title="lesson 10 - 05 L10.P109 Red alert 3C" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 10/05 L10.P109 Red alert 3C.mp3" data-free="false"></li>
<li data-title="lesson 10 - 06 L10.P110 The bugging operation" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 10/06 L10.P110 The bugging operation.mp3" data-free="false"></li>
<li data-title="lesson 10 - 07 L10.P110 Pass it on A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 10/07 L10.P110 Pass it on A.mp3" data-free="false"></li>
<li data-title="lesson 10 - 08 L10.P112 The scene" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 10/08 L10.P112 The scene.mp3" data-free="false"></li>
<li data-title="lesson 11 - 01 L11.P115 Let's investigate" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 11/01 L11.P115 Let's investigate.mp3" data-free="false"></li>
<li data-title="lesson 11 - 02 L11.P117 Ears only" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 11/02 L11.P117 Ears only.mp3" data-free="false"></li>
<li data-title="lesson 11 - 03 L11.P117 Red alert 1A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 11/03 L11.P117 Red alert 1A.mp3" data-free="false"></li>
<li data-title="lesson 11 - 04 L11.P118 Red alert 2B" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 11/04 L11.P118 Red alert 2B.mp3" data-free="false"></li>
<li data-title="lesson 11 - 05 L11.P119 Red alert 3C" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 11/05 L11.P119 Red alert 3C.mp3" data-free="false"></li>
<li data-title="lesson 11 - 06 L11.P119 The bugging operation" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 11/06 L11.P119 The bugging operation.mp3" data-free="false"></li>
<li data-title="lesson 11 - 07 L11.P119 Pass it on A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 11/07 L11.P119 Pass it on A.mp3" data-free="false"></li>
<li data-title="lesson 11 - 08 L11.P122 The scene" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 11/08 L11.P122 The scene.mp3" data-free="false"></li>
<li data-title="lesson 12 - 01 L12.P125 Let's investigate" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 12/01 L12.P125 Let's investigate.mp3" data-free="false"></li>
<li data-title="lesson 12 - 02 L12.P127 Ears only" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 12/02 L12.P127 Ears only.mp3" data-free="false"></li>
<li data-title="lesson 12 - 03 L12.P127 Red alert 1A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 12/03 L12.P127 Red alert 1A.mp3" data-free="false"></li>
<li data-title="lesson 12 - 04 L12.P128 Red alert 2B" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 12/04 L12.P128 Red alert 2B.mp3" data-free="false"></li>
<li data-title="lesson 12 - 05 L12.P129 Red alert 3C" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 12/05 L12.P129 Red alert 3C.mp3" data-free="false"></li>
<li data-title="lesson 12 - 06 L12.P130 The bugging operation" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 12/06 L12.P130 The bugging operation.mp3" data-free="false"></li>
<li data-title="lesson 12 - 07 L12.P130 Pass it on A" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 12/07 L12.P130 Pass it on A.mp3" data-free="false"></li>
<li data-title="lesson 12 - 08 L12.P132 The scene" data-artist="Have Fun 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Have Fun 3/lesson 12/08 L12.P132 The scene.mp3" data-free="false"></li>


	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
