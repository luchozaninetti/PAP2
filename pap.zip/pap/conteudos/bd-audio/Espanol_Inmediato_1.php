
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Espa�ol Inmediato 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">

            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="ACTIVIDADES DE CONSOLIDACION 1 - 01 AC1 P89 COMPRENSION AUDITIVA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/ACTIVIDADES DE CONSOLIDACION 1/01 AC1 P89 COMPRENSION AUDITIVA A.mp3" data-free="false"></li>
<li data-title="ACTIVIDADES DE CONSOLIDACION 1 - 02 AC1 P89 COMPRENSION AUDITIVA B" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/ACTIVIDADES DE CONSOLIDACION 1/02 AC1 P89 COMPRENSION AUDITIVA B.mp3" data-free="false"></li>
<li data-title="ACTIVIDADES DE CONSOLIDACION 2 - 01 AC2 P93 COMPRENSION AUDITIVA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/ACTIVIDADES DE CONSOLIDACION 2/01 AC2 P93 COMPRENSION AUDITIVA A.mp3" data-free="false"></li>
<li data-title="ACTIVIDADES DE CONSOLIDACION 2 - 02 AC2 P93 COMPRENSION AUDITIVA B" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/ACTIVIDADES DE CONSOLIDACION 2/02 AC2 P93 COMPRENSION AUDITIVA B.mp3" data-free="false"></li>
<li data-title="LECCION 01 - 01 L1 P08 COMUNICACION INMEDIATA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 01/01 L1 P08 COMUNICACION INMEDIATA A.mp3" data-free="false"></li>
<li data-title="LECCION 01 - 02 L1 MC P04 COMUNICACION INMEDIATA E" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 01/02 L1 MC P04 COMUNICACION INMEDIATA E.mp3" data-free="false"></li>
<li data-title="LECCION 01 - 03 L1 P10 PASO A PASO A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 01/03 L1 P10 PASO A PASO A.mp3" data-free="false"></li>
<li data-title="LECCION 01 - 04 L1 MC P05 PASO A PASO B" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 01/04 L1 MC P05 PASO A PASO B.mp3" data-free="false"></li>
<li data-title="LECCION 01 - 05 L1 P10 PASO A PASO C" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 01/05 L1 P10 PASO A PASO C.mp3" data-free="false"></li>
<li data-title="LECCION 01 - 06 L1 MC P06 PASO A PASO F" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 01/06 L1 MC P06 PASO A PASO F.mp3" data-free="false"></li>
<li data-title="LECCION 01 - 07 L1 P12 AMPLIACION B" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 01/07 L1 P12 AMPLIACION B.mp3" data-free="false"></li>
<li data-title="LECCION 01 - 08 L1 MC P07 ACCION" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 01/08 L1 MC P07 ACCION.mp3" data-free="false"></li>
<li data-title="LECCION 01 - 09 L1 P136 TALLER DE ORTOGRAFIA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 01/09 L1 P136 TALLER DE ORTOGRAFIA A.mp3" data-free="false"></li>
<li data-title="LECCION 02 - 01 L2 P16 COMUNICACION INMEDIATA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 02/01 L2 P16 COMUNICACION INMEDIATA A.mp3" data-free="false"></li>
<li data-title="LECCION 02 - 02 L2 MC P09 COMUNICACION INMEDIATA D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 02/02 L2 MC P09 COMUNICACION INMEDIATA D.mp3" data-free="false"></li>
<li data-title="LECCION 02 - 03 L2 P18 PASO A PASO A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 02/03 L2 P18 PASO A PASO A.mp3" data-free="false"></li>
<li data-title="LECCION 02 - 04 L2 MC P10 PASO A PASO B" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 02/04 L2 MC P10 PASO A PASO B.mp3" data-free="false"></li>
<li data-title="LECCION 02 - 05 L2 MC P10 PASO A PASO C" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 02/05 L2 MC P10 PASO A PASO C.mp3" data-free="false"></li>
<li data-title="LECCION 02 - 06 L2 P19 PASO A PASO F" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 02/06 L2 P19 PASO A PASO F.mp3" data-free="false"></li>
<li data-title="LECCION 02 - 07 L2 P20 AMPLIACION B" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 02/07 L2 P20 AMPLIACION B.mp3" data-free="false"></li>
<li data-title="LECCION 02 - 08 L2 MC P13 ACCION" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 02/08 L2 MC P13 ACCION.mp3" data-free="false"></li>
<li data-title="LECCION 02 - 09 L2 P137 TALLER DE ORTOGRAFIA B" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 02/09 L2 P137 TALLER DE ORTOGRAFIA B.mp3" data-free="false"></li>
<li data-title="LECCION 03 - 01 L3 P24 COMUNICACION INMEDIATA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 03/01 L3 P24 COMUNICACION INMEDIATA A.mp3" data-free="false"></li>
<li data-title="LECCION 03 - 02 L3 P25 COMUNICACION INMEDIATA D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 03/02 L3 P25 COMUNICACION INMEDIATA D.mp3" data-free="false"></li>
<li data-title="LECCION 03 - 03 L3 MC P15 COMUNICACION INMEDIATA E" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 03/03 L3 MC P15 COMUNICACION INMEDIATA E.mp3" data-free="false"></li>
<li data-title="LECCION 03 - 04 L3 MC P16 PASO A PASO C" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 03/04 L3 MC P16 PASO A PASO C.mp3" data-free="false"></li>
<li data-title="LECCION 03 - 05 L3 P27 PASO A PASO D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 03/05 L3 P27 PASO A PASO D.mp3" data-free="false"></li>
<li data-title="LECCION 03 - 06 L3 MC P17 PASO A PASO F" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 03/06 L3 MC P17 PASO A PASO F.mp3" data-free="false"></li>
<li data-title="LECCION 03 - 07 L3 MC P18 AMPLIACION D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 03/07 L3 MC P18 AMPLIACION D.mp3" data-free="false"></li>
<li data-title="LECCION 03 - 08 L3 MC P19 ACCION" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 03/08 L3 MC P19 ACCION.mp3" data-free="false"></li>
<li data-title="LECCION 03 - 09 L3 P138 TALLER DE ORTOGRAFIA C" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 03/09 L3 P138 TALLER DE ORTOGRAFIA C.mp3" data-free="false"></li>
<li data-title="LECCION 04 - 01 L4 P32 COMUNICACION INMEDIATA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 04/01 L4 P32 COMUNICACION INMEDIATA A.mp3" data-free="false"></li>
<li data-title="LECCION 04 - 02 L4 MC P21 COMUNICACION INMEDIATA D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 04/02 L4 MC P21 COMUNICACION INMEDIATA D.mp3" data-free="false"></li>
<li data-title="LECCION 04 - 03 L4 MC P22 PASO A PASO C" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 04/03 L4 MC P22 PASO A PASO C.mp3" data-free="false"></li>
<li data-title="LECCION 04 - 04 L4 P36 AMPLIACION A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 04/04 L4 P36 AMPLIACION A.mp3" data-free="false"></li>
<li data-title="LECCION 04 - 05 L4 MC P23 AMPLIACION C" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 04/05 L4 MC P23 AMPLIACION C.mp3" data-free="false"></li>
<li data-title="LECCION 04 - 06 L4 P139 TALLER DE ORTOGRAFIA D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 04/06 L4 P139 TALLER DE ORTOGRAFIA D.mp3" data-free="false"></li>
<li data-title="LECCION 05 - 01 L5 P40 COMUNICACION INMEDIATA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 05/01 L5 P40 COMUNICACION INMEDIATA A.mp3" data-free="false"></li>
<li data-title="LECCION 05 - 02 L5 MC P26 COMUNICACION INMEDIATA E" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 05/02 L5 MC P26 COMUNICACION INMEDIATA E.mp3" data-free="false"></li>
<li data-title="LECCION 05 - 03 L5 P43 PASO A PASO C" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 05/03 L5 P43 PASO A PASO C.mp3" data-free="false"></li>
<li data-title="LECCION 05 - 04 L5 MC P27 PASO A PASO D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 05/04 L5 MC P27 PASO A PASO D.mp3" data-free="false"></li>
<li data-title="LECCION 05 - 05 L5 MC P28 AMPLIACION D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 05/05 L5 MC P28 AMPLIACION D.mp3" data-free="false"></li>
<li data-title="LECCION 05 - 06 L5 MC P29 ACCION" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 05/06 L5 MC P29 ACCION.mp3" data-free="false"></li>
<li data-title="LECCION 05 - 07 L5 P140 TALLER DE ORTOGRAFIA E" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 05/07 L5 P140 TALLER DE ORTOGRAFIA E.mp3" data-free="false"></li>
<li data-title="LECCION 06 - 01 L6 P48 COMUNICACION INMEDIATA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 06/01 L6 P48 COMUNICACION INMEDIATA A.mp3" data-free="false"></li>
<li data-title="LECCION 06 - 02 L6 MC P32 COMUNICACION INMEDIATA D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 06/02 L6 MC P32 COMUNICACION INMEDIATA D.mp3" data-free="false"></li>
<li data-title="LECCION 06 - 03 L6 P51 PASO A PASO D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 06/03 L6 P51 PASO A PASO D.mp3" data-free="false"></li>
<li data-title="LECCION 06 - 04 L6 MC P33 PASO A PASO F" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 06/04 L6 MC P33 PASO A PASO F.mp3" data-free="false"></li>
<li data-title="LECCION 06 - 05 L6 P52 AMPLIACION A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 06/05 L6 P52 AMPLIACION A.mp3" data-free="false"></li>
<li data-title="LECCION 06 - 06 L6 MC P33 AMPLIACION C PARTE A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 06/06 L6 MC P33 AMPLIACION C PARTE A.mp3" data-free="false"></li>
<li data-title="LECCION 06 - 07 L6 MC P33 AMPLIACION C PARTE B" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 06/07 L6 MC P33 AMPLIACION C PARTE B.mp3" data-free="false"></li>
<li data-title="LECCION 06 - 08 L6 MC P34 ACCION" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 06/08 L6 MC P34 ACCION.mp3" data-free="false"></li>
<li data-title="LECCION 06 - 09 L6 P141 TALLER DE ORTOGRAFIA F" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 06/09 L6 P141 TALLER DE ORTOGRAFIA F.mp3" data-free="false"></li>
<li data-title="LECCION 07 - 01 L7 P56 COMUNICACION INMEDIATA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 07/01 L7 P56 COMUNICACION INMEDIATA A.mp3" data-free="false"></li>
<li data-title="LECCION 07 - 02 L7 P58 PASO A PASO A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 07/02 L7 P58 PASO A PASO A.mp3" data-free="false"></li>
<li data-title="LECCION 07 - 03 L7 MC P37 PASO A PASO B" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 07/03 L7 MC P37 PASO A PASO B.mp3" data-free="false"></li>
<li data-title="LECCION 07 - 04 L7 MC P37 PASO A PASO E" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 07/04 L7 MC P37 PASO A PASO E.mp3" data-free="false"></li>
<li data-title="LECCION 07 - 05 L7 P60 AMPLIACION A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 07/05 L7 P60 AMPLIACION A.mp3" data-free="false"></li>
<li data-title="LECCION 07 - 06 L7 P61 AMPLIACION F" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 07/06 L7 P61 AMPLIACION F.mp3" data-free="false"></li>
<li data-title="LECCION 07 - 07 L7 MC P38_39 ACCION" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 07/07 L7 MC P38_39 ACCION.mp3" data-free="false"></li>
<li data-title="LECCION 07 - 08 L7 P142 TALLER DE ORTOGRAFIA G" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 07/08 L7 P142 TALLER DE ORTOGRAFIA G.mp3" data-free="false"></li>
<li data-title="LECCION 08 - 01 L8 P64 COMUNICACION INMEDIATA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 08/01 L8 P64 COMUNICACION INMEDIATA A.mp3" data-free="false"></li>
<li data-title="LECCION 08 - 02 L8 MC P41 COMUNICACION INMEDIATA E" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 08/02 L8 MC P41 COMUNICACION INMEDIATA E.mp3" data-free="false"></li>
<li data-title="LECCION 08 - 03 L8 MC P42 PASO A PASO D PARTE A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 08/03 L8 MC P42 PASO A PASO D PARTE A.mp3" data-free="false"></li>
<li data-title="LECCION 08 - 04 L8 MC P42 PASO A PASO D PARTE B" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 08/04 L8 MC P42 PASO A PASO D PARTE B.mp3" data-free="false"></li>
<li data-title="LECCION 08 - 05 L8 P67 PASO A PASO E" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 08/05 L8 P67 PASO A PASO E.mp3" data-free="false"></li>
<li data-title="LECCION 08 - 06 L8 P68 AMPLIACION A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 08/06 L8 P68 AMPLIACION A.mp3" data-free="false"></li>
<li data-title="LECCION 08 - 07 L8 P69 AMPLIACION C" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 08/07 L8 P69 AMPLIACION C.mp3" data-free="false"></li>
<li data-title="LECCION 08 - 08 L8 P143 TALLER DE ORTOGRAFIA H" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 08/08 L8 P143 TALLER DE ORTOGRAFIA H.mp3" data-free="false"></li>
<li data-title="LECCION 09 - 01 L9 P72 COMUNICACION INMEDIATA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 09/01 L9 P72 COMUNICACION INMEDIATA A.mp3" data-free="false"></li>
<li data-title="LECCION 09 - 02 L9 MC P46 COMUNICACION INMEDIATA E" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 09/02 L9 MC P46 COMUNICACION INMEDIATA E.mp3" data-free="false"></li>
<li data-title="LECCION 09 - 03 L9 P74 PASO A PASO A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 09/03 L9 P74 PASO A PASO A.mp3" data-free="false"></li>
<li data-title="LECCION 09 - 04 L9 MC P47 PASO A PASO D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 09/04 L9 MC P47 PASO A PASO D.mp3" data-free="false"></li>
<li data-title="LECCION 09 - 05 L9 MC P47 AMPLIACION A PARTE A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 09/05 L9 MC P47 AMPLIACION A PARTE A.mp3" data-free="false"></li>
<li data-title="LECCION 09 - 06 L9 MC P47 AMPLIACION A PARTE B" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 09/06 L9 MC P47 AMPLIACION A PARTE B.mp3" data-free="false"></li>
<li data-title="LECCION 09 - 07 L9 MC P48 AMPLIACION C" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 09/07 L9 MC P48 AMPLIACION C.mp3" data-free="false"></li>
<li data-title="LECCION 09 - 08 L9 P77 AMPLIACION D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 09/08 L9 P77 AMPLIACION D.mp3" data-free="false"></li>
<li data-title="LECCION 09 - 09 L9 P77 AMPLIACION E" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 09/09 L9 P77 AMPLIACION E.mp3" data-free="false"></li>
<li data-title="LECCION 09 - 10 L9 MC P49 AMPLIACION F" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 09/10 L9 MC P49 AMPLIACION F.mp3" data-free="false"></li>
<li data-title="LECCION 09 - 11 L9 MC P49 ACCION" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 09/11 L9 MC P49 ACCION.mp3" data-free="false"></li>
<li data-title="LECCION 09 - 12 L9 P144 TALLER DE ORTOGRAFIA I" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 09/12 L9 P144 TALLER DE ORTOGRAFIA I.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 01 L10 P80 COMUNICACION INMEDIATA A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 10/01 L10 P80 COMUNICACION INMEDIATA A.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 02 L10 P82 PASO A PASO A" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 10/02 L10 P82 PASO A PASO A.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 03 L10 MC P52 PASO A PASO D" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 10/03 L10 MC P52 PASO A PASO D.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 04 L10 P83 PASO A PASO E" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 10/04 L10 P83 PASO A PASO E.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 05 L10 P85 AMPLIACION C" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 10/05 L10 P85 AMPLIACION C.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 06 L10 MC P54 ACCION" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 10/06 L10 MC P54 ACCION.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 07 L10 P144 TALLER DE ORTOGRAFIA J" data-artist="Espanol Inmediato 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 1/LECCION 10/07 L10 P144 TALLER DE ORTOGRAFIA J.mp3" data-free="false"></li>



	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
