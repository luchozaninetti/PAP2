
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Espa�ol con � 5</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
    
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->

<li data-title="Ejercicios del Anexo Gramatical - 001. EJ. AG - Texto 1, p. 238 - Ej. 62" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Ejercicios del Anexo Gramatical/001. EJ. AG - Texto 1, p. 238 - Ej. 62.mp3" data-free="false"></li>
<li data-title="Ejercicios del Anexo Gramatical - 002. EJ. AG - Texto 2, p. 238 - Ej. 62" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Ejercicios del Anexo Gramatical/002. EJ. AG - Texto 2, p. 238 - Ej. 62.mp3" data-free="false"></li>
<li data-title="Ejercicios del Anexo Gramatical - 003. EJ. AG - Texto 1, p. 239 - Ej. 64" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Ejercicios del Anexo Gramatical/003. EJ. AG - Texto 1, p. 239 - Ej. 64.mp3" data-free="false"></li>
<li data-title="Ejercicios del Anexo Gramatical - 004. EJ. AG - Texto 2, p. 240 - Ej. 64" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Ejercicios del Anexo Gramatical/004. EJ. AG - Texto 2, p. 240 - Ej. 64.mp3" data-free="false"></li>
<li data-title="Tema 1 - 001. MC - T1, p. 006" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 1/001. MC - T1, p. 006.mp3" data-free="false"></li>
<li data-title="Tema 1 - 002. T1, p. 007 - Texto" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 1/002. T1, p. 007 - Texto.mp3" data-free="false"></li>
<li data-title="Tema 1 - 003. T1, p. 009 - Ej. 6" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 1/003. T1, p. 009 - Ej. 6.mp3" data-free="false"></li>
<li data-title="Tema 1 - 004. MC - T1, p. 010 - Ej. 11" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 1/004. MC - T1, p. 010 - Ej. 11.mp3" data-free="false"></li>
<li data-title="Tema 1 - 005. MC - T1, p. 011 - Pena" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 1/005. MC - T1, p. 011 - Pena.mp3" data-free="false"></li>
<li data-title="Tema 1 - 006. T1, p. 011 - Ej. 13" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 1/006. T1, p. 011 - Ej. 13.mp3" data-free="false"></li>
<li data-title="Tema 1 - 007. MC - T1, p. 013 - Ej. 18" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 1/007. MC - T1, p. 013 - Ej. 18.mp3" data-free="false"></li>
<li data-title="Tema 1 - 008. T1 - EJ. COMPL. - p. 151 - Ej. 1" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 1/008. T1 - EJ. COMPL. - p. 151 - Ej. 1.mp3" data-free="false"></li>
<li data-title="Tema 1 - 009. T1 - EJ. COMPL. - p. 151 - Ej. 2" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 1/009. T1 - EJ. COMPL. - p. 151 - Ej. 2.mp3" data-free="false"></li>
<li data-title="Tema 1 - 010. T1 - EJ. COMPL. - p. 152 - Ej. 3" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 1/010. T1 - EJ. COMPL. - p. 152 - Ej. 3.mp3" data-free="false"></li>
<li data-title="Tema 1 - 011. T1 - EJ. COMPL. - p. 152 - Ej. 4" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 1/011. T1 - EJ. COMPL. - p. 152 - Ej. 4.mp3" data-free="false"></li>
<li data-title="Tema 2 - 001. MC - T2, p. 032" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 2/001. MC - T2, p. 032.mp3" data-free="false"></li>
<li data-title="Tema 2 - 002. T2, p. 033 - Entrevista" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 2/002. T2, p. 033 - Entrevista.mp3" data-free="false"></li>
<li data-title="Tema 2 - 003. MC - T2, p. 038 - Pena" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 2/003. MC - T2, p. 038 - Pena.mp3" data-free="false"></li>
<li data-title="Tema 2 - 004. T2, p. 038 - Ej. 12" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 2/004. T2, p. 038 - Ej. 12.mp3" data-free="false"></li>
<li data-title="Tema 2 - 005. T2, p. 040 - Ej. 22" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 2/005. T2, p. 040 - Ej. 22.mp3" data-free="false"></li>
<li data-title="Tema 2 - 006. MC - T2, p. 040 - Ej. 22" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 2/006. MC - T2, p. 040 - Ej. 22.mp3" data-free="false"></li>
<li data-title="Tema 2 - 007. T2 - EJ. COMPL. - p. 154 - Ej. 1" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 2/007. T2 - EJ. COMPL. - p. 154 - Ej. 1.mp3" data-free="false"></li>
<li data-title="Tema 2 - 008. T2 - EJ. COMPL. - p. 155 - Ej. 3" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 2/008. T2 - EJ. COMPL. - p. 155 - Ej. 3.mp3" data-free="false"></li>
<li data-title="Tema 3 - 001. MC - T3, p. 60 y 61" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 3/001. MC - T3, p. 60 y 61.mp3" data-free="false"></li>
<li data-title="Tema 3 - 002. T3, p. 062 - Venezuela" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 3/002. T3, p. 062 - Venezuela.mp3" data-free="false"></li>
<li data-title="Tema 3 - 003. T3, p. 063 - Guyana" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 3/003. T3, p. 063 - Guyana.mp3" data-free="false"></li>
<li data-title="Tema 3 - 004. T3, p. 064 - Espana" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 3/004. T3, p. 064 - Espana.mp3" data-free="false"></li>
<li data-title="Tema 3 - 005. T3, p. 065 - Marruecos" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 3/005. T3, p. 065 - Marruecos.mp3" data-free="false"></li>
<li data-title="Tema 3 - 006. T3, p. 069 - Ej. 11" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 3/006. T3, p. 069 - Ej. 11.mp3" data-free="false"></li>
<li data-title="Tema 3 - 007. T3 - EJ. COMPL. - p. 157 - Ej. 1" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 3/007. T3 - EJ. COMPL. - p. 157 - Ej. 1.mp3" data-free="false"></li>
<li data-title="Tema 3 - 008. T3 - EJ. COMPL. - p. 157 - Ej. 2" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 3/008. T3 - EJ. COMPL. - p. 157 - Ej. 2.mp3" data-free="false"></li>
<li data-title="Tema 3 - 009. T3 - EJ. COMPL. - p. 158 - Ej. 3" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 3/009. T3 - EJ. COMPL. - p. 158 - Ej. 3.mp3" data-free="false"></li>
<li data-title="Tema 4 - 001. T4, p. 092 - Ej. 1" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 4/001. T4, p. 092 - Ej. 1.mp3" data-free="false"></li>
<li data-title="Tema 4 - 002. MC - T4, p. 093 - Ej. 6" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 4/002. MC - T4, p. 093 - Ej. 6.mp3" data-free="false"></li>
<li data-title="Tema 4 - 003. T4, p. 094 - Ej. 7" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 4/003. T4, p. 094 - Ej. 7.mp3" data-free="false"></li>
<li data-title="Tema 4 - 004. MC - T4, p. 097 - Pena (Hombre)" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 4/004. MC - T4, p. 097 - Pena (Hombre).mp3" data-free="false"></li>
<li data-title="Tema 4 - 005. MC - T4, p. 097 - Pena (Mujer)" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 4/005. MC - T4, p. 097 - Pena (Mujer).mp3" data-free="false"></li>
<li data-title="Tema 4 - 006. T4, p. 097 - Ej. 16" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 4/006. T4, p. 097 - Ej. 16.mp3" data-free="false"></li>
<li data-title="Tema 4 - 007. T4 - EJ. COMPL. - p. 161 - Ej. 2" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 4/007. T4 - EJ. COMPL. - p. 161 - Ej. 2.mp3" data-free="false"></li>
<li data-title="Tema 4 - 008. T4 - EJ. COMPL. - p. 161 - Ej. 3" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 4/008. T4 - EJ. COMPL. - p. 161 - Ej. 3.mp3" data-free="false"></li>
<li data-title="Tema 4 - 009. T4 - EJ. COMPL. - p. 162 - Ej. 4" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 4/009. T4 - EJ. COMPL. - p. 162 - Ej. 4.mp3" data-free="false"></li>
<li data-title="Tema 5 - 001. MC - T5, p. 118" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 5/001. MC - T5, p. 118.mp3" data-free="false"></li>
<li data-title="Tema 5 - 002. T5, p. 119 - Ej. 1" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 5/002. T5, p. 119 - Ej. 1.mp3" data-free="false"></li>
<li data-title="Tema 5 - 003. T5, p. 123 - Franquicia un negocio en auge" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 5/003. T5, p. 123 - Franquicia un negocio en auge.mp3" data-free="false"></li>
<li data-title="Tema 5 - 004. MC - T5, p. 126 - Pena" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 5/004. MC - T5, p. 126 - Pena.mp3" data-free="false"></li>
<li data-title="Tema 5 - 005. T5, p. 126 - Ej. 17" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 5/005. T5, p. 126 - Ej. 17.mp3" data-free="false"></li>
<li data-title="Tema 5 - 006. T5, p. 128 - Ej. 21" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 5/006. T5, p. 128 - Ej. 21.mp3" data-free="false"></li>
<li data-title="Tema 5 - 007. T5 - EJ. COMPL. - p. 163 - Ej. 1" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 5/007. T5 - EJ. COMPL. - p. 163 - Ej. 1.mp3" data-free="false"></li>
<li data-title="Tema 5 - 008. T5 - EJ. COMPL. - p. 163 - Ej. 2" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 5/008. T5 - EJ. COMPL. - p. 163 - Ej. 2.mp3" data-free="false"></li>
<li data-title="Tema 5 - 009. T5 - EJ. COMPL. - p. 164 - Ej. 3" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 5/009. T5 - EJ. COMPL. - p. 164 - Ej. 3.mp3" data-free="false"></li>
<li data-title="Tema 5 - 010. T5 - EJ. COMPL. - p. 164 - Ej. 4" data-artist="Espanhol N 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 5/Tema 5/010. T5 - EJ. COMPL. - p. 164 - Ej. 4.mp3" data-free="false"></li>



	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
