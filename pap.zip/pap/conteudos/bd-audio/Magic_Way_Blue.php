
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Magic Way - Blue</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
      
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
<li data-title="Lesson 02 - 01 Itsy Bitsy Spider" data-artist="Magic Way - Blue Book" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Magic Way - Blue Book/Lesson 02/01 Itsy Bitsy Spider.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 02 Motor-coordination activity - Listen and circle" data-artist="Magic Way - Blue Book" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Magic Way - Blue Book/Lesson 02/02 Motor-coordination activity - Listen and circle.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 01 Five Little Monkeys" data-artist="Magic Way - Blue Book" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Magic Way - Blue Book/Lesson 04/01 Five Little Monkeys.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 02 Motor-coordination Activity- Listen and circle" data-artist="Magic Way - Blue Book" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Magic Way - Blue Book/Lesson 04/02 Motor-coordination Activity- Listen and circle.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 01 Walking Walking" data-artist="Magic Way - Blue Book" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Magic Way - Blue Book/Lesson 06/01 Walking Walking.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 02 Motor-coordination activity - Listen and circle" data-artist="Magic Way - Blue Book" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Magic Way - Blue Book/Lesson 06/02 Motor-coordination activity - Listen and circle.mp3" data-free="false"></li>
<li data-title="Lesson 07 - Motor-coordination Activity Listen and trace" data-artist="Magic Way - Blue Book" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Magic Way - Blue Book/Lesson 07/Motor-coordination Activity Listen and trace.mp3" data-free="false"></li>
<li data-title="Lesson 08 - Hokey Cokey" data-artist="Magic Way - Blue Book" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Magic Way - Blue Book/Lesson 08/Hokey Cokey.mp3" data-free="false"></li>
<li data-title="Lesson 10 - She'll Be Coming Round The Mountain" data-artist="Magic Way - Blue Book" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Magic Way - Blue Book/Lesson 10/She'll Be Coming Round The Mountain.mp3" data-free="false"></li>

	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
