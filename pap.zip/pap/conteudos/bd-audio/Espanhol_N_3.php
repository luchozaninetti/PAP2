
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Espa�ol con � 3</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
      
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Leccion 01 - 001. L 01, p. 008, A descubrir" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 01/001. L 01, p. 008, A descubrir.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 002. L 01, p. 009, A aprender" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 01/002. L 01, p. 009, A aprender.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 003. MC - L 01, p. 010, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 01/003. MC - L 01, p. 010, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 004. AG - L 01, p. 093, Ej. A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 01/004. AG - L 01, p. 093, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 005. AG - L 01, p. 093, Ej. B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 01/005. AG - L 01, p. 093, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 006. AG - L 01, p. 095, Ej. E" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 01/006. AG - L 01, p. 095, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 007. MC - L 01, p. 011, A hablar - A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 01/007. MC - L 01, p. 011, A hablar - A.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 008. L 01, p. 012, A escuchar - A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 01/008. L 01, p. 012, A escuchar - A.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 009. L 01, p. 013, A aprender" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 01/009. L 01, p. 013, A aprender.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 010. MC - L 01, p. 013, A aprender" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 01/010. MC - L 01, p. 013, A aprender.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 011. MC - L 01, p. 014, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 01/011. MC - L 01, p. 014, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 012. AG - L 01, p. 096, Ej. H" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 01/012. AG - L 01, p. 096, Ej. H.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 001. L 02, p. 016, A descubrir..." data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/001. L 02, p. 016, A descubrir....mp3" data-free="false"></li>
<li data-title="Leccion 02 - 002. AG - L 02, p. 097, Ej. A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/002. AG - L 02, p. 097, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 003. AG - L 02, p. 098, Ej. B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/003. AG - L 02, p. 098, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 004. AG - L 02, p. 099, Ej. E" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/004. AG - L 02, p. 099, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 005. MC - L 02, p. 019, A practicar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/005. MC - L 02, p. 019, A practicar.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 006. L 02, p. 019, A escuchar - A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/006. L 02, p. 019, A escuchar - A.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 007. MC - L 02, p. 020, A practicar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/007. MC - L 02, p. 020, A practicar.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 008. MC - L 02, p. 020, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/008. MC - L 02, p. 020, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 009. AG - L 02, p. 100, Ej. F" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/009. AG - L 02, p. 100, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 010. MC - L 02, p. 022, A practicar - A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/010. MC - L 02, p. 022, A practicar - A.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 011. MC - L 02, p. 022, A practicar - B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/011. MC - L 02, p. 022, A practicar - B.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 012. MC - L 02, p. 023, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/012. MC - L 02, p. 023, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 013. MC - L 02, p. 024, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/013. MC - L 02, p. 024, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 014. AG - L 02, p. 102, Ej. H" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 02/014. AG - L 02, p. 102, Ej. H.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 001. L 03, p. 026, A descubrir" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 03/001. L 03, p. 026, A descubrir.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 002. AG - L 03, p. 103, Ej. A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 03/002. AG - L 03, p. 103, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 003. AG - L 03, p. 104, Ej. B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 03/003. AG - L 03, p. 104, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 004. MC - L 03, p. 028, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 03/004. MC - L 03, p. 028, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 005. AG - L 03, p. 105, Ej. E" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 03/005. AG - L 03, p. 105, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 006. MC - L 03, p. 029, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 03/006. MC - L 03, p. 029, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 007. AG - L 03, p. 106, Ej. G" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 03/007. AG - L 03, p. 106, Ej. G.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 008. MC - L 03, p. 030, A hablar - A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 03/008. MC - L 03, p. 030, A hablar - A.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 009. MC - L 03, p. 031, A hablar - B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 03/009. MC - L 03, p. 031, A hablar - B.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 010. L 03, p. 032, A escuchar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 03/010. L 03, p. 032, A escuchar.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 011. AG - L 03, p. 107, Ej. I" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 03/011. AG - L 03, p. 107, Ej. I.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 001. AG - L 04, p. 108, Ej. A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 04/001. AG - L 04, p. 108, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 002. AG - L 04, p. 108, Ej. B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 04/002. AG - L 04, p. 108, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 003. AG - L 04, p. 109, Ej. C" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 04/003. AG - L 04, p. 109, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 004. AG - L 04, p. 109, Ej. D" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 04/004. AG - L 04, p. 109, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 005. AG - L 04, p. 110, Ej. E" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 04/005. AG - L 04, p. 110, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 006. MC - L 04, p. 036, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 04/006. MC - L 04, p. 036, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 007. L 04, p. 036, A conocer" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 04/007. L 04, p. 036, A conocer.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 008. L 04, p. 037, A escuchar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 04/008. L 04, p. 037, A escuchar.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 009. L 04, p. 039, A escuchar - A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 04/009. L 04, p. 039, A escuchar - A.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 010. L 04, p. 039, A escuchar - B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 04/010. L 04, p. 039, A escuchar - B.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 011. AG - L 04, p. 112, Ej. H" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 04/011. AG - L 04, p. 112, Ej. H.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 001. L 05, p. 042, A escuchar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 05/001. L 05, p. 042, A escuchar.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 002. AG - L 05, p. 113, Ej. A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 05/002. AG - L 05, p. 113, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 003. AG - L 05, p. 113, Ej. B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 05/003. AG - L 05, p. 113, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 004. MC - L 05, p. 044, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 05/004. MC - L 05, p. 044, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 005. L 05, p. 044, A escuchar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 05/005. L 05, p. 044, A escuchar.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 006. AG - L 05, p. 114, Ej. C" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 05/006. AG - L 05, p. 114, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 007. MC - L 05, p. 045, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 05/007. MC - L 05, p. 045, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 008. AG - L 05, p. 115, Ej. F" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 05/008. AG - L 05, p. 115, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 009. MC - L 05, p. 047, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 05/009. MC - L 05, p. 047, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 010. MC - L 05, p. 048, A practicar - B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 05/010. MC - L 05, p. 048, A practicar - B.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 011. AG - L 05, p. 117, Ej. H" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 05/011. AG - L 05, p. 117, Ej. H.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 001. L 06, p. 050, A descubrir" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 06/001. L 06, p. 050, A descubrir.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 002. AG - L 06, p. 118, Ej. A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 06/002. AG - L 06, p. 118, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 003. AG - L 06, p. 118, Ej. B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 06/003. AG - L 06, p. 118, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 004. AG - L 06, p. 119, Ej. C" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 06/004. AG - L 06, p. 119, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 005. AG - L 06, p. 119, Ej. D" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 06/005. AG - L 06, p. 119, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 006. L 06, p. 053, A escuchar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 06/006. L 06, p. 053, A escuchar.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 007. MC - L 06, p. 054, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 06/007. MC - L 06, p. 054, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 008. L 06, p. 055, A escuchar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 06/008. L 06, p. 055, A escuchar.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 009. L 06, p. 055, A practicar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 06/009. L 06, p. 055, A practicar.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 010. AG - L 06, p. 120, Ej. E" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 06/010. AG - L 06, p. 120, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 011. MC - L 06, p. 056, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 06/011. MC - L 06, p. 056, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 012. AG - L 06, p. 122, Ej. G" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 06/012. AG - L 06, p. 122, Ej. G.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 001. L 07, p. 058, A descubrir - A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/001. L 07, p. 058, A descubrir - A.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 002. L 07, p. 059, A descubrir - B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/002. L 07, p. 059, A descubrir - B.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 003. MC - L 07, p. 059, A practicar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/003. MC - L 07, p. 059, A practicar.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 004. AG - L 07, p. 123, Ej. A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/004. AG - L 07, p. 123, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 005. AG - L 07, p. 123, Ej. B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/005. AG - L 07, p. 123, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 006. AG - L 07, p. 124, Ej. C" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/006. AG - L 07, p. 124, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 007. AG - L 07, p. 124, Ej. E" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/007. AG - L 07, p. 124, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 008. MC - L 07, p. 060, A pensar - D" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/008. MC - L 07, p. 060, A pensar - D.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 009. MC - L 07, p. 061, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/009. MC - L 07, p. 061, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 010. AG - L 07, p. 125, Ej. F" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/010. AG - L 07, p. 125, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 011. AG - L 07, p. 126, Ej. G" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/011. AG - L 07, p. 126, Ej. G.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 012. L 07, p. 062, A escuchar - A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/012. L 07, p. 062, A escuchar - A.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 013. MC - L 07, p. 063, A practicar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/013. MC - L 07, p. 063, A practicar.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 014. MC - L 07, p. 063, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/014. MC - L 07, p. 063, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 015. L 07, p. 064, A escuchar - A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/015. L 07, p. 064, A escuchar - A.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 016. AG - L 07, p. 126, Ej. H" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 07/016. AG - L 07, p. 126, Ej. H.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 001. L 08, p. 067, A descubrir" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/001. L 08, p. 067, A descubrir.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 002. AG - L 08, p. 127, Ej. A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/002. AG - L 08, p. 127, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 003. AG - L 08, p. 127, Ej. B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/003. AG - L 08, p. 127, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 004. AG - L 08, p. 127, Ej. C" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/004. AG - L 08, p. 127, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 005. L 08, p. 068, A conocer - B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/005. L 08, p. 068, A conocer - B.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 006. AG - L 08, p. 128, Ej. D" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/006. AG - L 08, p. 128, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 007. AG - L 08, p. 129, Ej. F" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/007. AG - L 08, p. 129, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 008. MC - L 08, p. 069, A practicar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/008. MC - L 08, p. 069, A practicar.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 009. L 08, p. 070, A practicar - B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/009. L 08, p. 070, A practicar - B.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 010. MC - L 08, p. 070, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/010. MC - L 08, p. 070, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 011. AG - L 08, p. 129, Ej. G" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/011. AG - L 08, p. 129, Ej. G.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 012. L 08, p. 071, A escuchar - A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/012. L 08, p. 071, A escuchar - A.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 013. MC - L 08, p. 072, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/013. MC - L 08, p. 072, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 014. AG - L 08, p. 130, Ej. H" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 08/014. AG - L 08, p. 130, Ej. H.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 001. AG - L 09, p. 131, Ej. A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 09/001. AG - L 09, p. 131, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 002. L 09, p. 076, A conocer" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 09/002. L 09, p. 076, A conocer.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 003. AG - L 09, p. 131, Ej. B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 09/003. AG - L 09, p. 131, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 004. AG - L 09, p. 132, Ej. C" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 09/004. AG - L 09, p. 132, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 005. MC - L 09, p. 079, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 09/005. MC - L 09, p. 079, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 006. L 09, p. 079, A conocer" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 09/006. L 09, p. 079, A conocer.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 007. AG - L 09, p. 133, Ej. E" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 09/007. AG - L 09, p. 133, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 008. AG - L 09, p. 133, Ej. F" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 09/008. AG - L 09, p. 133, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 009. L 09, p. 081, A escuchar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 09/009. L 09, p. 081, A escuchar.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 010. MC - L 09, p. 082, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 09/010. MC - L 09, p. 082, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 011. AG - L 09, p. 134, Ej. G" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 09/011. AG - L 09, p. 134, Ej. G.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 001. AG - L 10, p. 135, Ej. A" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 10/001. AG - L 10, p. 135, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 002. AG - L 10, p. 135, Ej. B" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 10/002. AG - L 10, p. 135, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 003. AG - L 10, p. 136, Ej. C" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 10/003. AG - L 10, p. 136, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 004. L 10, p. 086, A escuchar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 10/004. L 10, p. 086, A escuchar.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 005. MC - L 10, p. 086, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 10/005. MC - L 10, p. 086, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 006. L 10, p. 087, A conocer" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 10/006. L 10, p. 087, A conocer.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 007. MC - L 10, p. 089, A hablar" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 10/007. MC - L 10, p. 089, A hablar.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 008. AG - L 10, p. 138, Ej. H" data-artist="Espanhol N 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 3/Leccion 10/008. AG - L 10, p. 138, Ej. H.mp3" data-free="false"></li>



	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

