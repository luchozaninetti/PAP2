
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Latitudes 2 - CD 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
        
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="05 Lat 2.2 - 01 1" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/01 1.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 02 2" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/02 2.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 03 3" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/03 3.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 04 4" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/04 4.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 05 5" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/05 5.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 06 6" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/06 6.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 07 7" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/07 7.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 08 8" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/08 8.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 09 9" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/09 9.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 10 10" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/10 10.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 11 11" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/11 11.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 12 12" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/12 12.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 13 13" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/13 13.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 14 14" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/14 14.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 15 15" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/15 15.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 16 16" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/16 16.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 17 17" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/17 17.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 18 18" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/18 18.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 19 19" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/19 19.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 20 20" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/20 20.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 21 21" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/21 21.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 22 22" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/22 22.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 23 23" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/23 23.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 24 24" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/24 24.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 25 25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/25 25.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 26 26" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/26 26.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 27 27" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/27 27.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 28 28" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/28 28.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 29 29" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/29 29.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 30 30" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/30 30.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 31 31" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/31 31.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 32 32" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/32 32.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 33 33" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/33 33.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 34 34" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/34 34.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 35 35" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/35 35.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 36 36" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/36 36.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 37 37" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/37 37.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 38 38" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/38 38.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 39 39" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/39 39.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 40 40" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/40 40.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 41 41" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/41 41.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 42 42" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/42 42.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 43 43" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/43 43.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 44 44" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/44 44.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 45 45" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/45 45.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 46 46" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/46 46.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 47 47" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/47 47.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 48 48" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/48 48.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 49 49" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/49 49.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 50 50" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/50 50.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 51 51" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/51 51.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 52 52" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/52 52.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 53 53" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/53 53.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 54 54" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/54 54.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 55 55" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/55 55.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 56 56" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/56 56.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 57 57" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/57 57.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 58 58" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/58 58.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 59 59" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/59 59.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 60 60" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/60 60.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 61 61" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/61 61.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 62 62" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/62 62.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 63 63" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/63 63.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 64 64" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/64 64.mp3" data-free="false"></li>
<li data-title="05 Lat 2.2 - 65 65" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/05 Lat 2.2/65 65.mp3" data-free="false"></li>




        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
