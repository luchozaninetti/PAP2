
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Conectate 4</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
   
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Leccion 1 - 01. Leccion 1 - ejercicio 1 - p. 08" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/01. Leccion 1 - ejercicio 1 - p. 08.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 02. Leccion 1 - ejercicio 2 - p. 08" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/02. Leccion 1 - ejercicio 2 - p. 08.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 03. Leccion 1 - ejercicio 3 - p. 09 - responde" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/03. Leccion 1 - ejercicio 3 - p. 09 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 04. Leccion 1 - ejercicio 3 - p. 09 - pregunta" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/04. Leccion 1 - ejercicio 3 - p. 09 - pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 05. Leccion 1 - ejercicio 4 - p. 10 - responde" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/05. Leccion 1 - ejercicio 4 - p. 10 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 06. Leccion 1 - ejercicio 1 - p. 10" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/06. Leccion 1 - ejercicio 1 - p. 10.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 07. Leccion 1 - ejercicio 5 - p. 12" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/07. Leccion 1 - ejercicio 5 - p. 12.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 08. Leccion 1 - ejercicio 7 - p. 13" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/08. Leccion 1 - ejercicio 7 - p. 13.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 09. Leccion 1 - ejercicio 8 - p. 14 - pregunta" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/09. Leccion 1 - ejercicio 8 - p. 14 - pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 10. Leccion 1 - ejercicio 8 - p. 14 - responde" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/10. Leccion 1 - ejercicio 8 - p. 14 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 11. Leccion 1 - ejercicio 9 - p. 14 - pregunta" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/11. Leccion 1 - ejercicio 9 - p. 14 - pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 12. Leccion 1 - ejercicio 9 - p. 14 - responde" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/12. Leccion 1 - ejercicio 9 - p. 14 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 13. Leccion 1 - ejercicio 1 - p. 14" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/13. Leccion 1 - ejercicio 1 - p. 14.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 14. Leccion 1 - ejercicio 3 - p. 14 - dialogo 1" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/14. Leccion 1 - ejercicio 3 - p. 14 - dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 15. Leccion 1 - ejercicio 3 - p. 14 - dialogo 2" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/15. Leccion 1 - ejercicio 3 - p. 14 - dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 1 - 16. Leccion 1 - ejercicio 3 - p. 14 - dialogo 3" data-artist="Leccion 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 1/16. Leccion 1 - ejercicio 3 - p. 14 - dialogo 3.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 01. Leccion 2 - ejercicio 1 - p. 20" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/01. Leccion 2 - ejercicio 1 - p. 20.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 02. Leccion 2 - ejercicio 2 - p. 21" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/02. Leccion 2 - ejercicio 2 - p. 21.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 03. Leccion 2 - ejercicio 3 - p. 21 - responde" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/03. Leccion 2 - ejercicio 3 - p. 21 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 04. Leccion 2 - ejercicio 3 - p. 21" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/04. Leccion 2 - ejercicio 3 - p. 21.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 05. Leccion 2 - ejercicio 3 - p. 21" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/05. Leccion 2 - ejercicio 3 - p. 21.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 06. Leccion 2 - ejercicio 3 - p. 21" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/06. Leccion 2 - ejercicio 3 - p. 21.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 07. Leccion 2 - ejercicio 3 - p. 21" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/07. Leccion 2 - ejercicio 3 - p. 21.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 08. Leccion 2 - ejercicio 3 - p. 21" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/08. Leccion 2 - ejercicio 3 - p. 21.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 09. Leccion 2 - ejercicio 3 - p. 21" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/09. Leccion 2 - ejercicio 3 - p. 21.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 10. Leccion 2 - ejercicio 3 - p. 21" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/10. Leccion 2 - ejercicio 3 - p. 21.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 11. Leccion 2 - ejercicio 5 - p. 22 - pregunta" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/11. Leccion 2 - ejercicio 5 - p. 22 - pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 12. Leccion 2 - ejercicio 5 - p. 22 - responde" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/12. Leccion 2 - ejercicio 5 - p. 22 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 13. Leccion 2 - ejercicio 4 - p. 24 - responde" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/13. Leccion 2 - ejercicio 4 - p. 24 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 14. Leccion 2 - ejercicio 4 - p. 24 - pregunta" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/14. Leccion 2 - ejercicio 4 - p. 24 - pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 15. Leccion 2 - ejercicio 6 - p. 24" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/15. Leccion 2 - ejercicio 6 - p. 24.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 16. Leccion 2 - ejercicio 1 - p. 25" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/16. Leccion 2 - ejercicio 1 - p. 25.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 17. Leccion 2 - ejercicio 4 - p. 26 - parte A - responde" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/17. Leccion 2 - ejercicio 4 - p. 26 - parte A - responde.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 18. Leccion 2 - ejercicio 4 - p. 26 - parte B" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/18. Leccion 2 - ejercicio 4 - p. 26 - parte B.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 19. Leccion 2 - ejercicio 4 - p. 26 - parte C - pregunta" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/19. Leccion 2 - ejercicio 4 - p. 26 - parte C - pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 2 - 20. Leccion 2 - ejercicio 9 - p. 27 - responde" data-artist="Leccion 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 2/20. Leccion 2 - ejercicio 9 - p. 27 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 3 - 01. Leccion 3 - ejercicio 1 - p. 32" data-artist="Leccion 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 3/01. Leccion 3 - ejercicio 1 - p. 32.mp3" data-free="false"></li>
<li data-title="Leccion 3 - 02. Leccion 3 - ejercicio 2 - p. 32" data-artist="Leccion 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 3/02. Leccion 3 - ejercicio 2 - p. 32.mp3" data-free="false"></li>
<li data-title="Leccion 3 - 03. Leccion 3 - ejercicio 9 - p. 35" data-artist="Leccion 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 3/03. Leccion 3 - ejercicio 9 - p. 35.mp3" data-free="false"></li>
<li data-title="Leccion 3 - 04. Leccion 3 - ejercicio 11 - p. 36 - parte A" data-artist="Leccion 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 3/04. Leccion 3 - ejercicio 11 - p. 36 - parte A.mp3" data-free="false"></li>
<li data-title="Leccion 3 - 05. Leccion 3 - ejercicio 11 - p. 36 - parte B - responde" data-artist="Leccion 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 3/05. Leccion 3 - ejercicio 11 - p. 36 - parte B - responde.mp3" data-free="false"></li>
<li data-title="Leccion 3 - 06. Leccion 3 - ejercicio 1 - p. 36" data-artist="Leccion 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 3/06. Leccion 3 - ejercicio 1 - p. 36.mp3" data-free="false"></li>
<li data-title="Leccion 3 - 07. Leccion 3 - ejercicio 4 - p. 38" data-artist="Leccion 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 3/07. Leccion 3 - ejercicio 4 - p. 38.mp3" data-free="false"></li>
<li data-title="Leccion 3 - 08. Leccion 3 - ejercicio 5 - p. 38 - responde" data-artist="Leccion 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 3/08. Leccion 3 - ejercicio 5 - p. 38 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 3 - 09. Leccion 3 - ejercicio 7 - p. 39 - pregunta" data-artist="Leccion 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 3/09. Leccion 3 - ejercicio 7 - p. 39 - pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 3 - 10. Leccion 3 - ejercicio 7 - p. 39 - responde" data-artist="Leccion 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 3/10. Leccion 3 - ejercicio 7 - p. 39 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 4 - 01. Leccion 4 - ejercicio 1 - p. 48" data-artist="Leccion 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 4/01. Leccion 4 - ejercicio 1 - p. 48.mp3" data-free="false"></li>
<li data-title="Leccion 4 - 02. Leccion 4 - ejercicio 2 - p. 49" data-artist="Leccion 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 4/02. Leccion 4 - ejercicio 2 - p. 49.mp3" data-free="false"></li>
<li data-title="Leccion 4 - 03. Leccion 4 - ejercicio 1 - p. 51" data-artist="Leccion 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 4/03. Leccion 4 - ejercicio 1 - p. 51.mp3" data-free="false"></li>
<li data-title="Leccion 4 - 04. Leccion 4 - ejercicio 4 - p. 52 - responde" data-artist="Leccion 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 4/04. Leccion 4 - ejercicio 4 - p. 52 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 4 - 05. Leccion 4 - ejercicio 7 - p. 53" data-artist="Leccion 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 4/05. Leccion 4 - ejercicio 7 - p. 53.mp3" data-free="false"></li>
<li data-title="Leccion 4 - 06. Leccion 4 - ejercicio 1 - p. 54" data-artist="Leccion 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 4/06. Leccion 4 - ejercicio 1 - p. 54.mp3" data-free="false"></li>
<li data-title="Leccion 4 - 07. Leccion 4 - ejercicio 3 - p. 55 - responde A" data-artist="Leccion 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 4/07. Leccion 4 - ejercicio 3 - p. 55 - responde A.mp3" data-free="false"></li>
<li data-title="Leccion 4 - 08. Leccion 4 - ejercicio 3 - p. 55 - responde B" data-artist="Leccion 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 4/08. Leccion 4 - ejercicio 3 - p. 55 - responde B.mp3" data-free="false"></li>
<li data-title="Leccion 4 - 09. Leccion 4 - ejercicio 3 - p. 55 - responde C" data-artist="Leccion 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 4/09. Leccion 4 - ejercicio 3 - p. 55 - responde C.mp3" data-free="false"></li>
<li data-title="Leccion 4 - 10. Leccion 4 - ejercicio 3 - p. 55 - responde D" data-artist="Leccion 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 4/10. Leccion 4 - ejercicio 3 - p. 55 - responde D.mp3" data-free="false"></li>
<li data-title="Leccion 4 - 11. Leccion 4 - ejercicio 3 - p. 55 - responde E" data-artist="Leccion 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 4/11. Leccion 4 - ejercicio 3 - p. 55 - responde E.mp3" data-free="false"></li>
<li data-title="Leccion 5 - 01. Leccion 5 - ejercicio 1 - p. 60" data-artist="Leccion 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 5/01. Leccion 5 - ejercicio 1 - p. 60.mp3" data-free="false"></li>
<li data-title="Leccion 5 - 02. Leccion 5 - ejercicio 5 - p. 62 - pregunta" data-artist="Leccion 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 5/02. Leccion 5 - ejercicio 5 - p. 62 - pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 5 - 03. Leccion 5 - ejercicio 5 - p. 62 - responde" data-artist="Leccion 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 5/03. Leccion 5 - ejercicio 5 - p. 62 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 5 - 04. Leccion 5 - ejercicio 6 - p. 63 - pregunta" data-artist="Leccion 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 5/04. Leccion 5 - ejercicio 6 - p. 63 - pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 5 - 05. Leccion 5 - ejercicio 6 - p. 63 - responde" data-artist="Leccion 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 5/05. Leccion 5 - ejercicio 6 - p. 63 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 5 - 06. Leccion 5 - ejercicio 7 - p. 63 - pregunta" data-artist="Leccion 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 5/06. Leccion 5 - ejercicio 7 - p. 63 - pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 5 - 07. Leccion 5 - ejercicio 7 - p. 63 - responde" data-artist="Leccion 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 5/07. Leccion 5 - ejercicio 7 - p. 63 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 5 - 08. Leccion 5 - ejercicio 8 - p. 63" data-artist="Leccion 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 5/08. Leccion 5 - ejercicio 8 - p. 63.mp3" data-free="false"></li>
<li data-title="Leccion 5 - 09. Leccion 5 - ejercicio 1 - p. 64" data-artist="Leccion 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 5/09. Leccion 5 - ejercicio 1 - p. 64.mp3" data-free="false"></li>
<li data-title="Leccion 5 - 10. Leccion 5 - ejercicio 2 - p. 64" data-artist="Leccion 5" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 5/10. Leccion 5 - ejercicio 2 - p. 64.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 01. Leccion 6 - ejercicio 1 - p. 73" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/01. Leccion 6 - ejercicio 1 - p. 73.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 02. Leccion 6 - ejercicio 2 - p. 74" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/02. Leccion 6 - ejercicio 2 - p. 74.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 03. Leccion 6 - ejercicio 4 - p. 74 - pregunta" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/03. Leccion 6 - ejercicio 4 - p. 74 - pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 04. Leccion 6 - ejercicio 4 - p. 74 - responde" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/04. Leccion 6 - ejercicio 4 - p. 74 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 05. Leccion 6 - ejercicio 1 - p. 75" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/05. Leccion 6 - ejercicio 1 - p. 75.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 06. Leccion 6 - ejercicio 2 - p. 76" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/06. Leccion 6 - ejercicio 2 - p. 76.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 07. Leccion 6 - ejercicio 5 - p. 78 - responde" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/07. Leccion 6 - ejercicio 5 - p. 78 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 08. Leccion 6 - ejercicio 6 - p. 78" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/08. Leccion 6 - ejercicio 6 - p. 78.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 09. Leccion 6 - ejercicio 8 - p. 78 - responde" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/09. Leccion 6 - ejercicio 8 - p. 78 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 10. Leccion 6 - ejercicio 9 - p. 79" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/10. Leccion 6 - ejercicio 9 - p. 79.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 11. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 1" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/11. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 12. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 2" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/12. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 13. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 3" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/13. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 3.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 14. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 4" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/14. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 4.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 15. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 5" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/15. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 5.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 16. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 6" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/16. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 6.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 17. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 7" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/17. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 7.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 18. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 8" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/18. Leccion 6 - ejercicio 10 - p. 79 - responde dialogo 8.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 19. Leccion 6 - ejercicio 11 - p. 80 - parte A" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/19. Leccion 6 - ejercicio 11 - p. 80 - parte A.mp3" data-free="false"></li>
<li data-title="Leccion 6 - 20. Leccion 6 - ejercicio 11 - p. 80 - parte B - responde" data-artist="Leccion 6" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 6/20. Leccion 6 - ejercicio 11 - p. 80 - parte B - responde.mp3" data-free="false"></li>
<li data-title="Leccion 7 - 01. Leccion 7 - ejercicio 1 - p. 88" data-artist="Leccion 7" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 7/01. Leccion 7 - ejercicio 1 - p. 88.mp3" data-free="false"></li>
<li data-title="Leccion 7 - 02. Leccion 7 - ejercicio 5 - p. 90 - responde" data-artist="Leccion 7" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 7/02. Leccion 7 - ejercicio 5 - p. 90 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 7 - 03. Leccion 7 - ejercicio 8 - p. 91 - responde" data-artist="Leccion 7" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 7/03. Leccion 7 - ejercicio 8 - p. 91 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 7 - 04. Leccion 7 - ejercicio 8 - p. 91 - pregunta" data-artist="Leccion 7" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 7/04. Leccion 7 - ejercicio 8 - p. 91 - pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 7 - 05. Leccion 7 - ejercicio 1 - p. 91" data-artist="Leccion 7" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 7/05. Leccion 7 - ejercicio 1 - p. 91.mp3" data-free="false"></li>
<li data-title="Leccion 7 - 06. Leccion 7 - ejercicio 3 - p. 92" data-artist="Leccion 7" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 7/06. Leccion 7 - ejercicio 3 - p. 92.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 01. Leccion 8 - ejercicio 1 - p. 100" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/01. Leccion 8 - ejercicio 1 - p. 100.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 02. Leccion 8 - ejercicio 2 - p. 101" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/02. Leccion 8 - ejercicio 2 - p. 101.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 03. Leccion 8 - ejercicio 4 - p. 102" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/03. Leccion 8 - ejercicio 4 - p. 102.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 04. Leccion 8 - ejercicio 6 - p. 103 - dialogo 1" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/04. Leccion 8 - ejercicio 6 - p. 103 - dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 05. Leccion 8 - ejercicio 6 - p. 103 - dialogo 2" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/05. Leccion 8 - ejercicio 6 - p. 103 - dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 06. Leccion 8 - ejercicio 5 - p. 105 - dialogo 1" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/06. Leccion 8 - ejercicio 5 - p. 105 - dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 07. Leccion 8 - ejercicio 5 - p. 105 - dialogo 2" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/07. Leccion 8 - ejercicio 5 - p. 105 - dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 08. Leccion 8 - ejercicio 5 - p. 105 - dialogo 3" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/08. Leccion 8 - ejercicio 5 - p. 105 - dialogo 3.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 09. Leccion 8 - ejercicio 5 - p. 105 - dialogo 4" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/09. Leccion 8 - ejercicio 5 - p. 105 - dialogo 4.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 10. Leccion 8 - ejercicio 1 - p. 106" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/10. Leccion 8 - ejercicio 1 - p. 106.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 11. Leccion 8 - ejercicio 3 - p. 107 - responde" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/11. Leccion 8 - ejercicio 3 - p. 107 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 12. Leccion 8 - ejercicio 4 - p. 107 - dialogo 1" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/12. Leccion 8 - ejercicio 4 - p. 107 - dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 13. Leccion 8 - ejercicio 4 - p. 107 - dialogo 2" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/13. Leccion 8 - ejercicio 4 - p. 107 - dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 14. Leccion 8 - ejercicio 4 - p. 107 - dialogo 3" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/14. Leccion 8 - ejercicio 4 - p. 107 - dialogo 3.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 15. Leccion 8 - ejercicio 4 - p. 107 - responde" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/15. Leccion 8 - ejercicio 4 - p. 107 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 16. Leccion 8 - ejercicio 6 - p. 108 - parte A" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/16. Leccion 8 - ejercicio 6 - p. 108 - parte A.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 17. Leccion 8 - ejercicio 6 - p. 108 - parte B - responde" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/17. Leccion 8 - ejercicio 6 - p. 108 - parte B - responde.mp3" data-free="false"></li>
<li data-title="Leccion 8 - 18. Leccion 8 - ejercicio 7 - p. 108" data-artist="Leccion 8" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 8/18. Leccion 8 - ejercicio 7 - p. 108.mp3" data-free="false"></li>
<li data-title="Leccion 9 - 01. Leccion 9 - ejercicio 1 - p. 112" data-artist="Leccion 9" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 9/01. Leccion 9 - ejercicio 1 - p. 112.mp3" data-free="false"></li>
<li data-title="Leccion 9 - 02. Leccion 9 - ejercicio 2 - p. 113" data-artist="Leccion 9" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 9/02. Leccion 9 - ejercicio 2 - p. 113.mp3" data-free="false"></li>
<li data-title="Leccion 9 - 03. Leccion 9 - ejercicio 4 - p. 114 - parte A" data-artist="Leccion 9" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 9/03. Leccion 9 - ejercicio 4 - p. 114 - parte A.mp3" data-free="false"></li>
<li data-title="Leccion 9 - 04. Leccion 9 - ejercicio 4 - p. 114 - parte B - responde" data-artist="Leccion 9" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 9/04. Leccion 9 - ejercicio 4 - p. 114 - parte B - responde.mp3" data-free="false"></li>
<li data-title="Leccion 9 - 05. Leccion 9 - ejercicio 5 - p. 114" data-artist="Leccion 9" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 9/05. Leccion 9 - ejercicio 5 - p. 114.mp3" data-free="false"></li>
<li data-title="Leccion 9 - 06. Leccion 9 - ejercicio 7 - p. 116" data-artist="Leccion 9" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 9/06. Leccion 9 - ejercicio 7 - p. 116.mp3" data-free="false"></li>
<li data-title="Leccion 9 - 07. Leccion 9 - ejercicio 8 - p. 116" data-artist="Leccion 9" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 9/07. Leccion 9 - ejercicio 8 - p. 116.mp3" data-free="false"></li>
<li data-title="Leccion 9 - 08. Leccion 9 - ejercicio 1 - p. 117" data-artist="Leccion 9" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 9/08. Leccion 9 - ejercicio 1 - p. 117.mp3" data-free="false"></li>
<li data-title="Leccion 9 - 09. Leccion 9 - ejercicio 6 - p. 119 - responde" data-artist="Leccion 9" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 9/09. Leccion 9 - ejercicio 6 - p. 119 - responde.mp3" data-free="false"></li>
<li data-title="Leccion 9 - 10. Leccion 9 - ejercicio 6 - p. 119 - pregunta" data-artist="Leccion 9" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Leccion 9/10. Leccion 9 - ejercicio 6 - p. 119 - pregunta.mp3" data-free="false"></li>
<li data-title="Vuelve a Conectarte - 01. Vuelve a conectarte ejercicio 1 - p. 06 - responde" data-artist="Vuelve a Conectarte" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Vuelve a Conectarte/01. Vuelve a conectarte ejercicio 1 - p. 06 - responde.mp3" data-free="false"></li>
<li data-title="Vuelve a Conectarte - 02. Vuelve a conectarte ejercicio 1 - p. 06 - pregunta" data-artist="Vuelve a Conectarte" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Vuelve a Conectarte/02. Vuelve a conectarte ejercicio 1 - p. 06 - pregunta.mp3" data-free="false"></li>
<li data-title="Vuelve a Conectarte - 03. Vuelve a conectarte ejercicio 2 - p. 06 - responde" data-artist="Vuelve a Conectarte" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Vuelve a Conectarte/03. Vuelve a conectarte ejercicio 2 - p. 06 - responde.mp3" data-free="false"></li>
<li data-title="Vuelve a Conectarte - 04. Vuelve a conectarte ejercicio 3 - p. 07 - responde" data-artist="Vuelve a Conectarte" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Vuelve a Conectarte/04. Vuelve a conectarte ejercicio 3 - p. 07 - responde.mp3" data-free="false"></li>
<li data-title="Vuelve a Conectarte - 05. Vuelve a conectarte ejercicio 4 - p. 07 - responde" data-artist="Vuelve a Conectarte" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 4/Vuelve a Conectarte/05. Vuelve a conectarte ejercicio 4 - p. 07 - responde.mp3" data-free="false"></li>


	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

