
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Latitudes 3 - Cahier</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
       
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
<li data-title="09 Lat 3 Cahier - 01 1" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/01 1.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 02 2" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/02 2.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 03 3" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/03 3.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 04 4" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/04 4.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 05 5" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/05 5.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 06 6" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/06 6.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 07 7" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/07 7.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 08 8" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/08 8.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 09 9" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/09 9.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 10 10" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/10 10.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 11 11" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/11 11.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 12 12" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/12 12.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 13 13" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/13 13.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 14 14" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/14 14.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 15 15" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/15 15.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 16 16" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/16 16.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 17 17" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/17 17.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 18 18" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/18 18.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 19 19" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/19 19.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 20 20" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/20 20.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 21 21" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/21 21.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 22 22" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/22 22.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 23 23" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/23 23.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 24 24" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/24 24.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 25 25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/25 25.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 26 26" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/26 26.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 27 27" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/27 27.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 28 28" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/28 28.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 29 29" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/29 29.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 30 30" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/30 30.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 31 31" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/31 31.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 32 32" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/32 32.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 33 33" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/33 33.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 34 34" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/34 34.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 35 35" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/35 35.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 36 36" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/36 36.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 37 37" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/37 37.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 38 38" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/38 38.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 39 39" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/39 39.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 40 40" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/40 40.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 41 41" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/41 41.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 42 42" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/42 42.mp3" data-free="false"></li>
<li data-title="09 Lat 3 Cahier - 43 43" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/09 Lat 3 Cahier/43 43.mp3" data-free="false"></li>



	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
