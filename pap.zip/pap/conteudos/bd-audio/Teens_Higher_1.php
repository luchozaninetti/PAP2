
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Higher 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
          
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Phrasal Verbs Units 1 and 2 - Phrasal Verbs  p38  Units 1 and 2 - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Activities/Phrasal Verbs Units 1 and 2/Phrasal Verbs  p38  Units 1 and 2 - CM.mp3" data-free="false"></li>
<li data-title="Phrasal Verbs Units 5 and 6 - Phrasal Verbs  p106 Units 5 and 6 - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Activities/Phrasal Verbs Units 5 and 6/Phrasal Verbs  p106 Units 5 and 6 - CM.mp3" data-free="false"></li>
<li data-title="Unit 01 - 01 L1p08 Reading and Talking - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/01 L1p08 Reading and Talking - C.mp3" data-free="false"></li>
<li data-title="Unit 01 - 02 L2p10 Grammar and Com - C - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/02 L2p10 Grammar and Com - C - CM.mp3" data-free="false"></li>
<li data-title="Unit 01 - 03 L2p11 Grammar and Com - E - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/03 L2p11 Grammar and Com - E - CM.mp3" data-free="false"></li>
<li data-title="Unit 01 - 04 L2p11 Grammar and Com - F"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/04 L2p11 Grammar and Com - F.mp3" data-free="false"></li>
<li data-title="Unit 01 - 05 L3p12 Listening and Speaking - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/05 L3p12 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Unit 01 - 06 L3p13 Listening and Speaking - F"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/06 L3p13 Listening and Speaking - F.mp3" data-free="false"></li>
<li data-title="Unit 01 - 07 L3p13 Listening and Speaking - G"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/07 L3p13 Listening and Speaking - G.mp3" data-free="false"></li>
<li data-title="Unit 01 - 08 L4p14 Writing and Discussing - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/08 L4p14 Writing and Discussing - B.mp3" data-free="false"></li>
<li data-title="Unit 01 - 09 L4p15 Writing and Discussing - E"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/09 L4p15 Writing and Discussing - E.mp3" data-free="false"></li>
<li data-title="Unit 01 - 10 L5p17 Phrasal Verbs - D - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/10 L5p17 Phrasal Verbs - D - CM.mp3" data-free="false"></li>
<li data-title="Unit 01 - 11 L6p18 Pronunciation - A"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/11 L6p18 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Unit 01 - 12 L6p18 Pronunciation - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/12 L6p18 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Unit 01 - 13 L6p18 Pronunciation - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/13 L6p18 Pronunciation - C.mp3" data-free="false"></li>
<li data-title="Unit 01 - 14 L6p18 Pronunciation - D - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 01/14 L6p18 Pronunciation - D - CM.mp3" data-free="false"></li>
<li data-title="Unit 02 - 01 L1p24 Reading and Talking - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/01 L1p24 Reading and Talking - C.mp3" data-free="false"></li>
<li data-title="Unit 02 - 02 L1p25 Reading and Talking - G"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/02 L1p25 Reading and Talking - G.mp3" data-free="false"></li>
<li data-title="Unit 02 - 03 L2p26 Grammar and Com - D"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/03 L2p26 Grammar and Com - D.mp3" data-free="false"></li>
<li data-title="Unit 02 - 04 L2p27 Grammar and Com - F"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/04 L2p27 Grammar and Com - F.mp3" data-free="false"></li>
<li data-title="Unit 02 - 05 L3p28 Listening and Speaking - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/05 L3p28 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Unit 02 - 06 L3p29 Listening and Speaking - E"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/06 L3p29 Listening and Speaking - E.mp3" data-free="false"></li>
<li data-title="Unit 02 - 07 L3p29 Listening and Speaking - F"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/07 L3p29 Listening and Speaking - F.mp3" data-free="false"></li>
<li data-title="Unit 02 - 08 L4p31 Writing and Discussing - D"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/08 L4p31 Writing and Discussing - D.mp3" data-free="false"></li>
<li data-title="Unit 02 - 09 L5p33 Phrasal Verbs - B - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/09 L5p33 Phrasal Verbs - B - CM.mp3" data-free="false"></li>
<li data-title="Unit 02 - 10 L5p33 Phrasal Verbs - D"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/10 L5p33 Phrasal Verbs - D.mp3" data-free="false"></li>
<li data-title="Unit 02 - 11 L6p34 Pronunciation - A"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/11 L6p34 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Unit 02 - 12 L6p34 Pronunciation - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/12 L6p34 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Unit 02 - 13 L6p34 Pronunciation - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/13 L6p34 Pronunciation - C.mp3" data-free="false"></li>
<li data-title="Unit 02 - 14 L6p34 Pronunciation - E - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 02/14 L6p34 Pronunciation - E - CM.mp3" data-free="false"></li>
<li data-title="Unit 03 - 01 L1p42 Reading and Talking - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/01 L1p42 Reading and Talking - B.mp3" data-free="false"></li>
<li data-title="Unit 03 - 02 L2p44 Grammar and Com - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/02 L2p44 Grammar and Com - B.mp3" data-free="false"></li>
<li data-title="Unit 03 - 03 L2p44 Grammar and Com - C - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/03 L2p44 Grammar and Com - C - CM.mp3" data-free="false"></li>
<li data-title="Unit 03 - 04 L2p45 Grammar and Com - E - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/04 L2p45 Grammar and Com - E - CM.mp3" data-free="false"></li>
<li data-title="Unit 03 - 05 L2p45 Grammar and Com - F"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/05 L2p45 Grammar and Com - F.mp3" data-free="false"></li>
<li data-title="Unit 03 - 06 L3p46 Listening and Speaking - A"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/06 L3p46 Listening and Speaking - A.mp3" data-free="false"></li>
<li data-title="Unit 03 - 07 L3p46 Listening and Speaking - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/07 L3p46 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Unit 03 - 08 L3p47 Listening and Speaking - E"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/08 L3p47 Listening and Speaking - E.mp3" data-free="false"></li>
<li data-title="Unit 03 - 09 L4p48 Writing and Discussing - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/09 L4p48 Writing and Discussing - B.mp3" data-free="false"></li>
<li data-title="Unit 03 - 10 L4p49 Writing and Discussing - E"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/10 L4p49 Writing and Discussing - E.mp3" data-free="false"></li>
<li data-title="Unit 03 - 11 L5p51 Phrasal Verbs - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/11 L5p51 Phrasal Verbs - C.mp3" data-free="false"></li>
<li data-title="Unit 03 - 12 L6p52 Pronunciation - A"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/12 L6p52 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Unit 03 - 13 L6p52 Pronunciation - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/13 L6p52 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Unit 03 - 14 L6p52 Pronunciation - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/14 L6p52 Pronunciation - C.mp3" data-free="false"></li>
<li data-title="Unit 03 - 15 L6p52 Pronunciation - D - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 03/15 L6p52 Pronunciation - D - CM.mp3" data-free="false"></li>
<li data-title="Unit 04 - 01 L1p58 Reading and Talking - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 04/01 L1p58 Reading and Talking - C.mp3" data-free="false"></li>
<li data-title="Unit 04 - 02 L1p59 Reading and Talking - G"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 04/02 L1p59 Reading and Talking - G.mp3" data-free="false"></li>
<li data-title="Unit 04 - 03 L2p60 Grammar and Com - D"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 04/03 L2p60 Grammar and Com - D.mp3" data-free="false"></li>
<li data-title="Unit 04 - 04 L3p62 Listening and Speaking - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 04/04 L3p62 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Unit 04 - 05 L3p63 Listening and Speaking - D"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 04/05 L3p63 Listening and Speaking - D.mp3" data-free="false"></li>
<li data-title="Unit 04 - 06 L4p65 Writing and Discussing - E"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 04/06 L4p65 Writing and Discussing - E.mp3" data-free="false"></li>
<li data-title="Unit 04 - 07 L5p66 Phrasal Verbs - B - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 04/07 L5p66 Phrasal Verbs - B - CM.mp3" data-free="false"></li>
<li data-title="Unit 04 - 08 L6p68 Pronunciation - A"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 04/08 L6p68 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Unit 04 - 09 L6p68 Pronunciation - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 04/09 L6p68 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Unit 04 - 10 L6p68 Pronunciation - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 04/10 L6p68 Pronunciation - C.mp3" data-free="false"></li>
<li data-title="Unit 04 - 11 L6p68 Pronunciation - D - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 04/11 L6p68 Pronunciation - D - CM.mp3" data-free="false"></li>
<li data-title="Unit 05 - 01 L1p76 Reading and Talking - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/01 L1p76 Reading and Talking - B.mp3" data-free="false"></li>
<li data-title="Unit 05 - 02 L1p76 Reading and Talking - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/02 L1p76 Reading and Talking - C.mp3" data-free="false"></li>
<li data-title="Unit 05 - 03 L1p77 Reading and Talking - G"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/03 L1p77 Reading and Talking - G.mp3" data-free="false"></li>
<li data-title="Unit 05 - 04 L2p78 Grammar and Com - B - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/04 L2p78 Grammar and Com - B - CM.mp3" data-free="false"></li>
<li data-title="Unit 05 - 05 L2p78 Grammar and Com - C - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/05 L2p78 Grammar and Com - C - CM.mp3" data-free="false"></li>
<li data-title="Unit 05 - 06 L2p79 Grammar and Com - F and G"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/06 L2p79 Grammar and Com - F and G.mp3" data-free="false"></li>
<li data-title="Unit 05 - 07 L3p80 Listening and Speaking - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/07 L3p80 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Unit 05 - 08 L3p81 Listening and Speaking - E"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/08 L3p81 Listening and Speaking - E.mp3" data-free="false"></li>
<li data-title="Unit 05 - 09 L3p81 Listening and Speaking - F"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/09 L3p81 Listening and Speaking - F.mp3" data-free="false"></li>
<li data-title="Unit 05 - 10 L3p81 Listening and Speaking - G"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/10 L3p81 Listening and Speaking - G.mp3" data-free="false"></li>
<li data-title="Unit 05 - 11 L4p83 Wrting and Discussing - D"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/11 L4p83 Wrting and Discussing - D.mp3" data-free="false"></li>
<li data-title="Unit 05 - 12 L5p84 Phrasal Verbs - B - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/12 L5p84 Phrasal Verbs - B - CM.mp3" data-free="false"></li>
<li data-title="Unit 05 - 13 L6p86 Pronunciation - A"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/13 L6p86 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Unit 05 - 14 L6p86 Pronunciation - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/14 L6p86 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Unit 05 - 15 L6p86 Pronunciation - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/15 L6p86 Pronunciation - C.mp3" data-free="false"></li>
<li data-title="Unit 05 - 16 L6p86 Pronunciation - D - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 05/16 L6p86 Pronunciation - D - CM.mp3" data-free="false"></li>
<li data-title="Unit 06 - 01 L1p092 Reading and Talking - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/01 L1p092 Reading and Talking - C.mp3" data-free="false"></li>
<li data-title="Unit 06 - 02 L1p093 Reading and Talking - F"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/02 L1p093 Reading and Talking - F.mp3" data-free="false"></li>
<li data-title="Unit 06 - 03 L2p095 Grammar and Com - F"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/03 L2p095 Grammar and Com - F.mp3" data-free="false"></li>
<li data-title="Unit 06 - 04 L3p096 Listening and Speaking - A"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/04 L3p096 Listening and Speaking - A.mp3" data-free="false"></li>
<li data-title="Unit 06 - 05 L3p096 Listening and Speaking - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/05 L3p096 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Unit 06 - 06 L3p096 Listening and Speaking - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/06 L3p096 Listening and Speaking - C.mp3" data-free="false"></li>
<li data-title="Unit 06 - 07 L3p097 Listening and Speaking - D"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/07 L3p097 Listening and Speaking - D.mp3" data-free="false"></li>
<li data-title="Unit 06 - 08 L4p098 Writing and Discussing - A"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/08 L4p098 Writing and Discussing - A.mp3" data-free="false"></li>
<li data-title="Unit 06 - 09 L4p098 Writing and Disc - B - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/09 L4p098 Writing and Disc - B - CM.mp3" data-free="false"></li>
<li data-title="Unit 06 - 10 L4p099 Writng and Discussing - D"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/10 L4p099 Writng and Discussing - D.mp3" data-free="false"></li>
<li data-title="Unit 06 - 11 L6p102 Pronunciation - A"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/11 L6p102 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Unit 06 - 12 L6p102 Pronunciation - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/12 L6p102 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Unit 06 - 13 L6p102 Pronunciation - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/13 L6p102 Pronunciation - C.mp3" data-free="false"></li>
<li data-title="Unit 06 - 14 L6p102 Pronunciation - D - CM"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Unit 06/14 L6p102 Pronunciation - D - CM.mp3" data-free="false"></li>
<li data-title="Review 1 - 01 Review 1 - p112 - A"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Review/Review 1/01 Review 1 - p112 - A.mp3" data-free="false"></li>
<li data-title="Review 1 - 02 Review 1 - p112 and 113 - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Review/Review 1/02 Review 1 - p112 and 113 - B.mp3" data-free="false"></li>
<li data-title="Review 1 - 03 Review 1 - p113 - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Review/Review 1/03 Review 1 - p113 - C.mp3" data-free="false"></li>
<li data-title="Review 1 - 04 Review 1 - p113 - D"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Review/Review 1/04 Review 1 - p113 - D.mp3" data-free="false"></li>
<li data-title="Review 2 - 01 Review 2 - p118 - A"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Review/Review 2/01 Review 2 - p118 - A.mp3" data-free="false"></li>
<li data-title="Review 2 - 02 Review 2 - p118 and 119 - B"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Review/Review 2/02 Review 2 - p118 and 119 - B.mp3" data-free="false"></li>
<li data-title="Review 2 - 03 Review 2 - p119 - C"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Review/Review 2/03 Review 2 - p119 - C.mp3" data-free="false"></li>
<li data-title="Review 2 - 04 Review 2 - p119 - D"data-artist="Teens Higher 1"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 1/Review/Review 2/04 Review 2 - p119 - D.mp3" data-free="false"></li>




        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

