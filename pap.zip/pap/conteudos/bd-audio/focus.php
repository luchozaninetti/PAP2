
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Focus</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
        
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Canada - 001. P. 056 - The people and the languages - A multilingual society" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Canada/001. P. 056 - The people and the languages - A multilingual society.mp3" data-free="false"></li>
<li data-title="Canada - 002. P. 057 - The people and the languages - A bit everywhere" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Canada/002. P. 057 - The people and the languages - A bit everywhere.mp3" data-free="false"></li>
<li data-title="Canada - 003. P. 058 - Changing times - Close to nature " data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Canada/003. P. 058 - Changing times - Close to nature .mp3" data-free="false"></li>
<li data-title="Canada - 004. P. 123 - Grammar Review - Verbs - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Canada/004. P. 123 - Grammar Review - Verbs - A.mp3" data-free="false"></li>
<li data-title="Canada - 005. P. 124 - Grammar Review - Verbs - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Canada/005. P. 124 - Grammar Review - Verbs - B.mp3" data-free="false"></li>
<li data-title="Canada - 006. P. 124 - Grammar Review - Verbs - C" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Canada/006. P. 124 - Grammar Review - Verbs - C.mp3" data-free="false"></li>
<li data-title="Canada - 007. P. 124 - Grammar Review - Verbs - D" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Canada/007. P. 124 - Grammar Review - Verbs - D.mp3" data-free="false"></li>
<li data-title="Canada - 008. P. 125 - Grammar Review - Verbs - E" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Canada/008. P. 125 - Grammar Review - Verbs - E.mp3" data-free="false"></li>
<li data-title="Canada - 009. P. 125 - Grammar Review - Verbs - F" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Canada/009. P. 125 - Grammar Review - Verbs - F.mp3" data-free="false"></li>
<li data-title="Canada - 010. P. 059 - Changing times - An alternative lifestyle" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Canada/010. P. 059 - Changing times - An alternative lifestyle.mp3" data-free="false"></li>
<li data-title="Canada - 011. P. 060 - Not for the skeptics - Real story or a tall tale" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Canada/011. P. 060 - Not for the skeptics - Real story or a tall tale.mp3" data-free="false"></li>
<li data-title="Egypt - 001. P. 048 - Women beware - Blame it on culture" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Egypt/001. P. 048 - Women beware - Blame it on culture.mp3" data-free="false"></li>
<li data-title="Egypt - 002. P. 049 - Women beware - Taking chances" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Egypt/002. P. 049 - Women beware - Taking chances.mp3" data-free="false"></li>
<li data-title="Egypt - 003. P. 049 - Women beware - Up to you" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Egypt/003. P. 049 - Women beware - Up to you.mp3" data-free="false"></li>
<li data-title="Egypt - 004. P. 050 - Unveiling the past - Archaeological paradise" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Egypt/004. P. 050 - Unveiling the past - Archaeological paradise.mp3" data-free="false"></li>
<li data-title="Egypt - 005. P. 131 - Grammar Review - Passive voice - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Egypt/005. P. 131 - Grammar Review - Passive voice - A.mp3" data-free="false"></li>
<li data-title="Egypt - 006. P. 131 - Grammar Review - Passive voice - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Egypt/006. P. 131 - Grammar Review - Passive voice - B.mp3" data-free="false"></li>
<li data-title="Egypt - 007. P. 131 - Grammar Review - Passive voice - C" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Egypt/007. P. 131 - Grammar Review - Passive voice - C.mp3" data-free="false"></li>
<li data-title="Egypt - 008. P. 051 - Unveiling the past - Vocabulary expansion - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Egypt/008. P. 051 - Unveiling the past - Vocabulary expansion - A.mp3" data-free="false"></li>
<li data-title="Egypt - 009. P. 052 - Ancient traditions - Belly dance" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Egypt/009. P. 052 - Ancient traditions - Belly dance.mp3" data-free="false"></li>
<li data-title="Egypt - 010. P. 052 - Ancient traditions - Perfume" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Egypt/010. P. 052 - Ancient traditions - Perfume.mp3" data-free="false"></li>
<li data-title="France - 001. P. 107 - Grammar Review - Nouns - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/001. P. 107 - Grammar Review - Nouns - A.mp3" data-free="false"></li>
<li data-title="France - 002. P. 107 - Grammar Review - Nouns - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/002. P. 107 - Grammar Review - Nouns - B.mp3" data-free="false"></li>
<li data-title="France - 003. P. 107 - Grammar Review - Nouns - C" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/003. P. 107 - Grammar Review - Nouns - C.mp3" data-free="false"></li>
<li data-title="France - 004. P. 111 - Grammar Review - Adjectives" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/004. P. 111 - Grammar Review - Adjectives.mp3" data-free="false"></li>
<li data-title="France - 005. P. 041 - What's wrong with that - A bitter taste" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/005. P. 041 - What's wrong with that - A bitter taste.mp3" data-free="false"></li>
<li data-title="France - 006. P. 042 - Portrait of a lifestyle - Arles" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/006. P. 042 - Portrait of a lifestyle - Arles.mp3" data-free="false"></li>
<li data-title="France - 007. P. 042 - Portrait of a lifestyle - Pastis" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/007. P. 042 - Portrait of a lifestyle - Pastis.mp3" data-free="false"></li>
<li data-title="France - 008. P. 042 - Portrait of a lifestyle - P�tanque" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/008. P. 042 - Portrait of a lifestyle - P�tanque.mp3" data-free="false"></li>
<li data-title="France - 009. P. 042 - Portrait of a lifestyle - May Day" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/009. P. 042 - Portrait of a lifestyle - May Day.mp3" data-free="false"></li>
<li data-title="France - 010. P. 043 - Portrait of a lifestyle - Vocabulary expansion" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/010. P. 043 - Portrait of a lifestyle - Vocabulary expansion.mp3" data-free="false"></li>
<li data-title="France - 011. P. 044 - Something is in the air - A scent of flowers" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/011. P. 044 - Something is in the air - A scent of flowers.mp3" data-free="false"></li>
<li data-title="France - 012. P. 044 - Something is in the air - Sense and sensibility" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/012. P. 044 - Something is in the air - Sense and sensibility.mp3" data-free="false"></li>
<li data-title="France - 013. P. 045 - Something is in the air - Don't get me wrong" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/France/013. P. 045 - Something is in the air - Don't get me wrong.mp3" data-free="false"></li>
<li data-title="Italy - 001. P. 088 - Let's party - Confetti and streamers" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Italy/001. P. 088 - Let's party - Confetti and streamers.mp3" data-free="false"></li>
<li data-title="Italy - 002. P. 089 - Let's party - Your turn" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Italy/002. P. 089 - Let's party - Your turn.mp3" data-free="false"></li>
<li data-title="Italy - 003. P. 129 - Grammar Review - Verbs - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Italy/003. P. 129 - Grammar Review - Verbs - A.mp3" data-free="false"></li>
<li data-title="Italy - 004. P. 129 - Grammar Review - Verbs - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Italy/004. P. 129 - Grammar Review - Verbs - B.mp3" data-free="false"></li>
<li data-title="Italy - 005. P. 129 - Grammar Review - Verbs - C" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Italy/005. P. 129 - Grammar Review - Verbs - C.mp3" data-free="false"></li>
<li data-title="Italy - 006. P. 090 - In and out - What a design" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Italy/006. P. 090 - In and out - What a design.mp3" data-free="false"></li>
<li data-title="Italy - 007. P. 116 - Grammar Review - Reflexive pronouns - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Italy/007. P. 116 - Grammar Review - Reflexive pronouns - A.mp3" data-free="false"></li>
<li data-title="Italy - 008. P. 116 - Grammar Review - Reflexive pronouns - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Italy/008. P. 116 - Grammar Review - Reflexive pronouns - B.mp3" data-free="false"></li>
<li data-title="Italy - 009. P. 091 - In and out - Vocabulary expansion" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Italy/009. P. 091 - In and out - Vocabulary expansion.mp3" data-free="false"></li>
<li data-title="Italy - 010. P. 092 - In and out - Trendy cities" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Italy/010. P. 092 - In and out - Trendy cities.mp3" data-free="false"></li>
<li data-title="Italy - 011. P. 092 - A few famous sons - Who am I" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Italy/011. P. 092 - A few famous sons - Who am I.mp3" data-free="false"></li>
<li data-title="Italy - 012. P. 093 - A few famous sons - Who am I" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Italy/012. P. 093 - A few famous sons - Who am I.mp3" data-free="false"></li>
<li data-title="Japan - 001. P. 080 - Sign of the times - Stickers, stamps and photos" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Japan/001. P. 080 - Sign of the times - Stickers, stamps and photos.mp3" data-free="false"></li>
<li data-title="Japan - 002. P. 081 - Sign of the times - Stickers, stamps and photos" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Japan/002. P. 081 - Sign of the times - Stickers, stamps and photos.mp3" data-free="false"></li>
<li data-title="Japan - 003. P. 081 - Sign of the times - Exchanges" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Japan/003. P. 081 - Sign of the times - Exchanges.mp3" data-free="false"></li>
<li data-title="Japan - 004. P. 082 - Sign of the times - Whose choice is this" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Japan/004. P. 082 - Sign of the times - Whose choice is this.mp3" data-free="false"></li>
<li data-title="Japan - 005. P. 083 - Traditions of old - Kimonos" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Japan/005. P. 083 - Traditions of old - Kimonos.mp3" data-free="false"></li>
<li data-title="Japan - 006. P. 083 - Traditions of old - Noh Theater" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Japan/006. P. 083 - Traditions of old - Noh Theater.mp3" data-free="false"></li>
<li data-title="Japan - 007. P. 108 - Grammar Review - Adjectives - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Japan/007. P. 108 - Grammar Review - Adjectives - A.mp3" data-free="false"></li>
<li data-title="Japan - 008. P. 109 - Grammar Review - Adjectives" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Japan/008. P. 109 - Grammar Review - Adjectives.mp3" data-free="false"></li>
<li data-title="Japan - 009. P. 110 - Grammar Review - Adjectives - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Japan/009. P. 110 - Grammar Review - Adjectives - A.mp3" data-free="false"></li>
<li data-title="Japan - 010. P. 084 - Traditions of old - Fold it over" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Japan/010. P. 084 - Traditions of old - Fold it over.mp3" data-free="false"></li>
<li data-title="Japan - 011. P. 084 - Traditions of old - Is that what you mean" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Japan/011. P. 084 - Traditions of old - Is that what you mean.mp3" data-free="false"></li>
<li data-title="Mexico - 001. P. 024 - Let's dance - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/001. P. 024 - Let's dance - A.mp3" data-free="false"></li>
<li data-title="Mexico - 002. P. 024 - Let's dance - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/002. P. 024 - Let's dance - B.mp3" data-free="false"></li>
<li data-title="Mexico - 003. P. 025 - An image problem - Something hot" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/003. P. 025 - An image problem - Something hot.mp3" data-free="false"></li>
<li data-title="Mexico - 004. P. 026 - An image problem - I'm not like that. Or am I" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/004. P. 026 - An image problem - I'm not like that. Or am I.mp3" data-free="false"></li>
<li data-title="Mexico - 005. P. 026 - Cheer up - A celebration" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/005. P. 026 - Cheer up - A celebration.mp3" data-free="false"></li>
<li data-title="Mexico - 006. P. 117 - Grammar Review - Possessive - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/006. P. 117 - Grammar Review - Possessive - A.mp3" data-free="false"></li>
<li data-title="Mexico - 007. P. 117 - Grammar Review - Possessive - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/007. P. 117 - Grammar Review - Possessive - B.mp3" data-free="false"></li>
<li data-title="Mexico - 008. P. 118 - Grammar Review - Possessive - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/008. P. 118 - Grammar Review - Possessive - A.mp3" data-free="false"></li>
<li data-title="Mexico - 009. P. 118 - Grammar Review - Possessive - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/009. P. 118 - Grammar Review - Possessive - B.mp3" data-free="false"></li>
<li data-title="Mexico - 010. P. 027 - Cheer up - I'll be here if you need me" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/010. P. 027 - Cheer up - I'll be here if you need me.mp3" data-free="false"></li>
<li data-title="Mexico - 011. P. 028 - A bit of everything - A bouquet of love" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/011. P. 028 - A bit of everything - A bouquet of love.mp3" data-free="false"></li>
<li data-title="Mexico - 012. P. 028 - A bit of everything - Love apples" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/012. P. 028 - A bit of everything - Love apples.mp3" data-free="false"></li>
<li data-title="Mexico - 013. P. 028 - A bit of everything - Going down and down" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Mexico/013. P. 028 - A bit of everything - Going down and down.mp3" data-free="false"></li>
<li data-title="Netherlands - 001. P. 016 - Is it true" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Netherlands/001. P. 016 - Is it true.mp3" data-free="false"></li>
<li data-title="Netherlands - 002. P. 016 - Beauty and the Beast - A first glance" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Netherlands/002. P. 016 - Beauty and the Beast - A first glance.mp3" data-free="false"></li>
<li data-title="Netherlands - 003. P. 115 - Grammar Review - Relative clauses - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Netherlands/003. P. 115 - Grammar Review - Relative clauses - A.mp3" data-free="false"></li>
<li data-title="Netherlands - 004. P. 115 - Grammar Review - Relative clauses - C" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Netherlands/004. P. 115 - Grammar Review - Relative clauses - C.mp3" data-free="false"></li>
<li data-title="Netherlands - 005. P. 017 - Cheese - A quick peek" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Netherlands/005. P. 017 - Cheese - A quick peek.mp3" data-free="false"></li>
<li data-title="Netherlands - 006. P. 018 - Cheese - An old tradition" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Netherlands/006. P. 018 - Cheese - An old tradition.mp3" data-free="false"></li>
<li data-title="Netherlands - 007. P. 019 - Cheese - I don't agree. Do you - C" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Netherlands/007. P. 019 - Cheese - I don't agree. Do you - C.mp3" data-free="false"></li>
<li data-title="Netherlands - 008. P. 020 - Light and color - Van Gogh" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Netherlands/008. P. 020 - Light and color - Van Gogh.mp3" data-free="false"></li>
<li data-title="Netherlands - 009. P. 020 - Light and color - The right color" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Netherlands/009. P. 020 - Light and color - The right color.mp3" data-free="false"></li>
<li data-title="New Zealand - 001. P. 096 - Pardon" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/New Zealand/001. P. 096 - Pardon.mp3" data-free="false"></li>
<li data-title="New Zealand - 002. P. 096 - To be a New Zealander is... - Aotearoa" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/New Zealand/002. P. 096 - To be a New Zealander is... - Aotearoa.mp3" data-free="false"></li>
<li data-title="New Zealand - 003. P. 097 - To be a New Zealander is... - A kiwi is not a kiwi" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/New Zealand/003. P. 097 - To be a New Zealander is... - A kiwi is not a kiwi.mp3" data-free="false"></li>
<li data-title="New Zealand - 004. P. 098 - Shivers down the spine - I wish I were there" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/New Zealand/004. P. 098 - Shivers down the spine - I wish I were there.mp3" data-free="false"></li>
<li data-title="New Zealand - 005. P. 136 - Grammar Review - Wish - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/New Zealand/005. P. 136 - Grammar Review - Wish - A.mp3" data-free="false"></li>
<li data-title="New Zealand - 006. P. 099 - Shivers down the spine - It's all black" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/New Zealand/006. P. 099 - Shivers down the spine - It's all black.mp3" data-free="false"></li>
<li data-title="New Zealand - 007. P. 099 - Shivers down the spine - Fair play" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/New Zealand/007. P. 099 - Shivers down the spine - Fair play.mp3" data-free="false"></li>
<li data-title="New Zealand - 008. P. 100 - Shivers down the spine - Vocabulary expansion" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/New Zealand/008. P. 100 - Shivers down the spine - Vocabulary expansion.mp3" data-free="false"></li>
<li data-title="New Zealand - 009. P. 100 - Shivers down the spine - Your turn" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/New Zealand/009. P. 100 - Shivers down the spine - Your turn.mp3" data-free="false"></li>
<li data-title="New Zealand - 010. P. 100 - Once upon a time - A good old story" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/New Zealand/010. P. 100 - Once upon a time - A good old story.mp3" data-free="false"></li>
<li data-title="Russia - 001. P. 008 - A royal mystery - The story" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/001. P. 008 - A royal mystery - The story.mp3" data-free="false"></li>
<li data-title="Russia - 002. P. 008 - A royal mystery - The evidence" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/002. P. 008 - A royal mystery - The evidence.mp3" data-free="false"></li>
<li data-title="Russia - 003. P. 009 - A royal mystery - Opinions - Dialogs" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/003. P. 009 - A royal mystery - Opinions - Dialogs.mp3" data-free="false"></li>
<li data-title="Russia - 004. P. 009 - A royal mystery - Opinions - Questions" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/004. P. 009 - A royal mystery - Opinions - Questions.mp3" data-free="false"></li>
<li data-title="Russia - 005. P. 135 - Grammar Review - Indirect questions" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/005. P. 135 - Grammar Review - Indirect questions.mp3" data-free="false"></li>
<li data-title="Russia - 006. P. 010 - Different times, same problem - Vocabulary" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/006. P. 010 - Different times, same problem - Vocabulary.mp3" data-free="false"></li>
<li data-title="Russia - 007. P. 011 - Having one too many - An ambiguous symbol" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/007. P. 011 - Having one too many - An ambiguous symbol.mp3" data-free="false"></li>
<li data-title="Russia - 008. P. 012 - Mosaic - An overview - Food" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/008. P. 012 - Mosaic - An overview - Food.mp3" data-free="false"></li>
<li data-title="Russia - 009. P. 012 - Mosaic - An overview - Nature" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/009. P. 012 - Mosaic - An overview - Nature.mp3" data-free="false"></li>
<li data-title="Russia - 010. P. 013 - Mosaic - An overview - Arts" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/010. P. 013 - Mosaic - An overview - Arts.mp3" data-free="false"></li>
<li data-title="Russia - 011. P. 013 - Mosaic - An overview - Saint Petersburg" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/011. P. 013 - Mosaic - An overview - Saint Petersburg.mp3" data-free="false"></li>
<li data-title="Russia - 012. P. 121 - Grammar Review - Prepositions - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/012. P. 121 - Grammar Review - Prepositions - A.mp3" data-free="false"></li>
<li data-title="Russia - 013. P. 121 - Grammar Review - Prepositions - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/013. P. 121 - Grammar Review - Prepositions - B.mp3" data-free="false"></li>
<li data-title="Russia - 014. P. 122 - Grammar Review - Prepositions - C" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/014. P. 122 - Grammar Review - Prepositions - C.mp3" data-free="false"></li>
<li data-title="Russia - 015. P. 122 - Grammar Review - Prepositions - D" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Russia/015. P. 122 - Grammar Review - Prepositions - D.mp3" data-free="false"></li>
<li data-title="Scotland - 001. P. 065 - About spendthrifts and penny-pinchers - A bit of laugh" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Scotland/001. P. 065 - About spendthrifts and penny-pinchers - A bit of laugh.mp3" data-free="false"></li>
<li data-title="Scotland - 002. P. 066 - About spendthrifts and penny-pinchers - The truth is..." data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Scotland/002. P. 066 - About spendthrifts and penny-pinchers - The truth is....mp3" data-free="false"></li>
<li data-title="Scotland - 003. P. 066 - About spendthrifts and penny-pinchers - Vocabulary expansion" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Scotland/003. P. 066 - About spendthrifts and penny-pinchers - Vocabulary expansion.mp3" data-free="false"></li>
<li data-title="Scotland - 004. P. 112 - Grammar Review - Adjectives - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Scotland/004. P. 112 - Grammar Review - Adjectives - A.mp3" data-free="false"></li>
<li data-title="Scotland - 005. P. 112 - Grammar Review - Adjectives - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Scotland/005. P. 112 - Grammar Review - Adjectives - B.mp3" data-free="false"></li>
<li data-title="Scotland - 006. P. 112 - Grammar Review - Adjectives - C" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Scotland/006. P. 112 - Grammar Review - Adjectives - C.mp3" data-free="false"></li>
<li data-title="Scotland - 007. P. 068 - Not only ball games - Ready to play" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Scotland/007. P. 068 - Not only ball games - Ready to play.mp3" data-free="false"></li>
<li data-title="Scotland - 008. P. 068 - Not only ball games - Your turn" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Scotland/008. P. 068 - Not only ball games - Your turn.mp3" data-free="false"></li>
<li data-title="Scotland - 009. P. 069 - In the spotlight - Two lochs" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Scotland/009. P. 069 - In the spotlight - Two lochs.mp3" data-free="false"></li>
<li data-title="South Africa - 001. P. 073 - The people - Different identities" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/South Africa/001. P. 073 - The people - Different identities.mp3" data-free="false"></li>
<li data-title="South Africa - 002. P. 073 - The people - An ounce of prevention" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/South Africa/002. P. 073 - The people - An ounce of prevention.mp3" data-free="false"></li>
<li data-title="South Africa - 003. P. 074 - The people - Don't mention it" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/South Africa/003. P. 074 - The people - Don't mention it.mp3" data-free="false"></li>
<li data-title="South Africa - 004. P. 075 - Welcome - Beadwork in Zulu culture" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/South Africa/004. P. 075 - Welcome - Beadwork in Zulu culture.mp3" data-free="false"></li>
<li data-title="South Africa - 005. P. 075 - Welcome - Kruger National Park" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/South Africa/005. P. 075 - Welcome - Kruger National Park.mp3" data-free="false"></li>
<li data-title="South Africa - 006. P. 076 - Changes - A country in motion" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/South Africa/006. P. 076 - Changes - A country in motion.mp3" data-free="false"></li>
<li data-title="South Africa - 007. P. 077 - Changes - Vocabulary expansion" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/South Africa/007. P. 077 - Changes - Vocabulary expansion.mp3" data-free="false"></li>
<li data-title="South Africa - 008. P. 133 - Grammar Review - Conditional sentences - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/South Africa/008. P. 133 - Grammar Review - Conditional sentences - A.mp3" data-free="false"></li>
<li data-title="South Africa - 009. P. 133 - Grammar Review - Conditional sentences - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/South Africa/009. P. 133 - Grammar Review - Conditional sentences - B.mp3" data-free="false"></li>
<li data-title="South Africa - 010. P. 134 - Grammar Review - Conditional sentences - D" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/South Africa/010. P. 134 - Grammar Review - Conditional sentences - D.mp3" data-free="false"></li>
<li data-title="South Africa - 011. P. 134 - Grammar Review - Conditional sentences - E" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/South Africa/011. P. 134 - Grammar Review - Conditional sentences - E.mp3" data-free="false"></li>
<li data-title="Turkey - 001. P. 032 - Culture puzzle" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Turkey/001. P. 032 - Culture puzzle.mp3" data-free="false"></li>
<li data-title="Turkey - 002. P. 033 - Putting your foot into your mouth - A cultural matter" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Turkey/002. P. 033 - Putting your foot into your mouth - A cultural matter.mp3" data-free="false"></li>
<li data-title="Turkey - 003. P. 113 - Grammar Review - Some, any and no - A " data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Turkey/003. P. 113 - Grammar Review - Some, any and no - A .mp3" data-free="false"></li>
<li data-title="Turkey - 004. P. 113 - Grammar Review - Some, any and no - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Turkey/004. P. 113 - Grammar Review - Some, any and no - B.mp3" data-free="false"></li>
<li data-title="Turkey - 005. P. 034 - Not just a drink - Black as hell" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Turkey/005. P. 034 - Not just a drink - Black as hell.mp3" data-free="false"></li>
<li data-title="Turkey - 006. P. 034 - Not just a drink - It's written in the coffee - 1" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Turkey/006. P. 034 - Not just a drink - It's written in the coffee - 1.mp3" data-free="false"></li>
<li data-title="Turkey - 007. P. 034 - Not just a drink - It's written in the coffee - 2" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Turkey/007. P. 034 - Not just a drink - It's written in the coffee - 2.mp3" data-free="false"></li>
<li data-title="Turkey - 008. P. 126 - Grammar Review - Verbs - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Turkey/008. P. 126 - Grammar Review - Verbs - A.mp3" data-free="false"></li>
<li data-title="Turkey - 009. P. 127 - Grammar Review - Verbs - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Turkey/009. P. 127 - Grammar Review - Verbs - B.mp3" data-free="false"></li>
<li data-title="Turkey - 010. P. 127 - Grammar Review - Verbs - C" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Turkey/010. P. 127 - Grammar Review - Verbs - C.mp3" data-free="false"></li>
<li data-title="Turkey - 011. P. 036 - The places - A few landmarks" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Turkey/011. P. 036 - The places - A few landmarks.mp3" data-free="false"></li>
<li data-title="Turkey - 012. P. 037 - The places - Guessing game" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Turkey/012. P. 037 - The places - Guessing game.mp3" data-free="false"></li>
<li data-title="Set 1 - 001. S1 - Part I - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 1/001. S1 - Part I - A.mp3" data-free="false"></li>
<li data-title="Set 1 - 002. S1 - Part I - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 1/002. S1 - Part I - B.mp3" data-free="false"></li>
<li data-title="Set 1 - 003. S1 - Part II" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 1/003. S1 - Part II.mp3" data-free="false"></li>
<li data-title="Set 2 - 001. S2 - Part I - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 2/001. S2 - Part I - A.mp3" data-free="false"></li>
<li data-title="Set 2 - 002. S2 - Part I - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 2/002. S2 - Part I - B.mp3" data-free="false"></li>
<li data-title="Set 2 - 003. S2 - Part II" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 2/003. S2 - Part II.mp3" data-free="false"></li>
<li data-title="Set 3 - 001. S3 - Part I - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 3/001. S3 - Part I - A.mp3" data-free="false"></li>
<li data-title="Set 3 - 002. S3 - Part I - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 3/002. S3 - Part I - B.mp3" data-free="false"></li>
<li data-title="Set 3 - 003. S3 - Part II" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 3/003. S3 - Part II.mp3" data-free="false"></li>
<li data-title="Set 4 - 001. S4 - Part I - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 4/001. S4 - Part I - A.mp3" data-free="false"></li>
<li data-title="Set 4 - 002. S4 - Part I - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 4/002. S4 - Part I - B.mp3" data-free="false"></li>
<li data-title="Set 4 - 003. S4 - Part II" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 4/003. S4 - Part II.mp3" data-free="false"></li>
<li data-title="Set 5 - 001. S5 - Part I - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 5/001. S5 - Part I - A.mp3" data-free="false"></li>
<li data-title="Set 5 - 002. S5 - Part I - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 5/002. S5 - Part I - B.mp3" data-free="false"></li>
<li data-title="Set 5 - 003. S5 - Part II" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 5/003. S5 - Part II.mp3" data-free="false"></li>
<li data-title="Set 6 - 001. S6 - Part I - A" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 6/001. S6 - Part I - A.mp3" data-free="false"></li>
<li data-title="Set 6 - 002. S6 - Part I - B" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 6/002. S6 - Part I - B.mp3" data-free="false"></li>
<li data-title="Sets of Pratice Tests/Set 6 - 003. S6 - Part II" data-artist="Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Focus/Sets of Pratice Tests/Set 6/003. S6 - Part II.mp3" data-free="false"></li>


	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
