
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Latitudes 1 - Cahier 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
          
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->

<li data-title="03 Lat 1 Cahier - 01 Intro" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/01 Intro.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 02 Module 1 Unite 1 Exercice 1" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/02 Module 1 Unite 1 Exercice 1.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 03 Module 1 Unite 1 Exercice 3" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/03 Module 1 Unite 1 Exercice 3.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 04 Module 1 Unite 1 Exercice 5" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/04 Module 1 Unite 1 Exercice 5.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 05 Module 1 Unite 1 Exercice 8" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/05 Module 1 Unite 1 Exercice 8.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 07 Module 1 Unite 1 Exercice 11" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/07 Module 1 Unite 1 Exercice 11.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 08 Module 1 Unite 1 Exercice 20" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/08 Module 1 Unite 1 Exercice 20.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 09 Module 1 Unite 1 Exercice 21" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/09 Module 1 Unite 1 Exercice 21.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 10 Module 1 Unite 1 Exercice 22" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/10 Module 1 Unite 1 Exercice 22.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 11 Module 1 Unite 1 Exercice 23" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/11 Module 1 Unite 1 Exercice 23.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 12 Module 1 Unite 1 Exercice 24" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/12 Module 1 Unite 1 Exercice 24.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 13 Module 1 Unite 1Exercice 25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/13 Module 1 Unite 1Exercice 25.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 14 Module 1 Unite 2 Exercice 1" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/14 Module 1 Unite 2 Exercice 1.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 15 Module 1 Unite 2 Exercice 14" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/15 Module 1 Unite 2 Exercice 14.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 16 Module 1 Unite 2 Exercice 19" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/16 Module 1 Unite 2 Exercice 19.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 17 Module 1 Unite 2 Exercice 23" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/17 Module 1 Unite 2 Exercice 23.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 18 Module 1 Unite 2 Exercice 25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/18 Module 1 Unite 2 Exercice 25.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 19 Module 1 Unite 3 Exercice 4" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/19 Module 1 Unite 3 Exercice 4.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 20 Module 1 Unite 3 Exercice 6" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/20 Module 1 Unite 3 Exercice 6.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 21 Module 1 Unite 3 Exercice 10" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/21 Module 1 Unite 3 Exercice 10.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 22 Module 1 Unite 3 Exercice 13" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/22 Module 1 Unite 3 Exercice 13.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 23 Module 1 Unite 3 Exercice 27" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/23 Module 1 Unite 3 Exercice 27.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 24 Module 2 Unite 4 Exercice 5" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/24 Module 2 Unite 4 Exercice 5.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 25 Module 2 Unite 4 Exercice 6" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/25 Module 2 Unite 4 Exercice 6.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 26 Module 2 Unite 4 Exercice 17" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/26 Module 2 Unite 4 Exercice 17.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 27 Module 2 Unite 4 Exercice 20" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/27 Module 2 Unite 4 Exercice 20.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 28 Module 2 Unite 4 Exercice 22" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/28 Module 2 Unite 4 Exercice 22.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 29 Module 2 Unite 4 Exercice 23" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/29 Module 2 Unite 4 Exercice 23.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 30 Module 2 Unite 4 Exercice 24" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/30 Module 2 Unite 4 Exercice 24.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 31 Module 2 Unite 4 Exercice 25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/31 Module 2 Unite 4 Exercice 25.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 32 Module 2 Unite 5 Exercice 1" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/32 Module 2 Unite 5 Exercice 1.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 33 Module 2 Unite 5 Exercice 4" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/33 Module 2 Unite 5 Exercice 4.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 34 Module 2 Unite 5 Exercice 8" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/34 Module 2 Unite 5 Exercice 8.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 35 Module 2 Unite 5 Exercice 10" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/35 Module 2 Unite 5 Exercice 10.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 36 Module 2 Unite 5 Exercice 17" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/36 Module 2 Unite 5 Exercice 17.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 37 Module 2 Unite 5 Exercice 22" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/37 Module 2 Unite 5 Exercice 22.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 38 Module 2 Unite 5 Exercice 25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/38 Module 2 Unite 5 Exercice 25.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 39 Module 2 Unite 5 Exercice 28" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/39 Module 2 Unite 5 Exercice 28.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 40 Module 2 Unite 5 Exercice 30" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/40 Module 2 Unite 5 Exercice 30.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 41 Module 2 Unite 6 Exercice 7" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/41 Module 2 Unite 6 Exercice 7.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 42 Module 2 Unite 6 Exercice 25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/42 Module 2 Unite 6 Exercice 25.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 43 Module 2 Unite 6 Exercice 28" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/43 Module 2 Unite 6 Exercice 28.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 44 Module 2 Unite 6 Exercice 29" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/44 Module 2 Unite 6 Exercice 29.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 45 Module 2 Unite 6 Exercice 30" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/45 Module 2 Unite 6 Exercice 30.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 46 Module 3 Unite 7 Exercice 5" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/46 Module 3 Unite 7 Exercice 5.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 47 Module 3 Unite 7 Exercice 12" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/47 Module 3 Unite 7 Exercice 12.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 48 Module 3 Unite 7 Exercice 18" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/48 Module 3 Unite 7 Exercice 18.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 49 Module 3 Unite 7 Exercice 21" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/49 Module 3 Unite 7 Exercice 21.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 50 Module 3 Unite 7 Exercice 25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/50 Module 3 Unite 7 Exercice 25.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 51 Module 3 Unite 7 Exercice 26" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/51 Module 3 Unite 7 Exercice 26.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 52 Module 3 Unite 7 Exercice 27a" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/52 Module 3 Unite 7 Exercice 27a.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 53 Module 3 Unite 7 Exercice 27b" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/53 Module 3 Unite 7 Exercice 27b.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 54 Module 3 Unite 7 Exercice 28" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/54 Module 3 Unite 7 Exercice 28.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 55 Module 3 Unite 8 Exercice 1" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/55 Module 3 Unite 8 Exercice 1.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 56 Module 3 Unite 8 Exercice 5" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/56 Module 3 Unite 8 Exercice 5.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 57 Module 3 Unite 8 Exercice 7" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/57 Module 3 Unite 8 Exercice 7.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 58 Module 3 Unite 8 Exercice 11" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/58 Module 3 Unite 8 Exercice 11.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 59 Module 3 Unite 8 Exercice 22" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/59 Module 3 Unite 8 Exercice 22.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 60 Module 3 Unite 8 Exercice 23" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/60 Module 3 Unite 8 Exercice 23.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 61 Module 3 Unite 8 Exercice 25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/61 Module 3 Unite 8 Exercice 25.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 62 Module 3 Unite 8 Exercice 26" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/62 Module 3 Unite 8 Exercice 26.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 63 Module 3 Unite 9 Exercice 2" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/63 Module 3 Unite 9 Exercice 2.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 64 Module 3 Unite 9 Exercice 5" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/64 Module 3 Unite 9 Exercice 5.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 65 Module 3 Unite 9 Exercice 20" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/65 Module 3 Unite 9 Exercice 20.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 66 Module 3 Unite 9 Exercice 21" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/66 Module 3 Unite 9 Exercice 21.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 67 Module 3 Unite 9 Exercice 24" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/67 Module 3 Unite 9 Exercice 24.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 68 Module 3 Unite 9 Exercice 25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/68 Module 3 Unite 9 Exercice 25.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 69 Module 3 Unite 9 Exercice 26" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/69 Module 3 Unite 9 Exercice 26.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 70 Module 4 Unite 10 Exercice 1" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/70 Module 4 Unite 10 Exercice 1.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 71 Module 4 Unite 10 Exercice 4" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/71 Module 4 Unite 10 Exercice 4.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 72 Module 4 Unite 10 Exercice 5" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/72 Module 4 Unite 10 Exercice 5.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 73 Module 4 Unite 10 Exercice 12" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/73 Module 4 Unite 10 Exercice 12.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 74 Module 4 Unite 10 Exercice 15" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/74 Module 4 Unite 10 Exercice 15.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 75 Module 4 Unite 10 Exercice 17" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/75 Module 4 Unite 10 Exercice 17.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 76 Module 4 Unite 10 Exercice 25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/76 Module 4 Unite 10 Exercice 25.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 77 Module 4 Unite 10 Exercice 26" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/77 Module 4 Unite 10 Exercice 26.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 78 Module 4 Unite 10 Exercice 27" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/78 Module 4 Unite 10 Exercice 27.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 79 Module 4 Unite 11 Exercice 4" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/79 Module 4 Unite 11 Exercice 4.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 80 Module 4 Unite 11 Exercice 11" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/80 Module 4 Unite 11 Exercice 11.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 81 Module 4 Unite 11 Exercice 15" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/81 Module 4 Unite 11 Exercice 15.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 82 Module 4 Unite 11 Exercice 20" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/82 Module 4 Unite 11 Exercice 20.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 83 Module 4 Unite 11 Exercice 21" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/83 Module 4 Unite 11 Exercice 21.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 84 Module 4 Unite 11 Exercice 22" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/84 Module 4 Unite 11 Exercice 22.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 85 Module 4 Unite 12 Exercice 7" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/85 Module 4 Unite 12 Exercice 7.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 86 Module 4 Unite 12 Exercice 11" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/86 Module 4 Unite 12 Exercice 11.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 87 Module 4 Unite 12 Exercice 16" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/87 Module 4 Unite 12 Exercice 16.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 88 Module 4 Unite 12 Exercice 23" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/88 Module 4 Unite 12 Exercice 23.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 89 Module 4 Unite 12 Exercice 24" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/89 Module 4 Unite 12 Exercice 24.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 90 Module 4 Unite 12 Exercice 25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/90 Module 4 Unite 12 Exercice 25.mp3" data-free="false"></li>
<li data-title="03 Lat 1 Cahier - 91 Module 4 Unite 12 Exercice 26" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/03 Lat 1 Cahier/91 Module 4 Unite 12 Exercice 26.mp3" data-free="false"></li>



	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

