
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Espa�ol Inmediato 3</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">

            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="LECCION 1 - 01 L01 MC P03 PUNTO DE PARTIDA" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 1/01 L01 MC P03 PUNTO DE PARTIDA.mp3" data-free="false"></li>
<li data-title="LECCION 1 - 02 L01 P07 PUNTO DE VISTA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 1/02 L01 P07 PUNTO DE VISTA A.mp3" data-free="false"></li>
<li data-title="LECCION 1 - 03 L01 P08 A TODA MARCHA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 1/03 L01 P08 A TODA MARCHA A.mp3" data-free="false"></li>
<li data-title="LECCION 1 - 04 L01 MC P05 A TODA MARCHA H" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 1/04 L01 MC P05 A TODA MARCHA H.mp3" data-free="false"></li>
<li data-title="LECCION 1 - 05 L01 P12 PUNTO DE LLEGADA B" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 1/05 L01 P12 PUNTO DE LLEGADA B.mp3" data-free="false"></li>
<li data-title="LECCION 1 - 06 L01 MC P06 PUNTO DE LLEGADA D" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 1/06 L01 MC P06 PUNTO DE LLEGADA D.mp3" data-free="false"></li>
<li data-title="LECCION 1 - 07 L01 P13 PUNTO DE LLEGADA E" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 1/07 L01 P13 PUNTO DE LLEGADA E.mp3" data-free="false"></li>
<li data-title="LECCION 2 - 01 L02 MC P08 PUNTO DE PARTIDA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 2/01 L02 MC P08 PUNTO DE PARTIDA A.mp3" data-free="false"></li>
<li data-title="LECCION 2 - 02 L02 P15 PUNTO DE VISTA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 2/02 L02 P15 PUNTO DE VISTA A.mp3" data-free="false"></li>
<li data-title="LECCION 2 - 03 L02 P16 A TODA MARCHA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 2/03 L02 P16 A TODA MARCHA A.mp3" data-free="false"></li>
<li data-title="LECCION 2 - 04 L02 MC P10 Y 11 A TODA MARCHA D" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 2/04 L02 MC P10 Y 11 A TODA MARCHA D.mp3" data-free="false"></li>
<li data-title="LECCION 2 - 05 L02 MC P11 A TODA MARCHA F" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 2/05 L02 MC P11 A TODA MARCHA F.mp3" data-free="false"></li>
<li data-title="LECCION 2 - 06 L02 MC P12 A TODA MARCHA I" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 2/06 L02 MC P12 A TODA MARCHA I.mp3" data-free="false"></li>
<li data-title="LECCION 2 - 07 L02 P20 PUNTO DE LLEGADA B" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 2/07 L02 P20 PUNTO DE LLEGADA B.mp3" data-free="false"></li>
<li data-title="LECCION 2 - 08 L02 P20 PUNTO DE LLEGADA D" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 2/08 L02 P20 PUNTO DE LLEGADA D.mp3" data-free="false"></li>
<li data-title="LECCION 2 - 09 L02 P21 PUNTO DE LLEGADA E" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 2/09 L02 P21 PUNTO DE LLEGADA E.mp3" data-free="false"></li>
<li data-title="LECCION 3 - 01 L03 MC P14 PUNTO DE PARTIDA B" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 3/01 L03 MC P14 PUNTO DE PARTIDA B.mp3" data-free="false"></li>
<li data-title="LECCION 3 - 02 L03 P23 PUNTO DE VISTA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 3/02 L03 P23 PUNTO DE VISTA A.mp3" data-free="false"></li>
<li data-title="LECCION 3 - 03 L03 P24 A TODA MARCHA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 3/03 L03 P24 A TODA MARCHA A.mp3" data-free="false"></li>
<li data-title="LECCION 3 - 04 L03 MC P16 A TODA MARCHA F" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 3/04 L03 MC P16 A TODA MARCHA F.mp3" data-free="false"></li>
<li data-title="LECCION 3 - 05 L03 MC P16 A TODA MARCHA G" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 3/05 L03 MC P16 A TODA MARCHA G.mp3" data-free="false"></li>
<li data-title="LECCION 3 - 06 L03 P27 A TODA MARCHA H" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 3/06 L03 P27 A TODA MARCHA H.mp3" data-free="false"></li>
<li data-title="LECCION 3 - 07 L03 P28 PUNTO DE LLEGADA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 3/07 L03 P28 PUNTO DE LLEGADA A.mp3" data-free="false"></li>
<li data-title="LECCION 3 - 08 L03 MC P17 PUNTO DE LLEGADA C" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 3/08 L03 MC P17 PUNTO DE LLEGADA C.mp3" data-free="false"></li>
<li data-title="LECCION 3 - 09 L03 P29 PUNTO DE LLEGADA D" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 3/09 L03 P29 PUNTO DE LLEGADA D.mp3" data-free="false"></li>
<li data-title="LECCION 4 - 01 L04 MC P19 PUNTO DE PARTIDA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 4/01 L04 MC P19 PUNTO DE PARTIDA A.mp3" data-free="false"></li>
<li data-title="LECCION 4 - 02 L04 P31 PUNTO DE VISTA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 4/02 L04 P31 PUNTO DE VISTA A.mp3" data-free="false"></li>
<li data-title="LECCION 4 - 03 L04 P32 A TODA MARCHA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 4/03 L04 P32 A TODA MARCHA A.mp3" data-free="false"></li>
<li data-title="LECCION 4 - 04 L04 MC P21 A TODA MARCHA D" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 4/04 L04 MC P21 A TODA MARCHA D.mp3" data-free="false"></li>
<li data-title="LECCION 4 - 05 L04 P36 Y 37 PUNTO DE LLEGADA B, C Y D" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 4/05 L04 P36 Y 37 PUNTO DE LLEGADA B, C Y D.mp3" data-free="false"></li>
<li data-title="LECCION 4 - 06 L04 P37 PUNTO DE LLEGADA E" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 4/06 L04 P37 PUNTO DE LLEGADA E.mp3" data-free="false"></li>
<li data-title="LECCION 5 - 01 L05 MC P24 PUNTO DE PARTIDA B" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 5/01 L05 MC P24 PUNTO DE PARTIDA B.mp3" data-free="false"></li>
<li data-title="LECCION 5 - 02 L05 P39 PUNTO DE VISTA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 5/02 L05 P39 PUNTO DE VISTA A.mp3" data-free="false"></li>
<li data-title="LECCION 5 - 03 L05 P40 A TODA MARCHA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 5/03 L05 P40 A TODA MARCHA A.mp3" data-free="false"></li>
<li data-title="LECCION 5 - 04 L05 MC P25 A TODA MARCHA B" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 5/04 L05 MC P25 A TODA MARCHA B.mp3" data-free="false"></li>
<li data-title="LECCION 5 - 05 L05 P44 PUNTO DE LLEGADA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 5/05 L05 P44 PUNTO DE LLEGADA A.mp3" data-free="false"></li>
<li data-title="LECCION 5 - 06 L05 MC P28 PUNTO DE LLEGADA D" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 5/06 L05 MC P28 PUNTO DE LLEGADA D.mp3" data-free="false"></li>
<li data-title="LECCION 5 - 07 L05 P45 PUNTO DE LLEGADA E" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 5/07 L05 P45 PUNTO DE LLEGADA E.mp3" data-free="false"></li>
<li data-title="LECCION 6 - 01 L06 P49 PUNTO DE VISTA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 6/01 L06 P49 PUNTO DE VISTA A.mp3" data-free="false"></li>
<li data-title="LECCION 6 - 02 L06 P50 A TODA MARCHA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 6/02 L06 P50 A TODA MARCHA A.mp3" data-free="false"></li>
<li data-title="LECCION 6 - 03 L06 MC P32 Y 33 A TODA MARCHA F" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 6/03 L06 MC P32 Y 33 A TODA MARCHA F.mp3" data-free="false"></li>
<li data-title="LECCION 6 - 04 L06 P52 A TODA MARCHA G" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 6/04 L06 P52 A TODA MARCHA G.mp3" data-free="false"></li>
<li data-title="LECCION 6 - 05 L06 MC P34 A TODA MARCHA K" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 6/05 L06 MC P34 A TODA MARCHA K.mp3" data-free="false"></li>
<li data-title="LECCION 6 - 06 L06 P54 PUNTO DE LLEGADA B" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 6/06 L06 P54 PUNTO DE LLEGADA B.mp3" data-free="false"></li>
<li data-title="LECCION 6 - 07 L06 P54 PUNTO DE LLEGADA C" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 6/07 L06 P54 PUNTO DE LLEGADA C.mp3" data-free="false"></li>
<li data-title="LECCION 6 - 08 L06 MC P35 Y 36 PUNTO DE LLEGADA F" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 6/08 L06 MC P35 Y 36 PUNTO DE LLEGADA F.mp3" data-free="false"></li>
<li data-title="LECCION 6 - 09 L06 MC P36 Y 37 PUNTO DE LLEGADA G" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 6/09 L06 MC P36 Y 37 PUNTO DE LLEGADA G.mp3" data-free="false"></li>
<li data-title="LECCION 7 - 01 L07 MC P38 PUNTO DE PARTIDA B" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 7/01 L07 MC P38 PUNTO DE PARTIDA B.mp3" data-free="false"></li>
<li data-title="LECCION 7 - 02 L07 P57 PUNTO DE VISTA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 7/02 L07 P57 PUNTO DE VISTA A.mp3" data-free="false"></li>
<li data-title="LECCION 7 - 03 L07 P58 A TODA MARCHA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 7/03 L07 P58 A TODA MARCHA A.mp3" data-free="false"></li>
<li data-title="LECCION 7 - 04 L07 P60 A TODA MARCHA H" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 7/04 L07 P60 A TODA MARCHA H.mp3" data-free="false"></li>
<li data-title="LECCION 7 - 05 L07 MC P41 A TODA MARCHA K" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 7/05 L07 MC P41 A TODA MARCHA K.mp3" data-free="false"></li>
<li data-title="LECCION 7 - 06 L07 MC P41 A TODA MARCHA L" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 7/06 L07 MC P41 A TODA MARCHA L.mp3" data-free="false"></li>
<li data-title="LECCION 7 - 07 L07 P62 PUNTO DE LLEGADA B" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 7/07 L07 P62 PUNTO DE LLEGADA B.mp3" data-free="false"></li>
<li data-title="LECCION 7 - 08 L07 MC P42 PUNTO DE LLEGADA D" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 7/08 L07 MC P42 PUNTO DE LLEGADA D.mp3" data-free="false"></li>
<li data-title="LECCION 8 - 01 L08 P65 PUNTO DE VISTA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 8/01 L08 P65 PUNTO DE VISTA A.mp3" data-free="false"></li>
<li data-title="LECCION 8 - 02 L08 P66 A TODA MARCHA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 8/02 L08 P66 A TODA MARCHA A.mp3" data-free="false"></li>
<li data-title="LECCION 8 - 03 L08 P67 A TODA MARCHA C" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 8/03 L08 P67 A TODA MARCHA C.mp3" data-free="false"></li>
<li data-title="LECCION 8 - 04 L08 MC P44 A TODA MARCHA E" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 8/04 L08 MC P44 A TODA MARCHA E.mp3" data-free="false"></li>
<li data-title="LECCION 8 - 05 L08 MC P45 A TODA MARCHA J" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 8/05 L08 MC P45 A TODA MARCHA J.mp3" data-free="false"></li>
<li data-title="LECCION 8 - 06 L08 P70 PUNTO DE LLEGADA B" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 8/06 L08 P70 PUNTO DE LLEGADA B.mp3" data-free="false"></li>
<li data-title="LECCION 8 - 07 L08 P71 PUNTO DE LLEGADA C" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 8/07 L08 P71 PUNTO DE LLEGADA C.mp3" data-free="false"></li>
<li data-title="LECCION 9 - 01 L09 P73 PUNTO DE VISTA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 9/01 L09 P73 PUNTO DE VISTA A.mp3" data-free="false"></li>
<li data-title="LECCION 9 - 02 L09 P74 A TODA MARCHA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 9/02 L09 P74 A TODA MARCHA A.mp3" data-free="false"></li>
<li data-title="LECCION 9 - 03 L09 P76 A TODA MARCHA F" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 9/03 L09 P76 A TODA MARCHA F.mp3" data-free="false"></li>
<li data-title="LECCION 9 - 04 L09 P76 A TODA MARCHA G" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 9/04 L09 P76 A TODA MARCHA G.mp3" data-free="false"></li>
<li data-title="LECCION 9 - 05 L09 MC P49 Y 50 A TODA MARCHA J" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 9/05 L09 MC P49 Y 50 A TODA MARCHA J.mp3" data-free="false"></li>
<li data-title="LECCION 9 - 06 L09 P78 PUNTO DE LLEGADA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 9/06 L09 P78 PUNTO DE LLEGADA A.mp3" data-free="false"></li>
<li data-title="LECCION 9 - 07 L09 P78 PUNTO DE LLEGADA D" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 9/07 L09 P78 PUNTO DE LLEGADA D.mp3" data-free="false"></li>
<li data-title="LECCION 9 - 08 L09 MC P51 PUNTO DE LLEGADA F" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 9/08 L09 MC P51 PUNTO DE LLEGADA F.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 01 L10 P81 PUNTO DE VISTA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 10/01 L10 P81 PUNTO DE VISTA A.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 02 L10 P82 A TODA MARCHA A" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 10/02 L10 P82 A TODA MARCHA A.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 03 L10 MC P54 A TODA MARCHA D" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 10/03 L10 MC P54 A TODA MARCHA D.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 04 L10 P84 A TODA MARCHA E" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 10/04 L10 P84 A TODA MARCHA E.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 05 L10 P85 A TODA MARCHA H" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 10/05 L10 P85 A TODA MARCHA H.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 06 L10 MC P56 A TODA MARCHA J" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 10/06 L10 MC P56 A TODA MARCHA J.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 07 L10 P86 PUNTO DE LLEGADA A Y B" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 10/07 L10 P86 PUNTO DE LLEGADA A Y B.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 08 L10 P87 PUNTO DE LLEGADA E" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 10/08 L10 P87 PUNTO DE LLEGADA E.mp3" data-free="false"></li>
<li data-title="LECCION 10 - 09 L10 MC P57 PUNTO DE LLEGADA H" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/LECCION 10/09 L10 MC P57 PUNTO DE LLEGADA H.mp3" data-free="false"></li>
<li data-title="PRACTICA PARA EL EXAMEN FINAL - 01 PRACTICA P156 TAREA 1" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/PRACTICA PARA EL EXAMEN FINAL/01 PRACTICA P156 TAREA 1.mp3" data-free="false"></li>
<li data-title="PRACTICA PARA EL EXAMEN FINAL - 02 PRACTICA P156 TAREA 2" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/PRACTICA PARA EL EXAMEN FINAL/02 PRACTICA P156 TAREA 2.mp3" data-free="false"></li>
<li data-title="PRACTICA PARA EL EXAMEN FINAL - 03 PRACTICA P157 TAREA 3" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/PRACTICA PARA EL EXAMEN FINAL/03 PRACTICA P157 TAREA 3.mp3" data-free="false"></li>
<li data-title="PRACTICA PARA EL EXAMEN FINAL - 04 PRACTICA P157 TAREA 4" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/PRACTICA PARA EL EXAMEN FINAL/04 PRACTICA P157 TAREA 4.mp3" data-free="false"></li>
<li data-title="PRACTICA PARA EL EXAMEN FINAL - 05 PRACTICA P158 TAREA 5" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/PRACTICA PARA EL EXAMEN FINAL/05 PRACTICA P158 TAREA 5.mp3" data-free="false"></li>
<li data-title="PRACTICA PARA EL EXAMEN FINAL - 06 PRACTICA P159 TAREA 6" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/PRACTICA PARA EL EXAMEN FINAL/06 PRACTICA P159 TAREA 6.mp3" data-free="false"></li>
<li data-title="ENSAYO PARA EL EXAMEN FINAL - 01 ENSAYO TAREA 1" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/TEST DE ESCUCHA/ENSAYO PARA EL EXAMEN FINAL/01 ENSAYO TAREA 1.mp3" data-free="false"></li>
<li data-title="ENSAYO PARA EL EXAMEN FINAL - 02 ENSAYO TAREA 2" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/TEST DE ESCUCHA/ENSAYO PARA EL EXAMEN FINAL/02 ENSAYO TAREA 2.mp3" data-free="false"></li>
<li data-title="ENSAYO PARA EL EXAMEN FINAL - 03 ENSAYO TAREA 3" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/TEST DE ESCUCHA/ENSAYO PARA EL EXAMEN FINAL/03 ENSAYO TAREA 3.mp3" data-free="false"></li>
<li data-title="ENSAYO PARA EL EXAMEN FINAL - 04 ENSAYO TAREA 4" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/TEST DE ESCUCHA/ENSAYO PARA EL EXAMEN FINAL/04 ENSAYO TAREA 4.mp3" data-free="false"></li>
<li data-title="ENSAYO PARA EL EXAMEN FINAL - 05 ENSAYO TAREA 5" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/TEST DE ESCUCHA/ENSAYO PARA EL EXAMEN FINAL/05 ENSAYO TAREA 5.mp3" data-free="false"></li>
<li data-title="ENSAYO PARA EL EXAMEN FINAL - 06 ENSAYO TAREA 6" data-artist="Espanhol Inmediato 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanol Inmediato 3/TEST DE ESCUCHA/ENSAYO PARA EL EXAMEN FINAL/06 ENSAYO TAREA 6.mp3" data-free="false"></li>



	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

