
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Big Box 3</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
          
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->

<li data-title="01   Introduction, page 06, STORY   WELCOME" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/01   Introduction, page 06, STORY   WELCOME.mp3" data-free="false"></li>
<li data-title="02   Lesson 01, page 08, STORY   I LOVE PETS" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/02   Lesson 01, page 08, STORY   I LOVE PETS.mp3" data-free="false"></li>
<li data-title="03   Lesson 01, page 09, LISTEN AND POINT" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/03   Lesson 01, page 09, LISTEN AND POINT.mp3" data-free="false"></li>
<li data-title="04   Lesson 01, page 11,  WHOOP IT UP" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/04   Lesson 01, page 11,  WHOOP IT UP.mp3" data-free="false"></li>
<li data-title="05   Lesson 01, page 11, LISTEN AND CROSS" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/05   Lesson 01, page 11, LISTEN AND CROSS.mp3" data-free="false"></li>
<li data-title="06   Lesson 02, page 14, STORY   IN A TOY STORE" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/06   Lesson 02, page 14, STORY   IN A TOY STORE.mp3" data-free="false"></li>
<li data-title="07   Lesson 02, page 15,  LISTEN, COLOR, AND CROSS" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/07   Lesson 02, page 15,  LISTEN, COLOR, AND CROSS.mp3" data-free="false"></li>
<li data-title="08   Lesson 02, page 17, WHOOP IT UP!" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/08   Lesson 02, page 17, WHOOP IT UP!.mp3" data-free="false"></li>
<li data-title="09   Lesson 02, page 17, LISTEN, SAY, AND STICK" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/09   Lesson 02, page 17, LISTEN, SAY, AND STICK.mp3" data-free="false"></li>
<li data-title="10   Lesson 03, page 20,  STORY   ITS BEACH TIME" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/10   Lesson 03, page 20,  STORY   ITS BEACH TIME.mp3" data-free="false"></li>
<li data-title="11   Lesson 03, page 21, LISTEN AND DRAW" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/11   Lesson 03, page 21, LISTEN AND DRAW.mp3" data-free="false"></li>
<li data-title="12   Lesson 03, page 23,  WHOOP IT UP" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/12   Lesson 03, page 23,  WHOOP IT UP.mp3" data-free="false"></li>
<li data-title="13   Lesson 03, page 23,  STICK, LISTEN, AND NUMBER" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/13   Lesson 03, page 23,  STICK, LISTEN, AND NUMBER.mp3" data-free="false"></li>
<li data-title="14   Lesson 04, page 26,  STORY   THATS MY TOWN" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/14   Lesson 04, page 26,  STORY   THATS MY TOWN.mp3" data-free="false"></li>
<li data-title="15   Lesson 04, page 27,  LISTEN AND STICK" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/15   Lesson 04, page 27,  LISTEN AND STICK.mp3" data-free="false"></li>
<li data-title="16   Lesson 04, page 29,  WHOOP IT UP" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/16   Lesson 04, page 29,  WHOOP IT UP.mp3" data-free="false"></li>
<li data-title="17   Lesson 04, page 29,  LISTEN AND SAY" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/17   Lesson 04, page 29,  LISTEN AND SAY.mp3" data-free="false"></li>
<li data-title="18   Lesson 05, page 32,  STORY   IN A COOKING CLASS" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/18   Lesson 05, page 32,  STORY   IN A COOKING CLASS.mp3" data-free="false"></li>
<li data-title="19   Lesson 05, page 33,  LISTEN AND NUMBER" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/19   Lesson 05, page 33,  LISTEN AND NUMBER.mp3" data-free="false"></li>
<li data-title="20   Lesson 05, page 35, WHOOP IT UP" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/20   Lesson 05, page 35, WHOOP IT UP.mp3" data-free="false"></li>
<li data-title="21   Lesson 05, page 35, LISTEN AND CROSS" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/21   Lesson 05, page 35, LISTEN AND CROSS.mp3" data-free="false"></li>
<li data-title="22   Lesson 06, page 38,  STORY   GOING ON A PICNIC" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/22   Lesson 06, page 38,  STORY   GOING ON A PICNIC.mp3" data-free="false"></li>
<li data-title="23   Lesson 06, page 39, LISTEN AND CIRCLE" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/23   Lesson 06, page 39, LISTEN AND CIRCLE.mp3" data-free="false"></li>
<li data-title="24   Lesson 06, page 41,  WHOOP IT UP!" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/24   Lesson 06, page 41,  WHOOP IT UP!.mp3" data-free="false"></li>
<li data-title="25   Lesson 06, page 41,  LISTEN AND MATCH" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/25   Lesson 06, page 41,  LISTEN AND MATCH.mp3" data-free="false"></li>
<li data-title="26   Lesson 07, page 44,  STORY   ON THE MINI FARM" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/26   Lesson 07, page 44,  STORY   ON THE MINI FARM.mp3" data-free="false"></li>
<li data-title="27   Lesson 07, page 45,  LISTEN, LOOK, AND COLOR" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/27   Lesson 07, page 45,  LISTEN, LOOK, AND COLOR.mp3" data-free="false"></li>
<li data-title="28   Lesson 07, page 47,  WHOOP IT UP" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/28   Lesson 07, page 47,  WHOOP IT UP.mp3" data-free="false"></li>
<li data-title="29   Lesson 07, page 47,  LISTEN, POINT, AND STICK" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/29   Lesson 07, page 47,  LISTEN, POINT, AND STICK.mp3" data-free="false"></li>
<li data-title="30   Lesson 08, page 50,  STORY   LET'S PLAY AND DANCE" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/30   Lesson 08, page 50,  STORY   LET'S PLAY AND DANCE.mp3" data-free="false"></li>
<li data-title="31   Lesson 08, page 51,  LISTEN AND CIRCLE" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/31   Lesson 08, page 51,  LISTEN AND CIRCLE.mp3" data-free="false"></li>
<li data-title="32   Lesson 08, page 53,  WHOOP IT UP" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/32   Lesson 08, page 53,  WHOOP IT UP.mp3" data-free="false"></li>
<li data-title="33   Lesson 08, page 53, LISTEN AND CROSS" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/33   Lesson 08, page 53, LISTEN AND CROSS.mp3" data-free="false"></li>
<li data-title="34   Lesson 09, page 56,  STORY   ON THE SHOPPING LIST" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/34   Lesson 09, page 56,  STORY   ON THE SHOPPING LIST.mp3" data-free="false"></li>
<li data-title="35   Lesson 09, page 57,  LISTEN AND CIRCLE" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/35   Lesson 09, page 57,  LISTEN AND CIRCLE.mp3" data-free="false"></li>
<li data-title="36   Lesson 09, page 59, WHOOP IT UP" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/36   Lesson 09, page 59, WHOOP IT UP.mp3" data-free="false"></li>
<li data-title="37   Lesson 09, page 59,  LISTEN AND COLOR" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/37   Lesson 09, page 59,  LISTEN AND COLOR.mp3" data-free="false"></li>
<li data-title="38   Lesson 10, page 62,  STORY   IS YOUR HOUSE BIG" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/38   Lesson 10, page 62,  STORY   IS YOUR HOUSE BIG.mp3" data-free="false"></li>
<li data-title="39   Lesson 10, page 63,  LISTEN, COLOR, AND DRAW" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/39   Lesson 10, page 63,  LISTEN, COLOR, AND DRAW.mp3" data-free="false"></li>
<li data-title="40   Lesson 10, page 65,  WHOOP IT UP" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/40   Lesson 10, page 65,  WHOOP IT UP.mp3" data-free="false"></li>
<li data-title="41   Lesson 10, page 65,  LISTEN, POINT, AND CIRCLE" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/41   Lesson 10, page 65,  LISTEN, POINT, AND CIRCLE.mp3" data-free="false"></li>
<li data-title="42   Lesson 11, page 68,  STORY   HAVING BREAKFAST" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/42   Lesson 11, page 68,  STORY   HAVING BREAKFAST.mp3" data-free="false"></li>
<li data-title="43   Lesson 11, page 69,  LISTEN AND MATCH" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/43   Lesson 11, page 69,  LISTEN AND MATCH.mp3" data-free="false"></li>
<li data-title="44   Lesson 11, page 71,  WHOOP IT UP" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/44   Lesson 11, page 71,  WHOOP IT UP.mp3" data-free="false"></li>
<li data-title="45   Lesson 11, page 71, LISTEN AND CROSS" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/45   Lesson 11, page 71, LISTEN AND CROSS.mp3" data-free="false"></li>
<li data-title="46   Lesson 12, page 74,  STORY   PLAYING HOUSE" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/46   Lesson 12, page 74,  STORY   PLAYING HOUSE.mp3" data-free="false"></li>
<li data-title="47   Lesson 12, page 75, LISTEN, SAY, AND GLUE" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/47   Lesson 12, page 75, LISTEN, SAY, AND GLUE.mp3" data-free="false"></li>
<li data-title="48   Lesson 12, page 77,  WHOOP IT UP" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/48   Lesson 12, page 77,  WHOOP IT UP.mp3" data-free="false"></li>
<li data-title="49   Lesson 12, page 77,  LISTEN AND CIRCLE" data-artist="Big Box 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Big Box 3/49   Lesson 12, page 77,  LISTEN AND CIRCLE.mp3" data-free="false"></li>


	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
