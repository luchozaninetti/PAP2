
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Intermediate</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
           
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Break Time 3 - 01. BreakTime3-p.82-Game(CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Break Time 3/01. BreakTime3-p.82-Game(CM).mp3" data-free="false"></li>
<li data-title="Break Time 4 - 01. BreakTime4-p.106-Game(CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Break Time 4/01. BreakTime4-p.106-Game(CM).mp3" data-free="false"></li>
<li data-title="Clear Com. 1 - 01. ClearCom.1-p.22-L&S-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Clear Com. 1/01. ClearCom.1-p.22-L&S-B.mp3" data-free="false"></li>
<li data-title="Clear Com. 1 - 02. ClearCom.1-p.23-R&S-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Clear Com. 1/02. ClearCom.1-p.23-R&S-A.mp3" data-free="false"></li>
<li data-title="Clear Com. 2 - 01. ClearCom.2-p.46-L&S-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Clear Com. 2/01. ClearCom.2-p.46-L&S-A.mp3" data-free="false"></li>
<li data-title="Clear Com. 2 - 02. ClearCom.2-p.47-R&S-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Clear Com. 2/02. ClearCom.2-p.47-R&S-A.mp3" data-free="false"></li>
<li data-title="Clear Com. 3 - 01. ClearCom.3-p.76-L&S-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Clear Com. 3/01. ClearCom.3-p.76-L&S-B.mp3" data-free="false"></li>
<li data-title="Clear Com. 3 - 02. ClearCom.3-p.77-R&S-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Clear Com. 3/02. ClearCom.3-p.77-R&S-B.mp3" data-free="false"></li>
<li data-title="Clear Com. 4 - 01. ClearCom.4-p.100-L&S-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Clear Com. 4/01. ClearCom.4-p.100-L&S-A.mp3" data-free="false"></li>
<li data-title="Clear Com. 4 - 02. ClearCom.4-p.101-R&S-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Clear Com. 4/02. ClearCom.4-p.101-R&S-A.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 01. L.1-p.06-Interacting-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 1/01. L.1-p.06-Interacting-A.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 02. L.1-p.06-Interacting-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 1/02. L.1-p.06-Interacting-B.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 03. L.1-p.07-Interacting-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 1/03. L.1-p.07-Interacting-D.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 04. L.1-p.08-Now I know!-B(CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 1/04. L.1-p.08-Now I know!-B(CM).mp3" data-free="false"></li>
<li data-title="Lesson 1 - 05. L.1-p.09-Now I know!-F"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 1/05. L.1-p.09-Now I know!-F.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 06. L.1-p.10-The right words-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 1/06. L.1-p.10-The right words-A.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 07. L.1-p.10-The right words-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 1/07. L.1-p.10-The right words-B.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 08. L.1-p.12-Say it naturally-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 1/08. L.1-p.12-Say it naturally-A.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 09. L.1-p.12-Say it naturally-B(CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 1/09. L.1-p.12-Say it naturally-B(CM).mp3" data-free="false"></li>
<li data-title="Lesson 1 - 10. L.1-p.13-What comes next-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 1/10. L.1-p.13-What comes next-A.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 01. L.2-p.14-Interacting-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 2/01. L.2-p.14-Interacting-A.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 02. L.2-p.14-Interacting-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 2/02. L.2-p.14-Interacting-B.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 03. L.2-p.15-Interacting-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 2/03. L.2-p.15-Interacting-D.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 04. L.2-p.17-Now I know!-E(CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 2/04. L.2-p.17-Now I know!-E(CM).mp3" data-free="false"></li>
<li data-title="Lesson 2 - 05. L.2-p.17-Now I know!-F"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 2/05. L.2-p.17-Now I know!-F.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 06. L.2-p.18-The right words-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 2/06. L.2-p.18-The right words-A.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 07. L.2-p.19-The right words-C(CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 2/07. L.2-p.19-The right words-C(CM).mp3" data-free="false"></li>
<li data-title="Lesson 2 - 08. L.2-p.19-The right words-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 2/08. L.2-p.19-The right words-D.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 09. L.2-p.20-Say it naturally-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 2/09. L.2-p.20-Say it naturally-A.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 10. L.2-p.21-What comes next-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 2/10. L.2-p.21-What comes next-A.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 01. L.3-p.30-Interacting-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 3/01. L.3-p.30-Interacting-A.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 02. L.3-p.30-Interacting-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 3/02. L.3-p.30-Interacting-B.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 03. L.3-p.31-Interacting-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 3/03. L.3-p.31-Interacting-D.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 04. L.3-p.32-Now I know!-C(CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 3/04. L.3-p.32-Now I know!-C(CM).mp3" data-free="false"></li>
<li data-title="Lesson 3 - 05. L.3-p.33-Now I know!-F"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 3/05. L.3-p.33-Now I know!-F.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 06. L.3-p.34-The right words-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 3/06. L.3-p.34-The right words-A.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 07. L.3-p.34-The right words-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 3/07. L.3-p.34-The right words-B.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 08. L.3-p.36-Say it naturally-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 3/08. L.3-p.36-Say it naturally-A.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 09. L.3-p.37-What comes next-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 3/09. L.3-p.37-What comes next-A.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 01. L.4-p.38-Interacting-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 4/01. L.4-p.38-Interacting-A.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 02. L.4-p.38-Interacting-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 4/02. L.4-p.38-Interacting-B.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 03. L.4-p.39-Interacting-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 4/03. L.4-p.39-Interacting-D.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 04. L.4-p.41-Now I know!-E(CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 4/04. L.4-p.41-Now I know!-E(CM).mp3" data-free="false"></li>
<li data-title="Lesson 4 - 05. L.4-p.41-Now I know!-F"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 4/05. L.4-p.41-Now I know!-F.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 06. L.4-p.42-The right words-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 4/06. L.4-p.42-The right words-A.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 07. L.4-p.43-The right words-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 4/07. L.4-p.43-The right words-D.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 08. L.4-p.44-Say it naturally-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 4/08. L.4-p.44-Say it naturally-A.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 09. L.4-p.45-What comes next-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 4/09. L.4-p.45-What comes next-A.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 01. L.5-p.60-Interacting-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 5/01. L.5-p.60-Interacting-A.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 02. L.5-p.60-Interacting-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 5/02. L.5-p.60-Interacting-B.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 03. L.5-p.61-Interacting-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 5/03. L.5-p.61-Interacting-D.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 04. L.5-p.62-Now I know!-C(CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 5/04. L.5-p.62-Now I know!-C(CM).mp3" data-free="false"></li>
<li data-title="Lesson 5 - 05. L.5-p.62-Now I know!-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 5/05. L.5-p.62-Now I know!-D.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 06. L.5-p.63-Now I know!-G(CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 5/06. L.5-p.63-Now I know!-G(CM).mp3" data-free="false"></li>
<li data-title="Lesson 5 - 07. L.5-p.64-The right words-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 5/07. L.5-p.64-The right words-A.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 08. L.5-p.65-The right words-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 5/08. L.5-p.65-The right words-D.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 09. L.5-p.66-Say it naturally-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 5/09. L.5-p.66-Say it naturally-A.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 10. L.5-p.67-What comes next-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 5/10. L.5-p.67-What comes next-A.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 01. L.6-p.68-Interacting-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 6/01. L.6-p.68-Interacting-A.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 02. L.6-p.68-Interacting-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 6/02. L.6-p.68-Interacting-B.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 03. L.6-p.69-Interacting-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 6/03. L.6-p.69-Interacting-D.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 04. L.6-p.70-Now I know!-C (CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 6/04. L.6-p.70-Now I know!-C (CM).mp3" data-free="false"></li>
<li data-title="Lesson 6 - 05. L.6-p.71-Now I know!-F"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 6/05. L.6-p.71-Now I know!-F.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 06. L.6-p.72-The right words-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 6/06. L.6-p.72-The right words-A.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 07. L.6-p.72-The right words-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 6/07. L.6-p.72-The right words-B.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 08. L.6-p.74-Say it naturally-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 6/08. L.6-p.74-Say it naturally-A.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 09. L.6-p.75-What comes next-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 6/09. L.6-p.75-What comes next-A.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 01. L.7-p.84-Interacting-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 7/01. L.7-p.84-Interacting-A.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 02. L.7-p.84-Interacting-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 7/02. L.7-p.84-Interacting-B.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 03. L.7-p.85-Interacting-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 7/03. L.7-p.85-Interacting-D.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 04. L.7-p.86-Now I know!-C"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 7/04. L.7-p.86-Now I know!-C.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 05. L.7-p.88-The right words-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 7/05. L.7-p.88-The right words-A.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 06. L.7-p.89-The right words-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 7/06. L.7-p.89-The right words-D.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 07. L.7-p.90-Say it naturally-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 7/07. L.7-p.90-Say it naturally-A.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 08. L.7-p.91-What comes next-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 7/08. L.7-p.91-What comes next-A.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 01. L.8-p.92-Interacting-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 8/01. L.8-p.92-Interacting-A.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 02. L.8-p.92-Interacting-B"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 8/02. L.8-p.92-Interacting-B.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 03. L.8-p.93-Interacting-D"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 8/03. L.8-p.93-Interacting-D.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 04. L.8-p.94-Now I know!-C(CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 8/04. L.8-p.94-Now I know!-C(CM).mp3" data-free="false"></li>
<li data-title="Lesson 8 - 05. L.8-p.95-Now I know!-E(CM)"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 8/05. L.8-p.95-Now I know!-E(CM).mp3" data-free="false"></li>
<li data-title="Lesson 8 - 06. L.8-p.95-Now I know!-F"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 8/06. L.8-p.95-Now I know!-F.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 07. L.8-p.96-The right words-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 8/07. L.8-p.96-The right words-A.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 08. L.8-p.97-The right words-C"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 8/08. L.8-p.97-The right words-C.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 09. L.8-p.98-Say it naturally-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 8/09. L.8-p.98-Say it naturally-A.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 10. L.8-p.99-What comes next-A"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Lesson 8/10. L.8-p.99-What comes next-A.mp3" data-free="false"></li>
<li data-title="Review 1 - 01. Review1-A - p.58"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Review 1/01. Review1-A - p.58.mp3" data-free="false"></li>
<li data-title="Review 1 - 02. Review1-B - p.58"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Review 1/02. Review1-B - p.58.mp3" data-free="false"></li>
<li data-title="Review 1 - 03. Review1-C - p.59"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Review 1/03. Review1-C - p.59.mp3" data-free="false"></li>
<li data-title="Review 1 - 04. Review1-D - p.59"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Review 1/04. Review1-D - p.59.mp3" data-free="false"></li>
<li data-title="Review 2 - 01. Review2-A - p.112"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Review 2/01. Review2-A - p.112.mp3" data-free="false"></li>
<li data-title="Review 2 - 02. Review2-B - p.112"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Review 2/02. Review2-B - p.112.mp3" data-free="false"></li>
<li data-title="Review 2 - 03. Review2-C - p.113"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Review 2/03. Review2-C - p.113.mp3" data-free="false"></li>
<li data-title="Review 2 - 04. Review2-D - p.113"data-artist="Teens Intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Intermediate/Review 2/04. Review2-D - p.113.mp3" data-free="false"></li>




        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
