
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Saison 2.1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
        
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
<li data-title="Saison 2 - Unite 0 - b. MF - Piste 1" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 0/b. MF - Piste 1.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 0 - c. Cahier - Piste 1 - Activite 3" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 0/c. Cahier - Piste 1 - Activite 3.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 0 - d. Cahier - Piste 2 - Activite 5" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 0/d. Cahier - Piste 2 - Activite 5.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 0 - e. MF - Piste 2" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 0/e. MF - Piste 2.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 0 - f. Cahier - Piste 3 - Activite 12" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 0/f. Cahier - Piste 3 - Activite 12.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 0 - g. MF - Piste 3" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 0/g. MF - Piste 3.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 0 - h. MF - Piste 4" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 0/h. MF - Piste 4.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 0 - i. Cahier - Piste 4 - Activite 16" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 0/i. Cahier - Piste 4 - Activite 16.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 0 - j. Cahier - Piste 5 - Activite 18" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 0/j. Cahier - Piste 5 - Activite 18.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - b. MF - Piste 5" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/b. MF - Piste 5.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - c. MF - Piste 6" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/c. MF - Piste 6.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - d. Cahier - Piste 6 - Activite 2" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/d. Cahier - Piste 6 - Activite 2.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - e. Cahier - Piste 7 - Activite 3" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/e. Cahier - Piste 7 - Activite 3.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - f. Cahier - Piste 10 - Activite 19" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/f. Cahier - Piste 10 - Activite 19.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - g. MF - Piste 7" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/g. MF - Piste 7.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - h. MF - Piste 8" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/h. MF - Piste 8.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - i. Cahier - Piste 8 - Activite 13" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/i. Cahier - Piste 8 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - j. Cahier - Piste 9 - Activite 16" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/j. Cahier - Piste 9 - Activite 16.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - k. MF - Piste 9" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/k. MF - Piste 9.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - l. MF - Piste 10" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/l. MF - Piste 10.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - m. MF - Piste 11" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/m. MF - Piste 11.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - n. MF - Piste 12" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/n. MF - Piste 12.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - o. Cahier - Piste 11 - Activite 25" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/o. Cahier - Piste 11 - Activite 25.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 1 - p. MF - DELF A2 - Unite 1" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 1/p. MF - DELF A2 - Unite 1.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - b. MF - Piste 13" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/b. MF - Piste 13.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - c. MF - Piste 14" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/c. MF - Piste 14.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - d. Cahier - Piste 12 - Activite 2" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/d. Cahier - Piste 12 - Activite 2.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - e. Cahier - Piste 13 - Activite 7" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/e. Cahier - Piste 13 - Activite 7.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - f. Cahier - Piste 15 - Activite 13" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/f. Cahier - Piste 15 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - g. Cahier - Piste 14 - Activite 10" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/g. Cahier - Piste 14 - Activite 10.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - h. MF - Piste 15" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/h. MF - Piste 15.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - i. MF - Piste 16" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/i. MF - Piste 16.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - j. Cahier - Piste 16 - Activite 22" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/j. Cahier - Piste 16 - Activite 22.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - k. MF - Piste 17" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/k. MF - Piste 17.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - l. MF - Piste 18" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/l. MF - Piste 18.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - m. MF - Piste 19" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/m. MF - Piste 19.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - n. Cahier - Piste 17 - Activite 25" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/n. Cahier - Piste 17 - Activite 25.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 2 - o. MF - DELF A2 - Unite 2" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 2/o. MF - DELF A2 - Unite 2.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - b. MF - Piste 21" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/b. MF - Piste 21.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - c. MF - Piste 22" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/c. MF - Piste 22.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - d. MF - Piste 23" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/d. MF - Piste 23.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - e. Cahier - Piste 18 - Activite 3" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/e. Cahier - Piste 18 - Activite 3.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - f. Cahier - Piste 19 - Activite 10" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/f. Cahier - Piste 19 - Activite 10.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - g. Cahier - Piste 20 - Activite 13" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/g. Cahier - Piste 20 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - h. MF - Piste 24" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/h. MF - Piste 24.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - i. MF - Piste 25" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/i. MF - Piste 25.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - j. Cahier - Piste 21 - Activite 22" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/j. Cahier - Piste 21 - Activite 22.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - k. MF - Piste 26" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/k. MF - Piste 26.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - l. MF - Piste 27" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/l. MF - Piste 27.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - m. MF - Piste 28" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/m. MF - Piste 28.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - n. Cahier - Piste 22 - Activite 7 - Bilan" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/n. Cahier - Piste 22 - Activite 7 - Bilan.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 3 - o. MF - DELF A2 - Unite 3" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 3/o. MF - DELF A2 - Unite 3.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - b. MF - Piste 30" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/b. MF - Piste 30.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - c. MF - Piste 31" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/c. MF - Piste 31.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - d. Cahier - Piste 23 - Activite 3" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/d. Cahier - Piste 23 - Activite 3.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - e. Cahier - Piste 24 - Activite 7" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/e. Cahier - Piste 24 - Activite 7.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - f. Cahier - Piste 28 - Activite 15" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/f. Cahier - Piste 28 - Activite 15.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - g. Cahier - Piste 29 - Activite 16" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/g. Cahier - Piste 29 - Activite 16.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - h. Cahier - Piste 25 - Activite 10" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/h. Cahier - Piste 25 - Activite 10.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - i. Cahier - Piste 26 - Activite 12" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/i. Cahier - Piste 26 - Activite 12.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - j. Cahier - Piste 27 - Activite 13" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/j. Cahier - Piste 27 - Activite 13.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - k. Cahier - Piste 30 - Activite 19" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/k. Cahier - Piste 30 - Activite 19.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - l. MF - Piste 32" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/l. MF - Piste 32.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - m. MF - Piste 33" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/m. MF - Piste 33.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - n. MF - Piste 34" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/n. MF - Piste 34.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - o. MF - Piste 35" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/o. MF - Piste 35.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - p. MF - Piste 36" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/p. MF - Piste 36.mp3" data-free="false"></li>
<li data-title="Saison 2 - Unite 4 - q. MF - DELF A2 - Unite 4" data-artist="Saison 2" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 2/Saison 2.1/Saison 2 - Unite 4/q. MF - DELF A2 - Unite 4.mp3" data-free="false"></li>

	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

