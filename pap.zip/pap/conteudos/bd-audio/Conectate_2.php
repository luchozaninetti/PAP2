
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Conectate 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
   
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->

<li data-title="Modulo 1 - 01. Modulo1 Unidad1 p06 E1" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 01/01. Modulo1 Unidad1 p06 E1.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 02. Modulo1 Unidad1 p06 Ej1 pregunta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 01/02. Modulo1 Unidad1 p06 Ej1 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 03. Modulo1 Unidad1 p07 Ej2" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 01/03. Modulo1 Unidad1 p07 Ej2.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 04. Modulo1 Unidad1 p09 Ej5" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 01/04. Modulo1 Unidad1 p09 Ej5.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 05. Modulo1 Unidad1 p09 Ej5 pregunta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 01/05. Modulo1 Unidad1 p09 Ej5 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 06. Modulo1 Unidad1 p11 Ej7" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 01/06. Modulo1 Unidad1 p11 Ej7.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 07. Modulo1 Unidad1 p11 Ej9" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 01/07. Modulo1 Unidad1 p11 Ej9.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 08. Modulo1 Unidad1 p12 Ej10" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 01/08. Modulo1 Unidad1 p12 Ej10.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 09. Modulo1 Unidad1 p13 Ej14_1" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 01/09. Modulo1 Unidad1 p13 Ej14_1.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 10. Modulo1 Unidad1 p13 Ej14_2" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 01/10. Modulo1 Unidad1 p13 Ej14_2.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 11. Modulo1 Unidad1 p13 Ej14 pregunta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 01/11. Modulo1 Unidad1 p13 Ej14 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 12. Juega con los sonidos p17" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 01/12. Juega con los sonidos p17.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 01. Modulo1 Unidad2 p18 Ej1" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 02/01. Modulo1 Unidad2 p18 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 02. Modulo1 Unidad2 p21 Ej5" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 02/02. Modulo1 Unidad2 p21 Ej5.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 03. Modulo1 Unidad2 p21 Ej5 pregunta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 02/03. Modulo1 Unidad2 p21 Ej5 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 04. Modulo1 Unidad2 p23 Ej9" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 02/04. Modulo1 Unidad2 p23 Ej9.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 05. Modulo1 Unidad2 p23 Ej9 pregunta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 02/05. Modulo1 Unidad2 p23 Ej9 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 06. Modulo1 Unidad2 p24 Ej11" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 02/06. Modulo1 Unidad2 p24 Ej11.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 07. Modulo1 Unidad2  p24 Ej12" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 02/07. Modulo1 Unidad2  p24 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 08. Modulo1 Unidad2 p25 Ej13" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 02/08. Modulo1 Unidad2 p25 Ej13.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 09. Juega con los sonidos p30" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 02/09. Juega con los sonidos p30.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 01. Modulo1 Unidad3 p31 Ej1" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 03/01. Modulo1 Unidad3 p31 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 02. Modulo1 Unidad3 p31 Ej1 pregunta" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 03/02. Modulo1 Unidad3 p31 Ej1 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 03. Modulo1 Unidad3 p32 Ej2" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 03/03. Modulo1 Unidad3 p32 Ej2.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 04. Modulo1 Unidad3 p34 Ej3" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 03/04. Modulo1 Unidad3 p34 Ej3.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 05. Modulo1 Unidad3 p34 Ej4" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 03/05. Modulo1 Unidad3 p34 Ej4.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 06. Modulo1 Unidad3 p35 Ej5" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 03/06. Modulo1 Unidad3 p35 Ej5.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 07. Modulo1 Unidad3 p36 Ej8" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 03/07. Modulo1 Unidad3 p36 Ej8.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 08. Modulo1 Unidad3 p37 Ej9" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 03/08. Modulo1 Unidad3 p37 Ej9.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 09. Modulo1 Unidad3 p38 Ej11" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 03/09. Modulo1 Unidad3 p38 Ej11.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 10. Modulo1 Unidad3 p38 Ej12" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 03/10. Modulo1 Unidad3 p38 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 11. Juega con los sonidos p43" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 03/11. Juega con los sonidos p43.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 01. Modulo1 Unidad4 p44 Ej1" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 04/01. Modulo1 Unidad4 p44 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 02. Mdulo1 Unidad4 p46 Ej4" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 04/02. Mdulo1 Unidad4 p46 Ej4.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 03. Modulo1 Unidad4 p47 Ej5" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 04/03. Modulo1 Unidad4 p47 Ej5.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 04. Modulo1 Unidad4 p47 Ej7" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 04/04. Modulo1 Unidad4 p47 Ej7.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 05. Modulo1 Unidad4 p49 Ej9" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 04/05. Modulo1 Unidad4 p49 Ej9.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 06. Modulo1 Unidad4 p50 Ej12" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 04/06. Modulo1 Unidad4 p50 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 1 - 07. Modulo1 Unidad4 p50 Ej13" data-artist="Modulo 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 1/Unidad 04/07. Modulo1 Unidad4 p50 Ej13.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 01. Modulo2 Unidad5 p54 Ej1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 05/01. Modulo2 Unidad5 p54 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 02. Modulo2 Unidad5 p57 Ej8" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 05/02. Modulo2 Unidad5 p57 Ej8.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 03. Modulo2 Unidad5 p57 Ej9" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 05/03. Modulo2 Unidad5 p57 Ej9.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 04. Modulo2 Unidad5 p58 Ej11 dialogo1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 05/04. Modulo2 Unidad5 p58 Ej11 dialogo1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 05. Modulo2 Unidad5 p58 Ej11 dialogo2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 05/05. Modulo2 Unidad5 p58 Ej11 dialogo2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 06. Modulo2 Unidad5 p58 Ej11 dialogo3" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 05/06. Modulo2 Unidad5 p58 Ej11 dialogo3.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 07. Modulo2 Unidad5 p58 Ej11 dialogo4" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 05/07. Modulo2 Unidad5 p58 Ej11 dialogo4.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 08. Modulo2 Unidad5 p58 Ej12" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 05/08. Modulo2 Unidad5 p58 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 09. Juega con los sonidos p64" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 05/09. Juega con los sonidos p64.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 01. Modulo2 Unidad6 p65 Ej1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/01. Modulo2 Unidad6 p65 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 02. Modulo2 Unidad6 p68 Ej8" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/02. Modulo2 Unidad6 p68 Ej8.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 03. Modulo2 Unidad6 p68 Ej8 pregunta" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/03. Modulo2 Unidad6 p68 Ej8 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 04. Modulo2 Unidad6 p68 Ej9" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/04. Modulo2 Unidad6 p68 Ej9.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 05. Modulo2 Unidad6 p69 Ej11" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/05. Modulo2 Unidad6 p69 Ej11.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 06. Modulo2 Unidad6 p70 Ej12" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/06. Modulo2 Unidad6 p70 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 07. Modulo2 Unidad6 p71 Ej14" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/07. Modulo2 Unidad6 p71 Ej14.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 08. Modulo2 Unidad6 p71 Ej14 pregunta" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/08. Modulo2 Unidad6 p71 Ej14 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 09. Modulo2 Unidad6 p71 Ej15 memoria1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/09. Modulo2 Unidad6 p71 Ej15 memoria1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 10. Modulo2 Unidad6 p71 Ej15 memoria 2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/10. Modulo2 Unidad6 p71 Ej15 memoria 2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 11. Modulo2 Unidad6 p71 Ej15 memoria3" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/11. Modulo2 Unidad6 p71 Ej15 memoria3.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 12. Modulo2 Unidad6 p71 Ej15 memoria4" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/12. Modulo2 Unidad6 p71 Ej15 memoria4.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 13. Modulo2 Unidad6 p71 Ej16 casilla1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/13. Modulo2 Unidad6 p71 Ej16 casilla1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 14. Modulo2 Unidad6 p71 Ej16 casilla2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/14. Modulo2 Unidad6 p71 Ej16 casilla2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 15. Modulo2 Unidad6 p71 Ej16 casilla3" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/15. Modulo2 Unidad6 p71 Ej16 casilla3.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 16. Modulo2 Unidad6 p71 Ej16 casilla4" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/16. Modulo2 Unidad6 p71 Ej16 casilla4.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 17. Modulo2 Unidad6 p71 Ej16 casilla5" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/17. Modulo2 Unidad6 p71 Ej16 casilla5.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 18. Modulo2 Unidad6 p71 Ej16 casilla6" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/18. Modulo2 Unidad6 p71 Ej16 casilla6.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 19. Modulo2 Unidad6 p71 Ej16 casilla1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/19. Modulo2 Unidad6 p71 Ej16 casilla1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 20. Modulo2 Unidad6 p71 Ej16 casilla2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/20. Modulo2 Unidad6 p71 Ej16 casilla2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 21. Modulo2 Unidad6 p71 Ej16 casilla3" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/21. Modulo2 Unidad6 p71 Ej16 casilla3.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 22. Modulo2 Unidad6 p71 Ej16 casilla4" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/22. Modulo2 Unidad6 p71 Ej16 casilla4.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 23. Modulo2 Unidad6 p71 Ej16 casilla5" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/23. Modulo2 Unidad6 p71 Ej16 casilla5.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 24. Juega con los sonidos p75" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 06/24. Juega con los sonidos p75.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 01. Modulo2 Unidad7 p76 Ej1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 07/01. Modulo2 Unidad7 p76 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 02. Modulo2 Unidad7 p76 Ej1 contesta" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 07/02. Modulo2 Unidad7 p76 Ej1 contesta.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 03. Modulo2 Unidad7 p78 Ej2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 07/03. Modulo2 Unidad7 p78 Ej2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 04. Modulo2 Unidad7 p80 Ej5" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 07/04. Modulo2 Unidad7 p80 Ej5.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 05. Modulo2 Unidad7 p80 Ej5 pregunta" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 07/05. Modulo2 Unidad7 p80 Ej5 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 06. Modulo2 Unidad7 p80 Ej6" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 07/06. Modulo2 Unidad7 p80 Ej6.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 07. Modulo2 Unidad7 p80 Ej7" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 07/07. Modulo2 Unidad7 p80 Ej7.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 08. Modulo2 Unidad7 p83 Ej9" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 07/08. Modulo2 Unidad7 p83 Ej9.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 09. Modulo2 Unidad7 p83 Ej10" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 07/09. Modulo2 Unidad7 p83 Ej10.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 10. Modulo2 Unidad7 p83 Ej10 pregunta" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 07/10. Modulo2 Unidad7 p83 Ej10 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 11. Modulo2 Unidad7 p85 Ej12" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 07/11. Modulo2 Unidad7 p85 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 12. Juega con los sonidos p91" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 07/12. Juega con los sonidos p91.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 01. Modulo2 Unidad8 p92 Ej1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 08/01. Modulo2 Unidad8 p92 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 02. Modulo2 Unidad8 p94 Ej5" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 08/02. Modulo2 Unidad8 p94 Ej5.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 03. Modulo2 Unidad8 p95 Ej6_1" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 08/03. Modulo2 Unidad8 p95 Ej6_1.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 04. Modulo2 Unidad8 p95 Ej6_2" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 08/04. Modulo2 Unidad8 p95 Ej6_2.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 05. Modulo2 Unidad8 p96 Ej7" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 08/05. Modulo2 Unidad8 p96 Ej7.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 06. Modulo2 Unidad8 p97 Ej8" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 08/06. Modulo2 Unidad8 p97 Ej8.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 07. Modulo2 Unidad8 p98 Ej10" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 08/07. Modulo2 Unidad8 p98 Ej10.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 08. Modulo2 Unidad8 p98 Ej12" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 08/08. Modulo2 Unidad8 p98 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 09. Modulo2 Unidad8 p98 Ej12" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 08/09. Modulo2 Unidad8 p98 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 2 - 10. Modulo2 Unidad8 p98 Ej12" data-artist="Modulo 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 2/Unidad 08/10. Modulo2 Unidad8 p98 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 01. Modulo3 Unidad9 p102 Ej1" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 09/01. Modulo3 Unidad9 p102 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 02. Modulo3  Unidad9 p103 Ej3" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 09/02. Modulo3  Unidad9 p103 Ej3.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 03. Modulo3 Unidad9 p106 Ej6" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 09/03. Modulo3 Unidad9 p106 Ej6.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 04. Modulo3 Unidad9 p106 Ej7" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 09/04. Modulo3 Unidad9 p106 Ej7.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 05. Modulo3 Unidad9 p107 Ej8" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 09/05. Modulo3 Unidad9 p107 Ej8.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 06. Modulo3 Unidad9 p108 Ej10" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 09/06. Modulo3 Unidad9 p108 Ej10.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 07. Modulo3 Unidad9 p109 Ej11" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 09/07. Modulo3 Unidad9 p109 Ej11.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 08. Modulo3 Unidad9 p109 Ej13" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 09/08. Modulo3 Unidad9 p109 Ej13.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 09. Modulo3 Unidad9 p109 Ej13 pregunta" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 09/09. Modulo3 Unidad9 p109 Ej13 pregunta.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 10. Juega con los sonidos p115" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 09/10. Juega con los sonidos p115.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 01. Modulo3 Unidad10 p116 Ej1" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 10/01. Modulo3 Unidad10 p116 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 02. Modulo3 Unidad10 p117 Ej3" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 10/02. Modulo3 Unidad10 p117 Ej3.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 03. Modulo3 Unidad10 p118 Ej5" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 10/03. Modulo3 Unidad10 p118 Ej5.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 04. Modulo3 Unidad10 p118 Ej6" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 10/04. Modulo3 Unidad10 p118 Ej6.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 05. Modulo3 Unidad10 p120 Ej10" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 10/05. Modulo3 Unidad10 p120 Ej10.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 06. Modulo3 Unidad10 p121 Ej11" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 10/06. Modulo3 Unidad10 p121 Ej11.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 07. Modulo3 Unidad10 p122 Ej12" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 10/07. Modulo3 Unidad10 p122 Ej12.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 08. Modulo3 Unidad10 p122 Ej12 Que te parece" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 10/08. Modulo3 Unidad10 p122 Ej12 Que te parece.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 09. Modulo3 Unidad10 p123 Ej13" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 10/09. Modulo3 Unidad10 p123 Ej13.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 10. Modulo3 Unidad10 p123 Ej14" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 10/10. Modulo3 Unidad10 p123 Ej14.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 11. Juega con los sonidos p127" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 10/11. Juega con los sonidos p127.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 01. Modulo3 Unidad11 p128 Ej1" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 11/01. Modulo3 Unidad11 p128 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 02. Modulo3 Unidad11 p132 Ej6" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 11/02. Modulo3 Unidad11 p132 Ej6.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 03. Modulo3 Unidad11 p133 Ej7" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 11/03. Modulo3 Unidad11 p133 Ej7.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 04. Modulo3 Unidad11 p134 Ej9" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 11/04. Modulo3 Unidad11 p134 Ej9.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 05. Modulo3 Unidad11 p136 Ej13" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 11/05. Modulo3 Unidad11 p136 Ej13.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 06. Juega con los sonidos p139" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 11/06. Juega con los sonidos p139.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 01. Modulo3 Unidad12 p140 Ej1" data-artist="Modulo 3" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 12/01. Modulo3 Unidad12 p140 Ej1.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 02. Modulo3 Unidad12 p142 Ej3" data-artist="Modulo 3" data-type="mp3" data-url="AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 12/02. Modulo3 Unidad12 p142 Ej3.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 03. Modulo3 Unidad12 p143 Ej7" data-artist="Modulo 3" data-type="mp3" data-url="AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 12/03. Modulo3 Unidad12 p143 Ej7.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 04. Modulo3 Unidad12 p144 Ej8" data-artist="Modulo 3" data-type="mp3" data-url="AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 12/04. Modulo3 Unidad12 p144 Ej8.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 05. Modulo3 Unidad12 p144 Ej10" data-artist="Modulo 3" data-type="mp3" data-url="AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 12/05. Modulo3 Unidad12 p144 Ej10.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 06. Modulo3 Unidad12 p146 Ej13" data-artist="Modulo 3" data-type="mp3" data-url="AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 12/06. Modulo3 Unidad12 p146 Ej13.mp3" data-free="false"></li>
<li data-title="Modulo 3 - 07. Modulo3 Unidad12 p146 Ej13 contesta" data-artist="Modulo 3" data-type="mp3" data-url="AUDIO/ESPANHOL/Conectate/Conectate 2/Modulo 3/Unidad 12/07. Modulo3 Unidad12 p146 Ej13 contesta.mp3" data-free="false"></li>



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

