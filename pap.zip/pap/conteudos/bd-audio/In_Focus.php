
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Fisk In Focus</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
        
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
<li data-title="Lesson 1 - 01 L1 P06  INTERACTION B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 1/01 L1 P06  INTERACTION B.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 02 L1 P07 LANGUAGE FOCUS B - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 1/02 L1 P07 LANGUAGE FOCUS B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 03 L1 P07 LANGUAGE FOCUS C - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 1/03 L1 P07 LANGUAGE FOCUS C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 04 L1 P08 FOCUS ON READING B - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 1/04 L1 P08 FOCUS ON READING B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 05 L1 P08 FOCUS ON READING C" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 1/05 L1 P08 FOCUS ON READING C.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 06 L1 P09 FOCUS ON READING G" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 1/06 L1 P09 FOCUS ON READING G.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 07 L1 P10 FOCUS ON LISTENING B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 1/07 L1 P10 FOCUS ON LISTENING B.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 08 L1 P11 FOCUS ON LISTENING E" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 1/08 L1 P11 FOCUS ON LISTENING E.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 09 L1 P12 FOCUS ON VOCABULARY B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 1/09 L1 P12 FOCUS ON VOCABULARY B.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 10 L1 P12 FOCUS ON VOCABULARY C - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 1/10 L1 P12 FOCUS ON VOCABULARY C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 01 L2 P14 INTERACTION B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 2/01 L2 P14 INTERACTION B.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 02 L2 P15 LANGUAGE FOCUS B - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 2/02 L2 P15 LANGUAGE FOCUS B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 03 L2 P15 LANGUAGE FOCUS C" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 2/03 L2 P15 LANGUAGE FOCUS C.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 04 L2 P16 FOCUS ON READING B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 2/04 L2 P16 FOCUS ON READING B.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 05 L2 P18 FOCUS ON LISTENING B-C" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 2/05 L2 P18 FOCUS ON LISTENING B-C.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 06 L2 P18 FOCUS ON LISTENING D" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 2/06 L2 P18 FOCUS ON LISTENING D.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 07 L2 P19 FOCUS ON VOCABULARY A" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 2/07 L2 P19 FOCUS ON VOCABULARY A.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 08 L2 P19 FOCUS ON VOCABULARY B - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 2/08 L2 P19 FOCUS ON VOCABULARY B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 01 L3 P22 INTERACTION B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 3/01 L3 P22 INTERACTION B.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 02 L3 P23 LANGUAGE FOCUS C - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 3/02 L3 P23 LANGUAGE FOCUS C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 03 L3 P23 LANGUAGE FOCUS E - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 3/03 L3 P23 LANGUAGE FOCUS E - CM.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 04 L3 P24 FOCUS ON READING B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 3/04 L3 P24 FOCUS ON READING B.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 05 L3 P26 FOCUS ON LISTENING C" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 3/05 L3 P26 FOCUS ON LISTENING C.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 06 L3 P26 FOCUS ON LISTENING D-E" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 3/06 L3 P26 FOCUS ON LISTENING D-E.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 07 L3 P26 FOCUS ON LISTENING F - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 3/07 L3 P26 FOCUS ON LISTENING F - CM.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 08 L3 P27 FOCUS ON VOCABULARY A" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 3/08 L3 P27 FOCUS ON VOCABULARY A.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 01 L4 P30 INTERACTION B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 4/01 L4 P30 INTERACTION B.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 02 L4 P30 INTERACTION D - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 4/02 L4 P30 INTERACTION D - CM.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 03 L4 P31 LANGUAGE FOCUS B - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 4/03 L4 P31 LANGUAGE FOCUS B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 04 L4 P31 LANGUAGE FOCUS D" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 4/04 L4 P31 LANGUAGE FOCUS D.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 05 L4 P32 FOCUS ON READING B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 4/05 L4 P32 FOCUS ON READING B.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 06 L4 P33 FOCUS ON READING G - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 4/06 L4 P33 FOCUS ON READING G - CM.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 07 L4 P34 FOCUS ON LISTENING B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 4/07 L4 P34 FOCUS ON LISTENING B.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 08 L4 P34 FOCUS ON LISTENING C" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 4/08 L4 P34 FOCUS ON LISTENING C.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 09 L4 P34 FOCUS ON LISTENING E - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 4/09 L4 P34 FOCUS ON LISTENING E - CM.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 10 L4 P34 FOCUS ON LISTENING F" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 4/10 L4 P34 FOCUS ON LISTENING F.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 11 L4 P35 FOCUS ON VOCABULARY A" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 4/11 L4 P35 FOCUS ON VOCABULARY A.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 01 L5 P38 INTERACTION B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 5/01 L5 P38 INTERACTION B.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 02 L5 P38 INTERACTION D - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 5/02 L5 P38 INTERACTION D - CM.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 03 L5 P39 LANGUAGE FOCUS B - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 5/03 L5 P39 LANGUAGE FOCUS B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 04 L5 P40 FOCUS ON READING B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 5/04 L5 P40 FOCUS ON READING B.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 05 L5 P42 FOCUS ON LISTENING B-C" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 5/05 L5 P42 FOCUS ON LISTENING B-C.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 06 L5 P42 FOCUS ON LISTENING D" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 5/06 L5 P42 FOCUS ON LISTENING D.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 07 L5 P43 FOCUS ON VOCABULARY A" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 5/07 L5 P43 FOCUS ON VOCABULARY A.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 08 L5 P43 FOCUS ON VOCABULARY B - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 5/08 L5 P43 FOCUS ON VOCABULARY B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 09 L5 P43 FOCUS ON VOCABULARY C - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 5/09 L5 P43 FOCUS ON VOCABULARY C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 01 L6 P46 INTERACTION B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 6/01 L6 P46 INTERACTION B.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 02 L6 P47 LANGUAGE FOCUS B - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 6/02 L6 P47 LANGUAGE FOCUS B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 03 L6 P48 FOCUS ON READING B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 6/03 L6 P48 FOCUS ON READING B.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 04 L6 P49 FOCUS ON READING F - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 6/04 L6 P49 FOCUS ON READING F - CM.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 05 L6 P50 FOCUS ON LISTENING C-E" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 6/05 L6 P50 FOCUS ON LISTENING C-E.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 06 L6 P51 FOCUS ON VOCABULARY A" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 6/06 L6 P51 FOCUS ON VOCABULARY A.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 07 L6 P51 FOCUS ON VOCABULARY C - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 6/07 L6 P51 FOCUS ON VOCABULARY C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 01 L7 P54 INTERACTION B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 7/01 L7 P54 INTERACTION B.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 02 L7 P54 INTERACTION D - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 7/02 L7 P54 INTERACTION D - CM.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 03 L7 P55 LANGUAGE FOCUS A - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 7/03 L7 P55 LANGUAGE FOCUS A - CM.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 04 L7 P56 READING B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 7/04 L7 P56 READING B.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 05 L7 P58 FOCUS ON LISTENING B-C" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 7/05 L7 P58 FOCUS ON LISTENING B-C.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 06 L7 P59 FOCUS ON VOCABULARY A" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 7/06 L7 P59 FOCUS ON VOCABULARY A.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 01 L8 P62 INTERACTION B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 8/01 L8 P62 INTERACTION B.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 02 L8 P63 LANGUAGE FOCUS B - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 8/02 L8 P63 LANGUAGE FOCUS B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 03 L8 P63 LANGUAGE FOCUS C - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 8/03 L8 P63 LANGUAGE FOCUS C - CM.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 04 L8 P64 FOCUS ON READING B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 8/04 L8 P64 FOCUS ON READING B.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 05 L8 P66 FOCUS ON LISTENING C" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 8/05 L8 P66 FOCUS ON LISTENING C.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 06 L8 P66 FOCUS ON LISTENING D" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 8/06 L8 P66 FOCUS ON LISTENING D.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 07 L8 P67 FOCUS ON VOCABULARY A" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 8/07 L8 P67 FOCUS ON VOCABULARY A.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 08 L8 P67 FOCUS ON VOCABULARY D - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 8/08 L8 P67 FOCUS ON VOCABULARY D - CM.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 01 L9 P70 INTERACTION B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 9/01 L9 P70 INTERACTION B.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 02 L9 P71 LANGUAGE FOCUS B - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 9/02 L9 P71 LANGUAGE FOCUS B - CM.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 03 L9 P72 FOCUS ON READING B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 9/03 L9 P72 FOCUS ON READING B.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 04 L9 P74 FOCUS ON LISTENING C" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 9/04 L9 P74 FOCUS ON LISTENING C.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 05 L9 P74 FOCUS ON LISTENING D" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 9/05 L9 P74 FOCUS ON LISTENING D.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 06 L9 P74 FOCUS ON LISTENING E - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 9/06 L9 P74 FOCUS ON LISTENING E - CM.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 07 L9 P75 FOCUS ON VOCABULARY B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 9/07 L9 P75 FOCUS ON VOCABULARY B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 01 L10 P78 INTERACTION B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 10/01 L10 P78 INTERACTION B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 02 L10 P79 LANGUAGE FOCUS A" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 10/02 L10 P79 LANGUAGE FOCUS A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 03 L10 P79 LANGUAGE FOCUS C" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 10/03 L10 P79 LANGUAGE FOCUS C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 04 L10 P80 FOCUS ON READING B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 10/04 L10 P80 FOCUS ON READING B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 05 L10 P81 FOCUS ON READING E - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 10/05 L10 P81 FOCUS ON READING E - CM.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 06 L10 P82 FOCUS ON LISTENING B" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 10/06 L10 P82 FOCUS ON LISTENING B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 07 L10 P82 FOCUS ON LISTENING C" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 10/07 L10 P82 FOCUS ON LISTENING C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 08 L10 P82 FOCUS ON LISTENING D" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 10/08 L10 P82 FOCUS ON LISTENING D.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 09 L10 P82 FOCUS ON LISTENING F" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 10/09 L10 P82 FOCUS ON LISTENING F.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 10 L10 P83 FOCUS ON VOCABULARY A" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 10/10 L10 P83 FOCUS ON VOCABULARY A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 11 L10 P83 FOCUS ON VOCABULARY B - CM" data-artist="Fisk in Focus" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Fisk in Focus/Lesson 10/11 L10 P83 FOCUS ON VOCABULARY B - CM.mp3" data-free="false"></li>




        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

