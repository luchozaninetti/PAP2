
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Latitudes 3 - CD 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
        
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
<li data-title="08 Lat 3.2 - 01 Latitudes 3CD2.1" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/01 Latitudes 3CD2.1.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 02 Latitudes 3CD2.2" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/02 Latitudes 3CD2.2.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 03 Latitudes 3CD2.3" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/03 Latitudes 3CD2.3.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 04 Latitudes 3CD2.4" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/04 Latitudes 3CD2.4.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 05 Latitudes 3CD2.5" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/05 Latitudes 3CD2.5.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 06 Latitudes 3CD2.6" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/06 Latitudes 3CD2.6.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 07 Latitudes 3CD2.7" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/07 Latitudes 3CD2.7.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 08 Latitudes 3CD2.8" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/08 Latitudes 3CD2.8.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 09 Latitudes 3CD2.9" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/09 Latitudes 3CD2.9.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 10 Latitudes 3CD2.10" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/10 Latitudes 3CD2.10.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 11 Latitudes 3CD2.11" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/11 Latitudes 3CD2.11.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 12 Latitudes 3CD2.12" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/12 Latitudes 3CD2.12.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 13 Latitudes 3CD2.13" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/13 Latitudes 3CD2.13.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 14 Latitudes 3CD2.14" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/14 Latitudes 3CD2.14.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 15 Latitudes 3CD2.15" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/15 Latitudes 3CD2.15.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 16 Latitudes 3CD2.16" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/16 Latitudes 3CD2.16.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 17 Latitudes 3CD2.17" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/17 Latitudes 3CD2.17.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 18 Latitudes 3CD2.18" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/18 Latitudes 3CD2.18.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 19 Latitudes 3CD2.19" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/19 Latitudes 3CD2.19.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 20 Latitudes 3CD2.20" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/20 Latitudes 3CD2.20.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 21 Latitudes 3CD2.21" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/21 Latitudes 3CD2.21.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 22 Latitudes 3CD2.22" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/22 Latitudes 3CD2.22.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 23 Latitudes 3CD2.23" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/23 Latitudes 3CD2.23.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 24 Latitudes 3CD2.24" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/24 Latitudes 3CD2.24.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 25 Latitudes 3CD2.25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/25 Latitudes 3CD2.25.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 26 Latitudes 3CD2.26" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/26 Latitudes 3CD2.26.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 27 Latitudes 3CD2.27" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/27 Latitudes 3CD2.27.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 28 Latitudes 3CD2.28" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/28 Latitudes 3CD2.28.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 29 Latitudes 3CD2.29" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/29 Latitudes 3CD2.29.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 30 Latitudes 3CD2.30" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/30 Latitudes 3CD2.30.mp3" data-free="false"></li>
<li data-title="08 Lat 3.2 - 31 Latitudes 3CD2.31" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/08 Lat 3.2/31 Latitudes 3CD2.31.mp3" data-free="false"></li>


	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
