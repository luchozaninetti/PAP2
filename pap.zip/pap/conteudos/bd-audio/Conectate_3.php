
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Conectate 3</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
  
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->

	<li data-title="Leccion 01 - 01. Leccion 1 - p. 08 - ejercicio 1" data-artist="Leccion 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 01/01. Leccion 1 - p. 08 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 02. Leccion 1 - p. 09 - ejercicio 3" data-artist="Leccion 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 01/02. Leccion 1 - p. 09 - ejercicio 3.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 03. Leccion 1 - p. 10 - ejercicio 5 escucha" data-artist="Leccion 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 01/03. Leccion 1 - p. 10 - ejercicio 5 escucha.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 04. Leccion 1 - p. 10 - ejercicio 5 responde" data-artist="Leccion 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 01/04. Leccion 1 - p. 10 - ejercicio 5 responde.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 05. Leccion 1 - p. 10 - ejercicio 2 responde" data-artist="Leccion 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 01/05. Leccion 1 - p. 10 - ejercicio 2 responde.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 06. Leccion 1 - p. 10 - ejercicio 2 pregunta" data-artist="Leccion 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 01/06. Leccion 1 - p. 10 - ejercicio 2 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 07. Leccion 1 - p. 10 - ejercicio 3" data-artist="Leccion 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 01/07. Leccion 1 - p. 10 - ejercicio 3.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 08. Leccion 1 - p. 11 - ejercicio 1" data-artist="Leccion 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 01/08. Leccion 1 - p. 11 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 09. Leccion 1 - p. 12 - ejercicio 2" data-artist="Leccion 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 01/09. Leccion 1 - p. 12 - ejercicio 2.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 10. Leccion 1 - p. 14 - ejercicio 8 (escucha)" data-artist="Leccion 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 01/10. Leccion 1 - p. 14 - ejercicio 8 (escucha).mp3" data-free="false"></li>
<li data-title="Leccion 01 - 11. Leccion 1 - p. 14 - ejercicio 8 (pregunta)" data-artist="Leccion 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 01/11. Leccion 1 - p. 14 - ejercicio 8 (pregunta).mp3" data-free="false"></li>
<li data-title="Leccion 01 - 12. Leccion 1 - p. 14 - ejercicio 9" data-artist="Leccion 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 01/12. Leccion 1 - p. 14 - ejercicio 9.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 01. Leccion 2 - p. 20 - ejercicio 1" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/01. Leccion 2 - p. 20 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 02. Leccion 2 - p. 22 - ejercicio 4 responde" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/02. Leccion 2 - p. 22 - ejercicio 4 responde.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 03. Leccion 2 - p. 22 - ejercicio 4 pregunta" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/03. Leccion 2 - p. 22 - ejercicio 4 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 04. Leccion 2 - p. 23 - ejercicio 1" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/04. Leccion 2 - p. 23 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 05. Leccion 2 - p. 24 - ejercicio 5" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/05. Leccion 2 - p. 24 - ejercicio 5.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 06. Leccion 2 - p. 24 - ejercicio 6 di�logo A" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/06. Leccion 2 - p. 24 - ejercicio 6 di�logo A.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 07. Leccion 2 - p. 24 - ejercicio 6 di�logo B" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/07. Leccion 2 - p. 24 - ejercicio 6 di�logo B.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 08. Leccion 2 - p. 25 - ejercicio 1" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/08. Leccion 2 - p. 25 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 09. Leccion 2 - p. 27 - ejercicio 4" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/09. Leccion 2 - p. 27 - ejercicio 4.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 10. Leccion 2 - p. 27 - ejercicio 5 responde" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/10. Leccion 2 - p. 27 - ejercicio 5 responde.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 11. Leccion 2 - p. 27 - ejercicio 5 pregunta" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/11. Leccion 2 - p. 27 - ejercicio 5 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 12. Leccion 2 - p. 27 - ejercicio 6 pregunta" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/12. Leccion 2 - p. 27 - ejercicio 6 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 13. Leccion 2 - p. 27 - ejercicio 6 responde" data-artist="Leccion 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 02/13. Leccion 2 - p. 27 - ejercicio 6 responde.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 01. Leccion 3 - p. 32 - ejercicio 1" data-artist="Leccion 03" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 03/01. Leccion 3 - p. 32 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 02. Leccion 3 - p. 34 - ejercicio 4" data-artist="Leccion 03" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 03/02. Leccion 3 - p. 34 - ejercicio 4.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 03. Leccion 3 - p. 34 - ejercicio 1" data-artist="Leccion 03" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 03/03. Leccion 3 - p. 34 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 04. Leccion 3 - p. 36 - ejercicio 4" data-artist="Leccion 03" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 03/04. Leccion 3 - p. 36 - ejercicio 4.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 05. Leccion 3 - p. 37 - ejercicio 6" data-artist="Leccion 03" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 03/05. Leccion 3 - p. 37 - ejercicio 6.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 06. Leccion 3 - p. 37 - ejercicio 2" data-artist="Leccion 03" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 03/06. Leccion 3 - p. 37 - ejercicio 2.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 07. Leccion 3 - p. 38 - ejercicio 5" data-artist="Leccion 03" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 03/07. Leccion 3 - p. 38 - ejercicio 5.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 01. Leccion 4 - p. 48 - ejercicio 1" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/01. Leccion 4 - p. 48 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 02. Leccion 4 - p. 48 - ejercicio 2 parte A" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/02. Leccion 4 - p. 48 - ejercicio 2 parte A.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 03. Leccion 4 - p. 49 - ejercicio 2 parte B" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/03. Leccion 4 - p. 49 - ejercicio 2 parte B.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 04. Leccion 4 - p. 50 - ejercicio 4 responde" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/04. Leccion 4 - p. 50 - ejercicio 4 responde.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 05. Leccion 4 - p. 50 - ejercicio 4 pregunta" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/05. Leccion 4 - p. 50 - ejercicio 4 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 06. Leccion 4 - p. 52 - ejercicio 3" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/06. Leccion 4 - p. 52 - ejercicio 3.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 07. Leccion 4 - p. 53 - ejercicio 5 pregunta" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/07. Leccion 4 - p. 53 - ejercicio 5 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 08. Leccion 4 - p. 53 - ejercicio 5 responde" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/08. Leccion 4 - p. 53 - ejercicio 5 responde.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 09. Leccion 4 - p. 53 - ejercicio 6 dialogo a" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/09. Leccion 4 - p. 53 - ejercicio 6 dialogo a.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 10. Leccion 4 - p. 53 - ejercicio 6 dialogo b" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/10. Leccion 4 - p. 53 - ejercicio 6 dialogo b.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 11. Leccion 4 - p. 53 - ejercicio 6 dialogo c" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/11. Leccion 4 - p. 53 - ejercicio 6 dialogo c.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 12. Leccion 4 - p. 53 - ejercicio 6 dialogo d" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/12. Leccion 4 - p. 53 - ejercicio 6 dialogo d.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 13. Leccion 4 - p. 53 - ejercicio 6 dialogo e" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/13. Leccion 4 - p. 53 - ejercicio 6 dialogo e.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 14. Leccion 4 - p. 54 - ejercicio 7 dialogo a" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/14. Leccion 4 - p. 54 - ejercicio 7 dialogo a.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 15. Leccion 4 - p. 54 - ejercicio 7 dialogo b" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/15. Leccion 4 - p. 54 - ejercicio 7 dialogo b.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 16. Leccion 4 - p. 54 - ejercicio 7 dialogo c" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/16. Leccion 4 - p. 54 - ejercicio 7 dialogo c.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 17. Leccion 4 - p. 54 - ejercicio 7 dialogo d" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/17. Leccion 4 - p. 54 - ejercicio 7 dialogo d.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 18. Leccion 4 - p. 54 - ejercicio 7 dialogo e" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/18. Leccion 4 - p. 54 - ejercicio 7 dialogo e.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 19. Leccion 4 - p. 54 - ejercicio 9 responde" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/19. Leccion 4 - p. 54 - ejercicio 9 responde.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 20. Leccion 4 - p. 54 - ejercicio 9 pregunta" data-artist="Leccion 04" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 04/20. Leccion 4 - p. 54 - ejercicio 9 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 01. Leccion 5 - p. 60 - ejercicio 1" data-artist="Leccion 05" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 05/01. Leccion 5 - p. 60 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 02. Leccion 5 - p. 61 - ejercicio 5" data-artist="Leccion 05" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 05/02. Leccion 5 - p. 61 - ejercicio 5.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 03. Leccion 5 - p. 62 - ejercicio 1" data-artist="Leccion 05" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 05/03. Leccion 5 - p. 62 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 04. Leccion 5 - p. 64 - ejercicio 4 responde" data-artist="Leccion 05" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 05/04. Leccion 5 - p. 64 - ejercicio 4 responde.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 05. Leccion 5 - p. 64 - ejercicio 4 pregunta" data-artist="Leccion 05" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 05/05. Leccion 5 - p. 64 - ejercicio 4 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 06. Leccion 5 - p. 64 - ejercicio 5" data-artist="Leccion 05" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 05/06. Leccion 5 - p. 64 - ejercicio 5.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 07. Leccion 5 - p. 65 - ejercicio 1" data-artist="Leccion 05" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 05/07. Leccion 5 - p. 65 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 08. Leccion 5 - p. 66 - ejercicio 4" data-artist="Leccion 05" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 05/08. Leccion 5 - p. 66 - ejercicio 4.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 09. Leccion 5 - p. 66 - ejercicio 5 responde" data-artist="Leccion 05" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 05/09. Leccion 5 - p. 66 - ejercicio 5 responde.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 10. Leccion 5 - p. 66 - ejercicio 5 pregunta" data-artist="Leccion 05" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 05/10. Leccion 5 - p. 66 - ejercicio 5 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 01. Leccion 6 - p. 72 - ejercicio 1" data-artist="Leccion 06" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 06/01. Leccion 6 - p. 72 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 02. Leccion 6 - p. 74 - ejercicio 6 A" data-artist="Leccion 06" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 06/02. Leccion 6 - p. 74 - ejercicio 6 A.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 03. Leccion 6 - p. 74 - ejercicio 6 B" data-artist="Leccion 06" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 06/03. Leccion 6 - p. 74 - ejercicio 6 B.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 04. Leccion 6 - p. 74 - ejercicio 1" data-artist="Leccion 06" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 06/04. Leccion 6 - p. 74 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 05. Leccion 6 - p. 76 - ejercicio 5 responde" data-artist="Leccion 06" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 06/05. Leccion 6 - p. 76 - ejercicio 5 responde.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 06. Leccion 6 - p. 76 - ejercicio 5 pregunta" data-artist="Leccion 06" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 06/06. Leccion 6 - p. 76 - ejercicio 5 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 07. Leccion 6 - p. 76 - ejercicio 1" data-artist="Leccion 06" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 06/07. Leccion 6 - p. 76 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 08. Leccion 6 - p. 77 - ejercicio 3 responde" data-artist="Leccion 06" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 06/08. Leccion 6 - p. 77 - ejercicio 3 responde.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 09. Leccion 6 - p. 77 - ejercicio 3 pregunta" data-artist="Leccion 06" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 06/09. Leccion 6 - p. 77 - ejercicio 3 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 01. Leccion 7 - p. 88 - ejercicio 1" data-artist="Leccion 07" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 07/01. Leccion 7 - p. 88 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 02. Leccion 7 - p. 90 - ejercicio 5" data-artist="Leccion 07" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 07/02. Leccion 7 - p. 90 - ejercicio 5.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 03. Leccion 7 - p. 92 - ejercicio 4" data-artist="Leccion 07" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 07/03. Leccion 7 - p. 92 - ejercicio 4.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 04. Leccion 7 - p. 94 - ejercicio 1" data-artist="Leccion 07" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 07/04. Leccion 7 - p. 94 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 05. Leccion 7 - p. 95 - ejercicio 4 pregunta" data-artist="Leccion 07" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 07/05. Leccion 7 - p. 95 - ejercicio 4 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 06. Leccion 7 - p. 95 - ejercicio 4 responde" data-artist="Leccion 07" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 07/06. Leccion 7 - p. 95 - ejercicio 4 responde.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 01. Leccion 8 - p. 100 - ejercicio 1" data-artist="Leccion 08" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 08/01. Leccion 8 - p. 100 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 02. Leccion 8 - p. 102 - ejercicio 4" data-artist="Leccion 08" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 08/02. Leccion 8 - p. 102 - ejercicio 4.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 03. Leccion 8 - p. 103 - ejercicio 4 pregunta" data-artist="Leccion 08" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 08/03. Leccion 8 - p. 103 - ejercicio 4 pregunta.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 04. Leccion 8 - p. 103 - ejercicio 4 responde" data-artist="Leccion 08" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 08/04. Leccion 8 - p. 103 - ejercicio 4 responde.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 05. Leccion 8 - p. 104 - ejercicio 1" data-artist="Leccion 08" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 08/05. Leccion 8 - p. 104 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 06. Leccion 8 - p. 105 - ejercicio 3" data-artist="Leccion 08" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 08/06. Leccion 8 - p. 105 - ejercicio 3.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 07. Leccion 8 - p. 106 - ejercicio 5" data-artist="Leccion 08" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 08/07. Leccion 8 - p. 106 - ejercicio 5.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 01. Leccion 9 - p. 112 - ejercicio 1" data-artist="Leccion 09" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 09/01. Leccion 9 - p. 112 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 02. Leccion 9 - p. 116 - ejercicio 3" data-artist="Leccion 09" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 09/02. Leccion 9 - p. 116 - ejercicio 3.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 03. Leccion 9 - p. 116 - ejercicio 4" data-artist="Leccion 09" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 09/03. Leccion 9 - p. 116 - ejercicio 4.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 04. Leccion 9 - p. 117 - ejercicio 1" data-artist="Leccion 09" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 09/04. Leccion 9 - p. 117 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 05. Leccion 9 - p. 119 - ejercicio 5" data-artist="Leccion 09" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Leccion 09/05. Leccion 9 - p. 119 - ejercicio 5.mp3" data-free="false"></li>
<li data-title="Recuerdate 01 - 01. Recuerdate 1 - ejercicio 1" data-artist="Recuerdate 01" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Recuerdate 01/01. Recuerdate 1 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Recuerdate 02 - 01. Recuerdate 2 - ejercicio 1 secuencia A" data-artist="Recuerdate 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Recuerdate 02/01. Recuerdate 2 - ejercicio 1 secuencia A.mp3" data-free="false"></li>
<li data-title="Recuerdate 02 - 02. Recuerdate 2 - ejercicio 1 secuencia B" data-artist="Recuerdate 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Recuerdate 02/02. Recuerdate 2 - ejercicio 1 secuencia B.mp3" data-free="false"></li>
<li data-title="Recuerdate 02 - 03. Recuerdate 2 - ejercicio 1 secuencia C" data-artist="Recuerdate 02" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Recuerdate 02/03. Recuerdate 2 - ejercicio 1 secuencia C.mp3" data-free="false"></li>
<li data-title="Recuerdate 03 - 01. Recuerdate 3 - ejercicio 1" data-artist="Recuerdate 03" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Recuerdate 03/01. Recuerdate 3 - ejercicio 1.mp3" data-free="false"></li>
<li data-title="Vuelve a Conectarte - 01. Vuelve a conectarte - p. 06 - ejercicio 1 responde" data-artist="Vuelve a Conectarte" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Vuelve a Conectarte/01. Vuelve a conectarte - p. 06 - ejercicio 1 responde.mp3" data-free="false"></li>
<li data-title="Vuelve a Conectarte - 02. Vuelve a conectarte - p. 06 - ejercicio 1 pregunta" data-artist="Vuelve a Conectarte" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Vuelve a Conectarte/02. Vuelve a conectarte - p. 06 - ejercicio 1 pregunta.mp3" data-free="false"></li>
<li data-title="Vuelve a Conectarte - 03. Vuelve a conectarte - p. 06 - ejercicio 2" data-artist="Vuelve a Conectarte" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Vuelve a Conectarte/03. Vuelve a conectarte - p. 06 - ejercicio 2.mp3" data-free="false"></li>
<li data-title="Vuelve a Conectarte - 04. Vuelve a conectarte - p. 07 - ejercicio 3" data-artist="Vuelve a Conectarte" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Conectate/Conectate 3/Vuelve a Conectarte/04. Vuelve a conectarte - p. 07 - ejercicio 3.mp3" data-free="false"></li>




        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
