
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Playground 4</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">

            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="lesson 01 - 01 L01.P006 A costume party" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 01/01 L01.P006 A costume party.mp3" data-free="false"></li>
<li data-title="lesson 01 - 02 L01.P008 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 01/02 L01.P008 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 01 - 03 L01.P008 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 01/03 L01.P008 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 01 - 04 L01.P009 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 01/04 L01.P009 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 01 - 05 L01.P009 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 01/05 L01.P009 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 02 - 01 L02.P010 Going shopping" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 02/01 L02.P010 Going shopping.mp3" data-free="false"></li>
<li data-title="lesson 02 - 02 L02.P012 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 02/02 L02.P012 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 02 - 03 L02.P012 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 02/03 L02.P012 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 02 - 04 L02.P012 Learning time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 02/04 L02.P012 Learning time (D).mp3" data-free="false"></li>
<li data-title="lesson 02 - 05 L02.P013 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 02/05 L02.P013 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 02 - 06 L02.P015 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 02/06 L02.P015 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 03 - 01 L03.P014 My favorite things" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 03/01 L03.P014 My favorite things.mp3" data-free="false"></li>
<li data-title="lesson 03 - 02 L03.P016 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 03/02 L03.P016 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 03 - 03 L03.P016 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 03/03 L03.P016 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 03 - 04 L03.P017 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 03/04 L03.P017 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 03 - 05 L03.P021 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 03/05 L03.P021 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 04 - 01 L04.P018 Talking about things" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 04/01 L04.P018 Talking about things.mp3" data-free="false"></li>
<li data-title="lesson 04 - 02 L04.P020 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 04/02 L04.P020 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 04 - 03 L04.P020 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 04/03 L04.P020 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 04 - 04 L04.P020 Learning time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 04/04 L04.P020 Learning time (D).mp3" data-free="false"></li>
<li data-title="lesson 04 - 05 L04.P021 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 04/05 L04.P021 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 04 - 06 L04.P027 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 04/06 L04.P027 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 05 - 01 L05.P022  Food is good" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 05/01 L05.P022  Food is good.mp3" data-free="false"></li>
<li data-title="lesson 05 - 02 L05.P024 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 05/02 L05.P024 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 05 - 03 L05.P024 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 05/03 L05.P024 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 05 - 04 L05.P025 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 05/04 L05.P025 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 05 - 05 L05.P033 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 05/05 L05.P033 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 06 - 01 L06.P026 Remember this" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 06/01 L06.P026 Remember this.mp3" data-free="false"></li>
<li data-title="lesson 06 - 02 L06.P029 Review time (F)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 06/02 L06.P029 Review time (F).mp3" data-free="false"></li>
<li data-title="lesson 06 - 03 L06.P039 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 06/03 L06.P039 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 07 - 01 L07.P030 Looking at the clouds" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 07/01 L07.P030 Looking at the clouds.mp3" data-free="false"></li>
<li data-title="lesson 07 - 02 L07.P032 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 07/02 L07.P032 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 07 - 03 L07.032 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 07/03 L07.032 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 07 - 04 L07.P032 Learning time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 07/04 L07.P032 Learning time (D).mp3" data-free="false"></li>
<li data-title="lesson 07 - 05 L07.P033 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 07/05 L07.P033 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 07 - 06 L07.P045 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 07/06 L07.P045 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 08 - 01 L08.P034 I don't have money" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 08/01 L08.P034 I don't have money.mp3" data-free="false"></li>
<li data-title="lesson 08 - 02 L08.P036 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 08/02 L08.P036 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 08 - 03 L08.P036 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 08/03 L08.P036 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 08 - 04 L08.P036 Learning time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 08/04 L08.P036 Learning time (D).mp3" data-free="false"></li>
<li data-title="lesson 08 - 05 L08.P037 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 08/05 L08.P037 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 08 - 06 L08.P051 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 08/06 L08.P051 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 09 - 01 L09.P038 Things I do every day" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 09/01 L09.P038 Things I do every day.mp3" data-free="false"></li>
<li data-title="lesson 09 - 02 L09.P040 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 09/02 L09.P040 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 09 - 03 L09.P040 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 09/03 L09.P040 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 09 - 04 L09.P040 Learning time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 09/04 L09.P040 Learning time (D).mp3" data-free="false"></li>
<li data-title="lesson 09 - 05 L09.P041 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 09/05 L09.P041 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 09 - 06 L09.P057 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 09/06 L09.P057 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 10 - 01 L10.P042 Winter time" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 10/01 L10.P042 Winter time.mp3" data-free="false"></li>
<li data-title="lesson 10 - 02 L10.P044 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 10/02 L10.P044 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 10 - 03 L10.P044 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 10/03 L10.P044 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 10 - 04 L10.P044 Learning time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 10/04 L10.P044 Learning time (D).mp3" data-free="false"></li>
<li data-title="lesson 10 - 05 L10.P045 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 10/05 L10.P045 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 10 - 06 L10.P063 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 10/06 L10.P063 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 11 - 01 L11.P046 Acting out" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 11/01 L11.P046 Acting out.mp3" data-free="false"></li>
<li data-title="lesson 11 - 02 L11.P048 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 11/02 L11.P048 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 11 - 03 L11.P048 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 11/03 L11.P048 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 11 - 04 L11.P048 Learning time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 11/04 L11.P048 Learning time (D).mp3" data-free="false"></li>
<li data-title="lesson 11 - 05 L11.P49 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 11/05 L11.P49 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 11 - 06 L11.P069 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 11/06 L11.P069 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 12 - 01 L12.P050 Remember this" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 12/01 L12.P050 Remember this.mp3" data-free="false"></li>
<li data-title="lesson 12 - 02 L12.0053 Review time (F)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 12/02 L12.0053 Review time (F).mp3" data-free="false"></li>
<li data-title="lesson 12 - 03 L12.P075 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 12/03 L12.P075 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 13 - 01 L13.P054 Describing" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 13/01 L13.P054 Describing.mp3" data-free="false"></li>
<li data-title="lesson 13 - 02 L13.P056 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 13/02 L13.P056 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 13 - 03 L13.P056 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 13/03 L13.P056 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 13 - 04 L13.P056 Learning time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 13/04 L13.P056 Learning time (D).mp3" data-free="false"></li>
<li data-title="lesson 13 - 05 L13.P057 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 13/05 L13.P057 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 13 - 06 L13.P081 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 13/06 L13.P081 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 14 - 01 L14.P058 Where is it" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 14/01 L14.P058 Where is it.mp3" data-free="false"></li>
<li data-title="lesson 14 - 02 L14.P060 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 14/02 L14.P060 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 14 - 03 L14.P060 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 14/03 L14.P060 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 14 - 04 L14.P060 Learning time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 14/04 L14.P060 Learning time (D).mp3" data-free="false"></li>
<li data-title="lesson 14 - 05 L14.P061 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 14/05 L14.P061 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 14 - 06 L14.P087 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 14/06 L14.P087 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 15 - 01 L15.P062 I know how to skate" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 15/01 L15.P062 I know how to skate.mp3" data-free="false"></li>
<li data-title="lesson 15 - 02 L15.P064 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 15/02 L15.P064 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 15 - 03 L15.P064 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 15/03 L15.P064 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 15 - 04 L15.P064 Learning time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 15/04 L15.P064 Learning time (D).mp3" data-free="false"></li>
<li data-title="lesson 15 - 05 L15.P065 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 15/05 L15.P065 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 15 - 06 L15.P093 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 15/06 L15.P093 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 16 - 01 L16.P066 My week" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 16/01 L16.P066 My week.mp3" data-free="false"></li>
<li data-title="lesson 16 - 02 L16.P068 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 16/02 L16.P068 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 16 - 03 L16.P068 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 16/03 L16.P068 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 16 - 04 L16.P068 Learning time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 16/04 L16.P068 Learning time (D).mp3" data-free="false"></li>
<li data-title="lesson 16 - 05 L16.P069 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 16/05 L16.P069 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 16 - 06 L16.P101 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 16/06 L16.P101 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 17 - 01 L17.P070 My clothes" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 17/01 L17.P070 My clothes.mp3" data-free="false"></li>
<li data-title="lesson 17 - 02 L17.P072 Learning time (B)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 17/02 L17.P072 Learning time (B).mp3" data-free="false"></li>
<li data-title="lesson 17 - 03 L17.P072 Learning time (C)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 17/03 L17.P072 Learning time (C).mp3" data-free="false"></li>
<li data-title="lesson 17 - 04 L17.P072 Learning time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 17/04 L17.P072 Learning time (D).mp3" data-free="false"></li>
<li data-title="lesson 17 - 05 L17.P073 Practice time (D)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 17/05 L17.P073 Practice time (D).mp3" data-free="false"></li>
<li data-title="lesson 17 - 06 L17.P107 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 17/06 L17.P107 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="lesson 18 - 01 L18.P074 Remember this" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 18/01 L18.P074 Remember this.mp3" data-free="false"></li>
<li data-title="lesson 18 - 02 L18.P077 Review time (G)" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 18/02 L18.P077 Review time (G).mp3" data-free="false"></li>
<li data-title="lesson 18 - 03 L18.P115 Act. Book - Listen" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/lesson 18/03 L18.P115 Act. Book - Listen.mp3" data-free="false"></li>
<li data-title="songs - 01 P089 Mary had a little lamb" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/songs/01 P089 Mary had a little lamb.mp3" data-free="false"></li>
<li data-title="songs - 02 P090 Do the boogie-woogie" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/songs/02 P090 Do the boogie-woogie.mp3" data-free="false"></li>
<li data-title="songs - 03 P093 There is There are" data-artist="Playground 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/INFANTIL/Playground 4/songs/03 P093 There is There are.mp3" data-free="false"></li>


	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
