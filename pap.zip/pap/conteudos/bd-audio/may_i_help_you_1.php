
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - May I Help You 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
 
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    
<li data-title="UNIT 1 - General review - 01 U01-P84 Ex. C" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/General review/01 U01-P84 Ex. C.mp3" data-free="false"></li>
<li data-title="UNIT 1 - General review - 02 U01-P85 Ex. F" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/General review/02 U01-P85 Ex. F.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 1 - 01 U01-L01-P09 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 1/01 U01-L01-P09 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 1 - 02 U01-L01-P09 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 1/02 U01-L01-P09 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 1 - 03 U01-L01-P10 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 1/03 U01-L01-P10 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 1 - 04 U01-L01-P10 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 1/04 U01-L01-P10 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 1 - 05 U01-L01-P10 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 1/05 U01-L01-P10 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 2 - 01 U01-L02-P13 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 2/01 U01-L02-P13 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 2 - 02 U01-L02-P13 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 2/02 U01-L02-P13 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 2 - 03 U01-L02-P14 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 2/03 U01-L02-P14 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 2 - 04 U01-L02-P00 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 2/04 U01-L02-P00 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 2 - 05 U01-L02-P15 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 2/05 U01-L02-P15 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 3 - 01 U01-L03-P17 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 3/01 U01-L03-P17 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 3 - 02 U01-L03-P17 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 3/02 U01-L03-P17 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 3 - 03 U01-L03-P18 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 3/03 U01-L03-P18 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 3 - 04 U01-L03-P19 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 3/04 U01-L03-P19 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 3 - 05 U01-L03-P19 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 3/05 U01-L03-P19 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 4 - 01 U01-L04-P21 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 4/01 U01-L04-P21 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 4 - 02 U01-L04-P21 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 4/02 U01-L04-P21 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 4 - 03 U01-L04-P21 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 4/03 U01-L04-P21 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 4 - 04 U01-L04-P23 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 4/04 U01-L04-P23 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 4 - 05 U01-L04-P23 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 4/05 U01-L04-P23 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 5 - 01 U01-L05-P25 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 5/01 U01-L05-P25 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 5 - 02 U01-L05-P25 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 5/02 U01-L05-P25 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 5 - 03 U01-L05-P26 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 5/03 U01-L05-P26 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 5 - 04 U01-L05-P27 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 5/04 U01-L05-P27 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 5 - 05 U01-L05-P27 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 5/05 U01-L05-P27 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 6 - 01 U01-L06-P29 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 6/01 U01-L06-P29 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 6 - 02 U01-L06-P29 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 6/02 U01-L06-P29 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 6 - 03 U01-L06-P30 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 6/03 U01-L06-P30 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 6 - 04 U01-L06-P31 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 6/04 U01-L06-P31 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 1 - LESSON 6 - 05 U01-L06-P31 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/LESSON 6/05 U01-L06-P31 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 1 - Useful Dialogs - 01 U01-P83 Pronunciation Tip" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 1/Useful Dialogs/01 U01-P83 Pronunciation Tip.mp3" data-free="false"></li>
<li data-title="UNIT 2 - General Review - 01 U02-P88 Ex. C" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/General Review/01 U02-P88 Ex. C.mp3" data-free="false"></li>
<li data-title="UNIT 2 - General Review - 02 U02-P89 Ex. F" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/General Review/02 U02-P89 Ex. F.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 1 - 01 U02-L01-P33 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 1/01 U02-L01-P33 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 1 - 02 U02-L01-P33 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 1/02 U02-L01-P33 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 1 - 03 U02-L01-P34 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 1/03 U02-L01-P34 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 1 - 04 U02-L01-P35 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 1/04 U02-L01-P35 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 1 - 05 U02-L01-P35 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 1/05 U02-L01-P35 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 2 - 01 U02-L02-P37 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 2/01 U02-L02-P37 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 2 - 02 U02-L02-P37 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 2/02 U02-L02-P37 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 2 - 03 U02-L02-P38 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 2/03 U02-L02-P38 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 2 - 04 U02-L02-P39 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 2/04 U02-L02-P39 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 2 - 05 U02-L02-P39 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 2/05 U02-L02-P39 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 3 - 01 U02-L03-P41 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 3/01 U02-L03-P41 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 3 - 02 U02-L03-P41 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 3/02 U02-L03-P41 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 3 - 03 U02-L03-P42 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 3/03 U02-L03-P42 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 3 - 04 U02-L03-P43 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 3/04 U02-L03-P43 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 3 - 05 U02-L03-P43 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 3/05 U02-L03-P43 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 4 - 01 U02-L04-P45 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 4/01 U02-L04-P45 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 4 - 02 U02-L04-P45 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 4/02 U02-L04-P45 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 4 - 03 U02-L04-P46 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 4/03 U02-L04-P46 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 4 - 04 U02-L04-P47 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 4/04 U02-L04-P47 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 4 - 05 U02-L04-P47 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 4/05 U02-L04-P47 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 5 - 01 U02-L05-P49 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 5/01 U02-L05-P49 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 5 - 02 U02-L05-P49 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 5/02 U02-L05-P49 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 5 - 03 U02-L05-P50 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 5/03 U02-L05-P50 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 5 - 04 U02-L05-P51 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 5/04 U02-L05-P51 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 5 - 05 U02-L05-P51 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 5/05 U02-L05-P51 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 6 - 01 U02-L06-P53 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 6/01 U02-L06-P53 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 6 - 02 U02-L06-P53 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 6/02 U02-L06-P53 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 6 - 03 U02-L06-P54 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 6/03 U02-L06-P54 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 6 - 04 U02-L06-P54 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 6/04 U02-L06-P54 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 2 - LESSON 6 - 05 U02-L06-P55 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/LESSON 6/05 U02-L06-P55 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 2 - Useful Dialogs - 01 U02-P87 Pronunciation Tip" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 2/Useful Dialogs/01 U02-P87 Pronunciation Tip.mp3" data-free="false"></li>
<li data-title="UNIT 3 - General Review - 01 U03-P92 Ex. C" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/General Review/01 U03-P92 Ex. C.mp3" data-free="false"></li>
<li data-title="UNIT 3 - General Review - 02 U03-P93 Ex. F" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/General Review/02 U03-P93 Ex. F.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 1 - 01 U03-L01-P57 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 1/01 U03-L01-P57 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 1 - 02 U03-L01-P57 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 1/02 U03-L01-P57 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 1 - 03 U03-L01-P58 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 1/03 U03-L01-P58 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 1 - 04 U03-L01-P59 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 1/04 U03-L01-P59 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 1 - 05 U03-L01-P59 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 1/05 U03-L01-P59 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 2 - 01 U03-L02-P61 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 2/01 U03-L02-P61 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 2 - 02 U03-L02-P61 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 2/02 U03-L02-P61 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 2 - 03 U03-L02-P61 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 2/03 U03-L02-P61 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 2 - 04 U03-L02-P62 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 2/04 U03-L02-P62 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 2 - 05 U03-L02-P63 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 2/05 U03-L02-P63 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 3 - 01 U03-L03-P65 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 3/01 U03-L03-P65 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 3 - 02 U03-L03-P65 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 3/02 U03-L03-P65 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 3 - 03 U03-L03-P66 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 3/03 U03-L03-P66 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 3 - 04 U03-L03-P67 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 3/04 U03-L03-P67 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 3 - 05 U03-L03-P67 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 3/05 U03-L03-P67 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 4 - 01 U03-L04-P69 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 4/01 U03-L04-P69 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 4 - 02 U03-L04-P69 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 4/02 U03-L04-P69 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 4 - 03 U03-L04-P70 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 4/03 U03-L04-P70 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 4 - 04 U03-L04-P70 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 4/04 U03-L04-P70 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 4 - 05 U03-L04-P71 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 4/05 U03-L04-P71 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 5 - 01 U03-L05-P73 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 5/01 U03-L05-P73 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 5 - 02 U03-L05-P73 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 5/02 U03-L05-P73 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 5 - 03 U03-L05-P74 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 5/03 U03-L05-P74 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 5 - 04 U03-L05-P75 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 5/04 U03-L05-P75 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 5 - 05 U03-L05-P75 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 5/05 U03-L05-P75 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 6 - 01 U03-L06-P77 Conversation Sample" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 6/01 U03-L06-P77 Conversation Sample.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 6 - 02 U03-L06-P77 Conversation Structures" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 6/02 U03-L06-P77 Conversation Structures.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 6 - 03 U03-L06-P78 Key Language" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 6/03 U03-L06-P78 Key Language.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 6 - 04 U03-L06-P79 Listening Practice A" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 6/04 U03-L06-P79 Listening Practice A.mp3" data-free="false"></li>
<li data-title="UNIT 3 - LESSON 6 - 05 U03-L06-P79 Listening Practice B" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/LESSON 6/05 U03-L06-P79 Listening Practice B.mp3" data-free="false"></li>
<li data-title="UNIT 3 - Useful Dialogs - 01 U03-P91 Pronunciation Tip" data-artist="May I help you 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/May I help you 1/UNIT 3/Useful Dialogs/01 U03-P91 Pronunciation Tip.mp3" data-free="false"></li>



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
