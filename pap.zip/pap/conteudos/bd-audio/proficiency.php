
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Proficiency</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
       
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Sample Tests I - 01 sample test 1 - A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/01 sample test 1 - A.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 02 sample test 1 - B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/02 sample test 1 - B.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 03 sample test 1 - C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/03 sample test 1 - C.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 04 sample test 2 - A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/04 sample test 2 - A.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 05 sample test 2 - B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/05 sample test 2 - B.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 06 sample test 2 - C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/06 sample test 2 - C.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 07 sample test 3 - A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/07 sample test 3 - A.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 08 sample test 3 - B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/08 sample test 3 - B.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 09 sample test 3 - C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/09 sample test 3 - C.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 10 sample test 4 - A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/10 sample test 4 - A.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 11 sample test 4 - B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/11 sample test 4 - B.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 12 sample test 4 - C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/12 sample test 4 - C.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 13 sample test 5 - A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/13 sample test 5 - A.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 14 sample test 5 - B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/14 sample test 5 - B.mp3" data-free="false"></li>
<li data-title="Sample Tests I - 15 sample test 5 - C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests I/15 sample test 5 - C.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 01 sample test 1 A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/01 sample test 1 A.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 02 sample test 1 B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/02 sample test 1 B.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 03 sample test 1 C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/03 sample test 1 C.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 04 sample test 2 A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/04 sample test 2 A.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 05 sample test 2 B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/05 sample test 2 B.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 06 sample test 2 C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/06 sample test 2 C.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 07 sample test 3 A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/07 sample test 3 A.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 08 sample test 3 B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/08 sample test 3 B.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 09 sample test 3 C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/09 sample test 3 C.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 10 sample test 4 A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/10 sample test 4 A.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 11 sample test 4 B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/11 sample test 4 B.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 12 sample test 4 C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/12 sample test 4 C.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 13 sample test 5 A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/13 sample test 5 A.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 14 sample test 5 B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/14 sample test 5 B.mp3" data-free="false"></li>
<li data-title="Sample Tests II - 15 sample test 5 C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Sample Tests II/15 sample test 5 C.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 01 Extra SAmple Test A - part A - Instructions" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/01 Extra SAmple Test A - part A - Instructions.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 02 Extra SAmple Test A - part A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/02 Extra SAmple Test A - part A.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 03 Extra Sample Test A - part B - Instructions" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/03 Extra Sample Test A - part B - Instructions.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 04 Extra Sample Test A - part B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/04 Extra Sample Test A - part B.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 05 Extra Sample Test A - part C - Instructions" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/05 Extra Sample Test A - part C - Instructions.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 06 Extra Sample Test A - part C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/06 Extra Sample Test A - part C.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 07 Extra Sample Test B - part A - Instructions" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/07 Extra Sample Test B - part A - Instructions.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 08 Extra Sample Test B - part A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/08 Extra Sample Test B - part A.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 09 Extra Sample Test B - part B - Instructions" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/09 Extra Sample Test B - part B - Instructions.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 10 Extra Sample Test B - part B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/10 Extra Sample Test B - part B.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 11 Extra Sample Test B - part C - Instructions" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/11 Extra Sample Test B - part C - Instructions.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 12 Extra Sample Test B - part C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/12 Extra Sample Test B - part C.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 13 Extra Sample Test C - part A - Instructions" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/13 Extra Sample Test C - part A - Instructions.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 14 Extra Sample Test C - part A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/14 Extra Sample Test C - part A.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 15 Extra Sample Test C - part B - Instructions" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/15 Extra Sample Test C - part B - Instructions.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 16 Extra Sample Test C - part B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/16 Extra Sample Test C - part B.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 17 Extra Sample Test C - part C - Instructions" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/17 Extra Sample Test C - part C - Instructions.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 18 Extra Sample Test C - part C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/18 Extra Sample Test C - part C.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 19 Extra Sample Test D - part A - Instructions" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/19 Extra Sample Test D - part A - Instructions.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 20 Extra Sample Test D - part A" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/20 Extra Sample Test D - part A.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 21 Extra Sample Test D - part B - Instructions" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/21 Extra Sample Test D - part B - Instructions.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 22 Extra Sample Test D - part B" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/22 Extra Sample Test D - part B.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 23 Extra Sample Test D - part C - Instructions" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/23 Extra Sample Test D - part C - Instructions.mp3" data-free="false"></li>
<li data-title="Extra Sample Tests - 24 Extra Sample Test D - part C" data-artist="Proficiency" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Proficiency/Extra Sample Tests/24 Extra Sample Test D - part C.mp3" data-free="false"></li>

	


        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
