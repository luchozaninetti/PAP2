
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Espa�ol con � 4</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
   
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Leccion 01 - 001. MC - L 01, p. 006 y 007" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/001. MC - L 01, p. 006 y 007.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 002. L 01, p. 008, El momento propicio" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/002. L 01, p. 008, El momento propicio.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 003. L 01, p. 008, Prince" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/003. L 01, p. 008, Prince.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 004. MC - L 01, p. 009 - Ej. 4" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/004. MC - L 01, p. 009 - Ej. 4.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 005. MC - L 01, p. 010 y 011" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/005. MC - L 01, p. 010 y 011.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 006. L 01, p. 011, Ej. 6" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/006. L 01, p. 011, Ej. 6.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 007. MC - L 01, p. 012 - Ej. 9" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/007. MC - L 01, p. 012 - Ej. 9.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 008. MC - L 01, p. 013 - Ej. 10" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/008. MC - L 01, p. 013 - Ej. 10.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 009. L 01, p. 013, Ej. 11" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/009. L 01, p. 013, Ej. 11.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 010. MC - L 01, p. 014 - Ej. 14" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/010. MC - L 01, p. 014 - Ej. 14.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 011. MC - L 01, p. 015 - Ej. 16" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/011. MC - L 01, p. 015 - Ej. 16.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 012. MC - L 01, p. 015 - Ej. 17" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/012. MC - L 01, p. 015 - Ej. 17.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 013. EJ.COMPL. - L 01, p. 103, Ej. A" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/013. EJ.COMPL. - L 01, p. 103, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 014. EJ. COMPL. - L 01, p. 103, Ej. B" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/014. EJ. COMPL. - L 01, p. 103, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 015. EJ. COMPL. - L 01, p. 104, Ej. C" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/015. EJ. COMPL. - L 01, p. 104, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 016. EJ. COMPL. - L 01, p. 104, Ej. D" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/016. EJ. COMPL. - L 01, p. 104, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 017. EJ. COMPL. - L 01, p. 105, Ej. E" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 01/017. EJ. COMPL. - L 01, p. 105, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 001. L 02, p. 016, Calcula tu numero" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 02/001. L 02, p. 016, Calcula tu numero.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 002. MC - L 02, p. 018 - Ej. 3" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 02/002. MC - L 02, p. 018 - Ej. 3.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 003. L 02, p. 019, Ej. 4" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 02/003. L 02, p. 019, Ej. 4.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 004. L 02, p. 020, Ej. 8" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 02/004. L 02, p. 020, Ej. 8.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 005. MC - L 02, p. 021 - Ej. 11" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 02/005. MC - L 02, p. 021 - Ej. 11.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 006. EJ. COMPL. - L 02, p. 106, Ej. A" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 02/006. EJ. COMPL. - L 02, p. 106, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 007. EJ. COMPL. - L 02, p. 106, Ej. B" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 02/007. EJ. COMPL. - L 02, p. 106, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 008. EJ. COMPL. - L 02, p. 107, Ej. C" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 02/008. EJ. COMPL. - L 02, p. 107, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 009. EJ. COMPL. - L 02, p. 107, Ej. D" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 02/009. EJ. COMPL. - L 02, p. 107, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 010. EJ. COMPL. - L 02, p. 108, Ej. F" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 02/010. EJ. COMPL. - L 02, p. 108, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 001. L 03, p. 022, Como va tu intuicion" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/001. L 03, p. 022, Como va tu intuicion.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 002. MC - L 03, p. 022" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/002. MC - L 03, p. 022.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 003. L 03, p. 023, Alicia" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/003. L 03, p. 023, Alicia.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 004. L 03, p. 024, Alicia" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/004. L 03, p. 024, Alicia.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 005. L 03, p. 024, Ej. 2" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/005. L 03, p. 024, Ej. 2.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 006. MC - L 03, p. 025 - Ej. 4" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/006. MC - L 03, p. 025 - Ej. 4.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 007. L 03, p. 026, Alicia" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/007. L 03, p. 026, Alicia.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 008. MC - L 03, p. 028 - Ej. 7" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/008. MC - L 03, p. 028 - Ej. 7.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 009. MC - L 03, p. 031 - Ej. 11" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/009. MC - L 03, p. 031 - Ej. 11.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 010. EJ. COMPL. - L 03, p. 111, Ej. A" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/010. EJ. COMPL. - L 03, p. 111, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 011. EJ. COMPL. - L 03, p. 111, Ej. B" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/011. EJ. COMPL. - L 03, p. 111, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 012. EJ. COMPL. - L 03, p. 112, Ej. C" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/012. EJ. COMPL. - L 03, p. 112, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 013. EJ. COMPL. - L 03, p. 113, Ej. E" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 03/013. EJ. COMPL. - L 03, p. 113, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 001. L 04, p. 032, Como estas hoy" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 04/001. L 04, p. 032, Como estas hoy.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 002. L 04, p. 034, Ej. 2" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 04/002. L 04, p. 034, Ej. 2.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 003. MC - L 04, p. 041 - Ej. 2" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 04/003. MC - L 04, p. 041 - Ej. 2.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 004. L 04, p. 043, Ej. 13" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 04/004. L 04, p. 043, Ej. 13.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 005. EJ. COMPL. - L 04, p. 114, Ej. A" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 04/005. EJ. COMPL. - L 04, p. 114, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 006. EJ. COMPL. - L 04, p. 114, Ej. B" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 04/006. EJ. COMPL. - L 04, p. 114, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 007. EJ. COMPL. - L 04, p. 114, Ej. C" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 04/007. EJ. COMPL. - L 04, p. 114, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 008. EJ. COMPL. - L 04, p. 115, Ej. D" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 04/008. EJ. COMPL. - L 04, p. 115, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 001. L 05, p. 046, Mejora tu concentracion" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 05/001. L 05, p. 046, Mejora tu concentracion.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 002. MC - L 05, p. 048 - Ej. 6" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 05/002. MC - L 05, p. 048 - Ej. 6.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 003. MC - L 05, p. 049 - Ej. 7" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 05/003. MC - L 05, p. 049 - Ej. 7.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 004. L 05, p. 050, Prince" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 05/004. L 05, p. 050, Prince.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 005. L 05, p. 051, Ej. 9" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 05/005. L 05, p. 051, Ej. 9.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 006. L 05, p. 052, Ej. 10" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 05/006. L 05, p. 052, Ej. 10.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 007. MC - L 05, p. 053 - Ej. 13" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 05/007. MC - L 05, p. 053 - Ej. 13.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 008. EJ. COMPL. - L 05, p. 116, Ej. A" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 05/008. EJ. COMPL. - L 05, p. 116, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 009. EJ. COMPL. - L 05, p. 116, Ej. B" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 05/009. EJ. COMPL. - L 05, p. 116, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 010. EJ. COMPL. - L 05, p. 117, Ej. C" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 05/010. EJ. COMPL. - L 05, p. 117, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 011. EJ. COMPL. - L 05, p. 117, Ej. D" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 05/011. EJ. COMPL. - L 05, p. 117, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 012. EJ. COMPL. - L 05, p. 117, Ej. E" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 05/012. EJ. COMPL. - L 05, p. 117, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 001. L 06, p. 058, Rapidez y precision" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 06/001. L 06, p. 058, Rapidez y precision.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 002. MC - L 06, p. 058 y 059 - Ej. 3" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 06/002. MC - L 06, p. 058 y 059 - Ej. 3.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 003. L 06, p. 060, Pruebas Psicotecnicas" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 06/003. L 06, p. 060, Pruebas Psicotecnicas.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 004. L 06, p. 063, Ej. 8" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 06/004. L 06, p. 063, Ej. 8.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 005. L 06, p. 064, Alicia" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 06/005. L 06, p. 064, Alicia.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 006. EJ. COMPL. - L 06, p. 119, Ej. A" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 06/006. EJ. COMPL. - L 06, p. 119, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 007. EJ. COMPL. - L 06, p. 119, Ej. B" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 06/007. EJ. COMPL. - L 06, p. 119, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 008. EJ. COMPL. - L 06, p. 120, Ej. C" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 06/008. EJ. COMPL. - L 06, p. 120, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 009. EJ. COMPL. - L 06, p. 120, Ej. D" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 06/009. EJ. COMPL. - L 06, p. 120, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 010. EJ. COMPL. - L 06, p. 120, Ej. E" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 06/010. EJ. COMPL. - L 06, p. 120, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 011. EJ. COMPL. - L 06, p. 121, Ej. F" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 06/011. EJ. COMPL. - L 06, p. 121, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 001. L 07, p. 066, Las mayores cosas..." data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/001. L 07, p. 066, Las mayores cosas....mp3" data-free="false"></li>
<li data-title="Leccion 07 - 002. L 07, p. 067, Alicia" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/002. L 07, p. 067, Alicia.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 003. L 07, p. 068, Alicia" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/003. L 07, p. 068, Alicia.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 004. L 07, p. 069, Ej. 4" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/004. L 07, p. 069, Ej. 4.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 005. MC - L 07, p. 069 - Ej. 6" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/005. MC - L 07, p. 069 - Ej. 6.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 006. L 07, p. 072, Ej. 11" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/006. L 07, p. 072, Ej. 11.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 007. EJ. COMPL. - L 07, p. 122, Ej. A" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/007. EJ. COMPL. - L 07, p. 122, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 008. EJ. COMPL. - L 07, p. 122, Ej. B" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/008. EJ. COMPL. - L 07, p. 122, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 009. EJ. COMPL. - L 07, p. 123, Ej. C" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/009. EJ. COMPL. - L 07, p. 123, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 010. EJ. COMPL. - L 07, p. 123, Ej. D" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/010. EJ. COMPL. - L 07, p. 123, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 011. EJ. COMPL. - L 07, p. 124, Ej. E" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/011. EJ. COMPL. - L 07, p. 124, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 012. EJ. COMPL. - L 07, p. 124, Ej. F" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/012. EJ. COMPL. - L 07, p. 124, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 013. EJ. COMPL. - L 07, p. 125, Ej. G" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 07/013. EJ. COMPL. - L 07, p. 125, Ej. G.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 001. MC - L 08, p. 074" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/001. MC - L 08, p. 074.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 002. L 08, p. 075, Sabores de la fortuna" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/002. L 08, p. 075, Sabores de la fortuna.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 003. MC - L 08, p. 075 - Ej. 1" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/003. MC - L 08, p. 075 - Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 004. L 08, p. 076, Ej. 2" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/004. L 08, p. 076, Ej. 2.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 005. L 08, p. 076, Brasil" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/005. L 08, p. 076, Brasil.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 006. L 08, p. 076, Como te alimentas" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/006. L 08, p. 076, Como te alimentas.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 007. MC - L 08, p. 077 - Ej. 4" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/007. MC - L 08, p. 077 - Ej. 4.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 008. L 08, p. 077, Ej. 5" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/008. L 08, p. 077, Ej. 5.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 009. L 08, p. 078, Los cinco sabores..." data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/009. L 08, p. 078, Los cinco sabores....mp3" data-free="false"></li>
<li data-title="Leccion 08 - 010. MC - L 08, p. 079 - Ej. 7" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/010. MC - L 08, p. 079 - Ej. 7.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 011. MC - L 08, p. 079 - Ej. 7" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/011. MC - L 08, p. 079 - Ej. 7.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 012. L 08, p. 080, El poder de cura..." data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/012. L 08, p. 080, El poder de cura....mp3" data-free="false"></li>
<li data-title="Leccion 08 - 013. MC - L 08, p. 081 - Ej. 9" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/013. MC - L 08, p. 081 - Ej. 9.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 014. EJ. COMPL. - L 08, p. 126, Ej. A" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/014. EJ. COMPL. - L 08, p. 126, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 015. EJ. COMPL. - L 08, p. 126, Ej. B" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/015. EJ. COMPL. - L 08, p. 126, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 016. EJ. COMPL. - L 08, p. 127, Ej. C" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/016. EJ. COMPL. - L 08, p. 127, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 017. EJ. COMPL. - L 08, p. 127, Ej. D" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/017. EJ. COMPL. - L 08, p. 127, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 018. EJ. COMPL. - L 08, p. 128, Ej. F" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 08/018. EJ. COMPL. - L 08, p. 128, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 001. L 09, p. 082, Ej. 1" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 09/001. L 09, p. 082, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 002. L 09, p. 084, Ej. 2" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 09/002. L 09, p. 084, Ej. 2.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 003. L 09, p. 087, Ej. 7" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 09/003. L 09, p. 087, Ej. 7.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 004. MC - L 09, p. 088 - Ej. 9" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 09/004. MC - L 09, p. 088 - Ej. 9.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 005. L 09, p. 088, Ej. 11" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 09/005. L 09, p. 088, Ej. 11.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 006. L 09, p. 091, Ej. 16" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 09/006. L 09, p. 091, Ej. 16.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 007. EJ. COMPL. - L 09, p. 129, Ej. A" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 09/007. EJ. COMPL. - L 09, p. 129, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 008. EJ. COMPL. - L 09, p. 129, Ej. B" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 09/008. EJ. COMPL. - L 09, p. 129, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 009. EJ. COMPL. - L 09, p. 129, Ej. C" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 09/009. EJ. COMPL. - L 09, p. 129, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 010. EJ. COMPL. - L 09, p. 130, Ej. D" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 09/010. EJ. COMPL. - L 09, p. 130, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 001. L 10, p. 095, El lenguaje de las manos" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 10/001. L 10, p. 095, El lenguaje de las manos.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 002. L 10, p. 096, Ej. 5" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 10/002. L 10, p. 096, Ej. 5.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 003. L 10, p. 097, Cuidado..." data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 10/003. L 10, p. 097, Cuidado....mp3" data-free="false"></li>
<li data-title="Leccion 10 - 004. L 10, p. 097, Ej. 7" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 10/004. L 10, p. 097, Ej. 7.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 005. L 10, p. 098, Las dinamicas..." data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 10/005. L 10, p. 098, Las dinamicas....mp3" data-free="false"></li>
<li data-title="Leccion 10 - 006. MC - L 10, p. 099 - Ej. 10" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 10/006. MC - L 10, p. 099 - Ej. 10.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 007. EJ. COMPL. - L 10, p. 131, Ej. A" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 10/007. EJ. COMPL. - L 10, p. 131, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 008. EJ. COMPL. - L 10, p. 131, Ej. B" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 10/008. EJ. COMPL. - L 10, p. 131, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 009. EJ. COMPL. - L 10, p. 131, Ej. C" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 10/009. EJ. COMPL. - L 10, p. 131, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 010. EJ. COMPL. - L 10, p. 132, Ej. D" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 10/010. EJ. COMPL. - L 10, p. 132, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 011. EJ. COMPL. - L 10, p. 132, Ej. E" data-artist="Espanhol N 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 4/Leccion 10/011. EJ. COMPL. - L 10, p. 132, Ej. E.mp3" data-free="false"></li>



	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

