
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Latitudes 3 - CD 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
        
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="07 Lat 3.1 - 01 01 Latitudes 1CD3.1" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/01 01 Latitudes 1CD3.1.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 02 02 Latitudes 1CD3.2" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/02 02 Latitudes 1CD3.2.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 03 03 Latitudes 1CD3.3" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/03 03 Latitudes 1CD3.3.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 04 04 Latitudes 1CD3.4" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/04 04 Latitudes 1CD3.4.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 05 05 Latitudes 1CD3.5" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/05 05 Latitudes 1CD3.5.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 06 06 Latitudes 1CD3.6" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/06 06 Latitudes 1CD3.6.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 07 07 Latitudes 1CD3.7" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/07 07 Latitudes 1CD3.7.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 08 08 Latitudes 1CD3.8" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/08 08 Latitudes 1CD3.8.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 09 09 Latitudes 1CD3.9" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/09 09 Latitudes 1CD3.9.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 10 10 Latitudes 1CD3.10" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/10 10 Latitudes 1CD3.10.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 11 11 Latitudes 1CD3.11" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/11 11 Latitudes 1CD3.11.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 12 12 Latitudes 1CD3.12" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/12 12 Latitudes 1CD3.12.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 13 13 Latitudes 1CD3.13" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/13 13 Latitudes 1CD3.13.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 14 14 Latitudes 1CD3.14" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/14 14 Latitudes 1CD3.14.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 15 15 Latitudes 1CD3.15" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/15 15 Latitudes 1CD3.15.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 16 16 Latitudes 1CD3.16" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/16 16 Latitudes 1CD3.16.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 17 17 Latitudes 1CD3.17" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/17 17 Latitudes 1CD3.17.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 18 18 Latitudes 1CD3.18" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/18 18 Latitudes 1CD3.18.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 19 19 Latitudes 1CD3.19" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/19 19 Latitudes 1CD3.19.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 20 20 Latitudes 1CD3.20" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/20 20 Latitudes 1CD3.20.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 21 21 Latitudes 1CD3.21" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/21 21 Latitudes 1CD3.21.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 22 22 Latitudes 1CD3.22" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/22 22 Latitudes 1CD3.22.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 23 23 Latitudes 1CD3.23" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/23 23 Latitudes 1CD3.23.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 24 24 Latitudes 1CD3.24" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/24 24 Latitudes 1CD3.24.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 25 25 Latitudes 1CD3.25" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/25 25 Latitudes 1CD3.25.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 26 26 Latitudes 1CD3.26" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/26 26 Latitudes 1CD3.26.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 27 27 Latitudes 1CD3.27" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/27 27 Latitudes 1CD3.27.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 28 28 Latitudes 1CD3.28" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/28 28 Latitudes 1CD3.28.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 29 29 Latitudes 1CD3.29" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/29 29 Latitudes 1CD3.29.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 30 30 Latitudes 1CD3.30" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/30 30 Latitudes 1CD3.30.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 31 31 Latitudes 1CD3.31" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/31 31 Latitudes 1CD3.31.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 32 32 Latitudes 1CD3.32" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/32 32 Latitudes 1CD3.32.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 33 33 Latitudes 1CD3.33" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/33 33 Latitudes 1CD3.33.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 34 34 Latitudes 1CD3.34" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/34 34 Latitudes 1CD3.34.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 35 35 Latitudes 1CD3.35" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/35 35 Latitudes 1CD3.35.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 36 36 Latitudes 1CD3.36" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/36 36 Latitudes 1CD3.36.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 37 37 Latitudes 1CD3.37" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/37 37 Latitudes 1CD3.37.mp3" data-free="false"></li>
<li data-title="07 Lat 3.1 - 38 38 Latitudes 1CD3.38" data-artist="Latitudes" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Latitudes/07 Lat 3.1/38 38 Latitudes 1CD3.38.mp3" data-free="false"></li>




	

        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

