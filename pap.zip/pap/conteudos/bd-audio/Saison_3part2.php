
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Saison 3.2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
         
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Saison 3.1 - Unite 5 - a. MF - Piste 52" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/a. MF - Piste 52.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - b. MF - Piste 53" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/b. MF - Piste 53.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - c. MF - Piste 54" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/c. MF - Piste 54.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - e. MF - Piste 58" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/e. MF - Piste 58.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - f. MF - Piste 55" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/f. MF - Piste 55.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - g. MF - Piste 59" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/g. MF - Piste 59.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - h. MF - Piste 60" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/h. MF - Piste 60.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - i. Cahier - Piste 48 - Activite 15" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/i. Cahier - Piste 48 - Activite 15.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - j. Cahier - Piste 49 - Activite 16" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/j. Cahier - Piste 49 - Activite 16.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - k. MF - Piste 56" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/k. MF - Piste 56.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - l. Cahier - Piste 50 - Activite 18" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/l. Cahier - Piste 50 - Activite 18.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - m. MF - Piste 57" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/m. MF - Piste 57.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - n. MF - Piste 61" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/n. MF - Piste 61.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - o. MF - Piste 62" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/o. MF - Piste 62.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - p. MF - Piste 63" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/p. MF - Piste 63.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - q. MF - Piste 62 - reprise" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/q. MF - Piste 62 - reprise.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - r. MF - Piste 64" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/r. MF - Piste 64.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - s. Cahier - Piste 51 - Activite 22" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/s. Cahier - Piste 51 - Activite 22.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - t. Cahier - Piste 52 - Activite 23" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/t. Cahier - Piste 52 - Activite 23.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - u. Cahier - Piste 53 - Activite 24" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/u. Cahier - Piste 53 - Activite 24.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - v. Cahier - Piste 54 - Activite 25" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/v. Cahier - Piste 54 - Activite 25.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - v. Cahier - Piste 56 - Activite 27" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/v. Cahier - Piste 56 - Activite 27.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - w. Cahier - Piste 55 - Activite 26" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/w. Cahier - Piste 55 - Activite 26.mp3" data-free="false"></li>
<li data-title="Saison 3.1 - Unite 5 - x. Cahier - Piste 57 - Activites 28 et 29" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.1/Unite 5/x. Cahier - Piste 57 - Activites 28 et 29.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - a. MF - Piste 65" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/a. MF - Piste 65.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - b. MF - Piste 66" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/b. MF - Piste 66.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - c. MF - Piste 67" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/c. MF - Piste 67.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - d. Cahier - Piste 58 - Activite 4" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/d. Cahier - Piste 58 - Activite 4.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - f. MF - Piste 71" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/f. MF - Piste 71.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - g. MF - Piste 68" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/g. MF - Piste 68.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - h. Cahier - Piste 59 - Activite 7" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/h. Cahier - Piste 59 - Activite 7.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - i. MF - Piste 72" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/i. MF - Piste 72.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - j. Cahier - Piste 60 - Activite 12" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/j. Cahier - Piste 60 - Activite 12.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - k. Cahier - Piste 61 - Activites 14 et 15" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/k. Cahier - Piste 61 - Activites 14 et 15.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - l. MF - Piste 69" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/l. MF - Piste 69.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - m. Cahier - Piste 62 - Activite 17" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/m. Cahier - Piste 62 - Activite 17.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - n. MF - Piste 73" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/n. MF - Piste 73.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - o. MF - Piste 74" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/o. MF - Piste 74.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - p. MF - Piste 75" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/p. MF - Piste 75.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - q. MF - Piste 76" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/q. MF - Piste 76.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - r. MF - Piste 77" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/r. MF - Piste 77.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - s. MF - Piste 78" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/s. MF - Piste 78.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - t. MF - Piste 79" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/t. MF - Piste 79.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - u. Cahier - Piste 63 - Activite 21" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/u. Cahier - Piste 63 - Activite 21.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - v. Cahier - Piste 64 - Activite 22" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/v. Cahier - Piste 64 - Activite 22.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - w. Cahier - Piste 65 - Activite 24" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/w. Cahier - Piste 65 - Activite 24.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - x. Cahier - Piste 66 - Activite 25a" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/x. Cahier - Piste 66 - Activite 25a.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - y. Cahier - Piste 67 - Activite 25b" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/y. Cahier - Piste 67 - Activite 25b.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - z. Cahier - Piste 68 - Activite 26" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/z. Cahier - Piste 68 - Activite 26.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - z1. MF - Piste 80" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/z1. MF - Piste 80.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - z2. Cahier - Piste 69 - Activite 33" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/z2. Cahier - Piste 69 - Activite 33.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - z3. Cahier - Piste 70 - Bilan 2" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/z3. Cahier - Piste 70 - Bilan 2.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 6 - z4. DELF B1 - Unite 6" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 6/z4. DELF B1 - Unite 6.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - a. MF - Piste 81" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/a. MF - Piste 81.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - b. MF - Piste 82" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/b. MF - Piste 82.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - c. MF - Piste 83" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/c. MF - Piste 83.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - e. MF - Piste 87" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/e. MF - Piste 87.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - f. Cahier - Piste 71 - Activite 6" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/f. Cahier - Piste 71 - Activite 6.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - g. Cahier - Piste 72 - Activite 8" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/g. Cahier - Piste 72 - Activite 8.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - h. MF - Piste 84" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/h. MF - Piste 84.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - i. MF - Piste 73 - Activite 10" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/i. MF - Piste 73 - Activite 10.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - j. MF - Piste 88" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/j. MF - Piste 88.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - k. Cahier - Piste 74 - Activite 16" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/k. Cahier - Piste 74 - Activite 16.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - l. Cahier - Piste 75 - Activite 17" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/l. Cahier - Piste 75 - Activite 17.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - m. Cahier - Piste 76 - Activite 19" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/m. Cahier - Piste 76 - Activite 19.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - n. MF - Piste 85" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/n. MF - Piste 85.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - n. MF - Piste 89" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/n. MF - Piste 89.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - o. MF - Piste 90" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/o. MF - Piste 90.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - p. MF - Piste 91" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/p. MF - Piste 91.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - q. MF - Piste 92" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/q. MF - Piste 92.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - r. Cahier - Piste 77 - Activite 23" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/r. Cahier - Piste 77 - Activite 23.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - s. Cahier - Piste 78 - Activite 24" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/s. Cahier - Piste 78 - Activite 24.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - t. Cahier - Piste 79 - Activite 25" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/t. Cahier - Piste 79 - Activite 25.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - u. Cahier - Piste 80 - Activite 26" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/u. Cahier - Piste 80 - Activite 26.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - v. Cahier - Piste 81 - Activite 27" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/v. Cahier - Piste 81 - Activite 27.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - w. Cahier - Piste 82 - Activite 28" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/w. Cahier - Piste 82 - Activite 28.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - x. Cahier - Piste 83 - Bilan 1" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/x. Cahier - Piste 83 - Bilan 1.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 7 - y. DELF B1 - Unite 7" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 7/y. DELF B1 - Unite 7.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - a. MF - Piste 93" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/a. MF - Piste 93.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - b. MF - Piste 94" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/b. MF - Piste 94.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - c. MF - Piste 95" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/c. MF - Piste 95.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - d. Cahier - Piste 88 - Activites 13 et 14" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/d. Cahier - Piste 88 - Activites 13 et 14.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - f. MF - Piste 99" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/f. MF - Piste 99.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - g. MF - Piste 100" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/g. MF - Piste 100.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - h. Cahier - Piste 84 - Activite 5" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/h. Cahier - Piste 84 - Activite 5.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - i. MF - Piste 96" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/i. MF - Piste 96.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - j. Cahier - Piste 85 - Activite 9" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/j. Cahier - Piste 85 - Activite 9.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - k. MF - Piste 101" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/k. MF - Piste 101.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - l. Cahier - Piste 87 - Activite 12" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/l. Cahier - Piste 87 - Activite 12.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - m. MF - Piste 97" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/m. MF - Piste 97.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - n. Cahier - Piste 89 - Activite 18" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/n. Cahier - Piste 89 - Activite 18.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - o. MF - Piste 98" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/o. MF - Piste 98.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - p. MF - Piste 102" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/p. MF - Piste 102.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - q. MF - Piste 103" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/q. MF - Piste 103.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - r. MF - Piste 104" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/r. MF - Piste 104.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - s. MF - Piste 105" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/s. MF - Piste 105.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - t. Cahier - Piste 90 - Activite 21" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/t. Cahier - Piste 90 - Activite 21.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - u. Cahier - Piste 91 - Activite 22" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/u. Cahier - Piste 91 - Activite 22.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - v. Cahier - Piste 92 - Activite 23" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/v. Cahier - Piste 92 - Activite 23.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - w. Cahier - Piste 93 - Activite 24" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/w. Cahier - Piste 93 - Activite 24.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - x. Cahier - Piste 94 - Activite 25" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/x. Cahier - Piste 94 - Activite 25.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - y. Cahier - Piste 95 - Activite 26" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/y. Cahier - Piste 95 - Activite 26.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - z. Cahier - Piste 96 - Activite 28" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/z. Cahier - Piste 96 - Activite 28.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 8 - z1. DELF B1 - Unite 8" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 8/z1. DELF B1 - Unite 8.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - a. MF - Piste 106" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/a. MF - Piste 106.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - b. MF - Piste 107" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/b. MF - Piste 107.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - c. MF - Piste 108" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/c. MF - Piste 108.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - d. Cahier - Piste 97 - Activite 6" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/d. Cahier - Piste 97 - Activite 6.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - f. MF - Piste 112" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/f. MF - Piste 112.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - g. MF - Piste 109" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/g. MF - Piste 109.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - h. MF - Piste 110" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/h. MF - Piste 110.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - i. Cahier - Piste 100 - Activite 18" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/i. Cahier - Piste 100 - Activite 18.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - j. MF - Piste 111" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/j. MF - Piste 111.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - k. MF - Piste 113" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/k. MF - Piste 113.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - l. MF - Piste 114" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/l. MF - Piste 114.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - m. MF - Piste 115" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/m. MF - Piste 115.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - n. MF - Piste 116" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/n. MF - Piste 116.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - o. Cahier - Piste 101 - Activite 20" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/o. Cahier - Piste 101 - Activite 20.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - p. Cahier - Piste 102 - Activite 21" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/p. Cahier - Piste 102 - Activite 21.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - q. Cahier - Piste 103 - Activite 22" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/q. Cahier - Piste 103 - Activite 22.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - r. Cahier - Piste 104 - Activite 23" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/r. Cahier - Piste 104 - Activite 23.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - s. Cahier - Piste 105 - Activite 24" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/s. Cahier - Piste 105 - Activite 24.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - t. Cahier - Piste 106 - Activite 25" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/t. Cahier - Piste 106 - Activite 25.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - t. Cahier - Piste 109 - Bilan 1" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/t. Cahier - Piste 109 - Bilan 1.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - u. Cahier - Piste 107 - Activite 26" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/u. Cahier - Piste 107 - Activite 26.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - v. Cahier - Piste 108 - Activite 29" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/v. Cahier - Piste 108 - Activite 29.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - w. DELF B1 - Unite 9 - Exercice 1" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/w. DELF B1 - Unite 9 - Exercice 1.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - x. DELF B1 - Unite 9 - Exercice 2" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/x. DELF B1 - Unite 9 - Exercice 2.mp3" data-free="false"></li>
<li data-title="Saison 3.2 - Unite 9 - y. DELF B1 - Unite 9 - Exercice 3" data-artist="Saison 3" data-type="mp3" data-url="../https://www.dmzi.com.br/fisk-online/dados/AUDIO/FRANCES/Saison/Saison 3/Saison 3.2/Unite 9/y. DELF B1 - Unite 9 - Exercice 3.mp3" data-free="false"></li>



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
