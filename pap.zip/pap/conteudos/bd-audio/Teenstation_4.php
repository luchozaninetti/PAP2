
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teenstation 4</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
          
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    



<li data-title="Lesson 01 - 01 L01 p06 Sparks A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/01 L01 p06 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 02 L01 p06 Sparks B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/02 L01 p06 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 03 L01 p06 Cultural Tip" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/03 L01 p06 Cultural Tip.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 04 L01 p07 Sparks C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/04 L01 p07 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 05 L01 p07 Sparks D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/05 L01 p07 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 06 L01 p07 Sparks E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/06 L01 p07 Sparks E.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 07 L01 p08 Discoveries A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/07 L01 p08 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 08 L01 p08 Discoveries B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/08 L01 p08 Discoveries B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 09 L01 p09 Discoveries F" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/09 L01 p09 Discoveries F.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 10 L01 p10 Explorations - Challenge" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/10 L01 p10 Explorations - Challenge.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 11 L01 p10 Explorations A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/11 L01 p10 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 12 L01 p10 Explorations C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/12 L01 p10 Explorations C.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 13 L01 p11 Explorations E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/13 L01 p11 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 14 L01 p11 Explorations F" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/14 L01 p11 Explorations F.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 15 L01 p11 Explorations H" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/15 L01 p11 Explorations H.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 16 L01 p12 Reflections A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/16 L01 p12 Reflections A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 17 L01 p13 Reflections D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 01/17 L01 p13 Reflections D.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 01 L02 p14 Sparks A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/01 L02 p14 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 02 L02 p14 Sparks B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/02 L02 p14 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 03 L02 p14 Cultural Tip" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/03 L02 p14 Cultural Tip.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 04 L02 p15 Sparks C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/04 L02 p15 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 05 L02 p15 Sparks D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/05 L02 p15 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 06 L02 p16 Discoveries A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/06 L02 p16 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 07 L02 p17 Discoveries C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/07 L02 p17 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 08 L02 p17 Discoveries F" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/08 L02 p17 Discoveries F.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 09 L02 p18 Explorations A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/09 L02 p18 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 10 L02 p19 Explorations D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/10 L02 p19 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 11 L02 p19 Explorations F" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/11 L02 p19 Explorations F.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 12 L02 p21 Reflections C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/12 L02 p21 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 13 L02 p21 Reflections D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 02/13 L02 p21 Reflections D.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 01 L03 p22 Sparks A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/01 L03 p22 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 02 L03 p22 Cultural Tip" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/02 L03 p22 Cultural Tip.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 03 L03 p22 Sparks B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/03 L03 p22 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 04 L03 p23 Sparks C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/04 L03 p23 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 05 L03 p23 Sparks D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/05 L03 p23 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 06 L03 p24 Discoveries A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/06 L03 p24 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 07 L03 p24 Discoveries B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/07 L03 p24 Discoveries B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 08 L03 p24 Challenge" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/08 L03 p24 Challenge.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 09 L03 p25 Discoveries D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/09 L03 p25 Discoveries D.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 10 L03 p25 Discoveries E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/10 L03 p25 Discoveries E.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 11 L03 p26 Discoveries G" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/11 L03 p26 Discoveries G.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 12 L03 p26 Explorations A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/12 L03 p26 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 13 L03 p27 Explorations E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/13 L03 p27 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 14 L03 p27 Explorations G" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/14 L03 p27 Explorations G.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 15 L03 p29 Reflections C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/15 L03 p29 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 16 L03 p29 Reflections D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 03/16 L03 p29 Reflections D.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 01 L04 p30 Sparks A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/01 L04 p30 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 02 L04 p30 Cultural Tip" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/02 L04 p30 Cultural Tip.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 03 L04 p30 Sparks B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/03 L04 p30 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 04 L04 p31 Sparks C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/04 L04 p31 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 05 L04 p31 Sparks D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/05 L04 p31 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 06 L04 p31 Sparks E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/06 L04 p31 Sparks E.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 07 L04 p32 Discoveries A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/07 L04 p32 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 08 L04 p32 Discoveries C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/08 L04 p32 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 09 L04 p33 Discoveries D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/09 L04 p33 Discoveries D.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 10 L04 p34 Explorations A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/10 L04 p34 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 11 L04 p34 Explorations B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/11 L04 p34 Explorations B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 12 L04 p34 Explorations C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/12 L04 p34 Explorations C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 13 L04 p34 Explorations E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/13 L04 p34 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 14 L04 p35 Reflections A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/14 L04 p35 Reflections A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 15 L04 p36 Reflections C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 04/15 L04 p36 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 01 L05 p38 Sparks A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/01 L05 p38 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 02 L05 p38 Cultural Tip" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/02 L05 p38 Cultural Tip.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 03 L05 p38 Sparks B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/03 L05 p38 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 04 L05 p39 Sparks C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/04 L05 p39 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 05 L05 p39 Sparks D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/05 L05 p39 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 06 L05 p40 Discoveries A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/06 L05 p40 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 07 L05 p41 Discoveries C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/07 L05 p41 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 08 L05 p42 Discoveries F" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/08 L05 p42 Discoveries F.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 09 L05 p42 Challenge" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/09 L05 p42 Challenge.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 10 L05 p42 Explorations A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/10 L05 p42 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 11 L05 p42 Explorations B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/11 L05 p42 Explorations B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 12 L05 p43 Explorations D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/12 L05 p43 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 13 L05 p43 Explorations E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/13 L05 p43 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 14 L05 p45 Reflections C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 05/14 L05 p45 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 01 L06 p46 Sparks A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/01 L06 p46 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 02 L06 p46 Cultural Tip" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/02 L06 p46 Cultural Tip.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 03 L06 p46 Sparks B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/03 L06 p46 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 04 L06 p47 Sparks C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/04 L06 p47 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 05 L06 p47 Sparks D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/05 L06 p47 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 06 L06 p48 Discoveries A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/06 L06 p48 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 07 L06 p48 Discoveries B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/07 L06 p48 Discoveries B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 08 L06 p49 Discoveries D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/08 L06 p49 Discoveries D.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 09 L06 p50 Discoveries F" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/09 L06 p50 Discoveries F.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 10 L06 p50 Explorations A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/10 L06 p50 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 11 L06 p51 Explorations C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/11 L06 p51 Explorations C.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 12 L06 p52 Explorations E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/12 L06 p52 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 13 L06 p52 Explorations F" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/13 L06 p52 Explorations F.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 14 L06 p52 Reflections A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/14 L06 p52 Reflections A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 15 L06 p53 Reflections C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 06/15 L06 p53 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 01 L07 p60 Sparks A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/01 L07 p60 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 02 L07 p60 Cultural Tip" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/02 L07 p60 Cultural Tip.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 03 L07 p60 Sparks B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/03 L07 p60 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 04 L07 p61 Sparks C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/04 L07 p61 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 05 L07 p61 Sparks D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/05 L07 p61 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 06 L07 p62 Discoveries A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/06 L07 p62 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 07 L07 p63 Discoveries C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/07 L07 p63 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 08 L07 p63 Discoveries D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/08 L07 p63 Discoveries D.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 09 L07 p64 Discoveries G" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/09 L07 p64 Discoveries G.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 10 L07 p64 Challenge" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/10 L07 p64 Challenge.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 11 L07 p64 Explorations B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/11 L07 p64 Explorations B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 12 L07 p65 Explorations E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/12 L07 p65 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 13 L07 p67 Reflections C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 07/13 L07 p67 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 01 L08 p68 Sparks A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 08/01 L08 p68 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 02 L08 p68 Cultural Tip" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 08/02 L08 p68 Cultural Tip.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 03 L08 p68 Sparks B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 08/03 L08 p68 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 04 L08 p69 Sparks C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 08/04 L08 p69 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 05 L08 p69 Sparks D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 08/05 L08 p69 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 06 L08 p70 Discoveries A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 08/06 L08 p70 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 07 L08 p71 Discoveries D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 08/07 L08 p71 Discoveries D.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 08 L08 p71 Discoveries G" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 08/08 L08 p71 Discoveries G.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 09 L08 p72 Explorations B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 08/09 L08 p72 Explorations B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 10 L08 p73 Explorations E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 08/10 L08 p73 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 11 L08 p74 Reflections B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 08/11 L08 p74 Reflections B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 12 L08 p75 Reflections D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 08/12 L08 p75 Reflections D.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 01 L09 p76 Sparks A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/01 L09 p76 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 02 L09 p76 Cultural Tip" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/02 L09 p76 Cultural Tip.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 03 L09 p76 Sparks B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/03 L09 p76 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 04 L09 p77 Sparks C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/04 L09 p77 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 05 L09 p77 Sparks D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/05 L09 p77 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 06 L09 p78 Sparks E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/06 L09 p78 Sparks E.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 07 L09 p78 Discoveries A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/07 L09 p78 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 08 L09 p79 Discoveries C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/08 L09 p79 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 09 L09 p79 Discoveries F" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/09 L09 p79 Discoveries F.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 10 L09 p80 Challenge" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/10 L09 p80 Challenge.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 11 L09 p80 Explorations A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/11 L09 p80 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 12 L09 p80 Explorations C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/12 L09 p80 Explorations C.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 13 L09 p83 Reflections C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 09/13 L09 p83 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 01 L10 p84 Sparks A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 10/01 L10 p84 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 02 L10 p84 Cultural Tip" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 10/02 L10 p84 Cultural Tip.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 03 L10 p84 Sparks B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 10/03 L10 p84 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 04 L10 p85 Sparks C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 10/04 L10 p85 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 05 L10 p85 Sparks D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 10/05 L10 p85 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 06 L10 p86 Discoveries A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 10/06 L10 p86 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 07 L10 p87 Discoveries C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 10/07 L10 p87 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 08 L10 p88 Discoveries F" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 10/08 L10 p88 Discoveries F.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 09 L10 p88 Explorations A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 10/09 L10 p88 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 10 L10 p89 Explorations D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 10/10 L10 p89 Explorations D.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 11 L10 p89 Explorations E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 10/11 L10 p89 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 12 L10 p91 Reflections C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 10/12 L10 p91 Reflections C.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 01 L11 p92 Sparks A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 11/01 L11 p92 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 02 L11 p92 Cultural Tip" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 11/02 L11 p92 Cultural Tip.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 03 L11 p92 Sparks B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 11/03 L11 p92 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 04 L11 p93 Sparks C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 11/04 L11 p93 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 05 L11 p93 Sparks D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 11/05 L11 p93 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 06 L11 p94 Discoveries A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 11/06 L11 p94 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 07 L11 p95 Discoveries C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 11/07 L11 p95 Discoveries C.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 08 L11 p95 Discoveries F" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 11/08 L11 p95 Discoveries F.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 09 L11 p96 Challenge" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 11/09 L11 p96 Challenge.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 10 L11 p96 Explorations A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 11/10 L11 p96 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 11 L11 p97 Explorations E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 11/11 L11 p97 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 12 L11 p99 Reflections E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 11/12 L11 p99 Reflections E.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 01 L12 p100 Sparks A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 12/01 L12 p100 Sparks A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 02 L12 p100 Cultural Tip" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 12/02 L12 p100 Cultural Tip.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 03 L12 p100 Sparks B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 12/03 L12 p100 Sparks B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 04 L12 p101 Sparks C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 12/04 L12 p101 Sparks C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 05 L12 p101 Sparks D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 12/05 L12 p101 Sparks D.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 06 L12 p102 Discoveries A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 12/06 L12 p102 Discoveries A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 07 L12 p102 Discoveries B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 12/07 L12 p102 Discoveries B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 08 L12 p103 Discoveries D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 12/08 L12 p103 Discoveries D.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 09 L12 p104 Explorations A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 12/09 L12 p104 Explorations A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 10 L12 p105 Explorations E" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 12/10 L12 p105 Explorations E.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 11 L12 p107 Reflections C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Lesson 12/11 L12 p107 Reflections C.mp3" data-free="false"></li>
<li data-title="Review 1 - 01 Review 1 p58 A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Review 1/01 Review 1 p58 A.mp3" data-free="false"></li>
<li data-title="Review 1 - 02 Review 1 p59 B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Review 1/02 Review 1 p59 B.mp3" data-free="false"></li>
<li data-title="Review 1 - 03 Review 1 p59 C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Review 1/03 Review 1 p59 C.mp3" data-free="false"></li>
<li data-title="Review 1 - 04 Review 1 p59 D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Review 1/04 Review 1 p59 D.mp3" data-free="false"></li>
<li data-title="Review 2 - 01 Review 2 p112 A" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Review 2/01 Review 2 p112 A.mp3" data-free="false"></li>
<li data-title="Review 2 - 02 Review 2 p113 B" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Review 2/02 Review 2 p113 B.mp3" data-free="false"></li>
<li data-title="Review 2 - 03 Review 2 p113 C" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Review 2/03 Review 2 p113 C.mp3" data-free="false"></li>
<li data-title="Review 2 - 04 Review 2 p113 D" data-artist="Teenstation 4" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENSTATION/Teenstation 4/Review 2/04 Review 2 p113 D.mp3" data-free="false"></li>

	



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
