
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Higher 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
           
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    


<li data-title="00 U3&4 - 01 Activities U3&4 Phrasal Verbs - CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Activities/00 U3&4/01 Activities U3&4 Phrasal Verbs - CM.mp3" data-free="false"></li>
<li data-title="01 U5&6 - 01 Activities U5&6 Phrasal Verbs - CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Activities/01 U5&6/01 Activities U5&6 Phrasal Verbs - CM.mp3" data-free="false"></li>
<li data-title="Unit 1 - 01 L1p008 Listening and Speaking - B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/01 L1p008 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Unit 1 - 02 L1p009 Listening and Speaking - D"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/02 L1p009 Listening and Speaking - D.mp3" data-free="false"></li>
<li data-title="Unit 1 - 03 L1p009 Listening and Speaking - F"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/03 L1p009 Listening and Speaking - F.mp3" data-free="false"></li>
<li data-title="Unit 1 - 04 L2p010 Phrasal Verbs - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/04 L2p010 Phrasal Verbs - A.mp3" data-free="false"></li>
<li data-title="Unit 1 - 05 L2p010 Phrasal Verbs - B CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/05 L2p010 Phrasal Verbs - B CM.mp3" data-free="false"></li>
<li data-title="Unit 1 - 06 L2p011 Phrasal Verbs - C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/06 L2p011 Phrasal Verbs - C.mp3" data-free="false"></li>
<li data-title="Unit 1 - 07 L2p011 Phrasal Verbs - E CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/07 L2p011 Phrasal Verbs - E CM.mp3" data-free="false"></li>
<li data-title="Unit 1 - 08 L3p012 Reading and Talking - B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/08 L3p012 Reading and Talking - B.mp3" data-free="false"></li>
<li data-title="Unit 1 - 09 L4p014 Grammar and Communication - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/09 L4p014 Grammar and Communication - A.mp3" data-free="false"></li>
<li data-title="Unit 1 - 10 L4p014 Grammar and Communication - C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/10 L4p014 Grammar and Communication - C.mp3" data-free="false"></li>
<li data-title="Unit 1 - 11 L4p015 Grammar and Communication - D"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/11 L4p015 Grammar and Communication - D.mp3" data-free="false"></li>
<li data-title="Unit 1 - 12 L4p015 Grammar and Communication - F CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/12 L4p015 Grammar and Communication - F CM.mp3" data-free="false"></li>
<li data-title="Unit 1 - 13 L5p017 Writing and Discussing - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/13 L5p017 Writing and Discussing - E.mp3" data-free="false"></li>
<li data-title="Unit 1 - 14 L6p018 Pronunciation - A CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/14 L6p018 Pronunciation - A CM.mp3" data-free="false"></li>
<li data-title="Unit 1 - 15 L6p018 Pronunciation - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/15 L6p018 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Unit 1 - 16 L6p018 Pronunciation - B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/16 L6p018 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Unit 1 - 17 L6p018 Pronunciation - C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/17 L6p018 Pronunciation - C.mp3" data-free="false"></li>
<li data-title="Unit 1 - 18 L6p018 Pronunciation - D"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 1/18 L6p018 Pronunciation - D.mp3" data-free="false"></li>
<li data-title="Unit 2 - 01 L1p024 Reading and Talking - C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/01 L1p024 Reading and Talking - C.mp3" data-free="false"></li>
<li data-title="Unit 2 - 02 L1p025 Reading and Talking - G"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/02 L1p025 Reading and Talking - G.mp3" data-free="false"></li>
<li data-title="Unit 2 - 03 L2p26 Grammar and Communication - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/03 L2p26 Grammar and Communication - A.mp3" data-free="false"></li>
<li data-title="Unit 2 - 04 L2p026 Grammar and Communication - B CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/04 L2p026 Grammar and Communication - B CM.mp3" data-free="false"></li>
<li data-title="Unit 2 - 05 L2p027 Grammar and Communication - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/05 L2p027 Grammar and Communication - E.mp3" data-free="false"></li>
<li data-title="Unit 2 - 06 L3p028 Phrasal Verbs - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/06 L3p028 Phrasal Verbs - A.mp3" data-free="false"></li>
<li data-title="Unit 2 - 07 L4p030 Listening and Speaking - B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/07 L4p030 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Unit 2 - 08 L4p030 Listening and Speaking - D CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/08 L4p030 Listening and Speaking - D CM.mp3" data-free="false"></li>
<li data-title="Unit 2 - 09 L4p31 Listening and Speaking - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/09 L4p31 Listening and Speaking - E.mp3" data-free="false"></li>
<li data-title="Unit 2 - 10 L5p033 Writing and Discussing - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/10 L5p033 Writing and Discussing - E.mp3" data-free="false"></li>
<li data-title="Unit 2 - 11 L6p34 Pronunciation - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/11 L6p34 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Unit 2 - 12  L6p34 Pronunciation - B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/12  L6p34 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Unit 2 - 13  L6p34 Pronunciation - C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 2/13  L6p34 Pronunciation - C.mp3" data-free="false"></li>
<li data-title="Unit 3 - 01 L1p042 Grammar and Communication - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/01 L1p042 Grammar and Communication - A.mp3" data-free="false"></li>
<li data-title="Unit 3 - 02 L1p043 Grammar and Communication - D"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/02 L1p043 Grammar and Communication - D.mp3" data-free="false"></li>
<li data-title="Unit 3 - 03 L1p043 Grammar and Communication - G"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/03 L1p043 Grammar and Communication - G.mp3" data-free="false"></li>
<li data-title="Unit 3 - 04 L2p044 Listening and Speaking - B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/04 L2p044 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Unit 3 - 05 L2p045 Listening and Speaking - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/05 L2p045 Listening and Speaking - E.mp3" data-free="false"></li>
<li data-title="Unit 3 - 06 L2p045 Listening and Speaking - F"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/06 L2p045 Listening and Speaking - F.mp3" data-free="false"></li>
<li data-title="Unit 3 - 07 L3p046 Reading and Talking - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/07 L3p046 Reading and Talking - A.mp3" data-free="false"></li>
<li data-title="Unit 3 - 08 L3p046 Reading and Talking - C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/08 L3p046 Reading and Talking - C.mp3" data-free="false"></li>
<li data-title="Unit 3 - 09 L3p047 Reading and Talking - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/09 L3p047 Reading and Talking - E.mp3" data-free="false"></li>
<li data-title="Unit 3 - 10 L4p048 Phrasal Verbs - B CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/10 L4p048 Phrasal Verbs - B CM.mp3" data-free="false"></li>
<li data-title="Unit 3 - 11 L4p049 Phrasal Verbs - D CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/11 L4p049 Phrasal Verbs - D CM.mp3" data-free="false"></li>
<li data-title="Unit 3 - 12 L4p049 Phrasal Verbs - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/12 L4p049 Phrasal Verbs - E.mp3" data-free="false"></li>
<li data-title="Unit 3 - 13 L5p050 Writing and Discussing - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/13 L5p050 Writing and Discussing - A.mp3" data-free="false"></li>
<li data-title="Unit 3 - 14 L5p051 Writing and Discussing - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/14 L5p051 Writing and Discussing - E.mp3" data-free="false"></li>
<li data-title="Unit 3 - 15 L6p052 Pronunciation - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/15 L6p052 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Unit 3 - 16 L6p052 Pronunciation - B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/16 L6p052 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Unit 3 - 17 L6p052 Pronunciation - C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 3/17 L6p052 Pronunciation - C.mp3" data-free="false"></li>
<li data-title="Unit 4 - 01 L1p058 Listening and Speaking - B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/01 L1p058 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Unit 4 - 02 L1p058 Listening and Speaking - C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/02 L1p058 Listening and Speaking - C.mp3" data-free="false"></li>
<li data-title="Unit 4 - 03 L1p059 Listening and Speaking - F"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/03 L1p059 Listening and Speaking - F.mp3" data-free="false"></li>
<li data-title="Unit 4 - 04 L1p059 Listening and Speaking - H CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/04 L1p059 Listening and Speaking - H CM.mp3" data-free="false"></li>
<li data-title="Unit 4 - 05 L2p060 Reading and Talking - B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/05 L2p060 Reading and Talking - B.mp3" data-free="false"></li>
<li data-title="Unit 4 - 06 L2p061 Reading and Talking - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/06 L2p061 Reading and Talking - E.mp3" data-free="false"></li>
<li data-title="Unit 4 - 07 L3p062 Phrasal Verbs - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/07 L3p062 Phrasal Verbs - A.mp3" data-free="false"></li>
<li data-title="Unit 4 - 08 L4p064 Grammar and Communication - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/08 L4p064 Grammar and Communication - A.mp3" data-free="false"></li>
<li data-title="Unit 4 - 09 L4p065 Grammar and Communication - D"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/09 L4p065 Grammar and Communication - D.mp3" data-free="false"></li>
<li data-title="Unit 4 - 10 L4p065 Grammar and Communication - F"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/10 L4p065 Grammar and Communication - F.mp3" data-free="false"></li>
<li data-title="Unit 4 - 11 L5p067 Writing and Discussing - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/11 L5p067 Writing and Discussing - E.mp3" data-free="false"></li>
<li data-title="Unit 4 - 12 L6p068 Pronunciation - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/12 L6p068 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Unit 4 - 13 L6p068 Pronunciation - B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/13 L6p068 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Unit 4 - 14 L6p068 Pronunciation - C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/14 L6p068 Pronunciation - C.mp3" data-free="false"></li>
<li data-title="Unit 4 - 15 L6p068 Pronunciation - D"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 4/15 L6p068 Pronunciation - D.mp3" data-free="false"></li>
<li data-title="Unit 5 - 01 L1p076 Reading and Talking - C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/01 L1p076 Reading and Talking - C.mp3" data-free="false"></li>
<li data-title="Unit 5 - 02 L1p077 Reading and Talking - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/02 L1p077 Reading and Talking - E.mp3" data-free="false"></li>
<li data-title="Unit 5 - 03 L1p077 Reading and Talking - F"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/03 L1p077 Reading and Talking - F.mp3" data-free="false"></li>
<li data-title="Unit 5 - 04 L2p078 Phrasal Verbs - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/04 L2p078 Phrasal Verbs - A.mp3" data-free="false"></li>
<li data-title="Unit 5 - 05 L2p079 Phrasal Verbs - D CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/05 L2p079 Phrasal Verbs - D CM.mp3" data-free="false"></li>
<li data-title="Unit 5 - 06 L2p079 Phrasal Verbs - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/06 L2p079 Phrasal Verbs - E.mp3" data-free="false"></li>
<li data-title="Unit 5 - 07 L3p080 Grammar and Communication - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/07 L3p080 Grammar and Communication - A.mp3" data-free="false"></li>
<li data-title="Unit 5 - 08 L3p081 Grammar and Communication - D"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/08 L3p081 Grammar and Communication - D.mp3" data-free="false"></li>
<li data-title="Unit 5 - 09 L4p082 Listening and Speaking - B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/09 L4p082 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Unit 5 - 10 L4p083 Listening and Speaking - E CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/10 L4p083 Listening and Speaking - E CM.mp3" data-free="false"></li>
<li data-title="Unit 5 - 11 L4p083 Listening and Speaking - F"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/11 L4p083 Listening and Speaking - F.mp3" data-free="false"></li>
<li data-title="Unit 5 - 12 L4p083 Listening and Speaking - G"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/12 L4p083 Listening and Speaking - G.mp3" data-free="false"></li>
<li data-title="Unit 5 - 13 L5p084 Writing and Discussing - C CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/13 L5p084 Writing and Discussing - C CM.mp3" data-free="false"></li>
<li data-title="Unit 5 - 14 L5p085 Writing and Discussing - E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/14 L5p085 Writing and Discussing - E.mp3" data-free="false"></li>
<li data-title="Unit 5 - 15 L6p086 Pronunciation - A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/15 L6p086 Pronunciation - A.mp3" data-free="false"></li>
<li data-title="Unit 5 - 16 L6p086 Pronunciation - B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/16 L6p086 Pronunciation - B.mp3" data-free="false"></li>
<li data-title="Unit 5 - 17 L6p086 Pronunciation - C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/17 L6p086 Pronunciation - C.mp3" data-free="false"></li>
<li data-title="Unit 5 - 18 L6p086 Pronunciation - D CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 5/18 L6p086 Pronunciation - D CM.mp3" data-free="false"></li>
<li data-title="Unit 6 - 01 L1p092 Grammar and Communication A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/01 L1p092 Grammar and Communication A.mp3" data-free="false"></li>
<li data-title="Unit 6 - 02 L1p092 Grammar and Communication C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/02 L1p092 Grammar and Communication C.mp3" data-free="false"></li>
<li data-title="Unit 6 - 03 L1p093 Grammar and Communication D CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/03 L1p093 Grammar and Communication D CM.mp3" data-free="false"></li>
<li data-title="Unit 6 - 04 L1p093 Grammar and Communication E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/04 L1p093 Grammar and Communication E.mp3" data-free="false"></li>
<li data-title="Unit 6 - 05 L2p094 Reading and Talking B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/05 L2p094 Reading and Talking B.mp3" data-free="false"></li>
<li data-title="Unit 6 - 06 L2p095 Reading and Talking E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/06 L2p095 Reading and Talking E.mp3" data-free="false"></li>
<li data-title="Unit 6 - 07 L3p096 Listening and Speaking B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/07 L3p096 Listening and Speaking B.mp3" data-free="false"></li>
<li data-title="Unit 6 - 08 L3p097 Listening and Speaking E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/08 L3p097 Listening and Speaking E.mp3" data-free="false"></li>
<li data-title="Unit 6 - 09 L4p098 Phrasal Verbs C CM"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/09 L4p098 Phrasal Verbs C CM.mp3" data-free="false"></li>
<li data-title="Unit 6 - 10 L4p099 Phrasal Verbs D"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/10 L4p099 Phrasal Verbs D.mp3" data-free="false"></li>
<li data-title="Unit 6 - 11 L5p101 Writing and Discussing E"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/11 L5p101 Writing and Discussing E.mp3" data-free="false"></li>
<li data-title="Unit 6 - 12 L6p102 Pronunciation A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/12 L6p102 Pronunciation A.mp3" data-free="false"></li>
<li data-title="Unit 6 - 13 L6p102 Pronunciation B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/13 L6p102 Pronunciation B.mp3" data-free="false"></li>
<li data-title="Unit 6 - 14 L6p102 Pronunciation C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/14 L6p102 Pronunciation C.mp3" data-free="false"></li>
<li data-title="Unit 6 - 15 L6p102 Pronunciation D"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Unit 6/15 L6p102 Pronunciation D.mp3" data-free="false"></li>
<li data-title="Review 1 - 01 R1p112 A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Review/Review 1/01 R1p112 A.mp3" data-free="false"></li>
<li data-title="Review 1 - 02 R1p112 B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Review/Review 1/02 R1p112 B.mp3" data-free="false"></li>
<li data-title="Review 1 - 03 R1p113 C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Review/Review 1/03 R1p113 C.mp3" data-free="false"></li>
<li data-title="Review 1 - 04 R1p113 D"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Review/Review 1/04 R1p113 D.mp3" data-free="false"></li>
<li data-title="Review 2 - 01 R2p118 A"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Review/Review 2/01 R2p118 A.mp3" data-free="false"></li>
<li data-title="Review 2 - 02 R2p118 B"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Review/Review 2/02 R2p118 B.mp3" data-free="false"></li>
<li data-title="Review 2 - 03 R2p119 C"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Review/Review 2/03 R2p119 C.mp3" data-free="false"></li>
<li data-title="Review 2 - 04 R2p119 D"data-artist="Teens Higher 2"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Higher 2/Review/Review 2/04 R2p119 D.mp3" data-free="false"></li>



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
