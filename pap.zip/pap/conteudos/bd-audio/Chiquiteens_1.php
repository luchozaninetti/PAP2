
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Chiquiteens 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
          
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
            
<li data-title="Leccion 00 - 01 L 00, p. 06, unidad 1, Ej. 1" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/01 L 00, p. 06, unidad 1, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 02 L 00, p. 06, unidad 1, Ej. 1 cont" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/02 L 00, p. 06, unidad 1, Ej. 1 cont.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 03 L 00, p. 07, unidad 1, Ej. 2" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/03 L 00, p. 07, unidad 1, Ej. 2.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 04 L 00, p. 08, unidad 1, Ej. 3" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/04 L 00, p. 08, unidad 1, Ej. 3.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 05 L 00, p. 09, unidad 1, Ej. 5a" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/05 L 00, p. 09, unidad 1, Ej. 5a.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 06 L 00, p. 09, unidad 1, Ej. 5b" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/06 L 00, p. 09, unidad 1, Ej. 5b.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 07 L 00, p. 09, unidad 1, Ej. 5c" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/07 L 00, p. 09, unidad 1, Ej. 5c.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 08 L 00, p. 09, unidad 1, Ej. 5d" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/08 L 00, p. 09, unidad 1, Ej. 5d.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 09 L 00, p. 09, unidad 1, Ej. 5e" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/09 L 00, p. 09, unidad 1, Ej. 5e.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 10 L 00, p. 09, unidad 1, Ej. 5f" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/10 L 00, p. 09, unidad 1, Ej. 5f.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 11 L 00, p. 09, unidad 1, Ej. 5g" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/11 L 00, p. 09, unidad 1, Ej. 5g.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 12 L 00, p. 75, unidad 1, Ejercicio de fonetica 1" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/12 L 00, p. 75, unidad 1, Ejercicio de fonetica 1.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 13 L 00, p.10, unidad 2, Ej. 1" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/13 L 00, p.10, unidad 2, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 14 L 00, p.11, unidad 2, Ej. 2, dialogo 1" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/14 L 00, p.11, unidad 2, Ej. 2, dialogo 1.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 15 L 00, p.11, unidad 2, Ej. 2, dialogo 2" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/15 L 00, p.11, unidad 2, Ej. 2, dialogo 2.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 16 L 00, p.11, unidad 2, Ej. 2, dialogo 3" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/16 L 00, p.11, unidad 2, Ej. 2, dialogo 3.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 17 L 00, p.11, unidad 2, Ej. 2, dialogo 4" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/17 L 00, p.11, unidad 2, Ej. 2, dialogo 4.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 18 L 00, p.11, unidad 2, Ej. 2, dialogo 5" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/18 L 00, p.11, unidad 2, Ej. 2, dialogo 5.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 19 L 00, p.11, unidad 2, Ej. 3" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/19 L 00, p.11, unidad 2, Ej. 3.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 20 L 00, p.12, unidad 2, Ej. 4" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/20 L 00, p.12, unidad 2, Ej. 4.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 21 L 00, p. 12, unidad 2, Ej. 5" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/21 L 00, p. 12, unidad 2, Ej. 5.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 22 L 00, p. 13, unidad 2, En Accion" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/22 L 00, p. 13, unidad 2, En Accion.mp3" data-free="false"></li>
<li data-title="Leccion 00 - 23 L 00, p. 75, unidad 2, Ejercicio de fonetica 2" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 00/23 L 00, p. 75, unidad 2, Ejercicio de fonetica 2.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 01 L 01, p. 14, Ej. 1" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 01/01 L 01, p. 14, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 02 L 01, p. 14, Ej. 1 cont" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 01/02 L 01, p. 14, Ej. 1 cont.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 03 L 01, p. 15, Ej. 2a" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 01/03 L 01, p. 15, Ej. 2a.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 04 L 01, p. 15, Ej. 2b" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 01/04 L 01, p. 15, Ej. 2b.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 05 L 01, p. 15, Ej. 2c" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 01/05 L 01, p. 15, Ej. 2c.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 06 L 01, p. 17, Ej. 5" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 01/06 L 01, p. 17, Ej. 5.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 07 L 01, p. 17, Ej. 7" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 01/07 L 01, p. 17, Ej. 7.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 08 L 01, p. 18, Ej. 8" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 01/08 L 01, p. 18, Ej. 8.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 09 L 01, p. 19, En accion" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 01/09 L 01, p. 19, En accion.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 10 L 01, p. 76, Ejercicio de fonetica 3" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 01/10 L 01, p. 76, Ejercicio de fonetica 3.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 01 L 02, p. 21, Ej. 4" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 02/01 L 02, p. 21, Ej. 4.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 02 L 02, p. 22, Ej. 5" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 02/02 L 02, p. 22, Ej. 5.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 03 L 02, p. 27, Ej. 10" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 02/03 L 02, p. 27, Ej. 10.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 04 L 02, p. 76, Ejercicio de fonetica 4" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 02/04 L 02, p. 76, Ejercicio de fonetica 4.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 01 L 03, p. 28, Ej. 1" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 03/01 L 03, p. 28, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 02 L 03, p. 29, Ej. 3" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 03/02 L 03, p. 29, Ej. 3.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 03 L 03, p. 30, Ej. 4" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 03/03 L 03, p. 30, Ej. 4.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 04 L 03, p. 31, Ej. 6" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 03/04 L 03, p. 31, Ej. 6.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 05 L 03, p. 76, Ejercicio de fonetica 5" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 03/05 L 03, p. 76, Ejercicio de fonetica 5.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 01 L 04, p. 36, Ej. 1" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 04/01 L 04, p. 36, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 02 L 04, p. 38, En accion" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 04/02 L 04, p. 38, En accion.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 03 L 04, p. 38, Ej. 7" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 04/03 L 04, p. 38, Ej. 7.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 04 L 04, p. 39, Ej. 8" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 04/04 L 04, p. 39, Ej. 8.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 05 L 04, p. 77, Ejercicio de fonetica 6" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 04/05 L 04, p. 77, Ejercicio de fonetica 6.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 01 L 06, p. 44, Ej. 1" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 06/01 L 06, p. 44, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 02 L 06, p. 45, Alim. prohib. para loros" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 06/02 L 06, p. 45, Alim. prohib. para loros.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 03 L 06, p. 47, Ej. 5" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 06/03 L 06, p. 47, Ej. 5.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 04 L 06, p. 47, Ej. 6" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 06/04 L 06, p. 47, Ej. 6.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 05 L 06, p. 49, Ej. 9" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 06/05 L 06, p. 49, Ej. 9.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 06 L 06, p. 77, Ejercicio de fonetica 7" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 06/06 L 06, p. 77, Ejercicio de fonetica 7.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 01 L 07, p. 50, Ej. 1" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 07/01 L 07, p. 50, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 02 L 07, p. 51, Ej. 3" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 07/02 L 07, p. 51, Ej. 3.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 03 L 07, p. 52, Ej. 4" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 07/03 L 07, p. 52, Ej. 4.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 04 L 07, p. 77, Ejercicio de fonetica 8" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 07/04 L 07, p. 77, Ejercicio de fonetica 8.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 01 L 08, p. 56, Ej. 1" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 08/01 L 08, p. 56, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 02 L 08, p. 57, En accion" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 08/02 L 08, p. 57, En accion.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 03 L 08, p. 61, En accion" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 08/03 L 08, p. 61, En accion.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 04 L 08, p. 61, Ej. 8" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 08/04 L 08, p. 61, Ej. 8.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 05 L 08, p. 61, Ej. 9" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 08/05 L 08, p. 61, Ej. 9.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 06 L 08, p. 78, Ejercicio de fonetica 9" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 08/06 L 08, p. 78, Ejercicio de fonetica 9.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 01 L 09, p. 62, Ej. 1" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 09/01 L 09, p. 62, Ej. 1.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 02 L 09, p. 64, Ej. 4" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 09/02 L 09, p. 64, Ej. 4.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 03 L 09, p. 64, En accion" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 09/03 L 09, p. 64, En accion.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 04 L 09, p. 65, Ej. 5" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 09/04 L 09, p. 65, Ej. 5.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 05 L 09, p. 66, Ej. 8" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 09/05 L 09, p. 66, Ej. 8.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 06 L 09, p. 78, Ejercicio de fonetica 10" data-artist="Chiquiteens 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Chiquiteens/Chiquiteens 1/Leccion 09/06 L 09, p. 78, Ejercicio de fonetica 10.mp3" data-free="false"></li>
 
        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
