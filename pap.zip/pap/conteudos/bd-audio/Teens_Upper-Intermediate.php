
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Upper-Intermediate</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
            
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Lesson 01 - 01 L1p06 Kick off - C"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 01/01 L1p06 Kick off - C.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 02 L1p07 Reading and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 01/02 L1p07 Reading and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 03 L1p08 Language Structure - B - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 01/03 L1p08 Language Structure - B - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 04 L1p08 Language Structure - B - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 01/04 L1p08 Language Structure - B - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 05 L1p08 Language Structure - B - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 01/05 L1p08 Language Structure - B - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 06 L1p08 Listening & Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 01/06 L1p08 Listening & Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 07 L1p10 Speaking naturally - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 01/07 L1p10 Speaking naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 08 L1p10 Speaking naturally - B - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 01/08 L1p10 Speaking naturally - B - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 09 L1p11 Curiosity - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 01/09 L1p11 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 01 L2p12 Kick-off - B - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 02/01 L2p12 Kick-off - B - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 02 L2p12 Kick-off - C"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 02/02 L2p12 Kick-off - C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 03 L2p13 Listening and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 02/03 L2p13 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 04 L2p15 Speaking - A - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 02/04 L2p15 Speaking - A - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 05 L2p16 Reading and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 02/05 L2p16 Reading and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 06 L2p16 Reading and Speaking - C"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 02/06 L2p16 Reading and Speaking - C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 07 L2p17 Speaking naturally - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 02/07 L2p17 Speaking naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 08 L2p17 Curiosity - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 02/08 L2p17 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 01 L3p18 Kick-off - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 03/01 L3p18 Kick-off - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 02 L3p19 Kick-off - C - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 03/02 L3p19 Kick-off - C - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 03 L3p20 Listening and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 03/03 L3p20 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 04 L3p21 Reading and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 03/04 L3p21 Reading and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 05 L3p23 Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 03/05 L3p23 Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 06 L3p23 Curiosity - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 03/06 L3p23 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 01 L4p28 Vocabulary and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 04/01 L4p28 Vocabulary and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 02 L4p29 Vocabulary and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 04/02 L4p29 Vocabulary and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 03 L4p29 Reading and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 04/03 L4p29 Reading and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 04 L4p31 Language Structure - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 04/04 L4p31 Language Structure - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 05 L4p31 Language Structure - D"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 04/05 L4p31 Language Structure - D.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 06 L4p32 Speaking naturally - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 04/06 L4p32 Speaking naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 07 L4p32 Speaking naturally - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 04/07 L4p32 Speaking naturally - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 08 L4p33 Curiosity - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 04/08 L4p33 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 01 L5p35 Vocabulary and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 05/01 L5p35 Vocabulary and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 02 L5p36 Listening and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 05/02 L5p36 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 03 L5p37 Reading and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 05/03 L5p37 Reading and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 04 L5p38 Language Structure - B - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 05/04 L5p38 Language Structure - B - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 05 L5p38 Language Structure - D"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 05/05 L5p38 Language Structure - D.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 06 L5p39 Speaking naturally - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 05/06 L5p39 Speaking naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 07 L5p39 Curiosity - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 05/07 L5p39 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 01 L6p40 Kick-off - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 06/01 L6p40 Kick-off - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 02 L6p40 Kick-off - C"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 06/02 L6p40 Kick-off - C.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 03 L6p41 Speaking naturally - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 06/03 L6p41 Speaking naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 04 L6p42 Reading and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 06/04 L6p42 Reading and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 05 L6p42 Reading and Speaking - C - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 06/05 L6p42 Reading and Speaking - C - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 06 L6p43 Language Structure - B - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 06/06 L6p43 Language Structure - B - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 07 L6p44 Listening and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 06/07 L6p44 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 08 L6p44 Listening and Speaking - D"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 06/08 L6p44 Listening and Speaking - D.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 09 L6p45 Curiosity - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 06/09 L6p45 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 01 L7p57 Vocabulary and Speaking - A - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 07/01 L7p57 Vocabulary and Speaking - A - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 02 L7p57 Vocabulary and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 07/02 L7p57 Vocabulary and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 03 L7p58 Listening and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 07/03 L7p58 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 04 L7p59 Language Structure - B - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 07/04 L7p59 Language Structure - B - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 05 L7p59 Language Structure  C"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 07/05 L7p59 Language Structure  C.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 06 L7p60 Reading and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 07/06 L7p60 Reading and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 07 L7p61 Curiosity - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 07/07 L7p61 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 01 L8p63 Listening and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 08/01 L8p63 Listening and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 02 L8p63 Listening and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 08/02 L8p63 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 03 L8p64 Language Structure - C - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 08/03 L8p64 Language Structure - C - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 04 L8p65 Speaking naturally - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 08/04 L8p65 Speaking naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 05 L8p65 Speaking naturally - B - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 08/05 L8p65 Speaking naturally - B - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 06 L8p66 Reading and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 08/06 L8p66 Reading and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 07 L8p67 Speaking - A - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 08/07 L8p67 Speaking - A - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 08 L8p67 Curiosity - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 08/08 L8p67 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 01 L9p69 Speaking naturally - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 09/01 L9p69 Speaking naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 02 L9p69 Reading and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 09/02 L9p69 Reading and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 03 L9p70 Reading and Speaking - E"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 09/03 L9p70 Reading and Speaking - E.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 04 L9p70 Listening and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 09/04 L9p70 Listening and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 05 L9p71 Listening and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 09/05 L9p71 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 06 L9p72 Language Structure - C"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 09/06 L9p72 Language Structure - C.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 07 L9p72 Vocabulary and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 09/07 L9p72 Vocabulary and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 09 - 08 L9p73 Curiosity - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 09/08 L9p73 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 01 L10p78 Kick-off - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 10/01 L10p78 Kick-off - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 02 L10p78 Speaking naturally - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 10/02 L10p78 Speaking naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 03 L10p79 Language Structure - C - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 10/03 L10p79 Language Structure - C - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 04 L10p80 Listening and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 10/04 L10p80 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 05 L10p81 Listening and Speaking - C"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 10/05 L10p81 Listening and Speaking - C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 06 L10p82 Reading and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 10/06 L10p82 Reading and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 07 L10p83 Curiosity - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 10/07 L10p83 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 01 L11p85 Speaking naturally - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 11/01 L11p85 Speaking naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 02 L11p86 Listening and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 11/02 L11p86 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 03 L11p87 Language Structure - D - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 11/03 L11p87 Language Structure - D - C.M.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 04 L11p87 Language Structure - D"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 11/04 L11p87 Language Structure - D.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 05 L11p88 Reading and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 11/05 L11p88 Reading and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 06 L11p89 Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 11/06 L11p89 Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 07 L11p89 Curiosity - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 11/07 L11p89 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 01 L12p90 Kick-off - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 12/01 L12p90 Kick-off - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 02 L12p91 Reading and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 12/02 L12p91 Reading and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 03 L12p92 Language Structure - C"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 12/03 L12p92 Language Structure - C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 04 L12p93 Listening and Speaking - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 12/04 L12p93 Listening and Speaking - B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 05 L12p94 Writing and Speaking - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 12/05 L12p94 Writing and Speaking - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 06 L12p95 Speaking naturally - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 12/06 L12p95 Speaking naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 07 L12p95 Curiosity - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Lesson 12/07 L12p95 Curiosity - B.mp3" data-free="false"></li>
<li data-title="Review 1 - Review 1 - A p54"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Review/Review 1/Review 1 - A p54.mp3" data-free="false"></li>
<li data-title="Review 1 - Review 1 - B p55"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Review/Review 1/Review 1 - B p55.mp3" data-free="false"></li>
<li data-title="Review 1 - Review 1 - C p55"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Review/Review 1/Review 1 - C p55.mp3" data-free="false"></li>
<li data-title="Review 1 - Review 1 - D p55"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Review/Review 1/Review 1 - D p55.mp3" data-free="false"></li>
<li data-title="Review 2 - Review 2 - A p104"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Review/Review 2/Review 2 - A p104.mp3" data-free="false"></li>
<li data-title="Review 2 - Review 2 - B p105"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Review/Review 2/Review 2 - B p105.mp3" data-free="false"></li>
<li data-title="Review 2 - Review 2 - C p105"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Review/Review 2/Review 2 - C p105.mp3" data-free="false"></li>
<li data-title="Review 2 - Review 2 - D p105"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Review/Review 2/Review 2 - D p105.mp3" data-free="false"></li>
<li data-title="Time Out - Time Out 1 p24 Progress check - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Time Out/Time Out 1 p24 Progress check - B.mp3" data-free="false"></li>
<li data-title="Time Out - Time Out 2 p46 Progress check - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Time Out/Time Out 2 p46 Progress check - B.mp3" data-free="false"></li>
<li data-title="Time Out - Time Out 2 p48 Game 2 - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Time Out/Time Out 2 p48 Game 2 - C.M.mp3" data-free="false"></li>
<li data-title="Time Out - Time Out 3 p74 Progress check - C"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Time Out/Time Out 3 p74 Progress check - C.mp3" data-free="false"></li>
<li data-title="Time Out - Time Out 3 p75 Speak up - A"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Time Out/Time Out 3 p75 Speak up - A.mp3" data-free="false"></li>
<li data-title="Time Out - Time Out 3 p76 Game 2 - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Time Out/Time Out 3 p76 Game 2 - C.M.mp3" data-free="false"></li>
<li data-title="Time Out - Time Out 4 p96 Progress check - B"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Time Out/Time Out 4 p96 Progress check - B.mp3" data-free="false"></li>
<li data-title="Time Out - Time Out 4 p97 Speak up - D - C.M"data-artist="Teens Upper-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Upper-intermediate/Time Out/Time Out 4 p97 Speak up - D - C.M.mp3" data-free="false"></li>



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
