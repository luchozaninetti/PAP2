
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Speed 1</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
         
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="In English! - 01 In English! p05 Your teacher may say" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/In English!/01 In English! p05 Your teacher may say.mp3" data-free="false"></li>
<li data-title="In English! - 02 In English! p05 You may need to say" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/In English!/02 In English! p05 You may need to say.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 01 L1 p06 The Interview Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/01 L1 p06 The Interview Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 02 L1 COMPLEMENTARY p06 Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/02 L1 COMPLEMENTARY p06 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 03 L1 p06 Listening & Reading" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/03 L1 p06 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 04 L1 p07 Vocabulary A Greetings & Introductions" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/04 L1 p07 Vocabulary A Greetings & Introductions.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 05 L1 p07 A Greetings & Introductions" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/05 L1 p07 A Greetings & Introductions.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 06 L1 p07 Circle the expressions" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/06 L1 p07 Circle the expressions.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 07 L1 p08 B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/07 L1 p08 B.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 08 L1 p08 1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/08 L1 p08 1.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 09 L1 p09 C The Alphabet" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/09 L1 p09 C The Alphabet.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 10 L1 p09 D Numbers" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/10 L1 p09 D Numbers.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 11 L1 p09 What's your name" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/11 L1 p09 What's your name.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 12 L1 COMPLEMENTARY p09 Vocabulary D1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/12 L1 COMPLEMENTARY p09 Vocabulary D1.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 13 L1 p09 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/13 L1 p09 2.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 14 L1 p10 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/14 L1 p10 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 15 L1 p10 A" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/15 L1 p10 A.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 16 L1 COMPLEMENTARY p10 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/16 L1 COMPLEMENTARY p10 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 17 L1 p10 B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/17 L1 p10 B.mp3" data-free="false"></li>
<li data-title="Lesson 1 - 18 L1 p11 Progress Check C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 1/18 L1 p11 Progress Check C.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 01 L2 p12 Hired Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/01 L2 p12 Hired Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 02 L2 p12 Listening & Reading" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/02 L2 p12 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 03 L2 p13 Vocabulary A" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/03 L2 p13 Vocabulary A.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 04 L2 p13 B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/04 L2 p13 B.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 05 L2 p14 C Days of the Week" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/05 L2 p14 C Days of the Week.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 06 L2 p14 We say" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/06 L2 p14 We say.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 07 L2 p14 What day is today" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/07 L2 p14 What day is today.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 08 L2 p14 D More Vocabulary" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/08 L2 p14 D More Vocabulary.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 09 L2 COMPLEMENTARY p14 Vocabulary D1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/09 L2 COMPLEMENTARY p14 Vocabulary D1.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 10 L2 p14 D 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/10 L2 p14 D 2.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 11 L2 p15 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/11 L2 p15 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 12 L2 p16 Pay attention" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/12 L2 p16 Pay attention.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 13 L2 p16 B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/13 L2 p16 B.mp3" data-free="false"></li>
<li data-title="Lesson 2 - 14 L2 p17 Progress Check C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 2/14 L2 p17 Progress Check C.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 01 L3 p18 The Meeting Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/01 L3 p18 The Meeting Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 02 L3 p18 Listening & Reading" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/02 L3 p18 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 03 L3 p19 Vocabulary A Numbers" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/03 L3 p19 Vocabulary A Numbers.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 04 L3 p19 Numbers" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/04 L3 p19 Numbers.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 05 L3 COMPLEMENTARY p19 Vocabulary A1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/05 L3 COMPLEMENTARY p19 Vocabulary A1.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 06 L3 p19 A 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/06 L3 p19 A 2.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 07 L3 p20 B More Numbers" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/07 L3 p20 B More Numbers.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 08 L3 p20 C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/08 L3 p20 C.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 09 L3 p20 C 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/09 L3 p20 C 2.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 10 L3 p20 One more thing" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/10 L3 p20 One more thing.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 11 L3 p21 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/11 L3 p21 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 12 L3 p22 B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/12 L3 p22 B.mp3" data-free="false"></li>
<li data-title="Lesson 3 - 13 L3 p23 Progress Check C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 3/13 L3 p23 Progress Check C.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 01 L4 p24 First Day at Work Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/01 L4 p24 First Day at Work Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 02 L4 p24 Listening & Reading" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/02 L4 p24 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 03 L4 p25 Vocabulary A Ordinal Numbers" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/03 L4 p25 Vocabulary A Ordinal Numbers.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 04 L4 p25 A Listen and complete" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/04 L4 p25 A Listen and complete.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 05 L4 p25 A 1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/05 L4 p25 A 1.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 06 L4 COMPLEMENTARY p25 Vocabulary A 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/06 L4 COMPLEMENTARY p25 Vocabulary A 2.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 07 L4 p26 B Months" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/07 L4 p26 B Months.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 08 L4 COMPLEMENTARY p26 Vocabulary" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/08 L4 COMPLEMENTARY p26 Vocabulary.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 09 L4 p26 B 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/09 L4 p26 B 2.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 10 L4 p27 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/10 L4 p27 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 11 L4 p27 Listen, complete" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/11 L4 p27 Listen, complete.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 12 L4 p28 C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/12 L4 p28 C.mp3" data-free="false"></li>
<li data-title="Lesson 4 - 13 L4 p29 Progress Check C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 4/13 L4 p29 Progress Check C.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 01 L5 p30 Tasks Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 5/01 L5 p30 Tasks Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 02 L5 p30 Listening & Reading" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 5/02 L5 p30 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 03 L5 p31 Vocabulary A Time" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 5/03 L5 p31 Vocabulary A Time.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 04 L5 COMPLEMENTARY p32 Vocabulary A 1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 5/04 L5 COMPLEMENTARY p32 Vocabulary A 1.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 05 L5 p32 A 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 5/05 L5 p32 A 2.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 06 L5 p32 A 3" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 5/06 L5 p32 A 3.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 07 L5 p32 B Definite and Indefinite Articles" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 5/07 L5 p32 B Definite and Indefinite Articles.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 08 L5 p32 B Complete with A or AN" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 5/08 L5 p32 B Complete with A or AN.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 09 L5 p33 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 5/09 L5 p33 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 10 L5 p33 Pay attention" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 5/10 L5 p33 Pay attention.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 11 L5 p35 C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 5/11 L5 p35 C.mp3" data-free="false"></li>
<li data-title="Lesson 5 - 12 L5 p 35 Progress Check C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 5/12 L5 p 35 Progress Check C.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 01 L6 p36 Good Work! Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/01 L6 p36 Good Work! Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 02 L6 p36 Listening & Reading" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/02 L6 p36 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 03 L6 p37 Vocabulary A Pronouns" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/03 L6 p37 Vocabulary A Pronouns.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 04 L6 p37 Subject Pronouns" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/04 L6 p37 Subject Pronouns.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 05 L6 p37 A 1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/05 L6 p37 A 1.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 06 L6 p37 A 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/06 L6 p37 A 2.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 07 L6 COMPLEMENTARY p37 Vocabulary 3" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/07 L6 COMPLEMENTARY p37 Vocabulary 3.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 08 L6 p38 B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/08 L6 p38 B.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 09 L6 p38 C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/09 L6 p38 C.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 10 L6 p39 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/10 L6 p39 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 11 L6 p39 Regular Verbs" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/11 L6 p39 Regular Verbs.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 12 L6 p40 B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/12 L6 p40 B.mp3" data-free="false"></li>
<li data-title="Lesson 6 - 13 L6 p41 Progress Check C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 6/13 L6 p41 Progress Check C.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 01 L7 p42 Welcome Back Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 7/01 L7 p42 Welcome Back Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 02 L7 p 42 Listening & Reading" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 7/02 L7 p 42 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 03 L7 p43 Vocabulary A Places" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 7/03 L7 p43 Vocabulary A Places.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 04 L7 p 43 A 1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 7/04 L7 p 43 A 1.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 05 L7 COMPLEMENTARY p43 Vocabulary A 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 7/05 L7 COMPLEMENTARY p43 Vocabulary A 2.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 06 L7 p44 B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 7/06 L7 p44 B.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 07 L7 p44 C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 7/07 L7 p44 C.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 08 L7 p45 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 7/08 L7 p45 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 09 L7 p45 Irregular Verbs" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 7/09 L7 p45 Irregular Verbs.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 10 L7 p46 A" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 7/10 L7 p46 A.mp3" data-free="false"></li>
<li data-title="Lesson 7 - 11 L7 p47 Progress Check C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 7/11 L7 p47 Progress Check C.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 01 L8 p48 Making Plans Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 8/01 L8 p48 Making Plans Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 02 L8 COMPLEMENTARY p48 Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 8/02 L8 COMPLEMENTARY p48 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 03 L8 p48 Listening & Reading" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 8/03 L8 p48 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 04 L8 p49 Vocabulary Food and Drinks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 8/04 L8 p49 Vocabulary Food and Drinks.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 05 L8 p50 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 8/05 L8 p50 2.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 06 L8 p51 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 8/06 L8 p51 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 07 L8 p51 Pay attention" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 8/07 L8 p51 Pay attention.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 08 L8 p52 B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 8/08 L8 p52 B.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 09 L8 p52 D" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 8/09 L8 p52 D.mp3" data-free="false"></li>
<li data-title="Lesson 8 - 10 L8 p53 Progress Check C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 8/10 L8 p53 Progress Check C.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 01 L9 p54 Getting a Promotion Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/01 L9 p54 Getting a Promotion Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 02 L9 COMPLEMENTARY p54 Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/02 L9 COMPLEMENTARY p54 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 03 L9 p54 Listening & Reading" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/03 L9 p54 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 04 L9 p55 Vocabulary A Professions" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/04 L9 p55 Vocabulary A Professions.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 05 L9 COMPLEMENTARY p55 Vocabulary A 1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/05 L9 COMPLEMENTARY p55 Vocabulary A 1.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 06 L9 p55 A 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/06 L9 p55 A 2.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 07 L9 p56 B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/07 L9 p56 B.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 08 L9 COMPLEMENTARY p56 Vocabulary B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/08 L9 COMPLEMENTARY p56 Vocabulary B.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 09 L9 p56 Pay attention" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/09 L9 p56 Pay attention.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 10 L9 p57 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/10 L9 p57 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 11 L9 p57 Complete the grids" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/11 L9 p57 Complete the grids.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 12 L9 p58 1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/12 L9 p58 1.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 13 L9 p58 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/13 L9 p58 2.mp3" data-free="false"></li>
<li data-title="Lesson 9 - 14 L9 p59 Progress Check C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 9/14 L9 p59 Progress Check C.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 01 L10 p60 Family Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 10/01 L10 p60 Family Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 02 L10 p60 Listening & Reading" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 10/02 L10 p60 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 03 L10 p61 Vocabulary A Family Tree" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 10/03 L10 p61 Vocabulary A Family Tree.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 04 L10 p61 Listen and check" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 10/04 L10 p61 Listen and check.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 05 L10 p62 Possessive Adjectives" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 10/05 L10 p62 Possessive Adjectives.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 06 L10 p63 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 10/06 L10 p63 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 07 L10 p64 A 1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 10/07 L10 p64 A 1.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 08 L10 COMPLEMENTARY p64 Language Bricks 3" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 10/08 L10 COMPLEMENTARY p64 Language Bricks 3.mp3" data-free="false"></li>
<li data-title="Lesson 10 - 09 L10 p65 Progress Check C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 10/09 L10 p65 Progress Check C.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 01 L11 p66 Dress Code Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 11/01 L11 p66 Dress Code Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 02 L11 p66 Listening & Reading" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 11/02 L11 p66 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 03 L11 p67 Vocabulary A Colors" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 11/03 L11 p67 Vocabulary A Colors.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 04 L11 COMPLEMENTARY p67 Vocabulary A 1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 11/04 L11 COMPLEMENTARY p67 Vocabulary A 1.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 05 L11 p67 A 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 11/05 L11 p67 A 2.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 06 L11 p68 B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 11/06 L11 p68 B.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 07 L11 p68 B 1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 11/07 L11 p68 B 1.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 08 L11 p68 B 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 11/08 L11 p68 B 2.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 09 L11 p69 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 11/09 L11 p69 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 10 L11 p69 Pay attention" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 11/10 L11 p69 Pay attention.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 11 L11 p70 A" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 11/11 L11 p70 A.mp3" data-free="false"></li>
<li data-title="Lesson 11 - 12 L11 p71 Progress Check C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 11/12 L11 p71 Progress Check C.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 01 L12 p72 I Can Do This! Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 12/01 L12 p72 I Can Do This! Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 02 L12 COMPLEMENTARY p72 Conversation" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 12/02 L12 COMPLEMENTARY p72 Conversation.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 03 L12 p72 Listening & Reading" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 12/03 L12 p72 Listening & Reading.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 04 L12 p73 Vocabulary A Appearances" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 12/04 L12 p73 Vocabulary A Appearances.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 05 L12 p73 A 1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 12/05 L12 p73 A 1.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 06 L12 p74 B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 12/06 L12 p74 B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 07 L12 COMPLEMENTARY p74 Vocabulary B" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 12/07 L12 COMPLEMENTARY p74 Vocabulary B.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 08 L12 p75 Language Bricks" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 12/08 L12 p75 Language Bricks.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 09 L12 p76 1" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 12/09 L12 p76 1.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 10 L12 COMPLEMENTARY p76 Language Bricks 2" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 12/10 L12 COMPLEMENTARY p76 Language Bricks 2.mp3" data-free="false"></li>
<li data-title="Lesson 12 - 11 L12 p77 Progress Check C" data-artist="Speed 1" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/ADULTOS/Speed 1/Lesson 12/11 L12 p77 Progress Check C.mp3" data-free="false"></li>


	



        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>
