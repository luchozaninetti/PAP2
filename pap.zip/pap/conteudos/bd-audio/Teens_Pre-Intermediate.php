
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Teens Pre-Intermediate</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
            
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    


<li data-title="Break Time 01 - 01. Break Time 1 - p. 26 - Game"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Break Time 01/01. Break Time 1 - p. 26 - Game.mp3" data-free="false"></li>
<li data-title="Break Time 01 - 02. Break Time 1 - p. 28 - Challenges - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Break Time 01/02. Break Time 1 - p. 28 - Challenges - B.mp3" data-free="false"></li>
<li data-title="Break Time 02 - 01. Break Time 2 - p. 50 - Game"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Break Time 02/01. Break Time 2 - p. 50 - Game.mp3" data-free="false"></li>
<li data-title="Break Time 02 - 02. Break Time 2 - p. 52 - Challenges - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Break Time 02/02. Break Time 2 - p. 52 - Challenges - B.mp3" data-free="false"></li>
<li data-title="Break Time 03 - 01. Break Time 3 - p. 80 - Game"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Break Time 03/01. Break Time 3 - p. 80 - Game.mp3" data-free="false"></li>
<li data-title="Break Time 03 - 02. Break Time 3 - p. 82 - Challenges - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Break Time 03/02. Break Time 3 - p. 82 - Challenges - B.mp3" data-free="false"></li>
<li data-title="Clear Com. 01 - 01. Clear Com.1 - p. 22 - R&S - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Clear Com. 01/01. Clear Com.1 - p. 22 - R&S - B.mp3" data-free="false"></li>
<li data-title="Clear Com. 01 - 02. Clear Com.1 - p. 23 - L&S - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Clear Com. 01/02. Clear Com.1 - p. 23 - L&S - A.mp3" data-free="false"></li>
<li data-title="Clear Com. 02 - 01. Clear Com.2 - p. 46 - R&S - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Clear Com. 02/01. Clear Com.2 - p. 46 - R&S - B.mp3" data-free="false"></li>
<li data-title="Clear Com. 02 - 02. Clear Com.2 - p. 48 - L&S - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Clear Com. 02/02. Clear Com.2 - p. 48 - L&S - B.mp3" data-free="false"></li>
<li data-title="Clear Com. 03 - 01. Clear Com.3 - p. 76 - R&S - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Clear Com. 03/01. Clear Com.3 - p. 76 - R&S - B.mp3" data-free="false"></li>
<li data-title="Clear Com. 03 - 02. Clear Com3 - p. 78 -L&Ss - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Clear Com. 03/02. Clear Com3 - p. 78 -L&Ss - B.mp3" data-free="false"></li>
<li data-title="Clear Com. 04 - 01. Clear Com.4 - p. 100 - R&S - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Clear Com. 04/01. Clear Com.4 - p. 100 - R&S - A.mp3" data-free="false"></li>
<li data-title="Clear Com. 04 - 02. Clear Com.4 - p. 102 - L&S - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Clear Com. 04/02. Clear Com.4 - p. 102 - L&S - A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 01. L01 - p. 06 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 01/01. L01 - p. 06 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 02. L01 - p. 07 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 01/02. L01 - p. 07 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 03. L01 - p. 08 - Now I know! - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 01/03. L01 - p. 08 - Now I know! - B.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 04. L01 - p. 09 - Now I know! - E"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 01/04. L01 - p. 09 - Now I know! - E.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 05. L01 - p. 09 - Now I know! - G"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 01/05. L01 - p. 09 - Now I know! - G.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 06. L01 - p. 10 - The right words - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 01/06. L01 - p. 10 - The right words - A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 07. L01 - p. 11 - The right words - C"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 01/07. L01 - p. 11 - The right words - C.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 08. L01 - p. 12 - Say it naturally - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 01/08. L01 - p. 12 - Say it naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 01 - 09. L01 - p. 13 - What comes next - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 01/09. L01 - p. 13 - What comes next - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 01. L02 - p. 14 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 02/01. L02 - p. 14 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 02. L02 - p. 15 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 02/02. L02 - p. 15 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 03. L02 - p. 16 - Now I know! - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 02/03. L02 - p. 16 - Now I know! - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 04. L02 - p. 17 - Now I know! - E"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 02/04. L02 - p. 17 - Now I know! - E.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 05. L02 - p. 18 - The right words - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 02/05. L02 - p. 18 - The right words - A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 06. L02 - p. 18 - The right words - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 02/06. L02 - p. 18 - The right words - B.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 07. L02 - p. 19 - The right words - C"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 02/07. L02 - p. 19 - The right words - C.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 08. L02 - p. 20 - Say it naturally - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 02/08. L02 - p. 20 - Say it naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 02 - 09. L02 - p. 21 - What comes next - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 02/09. L02 - p. 21 - What comes next - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 01. L03 - p. 30 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 03/01. L03 - p. 30 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 02. L03 - p. 31 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 03/02. L03 - p. 31 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 03. L03 - p. 32 - Now I know! - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 03/03. L03 - p. 32 - Now I know! - B.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 04. L03 - p. 33 - Now I know! - E"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 03/04. L03 - p. 33 - Now I know! - E.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 05. L03 - p. 33 - Now I know! - G"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 03/05. L03 - p. 33 - Now I know! - G.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 06. L03 - p. 34 - The right words - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 03/06. L03 - p. 34 - The right words - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 07. L03 - p. 35 - The right words - D"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 03/07. L03 - p. 35 - The right words - D.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 08. L03 - p. 36 - Say it naturally - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 03/08. L03 - p. 36 - Say it naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 03 - 09. L03 - p. 37 - What comes next - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 03/09. L03 - p. 37 - What comes next - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 01. L04 - p. 38 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 04/01. L04 - p. 38 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 02. L04 - p. 39 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 04/02. L04 - p. 39 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 03. L04 - p. 40 - Now I know! - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 04/03. L04 - p. 40 - Now I know! - B.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 04. L04 - p. 41 - Now I know! - F"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 04/04. L04 - p. 41 - Now I know! - F.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 05. L04 - p. 42 - The right words - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 04/05. L04 - p. 42 - The right words - A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 06. L04 - p. 43 - The right words - C"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 04/06. L04 - p. 43 - The right words - C.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 07. L04 - p. 43 - The right words - D"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 04/07. L04 - p. 43 - The right words - D.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 08. L04 - p. 44 - Say it naturally - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 04/08. L04 - p. 44 - Say it naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 04 - 09. L04 - p. 45 - What comes next - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 04/09. L04 - p. 45 - What comes next - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 01. L05 - p. 60 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 05/01. L05 - p. 60 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 02. L05 - p. 61 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 05/02. L05 - p. 61 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 03. L05 - p. 63 - Now I know! - D"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 05/03. L05 - p. 63 - Now I know! - D.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 04. L05 - p. 63 - Now I know! - G"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 05/04. L05 - p. 63 - Now I know! - G.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 05. L05 - p. 64 - The right words - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 05/05. L05 - p. 64 - The right words - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 06. L05 - p. 64 - The right words - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 05/06. L05 - p. 64 - The right words - B.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 07. L05 - p. 65 - The right words - D"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 05/07. L05 - p. 65 - The right words - D.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 08. L05 - p. 66 - Say it naturally - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 05/08. L05 - p. 66 - Say it naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 05 - 09. L05 - p. 67 - What comes next - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 05/09. L05 - p. 67 - What comes next - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 01. L06 - p. 68 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 06/01. L06 - p. 68 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 02. L06 - p. 69 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 06/02. L06 - p. 69 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 03. L06 - p. 70 - Now I know! - C"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 06/03. L06 - p. 70 - Now I know! - C.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 04. L06 - p. 71 - Now I know! - G"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 06/04. L06 - p. 71 - Now I know! - G.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 05. L06 - p. 72 - The right words - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 06/05. L06 - p. 72 - The right words - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 06. L06 - p. 73 - The right words - D"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 06/06. L06 - p. 73 - The right words - D.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 07. L06 - p. 73 - The right words - E"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 06/07. L06 - p. 73 - The right words - E.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 08. L06 - p. 74 - Say it naturally - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 06/08. L06 - p. 74 - Say it naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 09. L06 - p. 74 - Say it naturally - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 06/09. L06 - p. 74 - Say it naturally - B.mp3" data-free="false"></li>
<li data-title="Lesson 06 - 10. L06 - p. 75 - What comes next - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 06/10. L06 - p. 75 - What comes next - B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 01. L07 - p. 84 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 07/01. L07 - p. 84 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 02. L07 - p. 85 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 07/02. L07 - p. 85 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 03. L07 - p. 86 - Now I know! - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 07/03. L07 - p. 86 - Now I know! - B.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 04. L07 - p. 87 - Now I know! - D"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 07/04. L07 - p. 87 - Now I know! - D.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 05. L07 - p. 87 - Now I know! - F"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 07/05. L07 - p. 87 - Now I know! - F.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 06. L07 - p. 88 - The right words - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 07/06. L07 - p. 88 - The right words - A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 07. L07 - p. 89 - The right words - D"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 07/07. L07 - p. 89 - The right words - D.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 08. L07 - p. 90 - Say it naturally - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 07/08. L07 - p. 90 - Say it naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 07 - 09. L07 - p. 91 - What comes next - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 07/09. L07 - p. 91 - What comes next - B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 01. L08 - p. 92 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 08/01. L08 - p. 92 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 02. L08 - p. 93 - Interacting - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 08/02. L08 - p. 93 - Interacting - B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 03. L08 - p. 95 - Now I know! - F"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 08/03. L08 - p. 95 - Now I know! - F.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 04. L08 - p. 95 - Now I know! - G"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 08/04. L08 - p. 95 - Now I know! - G.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 05. L08 - p. 96 - The right words - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 08/05. L08 - p. 96 - The right words - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 06. L08 - p. 96 - The right words - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 08/06. L08 - p. 96 - The right words - B.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 07. L08 - p. 98 - Say it naturally - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 08/07. L08 - p. 98 - Say it naturally - A.mp3" data-free="false"></li>
<li data-title="Lesson 08 - 08. L08 - p. 99 -  - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Lesson 08/08. L08 - p. 99 -  - B.mp3" data-free="false"></li>
<li data-title="Review 01 - 01. Review 1 - p. 58 - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Review 01/01. Review 1 - p. 58 - A.mp3" data-free="false"></li>
<li data-title="Review 01 - 02. Review 1 - p. 58 - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Review 01/02. Review 1 - p. 58 - B.mp3" data-free="false"></li>
<li data-title="Review 01 - 03. Review 1 - p. 58 - C"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Review 01/03. Review 1 - p. 58 - C.mp3" data-free="false"></li>
<li data-title="Review 01 - 04. Review 1 - p. 59 - D"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Review 01/04. Review 1 - p. 59 - D.mp3" data-free="false"></li>
<li data-title="Review 02 - 01. Review 2 - p. 112 - A"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Review 02/01. Review 2 - p. 112 - A.mp3" data-free="false"></li>
<li data-title="Review 02 - 02. Review 2 - p. 112 - B"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Review 02/02. Review 2 - p. 112 - B.mp3" data-free="false"></li>
<li data-title="Review 02 - 03. Review 2 - p. 112 - C"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Review 02/03. Review 2 - p. 112 - C.mp3" data-free="false"></li>
<li data-title="Review 02 - 04. Review 2 - p. 113 - D"data-artist="Teens Pre-intermediate"data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/INGLES/TEENS/Teens Pre-intermediate/Review 02/04. Review 2 - p. 113 - D.mp3" data-free="false"></li>




        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

