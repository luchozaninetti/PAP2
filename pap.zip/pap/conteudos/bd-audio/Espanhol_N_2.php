
<?php require_once('../../inc/nav.php'); ?>

<?php require_once('../../inc/Medoo.php'); ?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fisk - Unidade</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Player de áudio -->
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery-1.11.3.min.js"></script>
    <script src="https://www.dmzi.com.br/pap/player/audio/jquery.cleanaudioplayer.js"></script>
    <link href="https://www.dmzi.com.br/pap/player/audio/player.css" rel="stylesheet">

    <!-- Ícones e favicon -->
    <link rel="shortcut icon" href="../../img/logo.jpg" type="image/x-icon" />
    <link rel="icon" href="../../img/logo.jpg" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../../img/logo.jpg">

    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="../../css/estilos.css">
</head>
<body>

<div class="container my-4">
    <div class="text-center mb-4">
        <img src="../../img/logo.jpg" alt="Logo" class="img-fluid" style="max-height: 80px;">
    </div>

    <div class="text-center mb-3">
        <h4 class="fw-bold text-primary">Livro - Espa�ol con � 2</h4>
    </div>

    <!-- Botões de navegação -->
    <div class="d-flex justify-content-center gap-2 mb-4">
        <button class="btn btn-secondary" onclick="history.back()">Voltar</button>
       
    </div>

    <!-- Lista de áudios -->
    <div class="mediatec-cleanaudioplayer">
        <ul data-theme="white" data-playlist-height="400px">
  
            <!-- ADICIONE OS DEMAIS ÁUDIOS-->
    

<li data-title="Leccion 01 - 001. L 01, p. 007, A descubrir... - B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 01/001. L 01, p. 007, A descubrir... - B.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 002. L 01, p. 008, A trabajar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 01/002. L 01, p. 008, A trabajar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 003. AG - L 01, p. 079, Ej. A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 01/003. AG - L 01, p. 079, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 004. AG - L 01, p. 080, Ej. B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 01/004. AG - L 01, p. 080, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 005. AG - L 01, p. 080, Ej. C" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 01/005. AG - L 01, p. 080, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 006. MC - L 01 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 01/006. MC - L 01 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 01 - 007. AG - L 01, p. 081, Ej. D" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 01/007. AG - L 01, p. 081, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 008. L 01, p. 011, A escuchar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 01/008. L 01, p. 011, A escuchar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 009. MC - L 01 - A hablar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 01/009. MC - L 01 - A hablar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 01 - 010. AG - L 01, p. 082, Ej. F" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 01/010. AG - L 01, p. 082, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 001. L 02, p. 015, A descubrir... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/001. L 02, p. 015, A descubrir... - A.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 002. AG - L 02, p. 083, Ej. A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/002. AG - L 02, p. 083, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 003. L 02, p. 016, A escuchar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/003. L 02, p. 016, A escuchar....mp3" data-free="false"></li>
<li data-title="Leccion 02 - 004. AG - L 02, p. 084, Ej. B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/004. AG - L 02, p. 084, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 005. AG - L 02, p. 084, Ej. C" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/005. AG - L 02, p. 084, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 006. AG - L 02, p. 085, Ej. D" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/006. AG - L 02, p. 085, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 007. AG - L 02, p. 085, Ej. E" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/007. AG - L 02, p. 085, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 008. MC - L 02 - A practicar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/008. MC - L 02 - A practicar....mp3" data-free="false"></li>
<li data-title="Leccion 02 - 009. MC - L 02 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/009. MC - L 02 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 02 - 010. AG - L 02, p. 086, Ej. F" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/010. AG - L 02, p. 086, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 011. AG - L 02, p. 087, Ej. G" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/011. AG - L 02, p. 087, Ej. G.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 012. AG - L 02, p. 087, Ej. H" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/012. AG - L 02, p. 087, Ej. H.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 013. MC - L 02 - A hablar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/013. MC - L 02 - A hablar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 014. MC - L 02 - A hablar... - C" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/014. MC - L 02 - A hablar... - C.mp3" data-free="false"></li>
<li data-title="Leccion 02 - 015. MC - L 02 - A practicar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/015. MC - L 02 - A practicar....mp3" data-free="false"></li>
<li data-title="Leccion 02 - 016. AG - L 02, p. 088, Ej. I" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 02/016. AG - L 02, p. 088, Ej. I.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 001. MC - L 03 - A trabajar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 03/001. MC - L 03 - A trabajar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 002. L 03, p. 022, A trabajar... - B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 03/002. L 03, p. 022, A trabajar... - B.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 003. MC - L 03 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 03/003. MC - L 03 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 03 - 004. L 03, p. 024, A escuchar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 03/004. L 03, p. 024, A escuchar....mp3" data-free="false"></li>
<li data-title="Leccion 03 - 005. MC - L 03 - A aprender... - B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 03/005. MC - L 03 - A aprender... - B.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 006. AG - L 03, p. 090, Ej. C" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 03/006. AG - L 03, p. 090, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 007. AG - L 03, p. 091, Ej. D" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 03/007. AG - L 03, p. 091, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 008. MC - L 03 - A practicar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 03/008. MC - L 03 - A practicar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 009. MC - L 03 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 03/009. MC - L 03 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 03 - 010. L 03, p. 026, A conocer..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 03/010. L 03, p. 026, A conocer....mp3" data-free="false"></li>
<li data-title="Leccion 03 - 011. AG - L 03, p. 091, Ej. E" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 03/011. AG - L 03, p. 091, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 03 - 012. AG - L 03, p. 092, Ej. F" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 03/012. AG - L 03, p. 092, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 001. L 04, p. 029, A trabajar... - B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 04/001. L 04, p. 029, A trabajar... - B.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 002. AG - L 04, p. 093, Ej. A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 04/002. AG - L 04, p. 093, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 003. AG - L 04, p. 093, Ej. B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 04/003. AG - L 04, p. 093, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 004. MC - L 04 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 04/004. MC - L 04 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 04 - 005. L 04, p. 032, A escuchar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 04/005. L 04, p. 032, A escuchar....mp3" data-free="false"></li>
<li data-title="Leccion 04 - 006. MC - L 04 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 04/006. MC - L 04 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 04 - 007. AG - L 04, p. 095, Ej. E" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 04/007. AG - L 04, p. 095, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 008. MC - L 04 - A practicar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 04/008. MC - L 04 - A practicar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 04 - 009. AG - L 04, p. 095, Ej. F" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 04/009. AG - L 04, p. 095, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 001. L 05, p. 036, A escuchar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/001. L 05, p. 036, A escuchar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 002. AG - L 05, p. 096, Ej. A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/002. AG - L 05, p. 096, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 003. AG - L 05, p. 096, Ej. B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/003. AG - L 05, p. 096, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 004. AG - L 05, p. 097, Ej. C" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/004. AG - L 05, p. 097, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 005. MC - L 05 - A practicar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/005. MC - L 05 - A practicar....mp3" data-free="false"></li>
<li data-title="Leccion 05 - 006. MC - L 05 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/006. MC - L 05 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 05 - 007. L 05, p. 039, A conocer..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/007. L 05, p. 039, A conocer....mp3" data-free="false"></li>
<li data-title="Leccion 05 - 008. MC - L 05 - A conocer..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/008. MC - L 05 - A conocer....mp3" data-free="false"></li>
<li data-title="Leccion 05 - 009. L 05, p. 040, A escuchar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/009. L 05, p. 040, A escuchar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 010. AG - L 05, p. 097, Ej. D" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/010. AG - L 05, p. 097, Ej. D.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 011. MC - L 05 - A trabajar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/011. MC - L 05 - A trabajar....mp3" data-free="false"></li>
<li data-title="Leccion 05 - 012. AG - L 05, p. 099, Ej. G" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/012. AG - L 05, p. 099, Ej. G.mp3" data-free="false"></li>
<li data-title="Leccion 05 - 013. AG - L 05, p. 099, Ej. H" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 05/013. AG - L 05, p. 099, Ej. H.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 001. L 06, p. 043, A descubrir... - C" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/001. L 06, p. 043, A descubrir... - C.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 002. MC - L 06 - A practicar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/002. MC - L 06 - A practicar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 003. AG - L 06, p. 100, Ej. A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/003. AG - L 06, p. 100, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 004. AG - L 06, p. 100, Ej. B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/004. AG - L 06, p. 100, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 005. MC - L 06 - A practicar... - B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/005. MC - L 06 - A practicar... - B.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 006. MC - L 06 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/006. MC - L 06 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 06 - 007. AG - L 06, p. 101, Ej. C" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/007. AG - L 06, p. 101, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 008. L 06, p. 045, A escuchar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/008. L 06, p. 045, A escuchar....mp3" data-free="false"></li>
<li data-title="Leccion 06 - 009. L 06, p. 046, A descubrir..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/009. L 06, p. 046, A descubrir....mp3" data-free="false"></li>
<li data-title="Leccion 06 - 010. AG - L 06, p. 102, Ej. E" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/010. AG - L 06, p. 102, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 011. AG - L 06, p. 103, Ej. F" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/011. AG - L 06, p. 103, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 06 - 012. MC - L 06 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/012. MC - L 06 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 06 - 013. AG - L 06, p. 103, Ej. G" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 06/013. AG - L 06, p. 103, Ej. G.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 001. L 07, p. 051, A escuchar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 07/001. L 07, p. 051, A escuchar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 002. MC - L 07 - A hablar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 07/002. MC - L 07 - A hablar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 003. AG - L 07, p. 104, Ej. A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 07/003. AG - L 07, p. 104, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 004. AG - L 07, p. 104, Ej. B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 07/004. AG - L 07, p. 104, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 005. MC - L 07 - A hablar... - B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 07/005. MC - L 07 - A hablar... - B.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 006. MC - L 07 - A hablar... - C" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 07/006. MC - L 07 - A hablar... - C.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 007. AG - L 07, p. 105, Ej. C" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 07/007. AG - L 07, p. 105, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 008. L 07, p. 054, A conocer... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 07/008. L 07, p. 054, A conocer... - A.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 009. AG - L 07, p. 106, Ej. E" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 07/009. AG - L 07, p. 106, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 07 - 010. AG - L 07, p. 107, Ej. G" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 07/010. AG - L 07, p. 107, Ej. G.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 001. L 08, p. 059, A descubrir... - B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 08/001. L 08, p. 059, A descubrir... - B.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 002. AG - L 08, p. 108, Ej. A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 08/002. AG - L 08, p. 108, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 003. AG - L 08, p. 108, Ej. B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 08/003. AG - L 08, p. 108, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 004. MC - L 08 - A practicar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 08/004. MC - L 08 - A practicar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 005. MC - L 08 - A practicar... - B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 08/005. MC - L 08 - A practicar... - B.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 006. MC - L 08 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 08/006. MC - L 08 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 08 - 007. L 08, p. 062, A escuchar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 08/007. L 08, p. 062, A escuchar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 008. L 08, p. 062, A escuchar... - B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 08/008. L 08, p. 062, A escuchar... - B.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 009. AG - L 08, p. 110, Ej. F" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 08/009. AG - L 08, p. 110, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 08 - 010. MC - L 08 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 08/010. MC - L 08 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 08 - 011. AG - L 08, p. 110, Ej. G" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 08/011. AG - L 08, p. 110, Ej. G.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 001. L 09, p. 065, A escuchar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/001. L 09, p. 065, A escuchar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 002. L 09, p. 065, A escuchar... - B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/002. L 09, p. 065, A escuchar... - B.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 003. AG - L 09, p. 111, Ej. A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/003. AG - L 09, p. 111, Ej. A.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 004. AG - L 09, p. 111, Ej. B" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/004. AG - L 09, p. 111, Ej. B.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 005. MC - L 09 - A practicar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/005. MC - L 09 - A practicar....mp3" data-free="false"></li>
<li data-title="Leccion 09 - 006. L 09, p. 067, A escuchar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/006. L 09, p. 067, A escuchar....mp3" data-free="false"></li>
<li data-title="Leccion 09 - 007. L 09, p. 067, A pensar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/007. L 09, p. 067, A pensar....mp3" data-free="false"></li>
<li data-title="Leccion 09 - 008. MC - L 09 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/008. MC - L 09 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 09 - 009. AG - L 09, p. 112, Ej. E" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/009. AG - L 09, p. 112, Ej. E.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 010. MC - L 09 - A trabajar... - A" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/010. MC - L 09 - A trabajar... - A.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 011. AG - L 09, p. 112, Ej. F" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/011. AG - L 09, p. 112, Ej. F.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 012. MC - L 09 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/012. MC - L 09 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 09 - 013. AG - L 09, p. 113, Ej. G" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/013. AG - L 09, p. 113, Ej. G.mp3" data-free="false"></li>
<li data-title="Leccion 09 - 014. AG - L 09, p. 113, Ej. H" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 09/014. AG - L 09, p. 113, Ej. H.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 001. L 10, p. 070, A escuchar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 10/001. L 10, p. 070, A escuchar....mp3" data-free="false"></li>
<li data-title="Leccion 10 - 002. MC - L 10 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 10/002. MC - L 10 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 10 - 003. AG - L 10, p. 115, Ej. C" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 10/003. AG - L 10, p. 115, Ej. C.mp3" data-free="false"></li>
<li data-title="Leccion 10 - 004. L 10, p. 073, A escuchar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 10/004. L 10, p. 073, A escuchar....mp3" data-free="false"></li>
<li data-title="Leccion 10 - 005. MC - L 10 - A hablar..." data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 10/005. MC - L 10 - A hablar....mp3" data-free="false"></li>
<li data-title="Leccion 10 - 006. AG - L 10, p. 116, Ej. G" data-artist="Espanhol N 2" data-type="mp3" data-url="https://www.dmzi.com.br/fisk-online/dados/AUDIO/ESPANHOL/Espanol con n/Espanhol N 2/Leccion 10/006. AG - L 10, p. 116, Ej. G.mp3" data-free="false"></li>




        </ul>
    </div>
</div>

<?php require_once('../../inc/rodape.php'); ?>


</body>
</html>

