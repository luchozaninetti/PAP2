<?php
session_start();
require_once('../inc/Medoo.php');

// Idioma: Espanhol (id = 1)
$idioma_id = 1;
$idioma = $basedados->get("idioma", "*", ["id" => $idioma_id]);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>FISK - Áudios de Espanhol</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Estilo -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/estilos.css" rel="stylesheet">
    
    <link rel="shortcut icon" href="../images/icone.ico" type="image/x-icon">
</head>

<body>

<?php require_once('../inc/nav.php'); ?>
<?php require_once('../inc/banner.php'); ?>

<main class="container mt-4 mb-5">

    <section class="text-center mb-5">
        <h1 class="display-5 fw-bold">Audio de Espanhol</h1>
        <p class="text-muted fs-5">Selecione o material de áudio disponível para o curso de espanhol.</p>
    </section>

    <section class="row g-4 justify-content-center">
        <?php
        $materiais = [
            [
                'titulo' => 'Chiquiteens',
                'icone' => 'fa-book',
                'cor' => 'primary',
                'links' => [
                    ['Chiquiteens 1', 'bd-audio/Chiquiteens_1.php'],
                    ['Chiquiteens 2', 'bd-audio/Chiquiteens_2.php']
                ]
            ],
            [
                'titulo' => 'Conectate',
                'icone' => 'fa-plug',
                'cor' => 'success',
                'links' => [
                    ['Conectate 1', 'bd-audio/Conectate_1.php'],
                    ['Conectate 2', 'bd-audio/Conectate_2.php'],
                    ['Conectate 3', 'bd-audio/Conectate_3.php'],
                    ['Conectate 4', 'bd-audio/Conectate_4.php']
                ]
            ],
            [
                'titulo' => 'Español con Ñ',
                'icone' => 'fa-language',
                'cor' => 'danger',
                'links' => [
                    ['Ñ 1', 'bd-audio/Espanhol_N_1.php'],
                    ['Ñ 2', 'bd-audio/Espanhol_N_2.php'],
                    ['Ñ 3', 'bd-audio/Espanhol_N_3.php'],
                    ['Ñ 4', 'bd-audio/Espanhol_N_4.php'],
                    ['Ñ 5', 'bd-audio/Espanhol_N_5.php'],
                    ['Inmediato 1', 'bd-audio/Espanol_Inmediato_1.php'],
                    ['Inmediato 2', 'bd-audio/Espanol_Inmediato_2.php'],
                    ['Inmediato 3', 'bd-audio/Espanol_Inmediato_3.php']
                ]
            ],
            [
                'titulo' => 'Siele',
                'icone' => 'fa-pencil',
                'cor' => 'warning text-dark',
                'links' => [
                    ['Extra 1', 'bd-audio/practica_extra_1.php'],
                    ['Extra 2', 'bd-audio/practica_extra_2.php']
                ]
            ],
        ];

        foreach ($materiais as $item):
        ?>
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-<?= $item['cor'] ?> text-white">
                    <i class="fa <?= $item['icone'] ?>"></i> <?= $item['titulo'] ?>
                </div>
                <ul class="list-group list-group-flush">
                    <?php foreach ($item['links'] as [$texto, $url]): ?>
                        <li class="list-group-item">
                            <a href="<?= $url ?>" class="text-decoration-none"><?= $texto ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <?php endforeach; ?>
    </section>
</main>

<?php require_once('../inc/rodape.php'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
