<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>FISK - Vídeos de Espanhol</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Estilo personalizado -->
    <link href="../css/estilos.css" rel="stylesheet">

    <!-- Ícones -->
    <link rel="shortcut icon" href="../images/icone.ico" type="image/x-icon" />
    <link rel="icon" href="../images/icone.ico" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../images/icone.ico">


</head>

<body>

<?php require_once('../inc/nav.php'); ?>
<?php require_once('../inc/banner.php'); ?>

<main class="container mt-4 mb-5">

    <section class="text-center mb-5">
        <h1 class="display-5 fw-bold">Vídeos de Espanhol</h1>
        <p class="text-muted fs-5">Selecione os materiais em vídeo disponíveis para o curso de espanhol.</p>
    </section>

    <section class="row g-4 justify-content-center">
        <?php
        $materiais = [
            [
                'titulo' => 'Chiquiteens',
                'icone' => 'fa-video',
                'cor' => 'danger',
                'links' => [
                    ['Chiquiteens 1', 'bd-video/Chiquiteens_1.php'],
                    ['Chiquiteens 2', 'bd-video/Chiquiteens_2.php']
                ]
            ],
            [
                'titulo' => 'Conectate',
                'icone' => 'fa-video',
                'cor' => 'success',
                'links' => [
                    ['Conectate 1', 'bd-video/Conectate_1.php'],
                    ['Conectate 2', 'bd-video/Conectate_2.php'],
                    ['Conectate 3', 'bd-video/Conectate_3.php'],
                    ['Conectate 4', 'bd-video/Conectate_4.php']
                ]
            ]
        ];

        foreach ($materiais as $item):
        ?>
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-<?= $item['cor'] ?> text-white">
                    <i class="fa <?= $item['icone'] ?>"></i> <?= $item['titulo'] ?>
                </div>
                <ul class="list-group list-group-flush">
                    <?php foreach ($item['links'] as [$texto, $url]): ?>
                        <li class="list-group-item">
                            <a href="<?= $url ?>" class="text-decoration-none"><?= $texto ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <?php endforeach; ?>
    </section>
</main>

<?php require_once('../inc/rodape.php'); ?>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139974229-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-139974229-1');
</script>

</body>
</html>
