<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>FISK - Vídeos de Inglês</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Estilo personalizado -->
    <link href="../css/estilos.css" rel="stylesheet">


    <!-- Ícones -->
    <link rel="shortcut icon" href="../images/icone.ico" type="image/x-icon" />
    <link rel="icon" href="../images/icone.ico" sizes="192x192">
    <link rel="apple-touch-icon" sizes="180x180" href="../images/icone.ico">

    
</head>
<body>

<?php require_once('../inc/nav.php'); ?>
<?php require_once('../inc/banner.php'); ?>

<main class="container mt-4 mb-5">

    <section class="text-center mb-5">
        <h1 class="display-5 fw-bold">Vídeos de Inglês</h1>
        <p class="text-muted fs-5">Selecione os materiais em vídeo disponíveis para o curso de inglês.</p>
    </section>

    <section class="row g-4 justify-content-center">
        <?php
        $categorias = [
            [
                'titulo' => 'Adulto',
                'cor' => 'primary',
                'videos' => [
                    ['Aiming At the Sky', 'bd-video/aiming_at_the_sky.php'],
                    ['Breaking Free', 'bd-video/breaking_free.php'],
                    ['Essentials 1', 'bd-video/essentials_1.php'],
                    ['Essentials 2', 'bd-video/essentials_2.php'],
                    ['Expanding Horizons', 'bd-video/expanding_horizons.php'],
                    ['Fluency 1', 'bd-video/fluency_1.php'],
                    ['Fluency 2', 'bd-video/fluency_2.php'],
                    ['Flying High', 'bd-video/flying_high.php'],
                    ['Spreading Wings', 'bd-video/Spreading_Wings.php'],
                    ['Transitions 1', 'bd-video/Transitions_1.php'],
                    ['Transitions 2', 'bd-video/Transitions_2.php'],
                    ['Wings of Freedom', 'bd-video/wings_of_freedom.php']
                ]
            ],
            [
                'titulo' => 'Infantil',
                'cor' => 'success',
                'videos' => [
                    ['Have Fun 1', 'bd-video/Have_Fun_1.php'],
                    ['Have Fun 2', 'bd-video/Have_Fun_2.php'],
                    ['Magic Way Blue', 'bd-video/Magic_Way_Blue.php'],
                    ['Magic Way Yellow', 'bd-video/Magic_Way_Yellow.php'],
                    ['Playground 1', 'bd-video/Playground_1.php'],
                    ['Playground 2', 'bd-video/Playground_2.php']
                ]
            ],
            [
                'titulo' => 'Teens',
                'cor' => 'warning',
                'videos' => [
                    ['Teens Advanced', 'bd-video/teens_advanced.php'],
                    ['Teens Elementary 1', 'bd-video/Teens_Elementary_1.php'],
                    ['Teens Elementary 2', 'bd-video/Teens_Elementary_2.php'],
                    ['Teens Higher 1', 'bd-video/Teens_Higher_1.php'],
                    ['Teens Higher 2', 'bd-video/Teens_Higher_2.php'],
                    ['Teens Intermediate', 'bd-video/Teens_Intermediate.php'],
                    ['Teens Pre-intermediate', 'bd-video/Teens_Pre-Intermediate.php'],
                    ['Teens Upper-intermediate', 'bd-video/Teens_Upper-Intermediate.php']
                ]
            ],
            [
                'titulo' => 'Teenstation',
                'cor' => 'danger',
                'videos' => [
                    ['Teenstation 1', 'bd-video/Teenstation_1.php'],
                    ['Teenstation 2', 'bd-video/Teenstation_2.php'],
                    ['Teenstation 3', 'bd-video/Teenstation_3.php'],
                    ['Teenstation 4', 'bd-video/Teenstation_4.php']
                ]
            ]
        ];

        foreach ($categorias as $categoria):
        ?>
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-<?= $categoria['cor'] ?> text-white">
                    <i class="fa fa-video"></i> <?= $categoria['titulo'] ?>
                </div>
                <ul class="list-group list-group-flush">
                    <?php foreach ($categoria['videos'] as [$titulo, $link]): ?>
                        <li class="list-group-item">
                            <a href="<?= $link ?>" class="text-decoration-none"><?= $titulo ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <?php endforeach; ?>
    </section>

</main>

<?php require_once('../inc/rodape.php'); ?>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139974229-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-139974229-1');
</script>

</body>
</html>
