<?php
session_start();

if (!isset($_SESSION['autenticado'])) {
    // header('Location: login.php');
    // exit;
}
?>
<!doctype html>
<html lang="pt">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fisk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/estilos.css" rel="stylesheet">
</head>

<body>

    <?php require_once('inc/nav.php'); ?>

    <main class="container-fluid">
        <?php require_once('inc/banner.php'); ?>

        <section class="row mt-4 mb-4">
            <article class="col-12 text-center">
                <h1 class="display-5 fw-bold text-danger">Bem-vindo à Plataforma Acadêmica Fisk</h1>
                <p class="lead">Ambiente exclusivo para alunos, professores e administradores da escola de línguas.</p>
            </article>
        </section>

        <section class="row justify-content-center mb-5">
            <div class="col-md-10 col-lg-8">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="card-title text-center text-primary mb-4">O que você pode fazer por aqui:</h5>
                        <ul class="list-group list-group-flush mb-3">
                            <li class="list-group-item"><i class="bi bi-person-lines-fill text-danger me-2"></i> Acessar suas turmas e disciplinas</li>
                            <li class="list-group-item"><i class="bi bi-card-checklist text-danger me-2"></i> Consultar o seu desempenho e suas notas</li>
                            <li class="list-group-item"><i class="bi bi-book-fill text-danger me-2"></i> Estudar de forma autonoma</li>
                            <li class="list-group-item"><i class="bi bi-shield-lock-fill text-danger me-2"></i> Navegar com segurança e acesso restrito</li>
                        </ul>
                        <div class="alert alert-info text-center mt-3">
                            Em caso de dúvidas, entre em contato com o suporte da escola.
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php require_once('inc/rodape.php'); ?>
    </main>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
